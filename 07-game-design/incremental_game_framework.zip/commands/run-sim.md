---
name: run-sim
description: "Deprecated — use the incremental-game-framework:auto-tester skill instead"
---

This command is deprecated. Ask the agent to use the **incremental-game-framework** skill `auto-tester` instead.

Default when invoking the skill: `--runs 100 --max-ticks 50000` unless the user specifies otherwise.
