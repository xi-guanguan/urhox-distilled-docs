---
name: fix-balance
description: Diagnose and fix balance or gameplay in an existing incremental game. Invokes mid-game-balance-fix skill.
---

Use the **incremental-game-framework** skill `mid-game-balance-fix`.

Collect symptoms first. If no simulation report exists, invoke `auto-tester` before changing JSON.

Do not change more than one balance variable per iteration.
