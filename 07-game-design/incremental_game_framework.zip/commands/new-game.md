---
name: new-game
description: Start a new incremental game (M0-M8 headless-first workflow). Invokes the new-incremental-game skill.
---

Use the **incremental-game-framework** skill `new-incremental-game`.

Follow `GAME_DESIGN_GUIDE.md` §2 opening route:

1. New game vs fix existing (existing → `mid-game-balance-fix`).
2. Confirm project root (sibling repo, not inside the framework).
3. Pick a guidance path in plain language:
   - **A 一键托管** — ≈5 key questions; AI fills the rest; confirm only at M0 + M4
   - **B 方案体检** — developer pastes design; AI asks only about gaps/contradictions
   - **C 逐步问答** — full sequential M0–M8 Q&A

Do not dump the full Path C questionnaire if the user chose A or B.

Do not design or implement UI until **M7** simulation passes. For **M8**, follow `GAME_DESIGN_GUIDE.md` §5 M8 (structure-rebuildable `docs/ui-layout.md` + `ui/ui-layout.json` before skinning). Ask one question at a time.
