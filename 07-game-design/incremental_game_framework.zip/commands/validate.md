---
name: validate
description: "Deprecated — use the incremental-game-framework:quality-validator skill instead"
---

This command is deprecated. Ask the agent to use the **incremental-game-framework** skill `quality-validator` instead.

When available in the project workspace, run `pwsh scripts/run-all-checks.ps1`.
