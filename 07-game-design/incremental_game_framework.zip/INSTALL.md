# Claude Code Plugin — Incremental Game Framework

> Cursor 适配见 `.cursor-plugin/`（保持原样未动）。
> 本目录是 **Claude Code 适配**，文件位置 `.claude-plugin/`。

## 安装（本地 marketplace）

在 Claude Code 里执行：

```
/plugin marketplace add D:/Projects/Skills/incremental_game_framework
/plugin install incremental-game-framework@incremental-game-framework
```

然后**重启 Claude Code** 让 plugin 生效。

## 提供的命令（slash）

| 命令 | 作用 | 调用的 skill |
|------|------|--------------|
| `/new-game` | 启动 M0-M7 全流程，做一款新增量游戏 | `new-incremental-game` |
| `/fix-balance` | 诊断并修复运行中游戏的平衡/玩法问题 | `mid-game-balance-fix` |
| `/run-sim` | （已废弃）批量模拟 | `auto-tester` |
| `/validate` | （已废弃）自动化校验 | `quality-validator` |

## 提供的 skills（12 个，平铺在 `skills/`）

每个 skill 在 description 中标明触发条件，**proactive 使用**——它会主动建议。

| Skill | 触发 |
|-------|------|
| `using-incremental-framework` | 任何增量游戏问题 |
| `new-incremental-game` | 做新游戏 / 从零开始 / M0 |
| `game-designer` | 玩法设计 / 模式选择 |
| `data-architect` | 数据 DAG / JSON schema |
| `core-engineer` | headless 引擎 / tick / 入库 |
| `balance-mathematician` | 数值 / 公式 / 节奏调优 |
| `pattern-integrator` | Pattern R/S/T/B/D/E/P2… 选型 |
| `optional-integrator` | O1-O13 模块选型 |
| `case-consultant` | 8 个 case 的玩法参考 |
| `auto-tester` | headless 批量模拟 / `--runs 100` |
| `quality-validator` | 自动化校验 / schema 检查 |
| `mid-game-balance-fix` | 中途数值修复 / 反模式诊断 |

## 目录约定（Claude Code 视角）

```
.claude-plugin/
├── marketplace.json   # marketplace 注册（被 /plugin marketplace add 加载）
└── plugin.json        # plugin manifest（被 /plugin install 加载）
skills/                # 每个子目录 = 一个 skill，含 SKILL.md
commands/              # 每个 .md = 一个 slash command，含 frontmatter 的 name
```

## 与 Cursor 共存

`.cursor-plugin/` 目录未动，Cursor 用户仍走原路。Claude Code 加载 `.claude-plugin/`，互不影响。

## 校验

启动 Claude Code 后：

```
/plugin marketplace list   # 应能看到 incremental-game-framework
/plugin list               # 应能看到已启用插件
```

如果命令找不到 plugin：先确认路径用了**正斜杠**，且指向包含 `.claude-plugin/marketplace.json` 的根目录。