# Core 必读 MVP

> 任何使用本框架的项目都应从这 5 篇开始。
>
> **工程顺序**：先按 Core 实现 headless 引擎（M6），再跑批量模拟验证（M7），最后才做 UI（M8）。见 [docs/ai-first-workflow.md](../docs/ai-first-workflow.md)。

Core 文档定义了增量游戏的**最小可玩循环**：资源 → 产线 → 升级 → Reset → 永久。

---

## 阅读顺序

按编号顺序读，建立最小框架：

1. [02-resources.md](02-resources.md) — 资源分层、`add_resource`、`global_multiplier`
2. [03-production-lines.md](03-production-lines.md) — 5 种产线触发器（T1-T5）、局部链
3. [04-upgrade-economy.md](04-upgrade-economy.md) — 购买流程、6 种成本曲线（C1-C6）
4. [05-reset-systems.md](05-reset-systems.md) — Reset、Cap 模式（Cap-1/2/3）、XP 链
5. [06-permanent-upgrades.md](06-permanent-upgrades.md) — 永久商店、Pattern C 条件专精

> **关于 01 缺号**：Core 文档编号从 `02` 开始，**没有 `01`**。早期版本的 `01-game-loop.md`（游戏循环总览）已并入本 README，编号保留空位以避免打乱既有交叉引用。

---

## 核心抽象

| 抽象 | 文档 | 一句话定义 |
|------|------|----------|
| 资源 | [02](02-resources.md) | DAG 分层，全局加成在入库乘一次 |
| 产线 | [03](03-production-lines.md) | 触发器 T1-T5 × 局部乘法链 × 入库 |
| 升级 | [04](04-upgrade-economy.md) | 购买流程 × 成本曲线 C1-C6 |
| Reset | [05](05-reset-systems.md) | XP → 永久点 → 永久商店 |
| 永久 | [06](06-permanent-upgrades.md) | 线性/复合/Grant + Pattern C 条件专精 |

---

## 相关实战 Pattern

每个 Core 文档末尾会标注相关 Pattern（来自 [patterns/](../patterns/)）：

| Core | 触发 Pattern |
|------|------------|
| [02](02-resources.md) | [Pattern R](../patterns/pattern-r-rarity.md) |
| [03](03-production-lines.md) | [Pattern D](../patterns/pattern-d-dual-pool.md) |
| [04](04-upgrade-economy.md) | [Pattern S](../patterns/pattern-s-skill-tiers.md) + [Pattern B](../patterns/pattern-b-binary-unlock.md) |
| [05](05-reset-systems.md) | — |
| [06](06-permanent-upgrades.md) | [Pattern T](../patterns/pattern-t-tier-jump.md) |

---

## 反模式（跨 Core）

| 反模式 | 后果 |
|--------|------|
| 只有指数 sink、无 Reset/永久 | 硬顶流失 |
| 永久仅加法、成本纯指数 | 追不上曲线 |
| 全局加成在多处乘算 | 数值膨胀 |
| 资源全互通兑换 | 失去 DAG 优势 |