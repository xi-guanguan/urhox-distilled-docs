# 升级经济（Core）

## 购买流程

```text
purchase(id):
    cost = get_cost(id, level)
    if not can_afford(cost): return
    pay(cost)
    level += level_increment        # 默认 1
    emit purchased(id)
    if grants_resource:
        add_resource(type, amount, apply_global=false)
```

---

## 成本曲线族

至少实现 **C1 + C2**。

### C1 · 超指数 Hard Cap

逼 Reset；用于人口、核心单位数等必须在单 run 触顶的 sink。

```text
level == 1:  cost = c0
level >= 2:  cost = floor(A + B × level^(P + Q × level^R) × K)
```

调参：定「无永久时单 run 约 level N」→ 扫累计成本 → 反推系数。

### C2 · 指数 / 线性 Scaling

```text
if linear:  cost = base + k × level
else:       cost = base × r^level
```

可对多种资源分别配置 `(base, k/r)`。

### C3 · 一次性 Unlock

```text
max_level = 1
cost = { resource_a: va, resource_b: vb, … }   # 固定，不随 level 变
```

解锁机制、区域、产线。

### C4 · 多项式软 Cap

```text
cost = round(base × (1 + level^2))    # 或 level^1.5 等
max_level = 很高或 ∞
```

后期 sink；**不**单独替代 Reset。

### C5 · 树深度

```text
cost = node_depth × coeff    # 或 cost = depth
pay(tree_currency, cost)
node_level += 1               # ≤ max_level
```

科技树、天赋；常配合 O2 树货币。

### C6 · 查表 Gate

```json
{ "from": 2, "to": 3, "cost": { "primary": "…", "secondary": "…" } }
```

O1 章节进阶、剧情节点；无闭合公式时用 `constants.json`。

---

## Sink 配对

| Sink | 应对 |
|------|------|
| C1 | Reset + 线性/条件永久（06） |
| C2 | T2 自动化 + typed_bonuses（02） |
| O1 多资源 Gate | 副产线 + O5 |
| C5 / C6 + O2 | 副进度条 XP 链 |

配置：`upgrades.json`、`constants.json`

---

## 相关实战模式

- [Pattern S · 成长轴分档](../patterns/pattern-s-skill-tiers.md) — 核心 8+跳 10 / 次要 3-5 / 开关 1-2
- [Pattern B · 二进制开关](../patterns/pattern-b-binary-unlock.md) — 1-2 级机制解锁，无成长曲线