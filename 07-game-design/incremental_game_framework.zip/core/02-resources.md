# 资源与入库（Core）

## 资源分层

| 层级 | 特征 | 常见用途 |
|------|------|----------|
| **主货币** | 最早获得、消耗最频 | 早期升级、主要 sink |
| **中间资源** | 解锁自动化或分支 | 单位、雇员、产能槽 |
| **副产物** | 专供产线或 Gate | 材料、研究点、零件 |
| **Meta 点** | 章节或布局 | 槽位、建造点（O1） |
| **终局物** | 慢变量产出 | 结局、树货币（O2） |
| **协议类** | 可选 O8 | 派系、合同、声望 |

宜形成 **DAG**；避免全资源互通兑换。

## 统一入库

```text
add_resource(type, base_amount, apply_global=true):
    if base_amount <= 0: return
    amount = base_amount × (global_multiplier(type) if apply_global else 1)
    累加库存；触发 on_resource_added(type, amount)
```

- 产线只算 **局部产出**；**全局乘区只在此乘一次**
- 固定奖励（购买赠送、任务）→ `apply_global=false`
- `on_resource_added` 可驱动 Reset XP（05）、统计、任务

## global_multiplier

```text
global_multiplier(type):
    return typed_bonuses(type) × bottleneck_bonuses(type)
```

`bottleneck_bonuses` 默认恒为 1；启用 **O5** 见 [optional/o05-bottleneck-balance.md](../optional/o05-bottleneck-balance.md)。

### typed_bonuses

```text
typed_bonuses(type):
    perm  = Π 线性永久(type) × Π 复合永久(type)
    coll  = 1 + Σ 收藏品(type)          # 常来自 O8
    meta  = Π Meta 建筑/套装(type)
    return perm × coll × meta
```

## 购买授予资源

```text
on_upgrade_purchased:
    if upgrade.grants_resource:
        add_resource(type, amount, apply_global=false)
```

开局负债 → [optional/o08-support-systems.md](../optional/o08-support-systems.md)

---

## 相关实战模式

- [Pattern R · 概率叠加资源](../patterns/pattern-r-rarity.md) — 多档稀有度 + 跨种类 meta 倍率