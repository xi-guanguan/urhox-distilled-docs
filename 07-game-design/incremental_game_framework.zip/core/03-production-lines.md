# 产出产线（Core）

产线 = **触发方式** + **局部乘法链** + **入库**。全局乘区见 [02-resources.md](02-resources.md)。

## 局部乘法链

```text
local_output =
    base
  × Π 线性升级(1 + level × p/100)
  × Π 复合升级(1 + p/100)^level
  × Π 条件永久(06)
  × Π O8                         # 默认空，见 optional/o08-support-systems.md
  × cross_axis                   # 默认 1.0，见 optional/o04-cross-axis-feedback.md

add_resource(type, local_output)
```

---

## T1：离散输入

```text
local = base × click_upgrade_chain
add_resource(primary, local)
```

长按连发 → [optional/o09-interaction-qol.md](../optional/o09-interaction-qol.md)

## T2：定时脉冲

```text
every interval:
    local = unit_base × chains…
    add_resource(primary, local)
```

## T3：进度条

```text
progress += tick_rate × speed_multipliers
if progress >= threshold: reward × chains → add_resource(secondary, …)
```

## T4：采集

```text
local = gather_base × chains…
add_resource(material, local)
```

区域加速 → [optional/o06-area-focus.md](../optional/o06-area-focus.md)

## T5：放置乘算

不调用 `add_resource`；`placed_modifier(tag)` 乘入 T1–T4。公式见 [optional/o08-support-systems.md](../optional/o08-support-systems.md)。

---

## 对照

| 类型 | 触发 | sink | 产出 |
|------|------|------|------|
| T1 | 输入 | — | 主货币 |
| T2 | clock | 自动化升级 | 主货币 |
| T3 | delta | 槽位升级 | 副产物 |
| T4 | tick | 区域升级 | 材料 |
| T5 | 建造 | 放置成本 | 乘算 |
| O2 | XP | 时间 | 终局物 |

---

## 相关实战模式

- [Pattern D · 双资源池共享](../patterns/pattern-d-dual-pool.md) — 1 个限制资源同时挂多链路放大器