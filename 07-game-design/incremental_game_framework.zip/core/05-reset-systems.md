# Reset 系统（Core）

## 持久状态

```text
meta_level       # 累计 Reset 等级（账号级，Reset 通常不降低）
run_xp_buffer    # 本 run 经验缓冲
run_points       # 本 run 待分配永久点
```

## 经验与升级

```text
on_resource_added(primary, amount):      # 或自定义 XP 源
    gain_xp(amount × xp_rate)

gain_xp(incoming):
    xp = incoming
    while xp > 0:
        room = cap(meta_level) - run_xp_buffer
        if room <= 0:
            run_xp_buffer = 0
            meta_level += 1
            run_points += 1
            continue
        add = min(xp, room)
        run_xp_buffer += add
        xp -= add
        if run_xp_buffer >= cap(meta_level):
            run_xp_buffer = 0
            meta_level += 1
            run_points += 1
```

**XP 源 Pattern：** P-A 主资源入库 · P-B 任意资源产出 · P-C 里程碑（O1）

## Cap 模式

| 模式 | 形式 |
|------|------|
| Cap-1 | `base × growth^level` |
| Cap-2 | `base × mult(level) × growth^(level^exp(level))` |
| Cap-3 | 低等级查表 + 高等级公式 |

`mult(level)` 可阶梯查表；系数进 `constants.json`。

## 等级上限（可选）

```text
if meta_level >= max_meta_level:
    stop gaining XP on this track
```

常见语义：**终身封顶**（达到后该轨不再产 XP，靠 O2/O3 等继续）。

## Reset 时

```text
clear: run 资源、run 内 upgrade、run 内 tier（若 O1）
keep:  meta_level、已购永久项、账号 Meta
grant: run_points → 永久商店；automatic / grant 永久项
```

双轨 → [../optional/o07-dual-reset-track.md](../optional/o07-dual-reset-track.md)
节奏 → [../optional/o10-pacing-milestones.md](../optional/o10-pacing-milestones.md)

---

## 收益区间参考（按游戏规模）

> **来源**：[Shelldiver](../cases/shelldiver/README.md)（无 Reset）+ [Kittens Game](../cases/kittens-game/README.md)（9 时代 / Pattern P2）+ [Upload Labs](../cases/upload-labs/README.md)（Pattern PR / soft reset）+ [Tower Wizard](../cases/tower-wizard/README.md)（多层破墙终局）+ [Dwarf Eat Mountain](../cases/dwarf-eat-mountain/README.md)（102 个 prestige 升级）

按单局长度把游戏分三档，给出 **prestige currency 收益公式** 和 **永久项价格** 的参考区间。新游戏起步时锚定其中一档，再按 M7 试玩数据微调 ±0.5。

### 短游戏（单局 30 min - 2 hr）

| 项 | 典型值 | 来源 |
|---|---|---|
| 单次 reset 获得 `run_points` | `floor(total_resources / 1e6) × base_points` | Shelldiver 风格（实际无 reset，本行是建议锚点） |
| `run_points` 永久项价格 | `1 / 2 / 3 / 5 / 8`（线性档位） | — |
| 首次 reset 触发时间 | 30 - 90 min（M3） | [optional/o10 § Phase 3](../optional/o10-pacing-milestones.md) |
| 永久项总档位 | 8 - 15 个 | — |
| Reset 收益可见性 | "立即 +5-15% 全局产出" | — |

### 中型游戏（单局 4 - 12 hr）

| 项 | 典型值 | 来源 |
|---|---|---|
| 单次 reset 获得 `paragon` | `floor(total_xp / 1e9)^0.5 × cap` | Upload Labs paragon 公式简化 |
| `paragon` 永久项价格 | `base × ratio^level` (ratio 1.5 - 2.0) | — |
| 首次 reset 触发时间 | 2 - 4 hr | KG 实证：玩家平均 2-3 hr 到首次 reset |
| 永久项总档位 | 15 - 40 个 | KG 实证 37 perk；Upload Labs 18 perk |
| Reset 收益可见性 | "立即 +10-30% 主货币产出 + 解锁 1-2 个新产线" | — |

### 超长游戏（单局 50+ hr / 多次 reset）

| 项 | 典型值 | 来源 |
|---|---|---|
| 双 prestige currency（短期 + 长期） | Pattern P2（KG `paragon` + `burnedParagon`） | [pattern-p2-dual-prestige.md](../patterns/pattern-p2-dual-prestige.md) |
| 短期 currency cap | `min(value × 0.01 × ratio, 2 × ratio)` | KG `getParagonProductionRatio` line 501 |
| 长期 currency cap | `min(value × 0.01 × ratio, 4 × ratio)` (dark future) | KG 同上（dark future 加速） |
| 永久项总档位 | 50 - 150 个 | DEM 实证 102 prestige 升级 |
| Reset 次数 | 8 - 30 次（每次开新 tier / 新 currency） | KG 9 个时代 + DEM 6 终局山 |
| Reset 收益可见性 | "短期 +X% 立即生效 + 长期 累计到 dark future 时 ×4 爆发" | — |

**核心原则**：单次 reset 收益应 **立即可见**（玩家感到"这次 reset 有意义"），但不应 **大到破坏下次 run 的节奏**（否则玩家跳过产线直奔 reset）。通常经验值是 +5% 到 +30% 主货币产出。

---

## Reset 时间间隔参考（节奏自检）

> **来源**：7 个 case 的 `progression` 字段 + GAME_DESIGN_GUIDE.md 附录 C 反模式「首次 reset 时间 < 5min 或 > 2 hr」。

**必测指标**（M7 alpha 测时记录）：

| Reset 序号 | 期望时长（短游戏） | 期望时长（中型） | 期望时长（超长） | 说明 |
|---|---|---|---|---|
| Reset #1 | 30 - 60 min | 2 - 4 hr | 4 - 8 hr | M3 首次 reset，建立 attachment 关键点 |
| Reset #2 | 20 - 40 min | 1.5 - 3 hr | 3 - 6 hr | 比 #1 短（熟悉机制） |
| Reset #3-5 | 15 - 30 min | 1 - 2 hr | 2 - 4 hr | 进入节奏循环 |
| Reset #6+ | 10 - 20 min | 30 min - 1 hr | 1 - 3 hr | 后期循环 |
| Dark Future / 终局循环 | — | — | 5 - 15 min | KG dark-future 加速 prestige |

**反模式**：

| 反模式 | 后果 |
|---|---|
| Reset #1 < 5 min | 玩家没建立 attachment，觉得 reset 廉价 |
| Reset #1 > 4 hr（中型）/ > 8 hr（超长） | 玩家挫败，单 session 内看不到 reset |
| Reset 间隔恒定 | 失去节奏感，玩家机械化循环 |
| Reset 后无立即可见 buff | 玩家怀疑 reset 价值，不愿 reset |
| Reset 后主货币产出 +100%+ | 破坏下次 run 节奏，玩家跳过产线直奔 reset |

**调试方法**：

```text
# log "reset_triggered" timestamp + "first_buff_applied" timestamp
# 测 5-10 个玩家：
#   - reset #1 时间分布（应在期望范围内）
#   - reset #1 → reset #2 间隔（应比 #1 短）
#   - reset 后第一次"感受到 buff"的延迟（应 < 30s）
```

---

## 多 Currency 形态参考（Pattern P2 扩展）

> **来源**：[Kittens Game](../cases/kittens-game/README.md) § 8（`paragon` + `burnedParagon` 双 cap）+ [cases/dwarf-eat-mountain/README.md § prestige](../cases/dwarf-eat-mountain/README.md)（102 个 prestige 升级 + 跨 run 累积）+ [cases/agrivore/README.md § sins](../cases/agrivore/README.md)（7 sins 是 7 种"罪孽 currency"，每种独立 cap）。

### 形态 A：双 currency（Pattern P2 实证）

```text
short_term = paragon                 # 单局
long_term  = burnedParagon            # 跨局（部分转换）
```

- 公式独立（KG 实证）
- 永久项分两个 shop（不能混）
- 转换规则显式（`conversion_cap = paragon × 0.05 + burnedParagon × 0.1 + cycleYear × 0.1`）

### 形态 B：多 currency 池（DEM 实证）

```text
prestige_currency_a  # 主 prestige，消耗型
prestige_currency_b  # 跨 run 累积，永久
prestige_currency_c  # 终局 currency，最后才用
```

- 每种 currency 有独立 cap
- currency_a → currency_b 显式转换（每次 reset）
- currency_b → currency_c 在 dark-future / 终局 trigger 显式转换

### 形态 C：N 货币平行（Agrivore sins 实证）

```text
sin_1 = pride        # 每个 sin 独立 currency
sin_2 = greed
...
sin_7 = sloth

# 共用 cap（sum ≤ cap），各自累计
```

- 7 个 currency 共享一个 cap（玩家必须选哪个 sin 先刷）
- 每个 sin 独立消耗（升级特定 sigil 树）
- 共用 cap 强制策略选择

### 设计规则

| 规则 | 说明 |
|---|---|
| currency 数 ≤ 3 | 多于 3 种玩家决策疲劳（KG / DEM 实证） |
| currency 间转换显式 | 隐式转换让玩家无法规划（Pattern P2 反模式） |
| 每种 currency 独立 cap | 共享 cap 会让短期 currency 刷爆 → 长期 currency 失效 |
| 永久项按 currency 分 shop | 混 shop 导致"用短期 currency 买长期 currency 才能买的项" |

详见 [pattern-p2-dual-prestige.md](../patterns/pattern-p2-dual-prestige.md) 双 currency 完整设计。
