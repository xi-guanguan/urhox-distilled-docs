# 永久加成商店（Core）

Reset 后消耗 **永久点** 购买的账号级乘区。

## 数据结构

```text
id, max_level, point_cost, point_requirement, automatic, effect_fields…
points_spent = Σ (level × point_cost)
points_available = run_points + carried_unspent
```

## 加成类型

| 类型 | 公式 | 用途 |
|------|------|------|
| 线性 | `1 + level × p/100` | 稳定全局 |
| 复合 | `(1 + p/100)^level` | 后期爆发 |
| 自动 | automatic=true | 开局/Reset 生效 |
| Grant | set_level / set_resource | 跳过早期 grind |
| 购买增量 | 指定 upgrade 购买时 level += N | 加速自动化 |

Tooltip 复合显示：`((1+p/100)^level - 1) × 100`（百分点）

---

## Pattern C：条件专精

奖励专精 build；**择一或组合**，非必须全套。乘入 [03-production-lines.md](03-production-lines.md) 局部链。

### C-a · 最高级产线

```text
if target != highest_level_production_upgrade:
    return 1.0
return 1 + p/100 × level
```

维护「生产类 upgrade」列表。

### C-b · 等级阈值

```text
if level == 0 or target.level < threshold:
    return 1.0
return 1 + p/100 × level
```

### C-c · 窄 build

```text
if narrow.level == 0 or broad_a.level > 1 or broad_b.level > 1:
    return 1.0
return 1 + p/100 × level
```

### C-d · Tag / 流派

```text
if upgrade.tags ∩ required_tags == ∅:
    return 1.0
return 1 + p/100 × level
```

多个条件永久项默认 **相乘**。

---

## Optional 扩展（非 Core）

| 代号 | 内容 |
|------|------|
| O4 | 跨轴 `cross_axis` → [optional/o04-cross-axis-feedback.md](../optional/o04-cross-axis-feedback.md) |
| O5 | 瓶颈平衡 → [optional/o05-bottleneck-balance.md](../optional/o05-bottleneck-balance.md) |
| O6 | 区域焦点 → [optional/o06-area-focus.md](../optional/o06-area-focus.md) |
| O1 | Grant 与 tier → [optional/o01-chapter-gates.md](../optional/o01-chapter-gates.md) |
| O9 | 等级跳跃 UX → [optional/o09-interaction-qol.md](../optional/o09-interaction-qol.md) |

配置：`permanent_upgrades.json`（名称自定）、`upgrade_tiers.json`（含跳跃等级表）

---

## 相关实战模式

- [Pattern T · 等级跳跃](../patterns/pattern-t-tier-jump.md) — 核心轴跳 9→10 的质变点设计