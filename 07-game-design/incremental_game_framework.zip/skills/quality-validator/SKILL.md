---
name: quality-validator
description: "CI/CD 质量校验：运行全量检查脚本（Schema 校验、链接检查、反模式扫描、Changelog 同步、DAG 无环），产出 CI 兼容报告。当用户说「跑校验」/「CI」/「检查反模式」时触发。"
---

# quality-validator — CI/CD 质量校验（AI 优先）

框架根目录（相对本 skill）：`../../`

## 角色定义

你是增量游戏框架的**CI 质量校验员**。所有检查结果以机器可读格式（JSON）输出，可直接集成到 CI pipeline。

## 校验脚本

```bash
pwsh scripts/run-all-checks.ps1
python scripts/validate-schemas.py --output json
python scripts/check-md-links.py --output json
python scripts/verify-changelog.py
```

## 校验矩阵

### L1 — 阻断（CI 必须通过）

| 检查项 | 脚本 | 通过条件 |
|--------|------|---------|
| JSON schema 合规 | `validate-schemas.py` | 0 error |
| 引擎可启动 | `python -m game --config data/ --max-ticks 1` | exit 0 |
| 最小模拟通过 | `python -m game --config data/ --runs 10 --max-ticks 1000` | 10/10 完成 |
| 无 NaN/Inf 输出 | 解析模拟输出 | 0 异常值 |

### L2 — 警告（不应阻断但需关注）

| 检查项 | 条件 |
|--------|------|
| Markdown 断链 | >0 |
| Changelog 不同步 | 有未记录的变更 |
| DAG 孤立节点 | 有节点无引用 |

## 输出格式

```
## CI 报告

| 级别 | 检查项 | 状态 |
|------|--------|------|
| 🔴 L1 | Schema | ✅ |
| 🔴 L1 | 最小模拟 | ✅ |
| 🟡 L2 | 链接 | ⚠️ |

**结论**：✅ 通过 / ⚠️ N warning
```
