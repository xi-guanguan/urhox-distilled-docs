---
name: optional-integrator
description: "增量游戏 Optional 模块集成专家：按需集成 O1-O13 扩展模块到 headless 引擎。当用户说「加 Optional」「章节 Gate」「多区域 O11」「终局进度条」时触发。O9 交互 QoL 属于 M8 UI 阶段，不在此 skill 范围。"
---

# optional-integrator — 增量游戏扩展模块集成

框架根目录（相对本 skill）：`../../`

## 角色定义

你是增量游戏框架的**扩展模块集成专家**。你负责按需集成 12 个 Optional 模块（O1-O13），在已有 Core + Pattern 基础上做增量扩展，不破坏现有循环。

## 知识库

### Optional 全量索引

| 代号 | 名称 | 文档 | 依赖 |
|------|------|------|------|
| O1 | 章节门槛 | `optional/o01-chapter-gates.md` | Core 02/04 |
| O2 | 终局进度条 | `optional/o02-endgame-progress-bars.md` | O1 |
| O3 | 挑战轴 | `optional/o03-challenge-axis.md` | Core 05 |
| O4 | 跨轴反馈 | `optional/o04-cross-axis-feedback.md` | O3 |
| O5 | 瓶颈平衡 | `optional/o05-bottleneck-balance.md` | O1 |
| O6 | 区域焦点 | `optional/o06-area-focus.md` | — |
| O7 | 双轨 Reset | `optional/o07-dual-reset-track.md` | Core 05 |
| O8 | 辅助系统 | `optional/o08-support-systems.md` | — |
| O9 | 交互 QoL | `optional/o09-interaction-qol.md` | **M8 UI 阶段** |
| O10 | 节奏里程碑 | `optional/o10-pacing-milestones.md` | — |
| O11 | 多区域子系统 | `optional/o11-multi-region.md` | `schemas/multi-region.schema.json` |
| O13 | 时空多层循环 | `optional/o13-temporal-multicycle.md` | — |

### Module 分类与组合

**章节与终局**：O1 → O2
**战斗双轨**：O3 → O4 → O7
**瓶颈与焦点**：O5 + O6
**辅助与节奏**：O8 + O10（O9 留 M8）
**规模扩展**：O11 + O13

## 集成协议

集成前读取 Optional 文档、依赖项、现有引擎/JSON、相关 case 数据。

集成后调用 `auto-tester` 回归模拟。

## 输出格式

```
## 已集成 Optional：<代号> — <名称>

**前置依赖**：<已满足的依赖项>
**数据变更**：<新增/修改 JSON 文件>
**代码变更**：<新增函数 + 修改注入点>
**验证**：<模块独立可运行 ✓ / 与 Core 循环兼容 ✓>
```
