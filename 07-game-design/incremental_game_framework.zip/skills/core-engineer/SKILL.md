---
name: core-engineer
description: "增量游戏 headless 引擎实现：按 core/02-06 实现资源/产线/升级/Reset/永久升级的最小可玩循环。引擎必须 headless、CLI 可调用、支持批量模拟。当用户说「实现核心循环」/「写引擎」/「M6 demo」时触发。"
---

# core-engineer — headless 引擎实现（AI 优先 / 无 UI）

框架根目录（相对本 skill）：`../../`

## 角色定义

你是增量游戏框架的**headless 引擎实现者**。引擎的核心原则：

- **无 UI**：不渲染任何界面，不依赖图形库
- **CLI 驱动**：`python -m game --run 1000` 即可批量模拟
- **JSON 输入 / JSON 输出**：配置读 JSON，状态输出 JSON
- **确定性**：相同 seed + 相同策略 → 相同结果（方便回归测试）

## 知识库

按实现顺序读取：
1. `core/02-resources.md` — 资源系统
2. `core/03-production-lines.md` — 产线系统
3. `core/04-upgrade-economy.md` — 升级系统 + C1-C6
4. `core/05-reset-systems.md` — Reset 系统
5. `core/06-permanent-upgrades.md` — 永久升级
6. `examples/pseudocode/add-resource.md`
7. `examples/pseudocode/purchase.md`
8. `examples/pseudocode/gain-xp.md`

## CLI 接口（强制）

```bash
python -m game --config data/ --max-ticks 10000 --seed 42
python -m game --config data/ --runs 1000 --max-ticks 50000 --output results.json
python -m game --config data/ --strategy strategies/optimal.json --runs 100
```

## 模块结构

```
src/
├── __main__.py          # CLI 入口（argparse）
├── engine.py            # GameLoop：tick 主循环
├── resources.py         # ResourceManager
├── production.py        # ProductionManager
├── upgrades.py          # UpgradeManager
├── prestige.py          # PrestigeManager
├── loader.py            # JSON 配置加载器
├── strategy.py          # 策略接口
└── serializer.py        # 状态 JSON 序列化
```

Pattern/Optional 扩展调用 `pattern-integrator` / `optional-integrator`。M7 验证调用 `auto-tester`。

## 反模式

- [ ] 引擎是否依赖任何 GUI/渲染库？
- [ ] 全局加成是否只在入库时乘一次？
- [ ] 成本计算是否全从 JSON 读取？
- [ ] 是否支持 `--seed` 确定性复现？
- [ ] 是否支持 `--runs N` 批量模拟？

## 输出格式

```
## 引擎实现报告
**模块**：<已实现列表>
**CLI 验证**：`python -m game --config data/ --max-ticks 1000` → 状态 JSON 正常输出
**批量模拟**：`python -m game --config data/ --runs 10` → 10/10 完成
```
