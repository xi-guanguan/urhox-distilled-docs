---
name: using-incremental-framework
description: Bootstrap skill for the incremental game framework. Use when starting any incremental/idle game task, when unsure which skill applies, or when the user mentions the framework, M0-M8, headless engine, batch simulation, or UI layout after M7.
---

# Using Incremental Game Framework

## Core philosophy

**JSON → headless engine → batch simulation → tune numbers → UI design last (M8)**

M0-M7 do **not** include rendering. Balance is validated by automated simulation, not subjective playtesting. **M8** = structure-rebuildable UI design (`docs/ui-layout.md` + `ui/ui-layout.json`) then optional skinning — see `GAME_DESIGN_GUIDE.md` §5 M8.

**Guidance paths** (pick at start of a new game — see `GAME_DESIGN_GUIDE.md` §2): **A 一键托管** (≈5 questions) · **B 方案体检** (review existing design) · **C 逐步问答** (full M0–M8 Q&A).

## Framework path resolution

Skills live in `skills/<name>/SKILL.md` at repo root (same layout as Superpowers). Framework docs are one level up from `skills/`:

| From any skill | Path to framework root |
|----------------|------------------------|
| Relative | `../../` |

| Key doc | Path |
|---------|------|
| Design guide (incl. **M8 UI design**) | `../../GAME_DESIGN_GUIDE.md` |
| AI-first workflow | `../../docs/ai-first-workflow.md` |
| UI DoD (附录 C) | `../../docs/case-to-framework-contribute.md` |
| Numerical design | `../../docs/numerical-design.md` |
| Core modules | `../../core/` |
| Patterns | `../../patterns/` |
| Cases | `../../cases/` |
| Schemas | `../../schemas/` |

**Separate game project**: set `FRAMEWORK_ROOT` (clone path or env) and read `{FRAMEWORK_ROOT}/GAME_DESIGN_GUIDE.md`.

## Skill groups (logical, not separate plugins)

| Group | Skills |
|-------|--------|
| **design** | `using-incremental-framework`, `new-incremental-game`, `game-designer`, `case-consultant` |
| **data** | `data-architect`, `balance-mathematician` |
| **engine** | `core-engineer`, `pattern-integrator`, `optional-integrator` |
| **validation** | `auto-tester`, `quality-validator`, `mid-game-balance-fix` |

## Skill routing

**Invoke the matching skill before implementing.**

| User intent | Skill |
|-------------|-------|
| New game from scratch | `new-incremental-game` |
| Existing game feels wrong (diagnose first) | `mid-game-balance-fix` |
| Have simulation report, tune one JSON knob | `balance-mathematician` |
| M0-M4 design docs (DAG, timeline, Pattern) | `game-designer` |
| Pick reference case (M1) | `case-consultant` |
| Fill JSON / schema (M5) | `data-architect` |
| Implement headless engine (M6) | `core-engineer` |
| Integrate Pattern | `pattern-integrator` |
| Integrate Optional (O1-O13; O9 **engine** wiring only after M7) | `optional-integrator` |
| Batch simulation (M7) | `auto-tester` |
| CI / schema / link checks | `quality-validator` |
| **M8 界面设计 / ui-layout / HUD 线框**（M7 已通过） | `new-incremental-game` → 读 `GAME_DESIGN_GUIDE.md` §5 M8（无单独 UI skill） |
| 一键托管 / 方案体检 / 逐步问答 | `new-incremental-game` → `GAME_DESIGN_GUIDE.md` §2–§4 |

## Mandatory rules

1. Invoke the matching **skill** before any response or action when intent matches.
2. One JSON variable change per balance iteration → changelog → re-run simulation.
3. Same seed + same strategy → same result (deterministic engine).
4. Never embed business logic in UI (M8 only after M7 passes; design docs before skinning).

## Red flags

- Implementing balance changes without reading `auto-tester` or simulation data first
- Designing or implementing UI during M0-M7
- Skipping structure-rebuildable docs and jumping straight to art in M8
- Changing multiple JSON knobs in one balance iteration
