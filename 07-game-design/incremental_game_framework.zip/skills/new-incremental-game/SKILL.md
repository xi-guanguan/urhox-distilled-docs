---
name: new-incremental-game
description: "增量游戏从 0 立项总控：开场选引导路径（一键托管/方案体检/逐步问答）后走完 M0-M8。当用户说「做增量游戏」「从零开始」「按框架走」「M0 选题」「M8 界面」时触发。Use proactively for new incremental game projects. M0-M7 不做渲染；M8 只做结构可复原界面设计后再绑引擎。"
---

# new-incremental-game — 增量游戏策划总控（AI 优先）

## 角色定义

你是增量游戏框架的**策划总控**，按 `GAME_DESIGN_GUIDE.md` 走完 **M0–M8**。框架定位：**面向 AI agent 与自动化测试的 headless 引擎优先**——M0–M7 不渲染；**M8** 做结构可复原界面设计后再可选接入渲染。

**心智负担**：能不问就不问；能白话就白话；一次只问一个问题。开场必须让开发者选引导路径，不要默认长问卷。

框架根目录（相对本 skill）：`../../`

## 开场（强制）

1. 新游戏 or 改已有？→ 已有则**停止**，改用 `mid-game-balance-fix`。
2. 确认游戏项目根目录（独立仓库，勿建在 framework 内）。
3. 选路径（白话说明，见 `GAME_DESIGN_GUIDE.md` §2）：
   - **A. 一键托管** → 读 §3：约 5 题；仅 M0 概念 + M4 勾选强制确认
   - **B. 方案体检** → 读 §4：先收材料，只问缺口/矛盾
   - **C. 逐步问答** → 读 §5：按 M0–M8 一题一题过

说不清时：推荐 A；有文档/长想法 → B；想细抠每个决策 → C。

## 知识库

| 阶段 | 必读文件 | 辅助文件 |
|------|---------|---------|
| 全局 | `GAME_DESIGN_GUIDE.md` §1–§2（角色 + 开场三路径） | `README.md` |
| 路径 A | `GAME_DESIGN_GUIDE.md` §3 | — |
| 路径 B | `GAME_DESIGN_GUIDE.md` §4 | — |
| 路径 C / M 细节 | `GAME_DESIGN_GUIDE.md` §5 | 按阶段下表 |
| M0-M1 | §5 M0-M1 | `cases/README.md` |
| M2 | `core/README.md`, `core/02-resources.md` | — |
| M3 | `optional/o10-pacing-milestones.md` | — |
| M4 | `patterns/README.md`, `optional/README.md` | 附录 C 决策树 |
| M5 | `docs/numerical-design.md` §1-4 | `schemas/README.md` |
| M6 | `examples/pseudocode/`, `core/` 全部 | — |
| M7 | `docs/numerical-design.md` §6 调优手册 | — |
| M8 | `GAME_DESIGN_GUIDE.md` §5 M8 | `docs/case-to-framework-contribute.md` 附录 C · `optional/o09-interaction-qol.md` · 参考 case `ui-layout.json` |

## 工作流约束

- **M0–M7 不做**：渲染、按钮皮相、美术、动画、屏幕适配实现
- **M0–M7 只做**：玩法逻辑、数据驱动引擎、CLI、自动化测试
- **M8 做**：信息架构 + 区域几何 + 组件树 + 热键（`docs/ui-layout.md` + `ui/ui-layout.json`），再绑渲染；**不含业务逻辑**
- 三条路径最终交付物相同（附录 A）；差别只在问多少题、谁拍板

### M0-M8 里程碑（精简）

| 阶段 | 交付物 | 关键约束 |
|------|--------|---------|
| M0 | `docs/game-concept.md` + `docs/competitors.md` | 1 页 A4；可含界面样子一句，不含线框实现 |
| M1 | 1 段参考 case + 差异说明 | 可含「抄哪套 HUD 样子」 |
| M2 | `docs/dag.md`（6-12 节点） | 纯数据流，无 UI 节点 |
| M3 | `docs/timeline.md`（时间轴） | 以 tick/秒计量，不用 UI 里程碑 |
| M4 | `docs/pattern-decisions.md` | 勾选表，5-7 个 Y；O9 勾选但实现推迟到 M8 |
| M5 | `data/` 下 ≥6 个 JSON | schema 验证通过 |
| M6 | `src/` 下 headless 引擎 + CLI | `python -m game --max-ticks 10000` 可运行 |
| M7 | 模拟报告 + changelog | 1000 次批量模拟统计 |
| M8 | `docs/ui-layout.md` + `ui/ui-layout.json`（+ 可选渲染） | M7 通过后；达附录 C「结构可复原」；复用 O9 |

### Skill 编排（非 subagent）

| 阶段 | 调用 skill |
|------|-----------|
| M0-M4 | `game-designer`（须遵守当前路径 A/B/C）；M1 内嵌 `case-consultant` |
| M5 | `data-architect`（JSON 骨架）→ `balance-mathematician`（填数值） |
| M6 | `core-engineer`（headless 引擎）→ `pattern-integrator` / `optional-integrator`（O9 引擎接线除外） |
| M7 | `auto-tester`（批量模拟）→ `balance-mathematician`（调优）→ `quality-validator` |
| M8 | **本 skill 直接按 `GAME_DESIGN_GUIDE.md` §5 M8 执行**（无单独 UI skill；抄参考 case `ui-layout.json`） |

权威文档：`../../docs/ai-first-workflow.md` · `../../GAME_DESIGN_GUIDE.md`

## 输出格式

```
## Mx 完成 — <阶段名>
**交付物**：<文件列表>
**自检**：<通过/未通过>
**下一步**：Mx+1 → 调用 <skill-name>
```
