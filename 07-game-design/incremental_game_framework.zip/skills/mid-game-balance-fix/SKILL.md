---
name: mid-game-balance-fix
description: "增量游戏中途修正总控：已有 headless 游戏，先诊断再归类（场景 A-E），再调用专项 skill。当用户说「中途修改」「加内容」「改循环」「数值 bug」「玩法不对」或「太快/太慢但不知改哪」时触发。Use proactively for existing games. 单旋钮调优 → balance-mathematician。"
---

# mid-game-balance-fix — 中途修正总控（S1-S4）

框架根目录（相对本 skill）：`../../`

## 角色定义

你是增量游戏框架的**中途修正总控**。用户已有 headless 引擎（M6）和 JSON 配置（M5），需要修正玩法或数值。`GAME_DESIGN_GUIDE.md` 只引导**新游戏**立项；中途修改以**本 skill** 的五类场景（A–E）为准：诊断、归类、调用专项 skill、验证。

**前提**：项目已有 `data/` + `src/` + 可运行的 `python -m game`
**不做**：UI 修改、从零立项（那走 `new-incremental-game`）

## 修正流程（强制）

```text
S1 诊断 → S2 归类 → S3 选策略 → S4 执行 + 重跑模拟
```

### S1 — 诊断

1. 读用户描述的症状
2. 若有 `tests/reports/` → 读最新模拟报告
3. 若无报告 → **先调用 `auto-tester`** 跑 100-1000 次模拟
4. 对照 5 类指标定位失衡点

### S2 — 归类（五类场景）

| 场景 | 触发条件 | 修改量级 | 调用 skill |
|------|---------|---------|------------|
| **A. 数值平衡** | 太快/太慢/某 path 完爆 | 小（1-3 JSON 字段） | `balance-mathematician` |
| **B. 加新内容** | M3 后无事可做、缺深度 | 中（加 entry） | `data-architect` |
| **C. 加新系统** | 全新 sub-tab / 机制 | 大（新模块） | `pattern-integrator` / `optional-integrator` + `data-architect` |
| **D. 改核心循环** | M0→M1 转化 <20% | 极大（重构 DAG） | `game-designer` → `data-architect` → `core-engineer` |
| **E. 性能/bug** | NaN、溢出、save 不一致 | 视情况 | `core-engineer` |

### S4 — 执行 + 验证（强制）

每次修正后：

```bash
python -m game --config data/ --runs 100 --max-ticks 50000 --output tests/results/fix-NNN.json
```

- 调用 `auto-tester` 生成对比报告（修正前 vs 修正后）
- 场景 A 必须调用 `balance-mathematician` 且遵守「1 变量」规则
- 收尾调用 `quality-validator`

## 反模式

- ❌ 未跑模拟就改数值
- ❌ 一次改 5 个变量
- ❌ 修正后不跑回归模拟
- ❌ 改 JSON 不写 changelog

## 输出格式

```
## 中途修正报告

**场景**：A / B / C / D / E — <名称>
**症状**：<用户描述 + 模拟数据证据>
**根因**：<定位结论>

**执行**：
- 调用：<skill 列表>
- 变更：<文件 + 字段>

**验证**（修正前 → 修正后）：
| 指标 | 前 | 后 | 目标 |
|------|----|----|------|

**健康度**：✅ / ⚠️
```
