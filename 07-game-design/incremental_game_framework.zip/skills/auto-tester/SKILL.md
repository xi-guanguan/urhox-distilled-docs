---
name: auto-tester
description: "增量游戏自动化测试与批量模拟：运行 N 次 headless 模拟，输出统计数据、平衡性报告、异常检测。当用户说「跑模拟」/「批量测试」/「1000 次」/「自动化测试」/「统计报告」等时触发。"
---

# auto-tester — 自动化测试与批量模拟（AI 优先 / 无 UI）

框架根目录（相对本 skill）：`../../`

## 角色定义

你是增量游戏框架的**自动化测试引擎**。你负责批量运行 headless 模拟、产出统计报告、检测异常。你不做任何 UI 测试，只做数据驱动验证。

## 测试矩阵

### 必跑测试集

| 测试类 | 命令 | 目标 |
|--------|------|------|
| 吞吐测试 | `--runs 1000 --max-ticks 10000` | 引擎不崩溃，100% 完成率 |
| 平衡性测试 | `--runs 100 --max-ticks 50000 --strategy greedy` | 无 build path 完爆其他 |
| 边界测试 | `--max-ticks 1` / `--max-ticks 1000000` | 极短/极长 run 不溢出 |
| 确定性测试 | `--runs 10 --seed 42` | 同 seed 同结果 |
| 策略对比 | 多策略各 100 次 | 贪心 vs 均衡 vs 随机 |

### 5 类核心指标

| 指标 | 统计方式 | 健康范围 |
|------|---------|---------|
| 首次 reset tick | P50/P90/P99 | 300-7200 ticks（5min-2hr @ 60tick/s） |
| 资源利用率 | 各 currency max_value 命中率 | 限制资源应当 ≥50% |
| build path 分布 | 各 upgrade 最终 level 分布 | 无单一升级占 >80% |
| reset 频率 | 每 N tick reset 一次 | 曲线平滑，无突变 |
| 永久点累积 | 1000 次 run 后的分布 | P90 应在设计目标 ±20% |

## 批量模拟入口

```bash
python -m game --config data/ --runs 1000 --max-ticks 50000 --output results.json
python scripts/analyze_results.py results.json --output report.md
```

## 异常检测规则

| 检测项 | 条件 | 严重度 |
|--------|------|--------|
| 数值溢出 | `currency > 1e308` 或 `NaN/Inf` | 🔴 阻断 |
| 零产出 | 所有产线 output=0 持续 >1000 tick | 🔴 阻断 |
| 资源泄漏 | reset 后 run 状态未完全清空 | 🔴 阻断 |

失衡指标交给 `balance-mathematician` 调优；CI 收尾调用 `quality-validator`。

## 输出格式

```
## 批量模拟报告

**参数**：runs=1000, max_ticks=50000, strategy=greedy

### 首次 Reset
| 指标 | tick |
|------|------|
| P50 | |
| P90 | |

**健康度**：✅ 通过 / ⚠️ N 项待修复
```
