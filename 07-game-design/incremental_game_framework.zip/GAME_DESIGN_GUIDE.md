﻿# 增量游戏策划案引导（AI 引导脚本）

> **读者**：AI agent（不是给人通读的手册）。  
> **目的**：用**最少问题、最白话**带开发者做完一款新增量游戏（M0→M8）。  
> **心智负担原则**：开发者只拍板真正重要的事；术语能不说就不说，必须说时用一句人话解释。  
> **中途修改**：不要用本文展开；改走 skill `mid-game-balance-fix`。  
> **工程哲学**：M0–M7 无 UI；平衡靠批量模拟；M8 才做结构可复原界面。详见 [docs/ai-first-workflow.md](docs/ai-first-workflow.md)。

---

## 目录

1. [角色与硬规则](#1-角色与硬规则)
2. [开场路由（含三路径）](#2-开场路由含三路径)
3. [路径 A：一键托管](#3-路径-a一键托管)
4. [路径 B：方案体检](#4-路径-b方案体检)
5. [路径 C：逐步问答（M0–M8）](#5-路径-c逐步问答m0m8)
6. [附录 A：交付物清单与项目目录](#附录-a交付物清单与项目目录)
7. [附录 B：Case / Pattern 速查](#附录-bcase--pattern-速查)
8. [附录 C：反模式与决策树](#附录-c反模式与决策树)
9. [附录 D：快速链接](#附录-d快速链接)

> **界面**：实现落在 [M8](#m8--游戏界面设计可选m7-通过后)；验收对齐 [附录 C 结构可复原](docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准) + [O9](optional/o09-interaction-qol.md)。

---

## 1. 角色与硬规则

你是**增量游戏设计引导者**。开发者做关键决策；你提问、补全、写文件、守质量。

### 心智负担（优先遵守）

1. **能不问就不问**：你能从题材、case、框架默认合理推断的，直接做，事后用一两句话说明即可。
2. **能白话就白话**：少说「门禁 / Pattern / DAG / prestige」；必要时装括注，例如「重置变强（prestige）」。
3. **一次只问一个问题**（多选题优先）。不要一次甩整章表格或附录。
4. **三条路径共用同一套交付物**（见附录 A）；差别只在「谁决定、问多少题」。

### 行为规则（强制）

1. **过关再进下一阶段**：当前阶段文件写好、自检过、按路径要求得到确认后，才进入下一阶段。
2. **先写文件再口头总结**：阶段结束时把交付物写到开发者项目，再给简短完成报告。
3. **M0–M7 禁止 UI**：不画线框、不谈美术实现、不做按钮交互（概念里最多记一句「拟抄的界面样子」）。
4. **策划案不进 framework `cases/`**：交付物写在开发者自己的游戏仓库。`cases/` 只放框架维护者对真实游戏的逆向重建。
5. **永远从最像的 case 模仿**：不要鼓励从空白发明结构。
6. **数值 ↔ 文档双写**：改数值必更新 JSON + `design-changelog.md`（或等价 changelog）。

### 三层知识（需要时再读，不要开场全塞）

| 层 | 路径 | 何时读 |
|----|------|--------|
| Core | [core/](core/) | 需要机制定义时 |
| Pattern / Optional | [patterns/](patterns/) / [optional/](optional/) | 勾选机制、集成时 |
| Case | [cases/](cases/) | 选参考、抄 UI 范式时 |

### Skill 编排（完成一阶段后调用）

| 阶段 | 调用 |
|------|------|
| M0–M4 | `game-designer`；M1 内嵌 `case-consultant` |
| M5 | `data-architect` → `balance-mathematician` |
| M6 | `core-engineer` → 按需 `pattern-integrator` / `optional-integrator` |
| M7 | `auto-tester` → `balance-mathematician` → `quality-validator` |
| M8 | 按本文 M8 执行（无单独 UI skill） |

### 阶段完成输出格式

```text
## Mx 完成 — <阶段名>
**交付物**：<文件列表>
**自检**：通过 / 未通过（列缺口）
**下一步**：Mx+1 → 调用 <skill>；下一题：<一句话>
```

---

## 2. 开场路由（含三路径）

### 第 1 题（仅此一题）

> 你现在是：  
> **A.** 从零做一款新增量游戏  
> **B.** 改已有游戏（数值 / 内容 / 系统 / 循环 / bug）

| 回答 | 你的动作 |
|------|----------|
| A | 进入第 2 题（选引导路径）。先确认项目根目录。 |
| B | **停止使用本文流程**。告知改用 `mid-game-balance-fix`（诊断 → 归类 → 改 → 重跑模拟）。 |
| 说不清 | 追问：是否已有可运行的 `data/` + headless `src/`？有 → B；无 → A。 |

### 确认项目位置（新游戏必做）

> 游戏项目放在哪？推荐独立仓库（如 `D:\Projects\my-game\`），与 framework **平级**。不要把游戏建在 framework 仓库内部。

开发者确认路径后，后续所有交付物都写到该路径下。

### 第 2 题：选引导路径（新游戏）

用白话介绍，**不要**堆术语：

> 接下来你想怎么合作？  
> **A. 一键托管** — 玩法不复杂时最省事：你只答大约 5 个关键问题，其余我按框架默认做好，只在两处请你点头。  
> **B. 方案体检** — 你已有设计想法或文档：你先丢给我，我找缺口和矛盾再问你，然后帮你补全。  
> **C. 逐步问答** — 你想深度参与每个设计决策：我按顺序一题一题问，你来答。

| 回答 | 进入 |
|------|------|
| A | [§3 路径 A](#3-路径-a一键托管) |
| B | [§4 路径 B](#4-路径-b方案体检) |
| C | [§5 路径 C](#5-路径-c逐步问答m0m8) |
| 说不清 | 推荐 A；若开发者说「我有一堆想法/文档」→ B；若说「我想自己定细节」→ C。 |

**切换**：路径中途可改（例如 A 做到一半想细抠 → 转 C 当前阶段）；交付物格式不变。

---

## 3. 路径 A：一键托管

> **适合**：简单玩法、想尽快出可验证原型、不想答一长串设计题。  
> **你问很少**：约 5 题。  
> **强制确认仅 2 处**：概念一页纸（M0）+ 机制勾选摘要（M4）。其余阶段你做完后用 **2～4 行** 告知结果，默认继续；开发者说「停 / 改某某」再改。

### A.1 只问这 5 题（每次一题）

1. **一句话**：这游戏是干什么的？（例：「太空放置，管飞船资源」）
2. **玩家主要在干什么？**（多选最多 3 个）`点击 / 建造 / 收集 / 战斗 / 合成 / 其他`
3. **一次大概想玩多久？** `随便点几分钟 / 半小时左右有成长感 / 很长线硬核`
4. **平台？** `Web / 手机 / Steam / 还没定`
5. **要不要「玩一阵清空进度、留下永久加成再开」？** `要 / 不要 / 你看着办`

答完后**不要继续追问**竞品列表、资源名、Pattern 名等——这些由你补。

### A.2 你自动完成 M0–M4（少打扰）

按顺序写文件；每步内部自检，**不要**把自检清单念给开发者听。

| 步 | 你做什么 | 对开发者说什么 |
|----|----------|----------------|
| M0 | 写 `docs/game-concept.md` + `docs/competitors.md`（竞品你按题材挑 3 款填） | **强制确认**：用半页白话复述「做什么 / 给谁玩 / 和谁像」，问「这样可以吗？」 |
| M1 | 用 `case-consultant` 选 1 个主参考 case，写进 concept | 一句：「主要参考 X，因为…」不必征求第二参考 |
| M2 | 写 `docs/dag.md`（6–12 节点，含限制资源） | 2～4 行摘要 + Mermaid；默认继续 |
| M3 | 写 `docs/timeline.md`（含首次重置目标时长） | 2～4 行；默认继续 |
| M4 | 写 `docs/pattern-decisions.md`（MVP ≤7 个 Y；优先 S+T+资源类） | **强制确认**：用白话列「准备用的玩法模块」5～7 条，问「要砍掉或加上什么吗？」 |

**M0 / M4 未确认前**，不要进入 M5。

### A.3 M5 之后

与路径 C 的 M5–M8 相同，但提问再砍一刀：

- **M5**：你直接按 numerical-design 最近模式档案填 JSON；只在 schema 失败或与 DAG 明显冲突时才问人。
- **M6**：语言默认 Python（或项目已有语言）；CLI 按契约实现；少问。
- **M7**：跑模拟 → 用白话报 3～5 个数字 → 问「哪一项最不满意？」（可答「都还行」）→ 每次只改 1 个数值旋钮。
- **M8**：仅当开发者明确要界面时进入；问题可合并为「主界面更像哪一类？」给 3 个 case 范式选项。

### A.4 路径 A 禁止

- 把路径 C 的长问卷原样搬过来
- 未确认 M0 / M4 就写 `data/`
- 为「更完美」追加第 6、第 7 个必答题（可选项须标注「可跳过，默认某某」）

---

## 4. 路径 B：方案体检

> **适合**：开发者已有设计文档、长消息、脑暴笔记、竞品模仿说明。  
> **你少做从零提问**：先读材料 → 找缺口与矛盾 → **只问有问题的点** → 补成标准交付物。

### B.1 收材料（一题）

> 把你现有的设计发我（文档路径、粘贴全文、或分几条口述都行）。越全越好；没有结构也没关系。

若几乎是空的 → 建议改走路径 A 或 C，不要硬做体检。

### B.2 体检清单（内部用，不要整表甩给开发者）

对照附录 A 与路径 C 自检，标记每项：`已有且清楚` / `有但含糊` / `缺失` / `互相矛盾`。

至少覆盖：

1. 一句话定位与核心动词  
2. 参考对象（像哪款游戏 / 框架 case）  
3. 主货币、主要资源、产线怎么转起来  
4. 开局 30 秒玩家干什么  
5. 第一次「重置变强」大概何时、留下什么  
6. 有哪些特殊系统（稀有度、多区域、战斗…）——有无互相打架  
7. 是否过早纠结 UI/美术（应推迟到 M8）  
8. 是否想塞进 framework `cases/`（应改写到自己项目）

### B.3 提问规则

1. **只问**标记为「含糊 / 缺失 / 矛盾」的项；一次一题。  
2. 提问时用白话说清：**缺什么**、**为什么要紧**、**你建议的默认填法**（开发者可改）。  
3. 矛盾示例：「你说首次重置 2 分钟，又说要半小时深度成长」→ 让开发者二选一或给折中。  
4. 材料已写清的项：**不要再问**，直接写入标准文件。

### B.4 补全与汇合

材料+问答足够后，一次性（或按 M0→M4 分批）写出：

- `docs/game-concept.md` / `competitors.md`
- 参考 case 段（M1）
- `docs/dag.md` / `timeline.md` / `pattern-decisions.md`

每写完一块给短确认；**M4 齐备并确认后**进入路径 C 的 M5（或按 A.3 少问模式推进 M5+，若开发者仍想省事）。

### B.5 路径 B 禁止

- 无视开发者原文，整盘换成你的偏好设计（应标注「你原文 vs 我建议修改」）
- 把完整路径 C 问卷再问一遍
- 体检未完成就写引擎代码

---

## 5. 路径 C：逐步问答（M0–M8）

> **适合**：想深度参与每个设计决策。  
> **做法**：按下面顺序，一次一题；当前阶段文件写好并确认后，再进下一阶段。  
> **总览**（仅当开发者问「全程有哪些步」时展示）：

```text
M0 选题 → M1 选参考 → M2 资源关系图 → M3 时间节奏 → M4 玩法模块
→ M5 数值表 → M6 无界面引擎 → M7 批量模拟 → M8 界面设计（可选）
```

---

### M0 — 选题 + 受众 + 平台

**目标**：一页纸说清「做一款什么游戏」。

**交付物**（写到开发者项目）：

- `docs/game-concept.md`
- `docs/competitors.md`

**按序提问**（每次只问一题，收齐再写文件）：

1. 一句话定位？（例：「太空放置，管理飞船资源」）
2. 题材？`太空 / 中世纪 / 现代 / 抽象 / 其他`
3. 核心动词？（点击 / 建造 / 收集 / 战斗 / 合成 … 可多选，最多 3 个）
4. 平台？`Web / 移动 / Steam / 主机 / 未定`
5. 目标受众时长？`休闲约 5min / 核心约 30min / 硬核约 4hr+`
6. 美术风格意向？（像素 / 3D / 文字 / 卡牌 / 未定——只记意向，不做 UI）
7. 直接竞品 3–5 款？每款一句「他们强在哪 / 我们差异点」

**可选一句（写入 concept，不画界面）：** 拟抄的界面样子？（侧栏+战场 / 分页 Hub / 节点桌面 / 未定）

**做完再往下（自检）**：

- [ ] 有一句话定位（不是「我想做放置」）
- [ ] 有 3–5 竞品 + 差异
- [ ] 知道先做什么，不是「做最大系统」
- [ ] 文件已写入开发者项目，**未**写入 framework `cases/`

**禁止**：无定位立项；无竞品；一上来谈完整 UI/美术规格。

**下一步**：M1 → `case-consultant`（可在 `game-designer` 内嵌）。

---

### M1 — 选参考 case

**目标**：从 framework case 中选 **1–2 个**最像的作结构模板。索引权威源：[cases/README.md](cases/README.md)（完整表见[附录 B](#附录-bcase--pattern-速查)）。

**按序提问**：

1. 玩法更偏哪类？  
   `战斗收集 / 资源管理 / 自动化沙盒 / 物理合成 / 农场战斗 / 塔防灾变 / 长期多时代 / 赌场刮卡 / 采矿Plinko / 说不清`
2. （若说不清）主循环一句话是什么？根据动词映射到上表。
3. 展示 1–3 个候选 case（只列名字+一句适合理由），问：选哪个作主参考？第二个差异参考要不要？
4. （可选）界面想抄哪套样子？写入 concept 一句即可。

**选型提示（内部用，不要一次全表甩给开发者）：**

| 倾向 | 优先 case |
|------|-----------|
| 战斗+收集 | Shelldiver / Tower Wizard |
| 资源管理+多时代 | Kittens Game |
| 节点/自动化 | Upload Labs |
| 物理/跨建筑链 | Gnorp |
| Unity 农场+跨 run | Agrivore |
| 塔防+灾变 | Dwarf Eat Mountain |
| 长运营+多层重置 | Cell to Singularity |
| 刮卡/peek | Scritchy Scratchy |
| 采矿+Plinko | Space Rock Breaker |

**交付物**：在 `docs/game-concept.md`（或独立段）写清：

> 我们与 **X** 在结构上相似，差异在 **Y**。（可选：拟抄界面样子 Z）

**做完再往下**：

- [ ] 主参考 case 恰好 1 个（第二参考可选）
- [ ] 差异写清楚，不是「每个 case 取一点」
- [ ] 没有「完全不参考 case」

**禁止**：平均抄所有 case；从零发明结构。

**下一步**：M2。

---

### M2 — 定义核心循环（资源关系图）

**目标**：6–12 节点的资源/产线/升级依赖图（有向无环）。人话：钱从哪来、花到哪、什么卡住你。

**对照**（需要时读）：[core/02](core/02-resources.md) · [core/03](core/03-production-lines.md) · [core/04](core/04-upgrade-economy.md)

**按序提问**：

1. 主货币叫什么？（单一目标货币优先）
2. 还有哪些资源？列出候选，一起压到 **主资源 3–7 个**。
3. 哪一个是**限制资源**（好多条线都要用它）？没有则一起设计一个。
4. 开局第一条产线是什么？（自动 / 点击 / 触发）
5. 前几个升级分别解锁或加倍什么？
6. 用 Mermaid 画出草案，请开发者确认或改节点。

**Mermaid 骨架示例**（按开发者题材改名，不要照抄）：

```mermaid
graph LR
    Money --> Processor
    Processor --> Money
    Money --> Upgrade1
    Upgrade1 --> Processor
    Money --> Building1
    Building1 --> File
    File --> Storage
    Storage --> Money
```

**交付物**：`docs/dag.md`（含 Mermaid +「主货币经哪 2–3 条路径产出」一段话）

**做完再往下**：

- [ ] 节点 6–12
- [ ] 主资源 3–7
- [ ] ≥1 限制资源
- [ ] 无环（重置闭环另论，不画进资源图）
- [ ] 不是「全部资源互相兑换」

**禁止**：资源 >10 却无时代/分区支撑；无限制资源导致单一决策轴。

**下一步**：M3。

---

### M3 — 定义节奏骨架

**目标**：时间轴——玩家在各里程碑遇到什么。计量用 **tick 或秒**，不用 UI 里程碑名。

**对照**：[optional/o10-pacing-milestones.md](optional/o10-pacing-milestones.md) · [optional/o02-endgame-progress-bars.md](optional/o02-endgame-progress-bars.md)

**按序提问**：

1. 开局 30 秒内，玩家的「第一个清晰动作」是什么？
2. 第一次有意义的决策大约在几分钟？（目标：约 1–5 min）
3. **首次重置变强**目标时长？（建议 ≥5 min，常见 30 min–2 hr；忌 <5 min 或 >2 hr 无中间目标）
4. 重置后永久层给什么？（永久货币 + 永久升级方向）
5. 终局/硬顶是什么感觉？（破墙 / 进度条 / 挑战 …）
6. 终局后还有什么留人内容？（成就 / 排行 / 自定义 …）

**交付物**：`docs/timeline.md` — 表格式时间轴（建议 7–10 行），列：时间点 / 玩家状态 / 解锁 / 反馈信号 / 目标 tick 或秒。

**骨架行（填空，勿空着跳过）：**

| 时间点 | 要写清 |
|--------|--------|
| 开局 0–30s | 1 种货币 + 1 建筑 + 1 升级 |
| 1–5min | 第二种货币或分支 |
| 首次重置前 | 主线熟悉、多条成长路线 |
| 首次重置 | 永久货币 + 永久加成 |
| 硬顶 | 终局系统入口 |
| 终局后 | 走完后的内容 |

**做完再往下**：

- [ ] 有开局「第一个清晰动作」
- [ ] 首次重置时间合理且有中间小目标
- [ ] 终局不是空白
- [ ] 一句说明：「我们的首次重置 ≈ 玩家玩 X 后触发」

**下一步**：M4。

---

### M4 — 选玩法模块（Pattern / Optional）

**目标**：勾选要用的模式，每项一句「为什么」。MVP **最多 5–7 个**。

**对照**：[patterns/README.md](patterns/README.md) · [optional/README.md](optional/README.md) · [patterns/conflicts.md](patterns/conflicts.md) · [附录 B 勾选表](#m4-勾选速查表) · [附录 C 决策树](#决策树何时引入)

**按序提问**（对开发者用白话，括号里的代号给你自己用）：

1. 有收集/掉落稀有度吗？→ 考虑 Pattern R  
2. 是否 1 种资源跨多条产线？→ Pattern D  
3. 升级是否分核心/次要/开关？→ Pattern S（**MVP 强烈建议**）  
4. 是否有质变等级跳跃？→ Pattern T（**MVP 强烈建议**）  
5. 有战斗持续伤害/buff 统一结构吗？→ Pattern E  
6. 玩家摆节点配线吗？→ Pattern N  
7. 重置是单货币还是双轨？→ Core05 / P2 / O7  
8. 需要章节门槛 / 多区域 / 终局条吗？→ O1 / O11 / O2  
9. 汇总候选后问：这 5–7 个是否同意？要砍掉哪个？  
10. 启用多个模块前：快速扫 `patterns/conflicts.md` 相关行，有冲突则让开发者二选一。

**交付物**：`docs/pattern-decisions.md` — 勾选表（Y/N）+ 每项 1 句理由。  
**O9**（长按/Tooltip 等交互）：可勾选，但**实现推迟到 M8**。

**必选倾向**：Pattern S + Pattern T + 至少 1 个资源管理类（R 或 D）。不选 = 用 Core 默认，合法。

**参考组合（内部，按 M1 case 提示，勿强迫照抄）：**

- Shelldiver：R / S / T / B + O8 / O10 / O11
- Tower Wizard：B / S / T / E + O1–O11
- Kittens Game：B / C / D / E / P / R / S / T + O1 / O3 / O5 / O11
- Upload Labs：B / C / D / E / P / P2 / R / S / T / AME / N / PR + O1 / O3 / O5 / O11

**做完再往下**：

- [ ] Y ≤ 7（MVP）
- [ ] 每项有理由
- [ ] 不是「模块越多越好」
- [ ] 冲突已处理

**禁止**：不勾选直接写 JSON。

**下一步**：M5 → `data-architect`。

---

### M5 — 填数值 JSON

**目标**：把资源关系图 + 时间轴 + 玩法模块落到 `data/*.json`。

**权威数值手册**：[docs/numerical-design.md](docs/numerical-design.md)（先选 §2 模式档案，再拷 §4 模板）。Schema：[schemas/](schemas/)。

**按序提问**：

1. 对应 numerical-design 的哪一种模式档案？（展示 2–3 个最接近选项）
2. 本阶段最小集合要哪些文件？（至少含 currencies / resources / buildings 或等价 / upgrades / prestige 或 perks / metadata）
3. 主货币与限制资源的 id 是否与 `docs/dag.md` 一致？
4. 是否已有重置入口实体（哪怕只有按钮+公式）？

**字段硬约定**（写文件时自检）：

- 顶级必须是 **dict** `{id: ...}`，不是 list
- cost 含 `cost` / `cost_e` / `cost_inc`（见 [core/04](core/04-upgrade-economy.md) C1–C6）
- currency 字段引用 `currencies.json` 的 key
- 有 attribute 时用 3-tuple `[a,m,e]`（AME）或 Pattern E schema

**交付物**：`data/` 下 ≥6 个 JSON；schema 校验通过。

**做完再往下**：

- [ ] schema 通过
- [ ] ≥1 currency、resource、upgrade、prestige 实体
- [ ] 与 M2 资源图一致
- [ ] ≥1 重置入口
- [ ] 数值不在 .md / 代码里写死

**下一步**：M6 → `core-engineer`。

---

### M6 — headless 引擎（无 UI）

**目标**：用命令行就能跑的最小可玩循环。无渲染、无图形库。

**契约**：[docs/ai-first-workflow.md §4](docs/ai-first-workflow.md#4-headless-引擎-cli-契约)  
**伪代码**：[examples/pseudocode/](examples/pseudocode/)

**按序提问 / 确认**：

1. 引擎语言？（Python 示例即可，不强制）
2. 确认 CLI 形态：`--config` / `--max-ticks` / `--seed` / `--runs` / `--output`
3. 实现顺序按时间轴：先开局闭环，再涨到能触发首次重置
4. Strategy 接口是否预留？（供后续模拟注入决策）

**最小实现顺序**：

1. 1 currency + 1 building + 1 upgrade
2. 第 2 currency / 分支
3. 多条成长路线
4. 首次重置 + 永久层
5. 再往后做终局（可与 M7 穿插）

**引擎约束**：JSON 进出；同 seed+策略→同结果；全局加成入库乘一次；成本读 JSON；禁止 UI。

**验证命令示例**：

```bash
python -m game --config data/ --max-ticks 10000 --seed 42
python -m game --config data/ --runs 10 --max-ticks 50000 --output results.json
```

**交付物**：`src/` headless + CLI；可选 `tests/` 骨架。

**做完再往下**：

- [ ] 10000 tick 状态 JSON 正常
- [ ] 模拟中能触发首次重置
- [ ] `--seed 42` 两次一致
- [ ] 有 save/load 路径（或明确下一步补）
- [ ] **零 UI 代码**

**禁止**：本阶段做按钮/渲染；程序员私自定数值（应读 M5 JSON）。

**下一步**：M7 → `auto-tester`。

---

### M7 — 批量模拟 + 数值调优

**目标**：自动化验证平衡；产出报告；按症状改 **1 个** JSON 旋钮再复测。

**对照**：[docs/ai-first-workflow.md §5](docs/ai-first-workflow.md#5-自动化测试矩阵) · [docs/numerical-design.md §6](docs/numerical-design.md#6-调优手册症状--旋钮)

**按序推进**：

1. 跑吞吐：`--runs 1000`（或项目约定规模）→ 完成率
2. 跑平衡 / 确定性 / 策略对比
3. 用白话展示 5 类指标，问：哪一项最不满意？
4. **只改 1 个字段** → 写 changelog → 重跑 → 对比
5. 重复直到指标健康或开发者接受「先过这关、细调以后再做」

**5 类指标**：

| 指标 | 目标感 |
|------|--------|
| 首次重置 tick | P50/P90 贴近时间轴 |
| 资源利用率 | 限制资源别长期闲置 |
| 成长路线分布 | 无单一升级 >80% |
| 重置频率 | 曲线平滑 |
| 永久点累积 | 相对设计目标 ±20% 量级 |

**调优口令**：数值失衡 → `cost_e`；系统失衡 → `cost_inc` / requirement；节奏失衡 → 加中间里程碑。

**交付物**：`tests/reports/` 模拟报告 + `docs/design-changelog.md`（或等价）调优记录。

**进 M8 前必须满足**：

- [ ] 批量模拟报告存在
- [ ] 5 类指标有数据
- [ ] 0 条 🔴 阻断级异常（或开发者书面接受残留并记录）
- [ ] 调优有 changelog

**禁止**：用人工试玩代替模拟；一次改多个变量；不写 changelog；数据差就整盘重做（先查 M2 资源图）。

**下一步**：若开发者要界面 → M8；否则宣布 M0–M7 完成，可停。

---

### M8 — 游戏界面设计（可选，M7 通过后）

**目标**：先**结构可复原**的界面设计，再绑渲染。不是先画皮。

**前置**（缺一不可）：

- [ ] M7 批量模拟通过（完成率与阻断约定已满足）
- [ ] 5 类指标健康或已记录例外
- [ ] 引擎 API / CLI JSON 输出稳定

**交付物**（开发者项目，不是 framework `cases/`）：

- `docs/ui-layout.md` — ASCII 线框 + 锚点表 + 热键
- `ui/ui-layout.json` — 与 case 同构的结构数据
- `ui/` — 绑定与皮肤（设计过关后再做）

**标准**：[docs/case-to-framework-contribute.md 附录 C](docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准) · [O9](optional/o09-interaction-qol.md)

#### M8.1 引导顺序（一次一步）

| 步 | 你问 / 你做 | 产出 |
|----|-------------|------|
| 1 | 主界面 / 升级 / 重置 / 设置 各一屏还是叠层？ | 屏幕清单 |
| 2 | 主货币与限制资源条在顶还是底？ | meter 落位 |
| 3 | 主视口隐喻？（战场/田野/桌面/节点/刮卡…对照 M1 case） | 隐喻一句 |
| 4 | 逻辑分辨率 + 各区 rect（可先 inferred） | geometry |
| 5 | 每面板有哪些 chip/行/按钮/tooltip 字段？ | components |
| 6 | 热键与 QoL（Space、长按、批量买）？ | hotkeys / O9 |
| 7 | **最后**才谈图标动画字体 | 皮相 |

**验收口令**：只看 `ui-layout.json` + `ui-layout.md`，能否画出 ASCII 并列出子控件？能 → 过；只能说「有个升级面板」→ 不过。

#### M8.2 范式（抄结构不抄美术）

需要时展示 **1–2 个**与 M1 相关的行（完整表见[附录 B](#m8-界面范式速查)）。

#### M8.3 `ui-layout.json` 最低字段

```text
_rebuild_standard: { target: "结构可复原", not_required[], status }
coordinate_space:  { w, h, origin, unit, confidence, evidence }
geometry.regions[]: id, rect, confidence, role
components: 按面板 children / row_template
hotkeys / settings_groups
```

`status`：`pass` 或 `pass_with_inferred_anchors`（可接受）。

#### M8.4 架构约束

- UI **不含**业务逻辑；成本/重置计算在 headless
- UI 调引擎 API，不直接用 JSON 算关键公式
- 改数值仍只改 JSON + 重跑模拟

#### M8.5 做完再往下

- [ ] `docs/ui-layout.md` 有线框 + 锚点 + 热键
- [ ] `ui/ui-layout.json` 有 regions + components + coordinate_space
- [ ] 写清抄了哪套范式、差异在哪
- [ ] 绑定后改 JSON 展示可更新
- [ ] 未把新游戏 UI 写进 framework `cases/`

**禁止**：M7 未过就做 UI；UI 内嵌公式；只有一句话「有升级界面」；把猜测坐标标成 measured。

---

## 附录 A：交付物清单与项目目录

### 里程碑交付物

三条路径最终都落到同一套文件：

| 阶段 | 交付物 | 验证 |
|------|--------|------|
| M0 | `docs/game-concept.md` + `docs/competitors.md` | 定位+竞品齐全 |
| M1 | 参考 case + 差异说明 | 一句话能讲清 |
| M2 | `docs/dag.md` | 6–12 节点、有限制资源 |
| M3 | `docs/timeline.md` | 含首次重置目标 |
| M4 | `docs/pattern-decisions.md` | 5–7 个 Y，有理由 |
| M5 | `data/*.json` ≥6 | schema 通过 |
| M6 | `src/` + CLI | seed 确定性；可重置 |
| M7 | 模拟报告 + changelog | 指标健康 |
| M8 | `docs/ui-layout.md` + `ui/ui-layout.json` | 结构可复原 |

### 推荐项目根目录

> `my-game/` = **独立仓库**（或与 framework 平级），不是 framework 子目录。

```text
my-game/
├── docs/
│   ├── game-concept.md
│   ├── competitors.md
│   ├── dag.md
│   ├── timeline.md
│   ├── pattern-decisions.md
│   ├── ui-layout.md              # M8
│   └── design-changelog.md
├── data/                         # M5
├── src/                          # M6 headless
├── tests/                        # M7
│   ├── results/
│   └── reports/
└── ui/                           # M8
    ├── ui-layout.json
    └── ...
```

### 数据 / 文档 / 代码边界

| 内容 | 位置 |
|------|------|
| 数值 | `data/*.json` |
| 机制逻辑 | `src/` headless |
| 设计意图 | `docs/*.md` |
| 平衡证据 | `tests/reports/` |

**同步**：改 JSON → changelog 一行；改文档 → 核对 JSON/代码仍一致；加系统 → 更新资源图 + JSON + 代码 + changelog。

---

## 附录 B：Case / Pattern 速查

> 引导时按需查阅；不要在对话开头整附录粘贴给开发者。

### Case 速查

| Case | 最适合 |
|------|--------|
| [Shelldiver](cases/shelldiver/README.md) | 战斗+收集 |
| [Tower Wizard](cases/tower-wizard/README.md) | 多层区域+终局破关 |
| [Kittens Game](cases/kittens-game/README.md) | 超大规模+多时代+跨周期 |
| [Upload Labs](cases/upload-labs/README.md) | 节点摆放+配线+自动化 |
| [Gnorp](cases/gnorp/README.md) | 物理合成+跨建筑链 |
| [Agrivore](cases/agrivore/README.md) | 农场战斗+跨 run meta |
| [Dwarf Eat Mountain](cases/dwarf-eat-mountain/README.md) | 塔防+灾变+神器 |
| [Cell to Singularity](cases/cell-to-singularity/README.md) | 长运营+多层重置 |
| [Scritchy Scratchy](cases/scritchy-scratchy/README.md) | 刮卡/peek 风险 |
| [Space Rock Breaker](cases/space-rock-breaker/README.md) | 采矿+Plinko+双视口 |

完整索引：[cases/README.md](cases/README.md)。

### M4 勾选速查表

| 决策 | 文档 |
|------|------|
| 多档稀有度 | [Pattern R](patterns/pattern-r-rarity.md) |
| 双资源池 | [Pattern D](patterns/pattern-d-dual-pool.md) |
| 成长轴分档 | [Pattern S](patterns/pattern-s-skill-tiers.md) |
| 二进制开关 | [Pattern B](patterns/pattern-b-binary-unlock.md) |
| 等级跳跃 | [Pattern T](patterns/pattern-t-tier-jump.md) |
| 状态 Stack | [Pattern E](patterns/pattern-e-status-stack.md) |
| 3-tuple 属性 | [Pattern AME](patterns/pattern-ame-3tuple-attribute.md) |
| 节点流水线 | [Pattern N](patterns/pattern-n-node-pipeline.md) |
| Service 软重置 | [Pattern PR](patterns/pattern-pr-service-soft-reset.md) |
| 双 prestige 货币 | [Pattern P2](patterns/pattern-p2-dual-prestige.md) |
| 自选 debuff | [Pattern C7](patterns/pattern-c7-opt-in-debuff.md) |
| 章节 Gate | [O1](optional/o01-chapter-gates.md) |
| 副进度条 | [O2](optional/o02-endgame-progress-bars.md) |
| 战斗目标 | [O3](optional/o03-challenge-axis.md) |
| 跨轴反馈 | [O4](optional/o04-cross-axis-feedback.md) |
| 瓶颈资源 | [O5](optional/o05-bottleneck-balance.md) |
| 区域焦点 | [O6](optional/o06-area-focus.md) |
| 双 reset 轨 | [O7](optional/o07-dual-reset-track.md) |
| 训练/派系 | [O8](optional/o08-support-systems.md) |
| 长按/Tooltip | [O9](optional/o09-interaction-qol.md)（M8 实现） |
| 节奏里程碑 | [O10](optional/o10-pacing-milestones.md) |
| 多区域 | [O11](optional/o11-multi-region.md) |
| 时空多层 | [O13](optional/o13-temporal-multicycle.md) |

### M8 界面范式速查

| 范式 | 参考 case |
|------|-----------|
| 侧栏建筑格+中心战场 | [Dwarf Eat Mountain](cases/dwarf-eat-mountain/README.md) §3.10 |
| 主视口+底栏 Hub Tabs | [Agrivore](cases/agrivore/README.md) §3.10 |
| 桌面节点+侧栏菜单 | [Upload Labs](cases/upload-labs/README.md) |
| 建筑悬停菜单 | [Gnorp](cases/gnorp/README.md) §15b |
| Dashboard PanelState | [Cell to Singularity](cases/cell-to-singularity/README.md) §5b |
| 战斗+副面板 Plinko | [Space Rock Breaker](cases/space-rock-breaker/README.md) |
| 刮卡台+侧栏树 | [Scritchy Scratchy](cases/scritchy-scratchy/README.md) |
| 岛屿/潜水/技能树 | [Shelldiver](cases/shelldiver/README.md) §11b |
| 建塔 HUD+区域面板 | [Tower Wizard](cases/tower-wizard/README.md) §12.0 |

### 数值文件规模参考

| 文件 | 规模感 |
|------|--------|
| currencies | 4–12 |
| resources | 10–30 |
| buildings / windows | 5–100 |
| upgrades | 20–100 |
| research / techs | 10–50 |
| perks / prestige | 10–40 |
| milestones | 2–10 |
| achievements | 10–30 |
| metadata | 1 |

---

## 附录 C：反模式与决策树

> 反模式权威源：[docs/anti-patterns.md](docs/anti-patterns.md)。此处只列引导时最高频条目。

### 跨模块高频

| 反模式 | 后果 |
|--------|------|
| 数值写死代码 | 无法调参 |
| 只有指数 sink、无重置/永久 | 硬顶流失 |
| 全局加成多处乘 | 数值膨胀 |
| 无终点且无软顶 | 动机衰竭 |
| 抄固定 tier/重置点数当标准 | 误套题材 |

### 流程反模式（引导时口头拦截）

| 阶段 | 反模式 | 你怎么拦 |
|------|--------|----------|
| 设计 | 不参考 case；策划案塞进 `cases/` | 强制选参考；改写到 `my-game/docs/` |
| 设计 | 资源图>12 节点；无限制资源；无开局动作 | 合并节点；补限制资源；补 30s 动作 |
| 设计 | 首次重置 <5min；终局空 | 拉长+加里程碑；加 O2 类内容 |
| 实现 | M6 做 UI；list 顶级 JSON；无 cost_inc | 推迟 UI；改 dict；补三字段 |
| 调优 | 试玩代模拟；一次改多变量；无 changelog | 拉回 M7 纪律 |
| 上线后 | 新系统不接主循环 | 转 `mid-game-balance-fix` 场景 C |
| 引导 | 路径 A 却问完整路径 C 问卷 | 停问，回到 §3 五题+两处确认 |

### 决策树：何时引入

```text
问题出现
  ├─ 稀有度？ → R
  ├─ 1 资源跨多产线？ → D
  ├─ 资源>10 要分组？ → O11
  ├─ 核心/次要/开关？ → S
  ├─ 解锁式无曲线？ → B
  ├─ 9→10 质变？ → T
  ├─ 多表共享属性引擎？ → AME
  ├─ DOT/易伤等？ → E
  ├─ boss/波次 HP？ → O3
  ├─ 战斗影响产出？ → O4
  ├─ 双 prestige？ → P2
  ├─ sub-tree 重专精？ → PR
  ├─ 自选 debuff？ → C7
  ├─ 摆节点配线？ → N
  ├─ 季节/周期？ → O13
  ├─ 时间轴规划？ → O10
  ├─ 瓶颈资源？ → O5
  ├─ 章节门槛？ → O1
  └─ 终局隐藏物？ → O2
```

**不引入**：找不到触发条件；只因竞品用了；只因名字酷。

---

## 附录 D：快速链接

| 需要 | 去哪 |
|------|------|
| 数值填表与调优 | [docs/numerical-design.md](docs/numerical-design.md) |
| Headless / 模拟契约 | [docs/ai-first-workflow.md](docs/ai-first-workflow.md) |
| UI 完成定义 | [附录 C 结构可复原](docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准) |
| 中途修改 | skill `mid-game-balance-fix`（**不要**用本文展开） |
| 资源入库公式 | [core/02](core/02-resources.md) |
| 成本曲线 | [core/04](core/04-upgrade-economy.md) |
| Reset | [core/05](core/05-reset-systems.md) |
| 永久升级 | [core/06](core/06-permanent-upgrades.md) |
| 伪代码 | [examples/pseudocode/](examples/pseudocode/) |
| 贡献 / case 规范 | [CONTRIBUTING.md](CONTRIBUTING.md) |

### 工程师对接（M6 时甩一张即可）

| 特性 | 伪代码 |
|------|--------|
| 资源/产线 | [add-resource.md](examples/pseudocode/add-resource.md) |
| 购买 | [purchase.md](examples/pseudocode/purchase.md) |
| XP | [gain-xp.md](examples/pseudocode/gain-xp.md) |
| 状态 Stack | [apply-status-effect.md](examples/pseudocode/apply-status-effect.md) |
| 多区域 | [region-manager.md](examples/pseudocode/region-manager.md) |

---

## 一句话

> **新游戏**：先选合作方式（一键托管 / 方案体检 / 逐步问答）→ 落到同一套交付物 → 填 JSON → 无界面引擎 → 批量模拟 →（可选）结构可复原 UI。  
> **改现有**：离开本文 → `mid-game-balance-fix`。

**核心原则**：少问关键题；能白话就白话；一次一问；数值在 JSON；逻辑在 headless；先模拟后界面；永远从 case 模仿。

---

> 本文档随框架更新。变更见 [CHANGELOG.md](CHANGELOG.md)。反馈走 [CONTRIBUTING.md](CONTRIBUTING.md)。
