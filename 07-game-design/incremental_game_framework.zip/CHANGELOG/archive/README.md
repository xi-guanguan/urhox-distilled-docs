# CHANGELOG 归档策略

> 当根目录 [CHANGELOG.md](../../CHANGELOG.md) 超过 **600 行** 时, 将已发布版本块移入本目录。

## 规则

1. **根 CHANGELOG.md** 只保留:
   - `[Unreleased]` 区块 (当前开发中变更)
   - 最近 **2 个已发布版本** 的完整记录 (便于快速查阅)

2. **归档文件命名**: `CHANGELOG-v0.x.md` (一个文件一个主版本)

3. **归档时机**: 跑 `python scripts/check-changelog-size.py` 返回非零时执行归档

4. **归档后必做**:
   - 在根 CHANGELOG.md 顶部 `[Unreleased]` 下加一行: `> 历史版本见 CHANGELOG/archive/`
   - 跑 `python scripts/check-md-links.py` 确认内链有效
   - 在 `[Unreleased]` 记录 "归档 CHANGELOG vX.Y"

## 当前状态

- 根 CHANGELOG: 仅保留 2026-07-10 及之后 Unreleased（2026-07-14 归档后）
- 本目录已有：[CHANGELOG-history-pre-2026-07-10.md](CHANGELOG-history-pre-2026-07-10.md)

## 无版本标签时如何归档?

根 CHANGELOG 目前只有 `[Unreleased]`。可按日期切片：将更早 `###` 条目移入本目录，根文件保留近期条目 + 指向 archive 的链接。打 tag 发布后再按 `CHANGELOG-v0.x.md` 命名。
