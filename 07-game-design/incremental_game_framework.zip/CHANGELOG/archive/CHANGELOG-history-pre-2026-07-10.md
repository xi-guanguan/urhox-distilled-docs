# Changelog 归档 — 2026-07-10 之前

> 从根 [CHANGELOG.md](../../CHANGELOG.md) 于 2026-07-14 归档。
> 根文件保留 [Unreleased] 中 2026-07-10 及之后条目；更早历史见本文件。

---

### numerical-design.md 按游戏模式分档重构 (2026-07-05)

回应用户反馈"当前设计指南不按游戏模式做区别，case 里其实有不同游戏模式，不应全部提炼到一起"：

- **[docs/numerical-design.md](docs/numerical-design.md) 主体重写** — 从"通用基础 + 5 规则"结构改为"按 8 种游戏模式分章"
- **§2 新增 8 种模式档案** — 每档直接引用 case 实证，并标注题材 / 时长 / 主 sink / Reset 类型 / 必含 Pattern / 数值锚点 / 常见配方 / 调优旋钮 / 反模式：
  - **A · Cozy 探险+多区域**（Shelldiver 档案，~4h 无 reset，4 核心轴跳 8→10）
  - **B · 塔层+多区域+破墙终局**（Tower Wizard 档案，10 塔层 + 12 区 + 4 堵墙 HP sink）
  - **C · 9 era 超长+跨周期**（Kittens Game 档案，58 资源 + 双 prestige + 4 季节日历）
  - **D · 节点流水线自动化**（Upload Labs 档案，3-tuple 单一引擎 + 6-type transfer + service 软重置）
  - **E · 物理合成+单 prestige**（Gnorp 档案，CE 11 级 + 跨建筑 inspiration + Reclamation）
  - **F · 农场+战斗+跨 run skill tree**（Agrivore 档案，7 sins 主题 run + 多阶段装备）
  - **G · 塔防+多阶段神器+多 tier prestige**（Dwarf Eat Mountain 档案，124 artifact 3 类 effect + 102 prestige 节点）
  - **H · 长程运营 12 era+3 层 prestige**（Cell to Singularity 档案，6 currency + 34 SO + live ops SDK）
- **§3 通用基础精简** — 保留 C1-C6 曲线族 / T1-T5 产线 / 3-tuple 引擎 / Reset 公式等通用公式
- **§4-9 配套调整** — 起步 JSON 加"按模式档案字段替换表"；调优手册分通用 / 模式专属两段；反模式按"跨模式共有 / 各模式专属 / core 传统"三类组织
- **[README.md](README.md) 与 [GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) 描述同步** — 强调"先选 §2 模式档案再填数值"

### Pattern 冲突矩阵 + Reset 经济细节补完 (2026-07-01)

回应用户自检中识别的两个缺口（"Reset 经济学细节偏薄"、"Pattern 间冲突检测缺失"），本轮沉淀：

- **新增 [patterns/conflicts.md](patterns/conflicts.md)** — 18×18 Pattern/Optional 冲突矩阵（✅ / ⚠️ / ❌ 三态）+ 18 条冲突详档
  - **18 条冲突分布**：12 Pattern + 6 Optional 两两组合
  - **每条详档含**：冲突现象 / 真实出处（case 实证 or 理论冲突）/ 解决策略 / 反模式
  - **冲突等级**：6 条双 case 实证 / 10 条单 case 实证 / 2 条理论冲突
  - **覆盖核心冲突**：P-R × P-C7、P-P2 × P-PR、P-N × P-C·跨建筑、P-AME × P-E、O5 × O11 等
- **[patterns/README.md](patterns/README.md) 索引**新增 conflicts.md 链接 + "同时启用多个 Pattern 前先查此表"提示
- **[CONTRIBUTING.md](CONTRIBUTING.md) 新增"修改/新增 Pattern 时的冲突矩阵更新"段** — 强制要求 Pattern 改动同步更新冲突矩阵
- **[core/05-reset-systems.md](core/05-reset-systems.md) 补完 3 段 Reset 经济细节**（按游戏规模分档）
  - **收益区间参考**：短/中/超长三档游戏的 prestige currency 公式 / 永久项价格 / 收益可见性（参考 5 个 case 的实际数据）
  - **Reset 时间间隔参考**：首次/二次/3-5 次/6+/dark-future 各次 reset 的期望时长（带调试 log 方法）
  - **多 Currency 形态参考**：3 种形态（双 currency / 多 currency 池 / N 货币平行）+ 设计规则（数 ≤ 3 / 转换显式 / cap 独立 / shop 分离）

### 自检审计优化：Pattern reverse-link 修复 + O6 误标纠正 (2026-07-01)

完成自检中的 4 个高优先级优化点（P1-P3）：

- **[audit/deep_coverage.py](audit/deep_coverage.py) 重写搜索逻辑** — 改用 word-boundary 正则 + 多种 Pattern 代号格式（`Pattern R` / `P-R` / `pattern-r-rarity.md`），消除之前的两个 bug：
  - **误报 0 引用**：之前用 `text.count(short_name)` 对 3 字符 short 名（如 "ame"）做无词边界搜索 → false-negative。修复后 P-AME 在 upload-labs + gnorp 找到 4 refs / P-N 在 upload-labs 找到 1 ref / P-PR 找到 1 ref / P-C·跨建筑在 6 case 找到 16 refs / P-D 在 4 case 找到 13 refs
  - **避免过度泛匹配**：单字母短代号（`r` / `d` / `s` / `b` / `t` / `e` / `n`）必须以 `Pattern X` / `P-X` 格式引用才计数（避免误匹 "game" 中的 "ame"）
- **[cases/shelldiver/README.md](cases/shelldiver/README.md) §6 加 Pattern D reverse-link** — 把 §6 标题从 "Pattern S/T/B 全覆盖" 改为 "+ D 全覆盖"，framework 映射段加 5 行说明：oxygen 作为单限制资源跨挂 3_oxygen 模块 + 5/6 战斗伤害 = Pattern D 的实证。同步加 `数据源` 行到头部元信息表
- **[cases/README.md](cases/README.md) 新增"Pattern / Optional 引用约定"段** — 标准化 3 种引用格式（代号+长名+链接 / 纯代号 / 文件名）+ reverse-link 强制要求 + 给出"O6 误标判别规则"（短时加速+冷却 = O6 / 永久解锁 meta 倍率 = Pattern R / 短时主动切换类系天赋 = Pattern C7 镜像）
- **[cases/agrivore/README.md](cases/agrivore/README.md) §4 框架映射表修正 O6 误标** — Agrivore 的 7 个 SinType（Pride/Greed/Lust/Envy/Gluttony/Wrath/Sloth）是**永久解锁的 7 类 meta 倍率槽**，不符合 O6（短时加速 + 冷却）定义。改映射到 `patterns/pattern-r-rarity` (variant)，并显式标注 O6 为 ❌ 未使用
- **[cases/README.md](cases/README.md) Agrivore 摘要行同步去掉 + O6** — 配合 agrivore README §4 修正

**未做（避免范围蔓延）**：

- **P3 (docs/case-candidates.md 加 O14/O15/O16 决策)** 误判 — 检查后发现 [cases/dwarf-eat-mountain/derived/candidates.md](cases/dwarf-eat-mountain/derived/candidates.md) 已含 5 个候选（含 O14/O15/O16）的完整决策矩阵（评分 / 决策 / 理由 / 影响范围 / 下次触发条件），无需新建
- **agrivore metadata.json framework_evidence 字段** 未加 — 因 agrivore 整个目录尚 untracked（与本轮 audit 优化无关），留给后续轮次统一入 git 时再加


> ⚠️ **BREAKING: cases/ 目录结构重构** —— `cases/<game>.md` + `cases/data/<game>/` 合并为 `cases/<game>/{README.md, *.json, mapping.json, derived/}`。所有外部 fork / link / doc 引用会失效，需重新指向 `cases/<game>/README.md` 或 `cases/<game>/<filename>`。

### 框架臃肿度审计 + 工作流修复（2026-07-01）

完成首次框架臃肿度全面分析（[`audit/FRAMEWORK_BLOAT_ANALYSIS.md`](audit/FRAMEWORK_BLOAT_ANALYSIS.md)），结论：**框架本体 git 追踪 1.08 MB / 160 文件——非常精简**。`_tools/` 35 MB 是工作目录体积而非 git 追踪（已通过 `.gitignore` 显式忽略防误入）。

#### 修复的工作流缺陷

- **P0 根 README 漏 2 个新 case**：补全 [cases/agrivore/](cases/agrivore/README.md) + [cases/dwarf-eat-mountain/](cases/dwarf-eat-mountain/README.md) 的"应用案例"表 + 目录结构示意 + 简介段引用（应用案例计数从 5 改 7）
- **P1 `.github/workflows/ci.yml` 漏 2 个 check**：补 `case-to-framework-coverage.py --check` step（`run-all-checks.ps1` 已含此检查但未在 CI 直接调用）
- **P1 GAME_DESIGN_GUIDE M1 段"4 个 case"过期**：扩展到 7 个 case（新增 Gnorp/Agrivore/Dwarf Eat Mountain），加指回 [cases/README.md](cases/README.md) 的入口链接
- **P2 O6 状态不明**：从隐式"参考形态"升级为显式"## 状态"段，明确升格为"实证"需满足的 4 条特征 + 升格流程
- **基础设施 `.gitignore`**：新增，覆盖 `_tools/*/extracted/`（GMS/Unity 逆向工程的中间产物）+ Python `__pycache__` + OS 临时文件

#### 不修复项（用户决策）

- **O14/O15/O16（DEM 候选）暂不沉淀**：记录到 [cases/dwarf-eat-mountain/README.md](cases/dwarf-eat-mountain/README.md) 的 framework coverage 段，未来根据新 case 触发
- **5 个 Pattern reverse-link 缺失**（AME/N/PR/C·跨建筑/D 在 case 文件中找不到引用）：不是真正问题（Pattern 沉淀后即通用），但已在 [audit/FRAMEWORK_BLOAT_ANALYSIS.md §6.5](audit/FRAMEWORK_BLOAT_ANALYSIS.md) 记录为 P2 候选

#### 新增的审计基础设施

- `audit/measure.py` + `audit/measure_framework.py`：规模测量
- `audit/duplication_check.py`：case 引用一致性 + Pattern 引用计数
- `audit/quality_metrics.py`：占位符 / 案例 / Pattern 质量指标
- `audit/deep_coverage.py`：Pattern/Optional 在 case 文件中的深度引用矩阵
- `audit/overlap_check.py`：Jaccard 相似度文档重叠检测
- `audit/gdg_analyze.py`：GAME_DESIGN_GUIDE 结构分析
- `audit/FRAMEWORK_BLOAT_ANALYSIS.md`：完整分析报告

> **审计结论**：框架**一点也不臃肿**（1.08 MB 装 7 案例 + 13 pattern + 12 optional + 8 schema + 7 check script），反而是同类"设计沉淀型框架"中最精简的。
> 待解决的不是"内容臃肿",而是"工作流完整性"——5 处遗漏（README 2 + CI 2 + GDG 1 + O6 状态）。本 PR 修完这 5 处后,框架可视为"产品级"完整。

### P2/P3 跟进：沉淀工作流强化 (2026-07-01)

**P2 — reverse-link + 候选索引自动化**

- `scripts/case-to-framework-coverage.py` 增强:
  - `--check` 模式新增 **Pattern reverse-link 完整性** 守门 (缺失 → CI 失败)
  - 扫描所有含 README 的 case (含 upload-labs / kittens-game, 不限于 mapping.json)
  - 自动生成 `docs/case-candidates.md` — 分「命名候选」(O14+) 与「自动候选」(🆕/⚠️) 两区
  - README 章节噪声过滤增强 (跳过 Checklist / 数据来源等)
- `docs/case-to-framework-contribute.md` 更新: 引用 case-candidates.md + reverse-link CI 说明

**P3 — DEM 候选决策 + CHANGELOG 归档策略**

- 新增 [cases/dwarf-eat-mountain/derived/candidates.md](cases/dwarf-eat-mountain/derived/candidates.md) — 首份阶段 4 决策:
  - **O14** Multi-Phase Artifact → **推迟** (8/12, 等第 2 个实证)
  - **O15** Den Spawn → **推迟** (7/12)
  - **O16** Dwarf Units → **不沉淀** (case 独有)
  - Calamities / Special Mountains → **不沉淀** (< 6 分)
- 新增 [CHANGELOG/archive/README.md](CHANGELOG/archive/README.md) — 归档策略 (soft 600 / hard 900 行)
- 新增 `scripts/check-changelog-size.py` — CI 接入 (`run-all-checks.ps1` + `.github/workflows/ci.yml`)
- DEM README 补充 O15/O16 候选标注 + 链到 candidates.md

### 新案例：Dwarf Eats Mountain（GMS 2.3+ 矮人挖山 + 塔防 + 灾变）

新增 [cases/dwarf-eat-mountain/](cases/dwarf-eat-mountain/) 案例，覆盖 GameMaker Studio 2.3+ (GEN8 IFF) 引擎下的矮人挖山 + 塔防 + 灾变 + 6 终局山 + 三类神器 effect 玩法。

- 数据规模: **14 建筑 / 199 升级 / 124 artifacts / 102 prestige / 27 ore / 5 den / 30 calamity / 6 mountain / 10 dwarf** + 7 语言 (1236 EN keys)
- 9 大系统: resources / buildings+upgrades / artifacts (3 类 effect) / prestige / ores / dens / calamities / mountains / dwarves
- 6 货币 (gold/ore×27/mithril/PP/faith/soul) + 14 建筑 + 199 升级 + 124 artifacts (24 collect + 83 passive + 14 混合) + 102 prestige + 27 ore + 5 den + 30 calamity + 6 mountain + 10 dwarf
- **artifact 3 类 effect type 是新发现**：collect_only (24) / passive_only (83) / collect+passive (14) — 可作为 framework 候选 O14 (multi-phase artifact) 的实证
- 框架覆盖: **core + Pattern B / S / T + O5 (cross-run mithril/PP) + 候选 O14 (multi-phase artifact)**
- 数据源: `D:\program files (x86)\steam\steamapps\common\Dwarf Eat Mountain\data.win`（GMS GEN8 IFF 块解析）+ `DEM_loc.json` (JSON localization, 1236 keys)
- **提取方法**: GMS data.win 是 IFF/FORM 格式二进制（与 Unity 的 AssetBundle 完全不同），需自写 `extract_chunks.py` 解析 FORM/STRG/SCPT/OBJT 块结构。STRG chunk 占 56% 文件大小但内容大多是 Juju Adams ImGui/Gooey 库代码，游戏实体数据（artifact/building/prestige/ore/den/calamity/mountain）完全通过 **JSON localization** 提供
- 数据完整性: 本地化字符串 (1236 EN keys) + 实体 name/desc 完整; 具体数值（upgrade cost、artifact effect 数值、den HP 等）在 GMS bytecode 中，loc 不可见（已在 `metadata.json` 的 `data_completeness` 字段记录）
- 提取工具: `_tools/dem-extract/{extract_chunks,extract_strings,extract_taxonomy,analyze_*}.py`
- 验证: `python scripts/case-to-framework.py dwarf-eat-mountain --report` 生成 9 个 framework-view + `derived/missing-fields.md` 缺口报告 + `derived/coverage-report.md` (5 ✅ / 4 ⚠️)

### 新增：Case → Framework 贡献工作流（[docs/case-to-framework-contribute.md](docs/case-to-framework-contribute.md)）

跑完 case 后, 哪些内容值得反向沉淀到 framework? 此工作流提供 6 个阶段 + 4 类覆盖标记 + 4 维评分 + 4 种决策的标准化流程, 避免 framework 膨胀/挂名 pattern/沉淀污染.

- 新增 [docs/case-to-framework-contribute.md](docs/case-to-framework-contribute.md): 6 阶段 (完成度自检 → 差异分析 → 候选清单 → 决策矩阵 → 执行沉淀 → CI 接入) + 4 类覆盖标记 (✅/🆕/⚠️/❌) + 4 维评分 (通用性/复杂度/已实证/文档成本) + 4 种决策 (沉淀/部分/不沉淀/推迟)
- 新增 [scripts/case-to-framework-coverage.py](scripts/case-to-framework-coverage.py): 自动生成 `cases/<case>/derived/coverage-report.md` 报告 (4 类标记 + 框架映射过载检测 + 阶段 3 进入条件)
- [scripts/run-all-checks.ps1](scripts/run-all-checks.ps1) 接入 `--check` 模式, 阻止报告漂移
- [scripts/README.md](scripts/README.md) 追加 "Case → Framework 贡献工作流" 段
- 已为 4 个 case (agrivore / gnorp / shelldiver / tower-wizard) 生成初始覆盖度报告

### 新案例：Agrivore（Unity 6 增量农场 + 战斗 + 7 原罪）

新增 [cases/agrivore/](cases/agrivore/) 案例，覆盖 Unity 6 + Addressables 2.7.3 引擎下的增量农场 + 战斗 + 7 原罪 + 跨 run Treasury 玩法。

- 数据规模: **38 enum / 478 values** + 50 main data classes + 13 languages (625 EN strings)
- 9 大系统: resources / items / crops / sigils / set-bonus / sins / evolutions / unique-skills / quests+achievements
- 6 货币（coins + 4 seed + gems + crowns）+ 26 crops + 13 item types + 7 sins + 35 evolutions + 4 sigils + 1 set bonus + 5 lifetime stats
- 框架覆盖: **core + Pattern B / C / E / R / S + O6 (area-focus — 7 sins 实证)**
- 数据源: `D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\Managed\Assembly-CSharp.dll`（IL 反汇编 via monodis）+ `localization-string-tables-english(en)_assets_all.bundle`（Addressables bundle via UnityPy + AddressablesTools）
- **O6 实证**: 7 个 SinType (Pride/Greed/Lust/Envy/Gluttony/Wrath/Sloth) 是 optional/o06-area-focus.md 的第一个完整案例实证
- 数据完整性: enum + class field schema + localization 完整；ScriptableObject 实例数值（ItemSO.price, CropData.coinValue 等）从发布版 IL 无法提取（需 AssetRipper/ilspycmd），已在 `metadata.json` 的 `data_completeness` 字段记录
- 验证: `python scripts/case-to-framework.py agrivore --report` 生成 10 个 framework-view + `derived/missing-fields.md` 缺口报告

### 文档：精简反模式速查表

- [README.md](README.md) § 反模式：17 条跨模块速查 → 5 条最高频 + 指向 [docs/anti-patterns.md](docs/anti-patterns.md)
- [GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) § 7：新增同款 5 条跨模块速查；流程反模式（设计 / 实现 / 调优 / 上线后）保留为子节

### 工程：新增 pre-commit hook（本地一键校验）

- 新增 [scripts/install-pre-commit.ps1](scripts/install-pre-commit.ps1) 与 [scripts/install-pre-commit.sh](scripts/install-pre-commit.sh)
- [scripts/README.md](scripts/README.md) 追加 § 本地 pre-commit 集成

### 工程：新增案例元信息同步校验脚本（verify-case-metadata.py）

- 新增 [scripts/verify-case-metadata.py](scripts/verify-case-metadata.py)：校验 `metadata.json` ↔ case `README.md` 头部元信息
- CI 与 [scripts/run-all-checks.ps1](scripts/run-all-checks.ps1) 追加该门禁

### 工程：case-to-framework.py 新增 --report 缺口报告

- [scripts/case-to-framework.py](scripts/case-to-framework.py) 支持 `--report`，输出 `derived/missing-fields.md`

### 工程：schema 索引表自动生成（build-schema-index.py）

- 新增 [scripts/build-schema-index.py](scripts/build-schema-index.py)，维护 [schemas/README.md](schemas/README.md) 的 AUTO-GENERATED 索引段
- CI 追加 `--check` 模式防索引漂移

### 文档：O6 加参考形态模板段（无案例实证，显式标注非默认）

- [optional/o06-area-focus.md](optional/o06-area-focus.md) 末尾新增 § 参考形态
- [optional/README.md](optional/README.md) O6 索引行标注「参考形态，无实证」

### 重构：cases/ 目录结构（每个 case 一个子目录）

**问题**：`cases/` 原本形态是顶层 5 个 `.md` + 一个 `data/` 平行摆放,`data/` 下再分子目录。这种"md 平铺 + data 集中"形态:
- 同 case 文档与数据物理分离,读 case 时要在两个目录间跳转
- `cases/data/README.md` 与 `cases/README.md` 内容重叠,概念边界模糊
- 新人看 5 个 md 平铺容易误以为策划案也放这里(和上一个"策划案位置"问题叠加)
- 复制整个 case 启动新项目时(`cp -r cases/data/<game>/ my-game/data/`),文档不一起走

**修复**:**一个 case 一个子目录**——`cases/<game>/` 内部包含 `README.md` (实现式说明书) + 所有 `*.json` + `mapping.json` + `derived/` 派生视图,自包含。

具体改动：
- `cases/shelldiver.md` → `cases/shelldiver/README.md`
- `cases/data/shelldiver/*.json` → `cases/shelldiver/*.json`
- `cases/data/shelldiver/derived/` → `cases/shelldiver/derived/`
- (5 个 case 同理)
- `cases/data/README.md` 内容并入 `cases/README.md`(原独立文件删除)
- `cases/data/` 目录删除
- 所有文档中 `cases/<game>.md` / `cases/data/<game>/` 引用统一改为 `cases/<game>/README.md` / `cases/<game>/`
- `scripts/case-to-framework.py` 与 `scripts/validate-schemas.py` 中 `cases/data/` 写死路径改为 `cases/`
- `cases/README.md` 案例目录结构树、反模式表、复用方法段同步更新

**迁移影响**：
- 外部文档 / link 失效（指向 `cases/<game>.md` 或 `cases/data/<game>/` 的所有引用需改）
- 脚本 `cp -r cases/data/<game>/ my-game/data/` 改为 `cp -r cases/<game>/ my-game/`
- 之前 `cases/data/README.md` 引用改用 `cases/README.md`

### 文档：明确"策划案位置"约定

**问题**：[GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) 多处暗示 `cases/` 由框架维护者维护，但没有任何显眼警示，策划容易把自己的策划案当成"新 case"塞进 framework 的 `cases/`，导致内容耦合 + `git pull` 冲突。

**修复**：
- `GAME_DESIGN_GUIDE.md` § 1 总览表后加 ⚠️ 位置约定框（说明 `cases/` ≠ 策划案位置 + 两类文件的区分特征）
- `GAME_DESIGN_GUIDE.md` § 2 M0 段首加交付物路径提示（指到 `my-game/docs/`，反向引用 § 1 位置约定）
- `GAME_DESIGN_GUIDE.md` § 4「项目根目录推荐结构」段前加 ⚠️ 警示（说明 `my-game/` 不是 framework 子目录、常见两种放法、错误做法）
- `GAME_DESIGN_GUIDE.md` § 7 反模式表补 1 条：把新游戏策划案写进 framework `cases/`
- [CONTRIBUTING.md](CONTRIBUTING.md) §「新增 Case」段首加 ⚠️ 提示（说明本节是给 framework 维护者贡献 case 用的，不是策划写新游戏用的，并要求真实可查数据源）

**用户影响**：策划读 `GAME_DESIGN_GUIDE.md` 后应能直接看懂"策划案放到自己项目 `my-game/docs/`，不是 framework 的 `cases/`"，不需要读完所有章节自己拼。

### 修复轮回：文档/数据一致性修复（基于全框架审查）

**核心变更**：一次系统性审查发现 7 个 example config 与 schema 不匹配、12 个 case data 误用 `$schema`、CHANGELOG 伪同步、验收清单过时等致命/严重/中等级问题。本轮全部修复，并新增一套 CI 自动校验脚本防止回归。

> ⚠️ **破坏性变更（升 v2.0 候选）**：`schemas/status-effect.schema.json` 与 `schemas/cross-building-inspiration.schema.json` 从"单实体"改为"包装型"（顶层 `{effects:[...]}` / `{inspirations:[...]}`，单实体定义移入 `definitions`）。依赖旧单实体形态的外部用户需调整。

**Schema 修复（致命级）**：
| 文件 | 修复 |
|------|------|
| `schemas/upgrade.schema.json` | 修 `if/then` 真空为真 bug（`tier_jump`/`C1`/`core` 的 `if` 补 `required`，避免字段缺失时误触发）；新增 `tiers`/`max_tier`（Pattern T 显式序列）表示法，与 `curve`/`max_level` 二选一 |
| `schemas/permanent-upgrade.schema.json` | 修 `effect_type=grant` / `pattern=C` 的 `if` 真空为真 bug |
| `schemas/rarity.schema.json` | `skill_id=null → base_probability≤0.1` 约束加 `value_multiplier>1` 条件，不再误伤基础档（common） |
| `schemas/status-effect.schema.json` | 改包装型 `{effects:[...]}`，允许 `_note`/`_comment`；`$id` 去掉 `.local` |
| `schemas/cross-building-inspiration.schema.json` | 改包装型 `{inspirations:[...]}`，允许 `_note`/`_comment`；`$id` 去掉 `.local` |
| `schemas/multi-region.schema.json` | `$id` 去掉 `.local` |

**Example 修复**：`example-upgrades.json`（`category:core`→`skill`）、`example-tier-jump.json`（顶层 `tier_jump_skills`→`upgrades`）、`example-multi-region.json`（补 `$schema`）。7 个 example config 现全部通过对应 schema 校验。

**Case data 改造（Direction C）**：
- 从 12 个 case data 删除 `$schema`（原生字段名 ≠ 框架概念名，强校验必失败）
- 新增 `cases/data/{shelldiver,tower-wizard,gnorp}/mapping.json` 桥接"原生字段 → 框架 schema 概念"
- `cases/data/README.md` 新增 §原生字段 vs 框架概念，更新约定与反模式表
- `kittens-game`/`upload-labs` 的 `metadata.json` 补 `_source`

**CHANGELOG 伪同步修复**：`pattern-e-status-stack.md` 来源改为"通用战斗增量规律"、`example-status-effect.json` 与 `example-multi-region.json` 的 `_source` 改为"理论沉淀"，彻底清除残留的 Tower Wizard 引用。

**跨文档同步**：
- Shelldiver 稀有度 4 档 → 3 档（`pattern-r-rarity.md` 3 处 + 源行）
- 核心轴跳点统一：Shelldiver 跳 8→10、Gnorp 跳 9→10（`pattern-t`、`pattern-s`、根 README、`patterns/README.md`）
- `region-manager.md` 验收清单字段名对齐真实伪代码（tower_level/broken_wall_level 等）
- `kittens-game.md`：9 vs 8 挑战澄清（9 挑战，8 个可选 debuff + ironWill）；O11→O13（时间多周期）、O5 标注"部分实现"；§16 三个"候选模式"更正为"已正式纳入框架"（P2/C7/O13）
- 删除全部对不存在的 `core/01-game-loop.md` 的引用（7 处，改指 `core/README.md` 或 `core/03-production-lines.md`）
- `CONTRIBUTING.md` 模板占位符显式标注
- `optional/o01-chapter-gates.md` 新增 §字段约定（统一 `unlock_gate`，区分原生字段）

**反模式去重**：新增 `docs/anti-patterns.md` 作为唯一权威目录；根 README / `patterns/README.md` / `optional/README.md` 的反模式表加指向它的链接。

**新增 CI 脚本**（`scripts/`）：
| 脚本 | 作用 |
|------|------|
| `validate-schemas.py` | 校验 schema 合法 + example 通过 schema + mapping 结构 + case data 规范 |
| `verify-changelog.py` | CHANGELOG 同步声明编码为不变量，防伪同步回归 |
| `check-md-links.py` | 扫描全部 `.md` 内部链接，标记断链与已删除文档引用 |
| `case-to-framework.py` | 按 mapping 生成 case data 的"框架视图"（最佳努力工具） |
| `run-all-checks.ps1` | 本地一键跑全部门禁 |
| `.github/workflows/ci.yml` | push / PR 触发上述前三个校验 |

**验证**：`validate-schemas.py` / `verify-changelog.py` / `check-md-links.py` 三者均退出码 0（596 条内部链接全有效，7/7 example 通过 schema）。

---

### 增强 Pattern E + 新增 Pattern C·跨建筑 Inspiration 链（从 Gnorp 案例逆向抽取）

**核心变更**：把 Gnorp 案例中两个最具 framework 价值的机制沉淀为通用模式——新增 1 个 Pattern 变体 + 增强 1 个现有 Pattern。

**新增文件**：
| 文件 | 用途 |
|------|------|
| `patterns/pattern-c-cross-building-inspiration.md` | 新 Pattern C·跨建筑变体：源建筑达成条件 → 目标建筑单位获永久被动/事件增益（4-tuple 模板 + 互斥/可叠加 + 3 类触发） |
| `schemas/cross-building-inspiration.schema.json` | 跨建筑 Inspiration 的 JSON Schema（draft-07） |
| `examples/configs/example-cross-building-inspiration.json` | 4 个示范 inspiration（引用上述 $schema） |
| `examples/pseudocode/inspiration-resolver.md` | `resolve()` 伪代码（Python + TypeScript）：互斥槽 + 可叠加链 |

**增强文件**：
- `patterns/pattern-e-status-stack.md`：追加 `## 5 段式衰减时序` 章——把"何时衰减"显式建模为 `decay_strategy` 字段（`tick`/`time`/`charge`/`event`/`element-gated`），由 Gnorp 5 种 status effect（Fire/Ice/Vulnerability/Zybe/Acid）实证。明确 Pattern E 的两个正交维度 = `stacking_policy`（施加累加）× `decay_strategy`（消退时序）。

**为什么抽取这两个**：
- 跨建筑 Inspiration：原 O4（纯数值跨轴）/ O8（5 类辅助）/ core06 Pattern C（广义条件专精）都没有"建筑 A 启发建筑 B 单位 + 触发条件 + 互斥/可叠加"的标准模板。Gnorp 11 个 inspiration + 6 source building 是最完整实证。
- 5 段式衰减：原 Pattern E 只描述了 1 种衰减时序（tick + decay_start 公式），缺少"用错时序类型"的反模式警告。Gnorp 5 status 各用不同时序，正好补全。

**索引更新**：
- `patterns/README.md`：模式索引表 + 依赖图 + 跨模式反模式表 + 引言段
- `schemas/README.md`：Schema 索引表新增 1 行
- `examples/README.md`：伪代码表 + 对照表 + 配置表各新增 1 行
- `README.md`：根反模式表新增 2 行（用错 status 衰减时序 / 跨建筑 source 与 target 同建筑）

**数据源**：`cases/data/gnorp/inspirations.json`（11 inspiration）+ `cases/data/gnorp/status-effects.json`（5 status）+ `cases/gnorp.md` §5/§9。

---

### 新增案例: (the) Gnorp Apologue（11 个数据 JSON + 1 个实现说明书）

**核心变更**: 新增 `cases/gnorp.md` + `cases/data/gnorp/*.json` 11 个文件——把 Steam 游戏 **(the) Gnorp Apologue**（App ID 1473350, by Myco）作为第 5 个 case 集成进框架。

**数据规模**：
| 维度 | 数量 | 来源 |
|------|------|------|
| 资源货币 | 3（Shards + Loose/Stored Zybellium + Talent Points） | gnorp.wiki.gg → Physical_Shards/Zybellium |
| 物理资源 | 2（Physical Shards + Baby Drones） | gnorp.wiki.gg |
| 建筑 | 14 | 14 个 wiki page |
| Gnorp 类型 | 8（Slammer/Runner/Mountaineer/Bomber/Rifle/Gatle/Zygnorp/Drone） | Gnorp page |
| Status Effect | 5（Fire/Ice/Vulnerability/Zybe/Acid） | Status_Effects page |
| Talents | 41（5 default + 6 group×6 gated，含 6 free passives） | Talents page |
| Inspirations | 16（6 source buildings） | Inspiration + 各 building |
| Compression | 10 + 1（Railgun Finale trigger） | Compression page |
| Upgrade | ~75 | 14 building pages |
| Achievements | 17（含 7+ hats） | TrueSteamAchievements + Steam 指南 |
| 成本曲线 | C1/C2/C3/C4/C5/C6 全部实证 | 整合公式 |
| 时空循环 | Speedrun Mode（20 TP 起始）+ Epilogue 2025-2026 beta 占位 | gnorp.dev devlog |

**framework 映射**（11 Pattern + 12 Optional 全实证）：
- Pattern B/C/D/E/P/R/S/T 全部触发，Pattern E（5 status effect stack）是最丰富的案例
- Optional O1/O2/O3/O4/O5/O6/O7/O8/O9/O10/O11/O13 全部触发，O13（Speedrun + Epilogue）是新增的多循环实证
- C1-C6 全部有具体公式实例（X-rockets C2 5.0^n 是 framework 反模式警告的真实案例）
- Talent Stone = framework `core/06 permanent-upgrade` 完美单轨 reset
- Compression 1-10 = framework `O2 endgame progress bar` 阶梯 cap 范本

**反模式自检**：
- C1 sink（Build Housing）有 Prestige 配套 ✓
- 永久项含乘法/指数（35 talents,非纯加法）✓
- 5 状态 stack 上限合理（no upper limit，但只有 1 DOT）✓
- DOT 走主伤害链（acid 2x dmg 走同一 chain）✓
- O11 区域 < 10 活跃（14 建筑,使用时通常 8-10 活跃）✓

**索引更新**：
- `README.md` 新增 gnorp 案例行（应用案例表 + 反模式引用）
- `cases/README.md` 新增 gnorp 案例索引行
- 目录树新增 `cases/gnorp.md` 和 `cases/data/gnorp/` 节点

**数据源**：gnorp.wiki.gg (78 articles) + Steam Community guides (100% Gnorp, Build for C10, High Collection, Gnorping your way into C10) + gnorp.dev devlog (#1-#22) + TrueSteamAchievements API + incrementaldb.com。多源交叉验证,所有数值已 ≥ 2 源比对;只 3 个细节(G.E.E.T. 公式细节 / Capacity 曲线 / reclamation rate 指数底数)在数据 JSON 中标注 `_inferred: true`。

---

### 新增策划侧工作流文档 GAME_DESIGN_GUIDE.md（778 行）

**核心变更**：新增 [GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md)——给策划/设计师使用的完整工作流手册，区别于 [CONTRIBUTING.md](CONTRIBUTING.md) 给程序员的"如何贡献"。

**文档结构**（8 节）：
1. 总览：工作流的两条路径（新游戏 / 中途修改）
2. 新游戏立项：M0-M7 共 8 个阶段（选题 → 选 case → DAG → 时间轴 → 勾 Pattern → 填 JSON → 实现 → 调优）
3. 中途修改：5 类典型场景（数值平衡 / 加新内容 / 加新系统 / 改核心循环 / 性能 bug）
4. 里程碑检查点与交付物清单（每阶段必填项 + 推荐项目根结构）
5. 数据/文档/代码的同步策略（边界 + 4 条同步规则）
6. 决策树：何时引入 Pattern / Optional（按"问题 → 触发条件 → Pattern"）
7. 常见陷阱与反模式（4 阶段：设计 / 实现 / 调优 / 上线后）
8. 附录：参考资源、公式速查、工程师对接清单、30 分钟/10 分钟上手指南

**关键设计**：
- 用 "M0-M7" 命名 8 个立项阶段（与 Core 02-06 编号风格一致）
- 5 类中途修改场景对应不同紧急度（小/中/大/极大/技术债）
- 决策树用 ASCII 树状图展示"问题 → Pattern"路径
- 工程师对接清单直接对接 [examples/pseudocode/](examples/pseudocode/) 的 5 个伪代码

**索引更新**：
- `README.md`（根）新增 "🎯 策划侧工作流" 段落，引导策划先读 GAME_DESIGN_GUIDE.md
- `README.md` 目录树新增 `GAME_DESIGN_GUIDE.md` 节点

---

### 目录结构优化（7 项修复）

经框架结构审计，识别 7 项可优化点，全部修复：

**高优先级**：
1. **upload-labs 派生索引隔离**：4 个派生 JSON（`upgrades_by_category` / `windows_by_category` / `windows_by_group` / `research_tree`）从 `cases/data/upload-labs/` 移入 `cases/data/upload-labs/derived/`，与源数据隔离。同步更新 `README.md` / `cases/README.md` / `cases/upload-labs.md` / `patterns/pattern-n-node-pipeline.md` / `CHANGELOG.md` 中所有引用路径。
2. **examples 伪代码 ↔ 配置对照表**：[examples/README.md](examples/README.md) 新增 "伪代码 ↔ 配置对照表" 段，将 5 个伪代码与 6 个配置示例按"框架概念"维度映射成 7 行表，明确"无伪代码"配置（如 example-rarity）的角色（仅展示数据形态，不展示运行逻辑）。

**中优先级**：
3. **cases/data 总索引**：新增 [cases/data/README.md](cases/data/README.md)（56 行）—— 4 个 case 的元信息表 + 目录结构约定 + 复用方法 + 反模式。
4. **元数据同步约定**：[cases/README.md](cases/README.md) 新增"元数据同步约定"段，明确"`cases/<case>.md` 头部元信息表"必须与 `data/<case>/metadata.json` 保持一致；冲突时**以数据为准**。
5. **O12 缺号说明**：[optional/README.md](optional/README.md) 在 O 模块索引后新增"关于 O12 缺号"说明——O12 编号有意保留空位（曾规划"全局事件系统"模块，因 O4/O8/O10 已覆盖而被废弃）。

**低优先级**：
6. **根级文档顺序说明**：[README.md](README.md) 目录树末尾新增"根级 4 个 .md 按阅读顺序排列（不是字母序）"的注释，避免读者疑惑。
7. **schema 命名约定**：[schemas/README.md](schemas/README.md) 新增"命名约定"小节——单数 entity（`upgrade.schema.json`）/ 复数 collection（`constants.schema.json`）/ 修饰前缀（`permanent-upgrade`）/ 不缩写。

**审计结果**：
- 47 个 .md 文件，69 个 .json 文件
- 69 个 JSON 全部解析通过
- 0 失效内部链接（`CONTRIBUTING.md` 中的 2 个 `xxx` 占位符为有意保留的模板示例）
- 跨文档引用路径已全部同步

---

### Upload Labs 案例内容整合到框架（3 个新 Pattern + 24 个真实数据文件）

**核心变更**：基于 `cases/upload-labs.md` 的真实实证，沉淀 3 个新 Pattern（AME / N / PR）。所有内容来自 [LibreSeed-Labs 源码](https://github.com/Official-Husko/LibreSeed-Labs) 解析（Godot 4 GDScript + 20 个 JSON 数据文件，基于 Upload Labs v1.0.9）。

**新增 3 个独立 .md 文件**：

| 文件 | 描述 |
|------|------|
| `patterns/pattern-ame-3tuple-attribute.md` | **Pattern AME** 3-tuple 属性统一（`[a, m, e]` 三元组 + 单一 `Attribute.add()` 引擎，15 行核心类） |
| `patterns/pattern-n-node-pipeline.md` | **Pattern N** 节点流水线图（玩家摆放 + 配线 + 6-type transfer engine） |
| `patterns/pattern-pr-service-soft-reset.md` | **Pattern PR** Service 软重置（代币消费触发单 sub-tree refund + 可选 window 销毁） |

**新增 1 个实现式案例**：

| 文件 | 数据规模 |
|------|---------|
| `cases/upload-labs.md` | 8 货币 / 57 属性 / 103 window / 86 升级 / 47 research / 18 perk / 3 milestone / 24 achievement / 42 request / 7 boost / 3 service 软重置 |
| `cases/data/upload-labs/*.json` | 24 个数据文件 + 3 个索引（24×13 + 3 = 327 KB），含 `metadata.json` / `currencies.json` / `attributes.json` / `resources.json` / `windows.json` / `upgrades.json` / `research.json` / `perks.json` / `milestones.json` / `services.json` / `boosts.json` / `achievements.json` / `requests.json` / `stats.json` / `files.json` / `storage.json` / `symbols.json` / `themes.json` / `connectors.json` / `guides.json` / `source_code.json` + 3 索引 |

**Upload Labs 关键事实（实证）**：
- 8 货币：5 个 non-produced（hack_point / corporation_data / government_data / optimization_point / application_point）通过研究树 gating
- 103 window 跨 7 类（cpu=22, network=15, gpu=16, hacking=12, coding=18, research=5, utility=13）
- 86 upgrade 跨 6 类（_uncategorized=9, main=31, hacking=8, breach=6, optimizations=22, applications=10）
- 47 research node，1 根（`research`），4 主分支
- 3 milestone（cost_inc=100，steepest in game），18 perk（cost_inc=1，linear）
- 3 service 软重置（hack_reset / optimization_reset / application_reset）
- 14-bit file variation bitflag × 6 base file = 84 变体
- 单一 cost 公式 `price = base × 10^cost_e × cost_inc^level × price_multiplier`
- 单一 attribute 引擎 `Attribute.add(a, m, e, e_count)`，所有 5 个 progression table 共享

**索引更新**：
- `patterns/README.md` 模式索引从 8 个扩到 11 个（+AME / +N / +PR），依赖图新增 1 条主支 + 2 个分支
- `optional/README.md` "实战 Pattern 集成"表新增 2 行（O5 + AME、O11 + N），新增"软重置变体（O7 变体）"小节
- `README.md`（root）案例计数从 3 改 4，Pattern 计数从 6 改 11，"实战模式"列表新增 5 个 Pattern 项，"应用案例"表新增 1 行

**验证**：所有新增 / 修改的 .md 文件已通过文本完整性检查，框架内链引用均指向已存在的 .md 文件。

---

### Kittens Game 案例内容整合到框架（3 个新 Pattern + 4 个补充小节）

**核心变更**：基于 `cases/kittens-game.md` 的真实实证，沉淀 3 个新 Pattern 和 4 个现有 Pattern / Optional 的小节补充。所有内容来自 [https://gitee.com/likexia/cat-zh](https://gitee.com/likexia/cat-zh) 源码（19 个 JS 文件）。

**新增 3 个独立 .md 文件**：

| 文件 | 描述 |
|------|------|
| `patterns/pattern-p2-dual-prestige.md` | **Pattern P2** 双 prestige 货币（paragon 单局 + burnedParagon 跨局，各自 cap / 公式） |
| `patterns/pattern-c7-opt-in-debuff.md` | **Pattern C7** 自选永久 debuff（8 challenge toggle 换 paragon 加速） |
| `optional/o13-temporal-multicycle.md` | **O13** 时空多层循环（4 季节 × 5 年色 × 3 周期 = 60 日历状态） |

**补充 4 个现有 Pattern / Optional 小节**：

| 文件 | 新增小节 | 来源 |
|------|---------|------|
| `patterns/pattern-e-status-stack.md` | 经济轴 Permanent Effect 变体（6 键命名约定 + getEffect 单聚合器） | `core.js:getEffect()` + 137 workshop upgrade |
| `patterns/pattern-r-rarity.md` | 非掉落型分档变体（资源 type 字段 4 档，58 资源实证） | `js/resources.js:resourceData` |
| `optional/o01-chapter-gates.md` | 资源门槛 Gate 小节（`unlockScheme: { name, threshold }`） | `js/buildings.js:buildingsData.unlockScheme` |
| `optional/o05-bottleneck-balance.md` | 折扣上限规则小节（`getLimitedDR(discount, 1.0)` 截断到 100%） | `js/buildings.js:getPricesWithAccessor` |

**索引更新**：
- `patterns/README.md` 模式索引从 6 个扩到 8 个（+P2 / +C7），依赖图新增 2 条支路
- `optional/README.md` 模块索引从 11 个扩到 12 个（+O13），"实战 Pattern 集成"表新增 2 行

**验证**：所有新增 / 修改的 .md 文件已通过文本完整性检查，框架内链引用均指向已存在的 .md 文件。

---

### Upload Labs 案例新增（基于 LibreSeed-Labs 真实源码）

**核心变更**：新增 Upload Labs 案例，基于 [LibreSeed-Labs](https://github.com/Official-Husko/LibreSeed-Labs) 仓库的 GDScript 源码 + 20 个 JSON 数据文件（Godot 4 引擎，基于 Steam 上 *Upload Labs* v1.0.9 逆向）。所有数据通过 `gh-proxy.com` 加速克隆，使用 Python 解析 18 个核心 JSON（trailing-comma 容错）。

**Source acquisition**：
- 仓库：`https://github.com/Official-Husko/LibreSeed-Labs`（社区开源重构版，GitHub 13 stars）
- 加速：通过 `gh-proxy.com` 镜像，~28 秒克隆 2233 文件
- 引擎：Godot 4.x；脚本：~95 个 .gd 文件

**24 个提取数据文件**：
- 8 currencies / 57 attributes / 103 windows / 86 upgrades / 47 research / 18 perks / 3 milestones
- 24 achievements / 42 requests / 7 boosts / 3 services / 6 file types / 6 storage / 4 themes / 11 connector colors
- 3 索引（现位于 `data/derived/`）：upgrades_by_category / windows_by_category / windows_by_group + research_tree
- 1 case-metadata + 1 source-code summary + 1 guides

**核心发现**（成为新 Pattern 基础）：
- 单一 attribute 引擎 `Attribute.add(a, m, e, e_count)`，所有 progression 共享
- 单一 cost 公式，4 种 cost_inc 变体（1 / 10 / 100 / 2000）
- 6-type transfer engine 统一 95 个 node 的资源流转
- 3 service 软重置（区别于 hard prestige）— token-paid partial refund
- 14-bit file variation × 6 base file = 84 变体

---

### Kittens Game 案例新增（基于 gitee.com/likexia/cat-zh 真实源码）

**核心变更**：新增 Kittens Game (猫国建设者) 案例，基于 `https://gitee.com/likexia/cat-zh`（v1.4.6.2d，19 个 JS 源文件 ~778 KB）的真实源代码。所有数值、字段、unlocks 关系、公式均直接从源码解析。

**新增 13 个真实数据 JSON**（`cases/data/kittens-game/`）：

| 文件 | 来源 | 内容 |
|------|------|------|
| `metadata.json` | `js/*.js` 全文件 + README | 案例元信息（标题/版本/数据源/JS 文件大小） |
| `resources.json` | `js/resources.js:resourceData` | 58 资源（43 common / 3 uncommon / 5 rare / 7 exotic） |
| `buildings.json` | `js/buildings.js:buildingsData` | 39 建筑 + priceRatio 1.10-2.50 |
| `techs.json` | `js/science.js:techs` | 62 tech + 多系统 unlocks 链 |
| `upgrades.json` | `js/workshop.js:upgrades` | 137 workshop 升级（49KB） |
| `religion.json` | `js/religion.js:religionUpgrades + transcendenceUpgrades` | 10+10 宗教/超脱升级 |
| `space.json` | `js/space.js:programs` | 13 太空计划 |
| `time.json` | `js/time.js:chronoforgeUpgrades + voidspaceUpgrades` | 7+6 时空升级 |
| `prestige.json` | `js/prestige.js:perks` | 37 转生 perk |
| `challenges.json` | `js/challenges.js:challenges` | 9 挑战模式 |
| `diplomacy.json` | `js/diplomacy.js:races` | 8 种族（蜥蜴/鲨鱼/狮鹫/娜迦/斑马/蜘蛛/龙/利维坦） |
| `calendar.json` | `js/calendar.js:seasons` | 4 季节 × 5 颜色 × 3 周期 |
| `village.json` | `js/village.js:jobs + traits` | 8 工作 + 8 小猫特质 |

**新增 1 个案例说明书**：`cases/kittens-game.md`（16 节 / ~358 行 / 描述 9 平行轨道 + 单一 `getEffect()` 聚合器 + 价格公式 + 跨周期转生）。

**新候选 Pattern（3 个）**：
- **Pattern P2 双向转生货币** — `paragon`（单局）+ `burnedParagon`（跨局）双轨，公式 `getParagonProductionRatio` + `getParagonStorageRatio`。
- **Pattern C7 自选永久 debuff** — 8 挑战模式让玩家自选永久减益换取 `paragon` 奖励。
- **Optional O13 时空多层循环** — 4 季节 × 5 年色 × 3 周期 = 60 个独立日历状态，每状态有独立乘区。

**框架 README 与 cases/README 更新**：
- 案例数量 2 → 3。
- 目录结构树展示 `cases/data/kittens-game/*.json`。
- 表格新增 kittens-game 行（58 资源 / 39 建筑 / 62 科技 / 137 升级 / 8 行星 / 8 种族）。
- cases/README.md 案例目录结构同步更新。

**数据获取方式**：从 gitee 克隆仓库 → Python 解析 `js/*.js` 源文件中各 array 块 → 提取 name/label/prices/effects/unlocks 字段 → 写入 JSON → 通过浏览器 CDP 验证 `window.game` 全局对象中运行时状态。

---

### Tower Wizard 案例恢复（基于 Steam 真实数据）

**核心变更**：恢复 Tower Wizard 案例（基于 `D:\Program Files (x86)\Steam\steamapps\common\Tower Wizard\docs\` 真实可查的解包数据），并把之前被错误"中性化"的 Pattern E / O11 / O5 重新标注为 Tower Wizard 来源。

**触发原因**：上一轮基于"D:\Projects\Skills\Tower Wizard 目录不存在"误判 Tower Wizard 数据已丢失，错误地删除 case 并把实证模式中性化。本轮确认 Steam 安装目录的 `docs/` 仍完整可用（15 个 .md + 6 个 .json），恢复案例。

**新增 14 个真实数据 JSON**（`cases/data/tower-wizard/`）：

| 文件 | 来源 | 内容 |
|------|------|------|
| `metadata.json` | docs/README.md + overview.md | 案例元信息（标题/引擎/数据源） |
| `resources.json` | docs/resources.md | 11 个资源 + 通用 add_resource 流程 |
| `tower-progression.json` | docs/tower-progression.md + constants.json | 10 档塔层 + 11 条升塔成本 |
| `regions.json` | docs/tower-progression.md §主要区域 | 12 区域 + 跨区域绑定 |
| `status-effects.json` | docs/combat-and-walls.md + other.json | 5 状态 + 衰减公式 |
| `walls.json` | docs/combat-and-walls.md + constants.json | 4 墙 + HP + 破墙逻辑 |
| `skills.json` | docs/data/skills.json | 80 技能 ID + 5 脚本类型 |
| `blessings.json` | docs/data/blessings.json | 40 祝福 + 9 分类 |
| `nations.json` | docs/data/nations.json | 22 国家 + 绑定产出 |
| `trainings.json` | docs/data/trainings.json | 4 训练 + 跨区域乘区 |
| `prestige.json` | docs/prestige.md + constants.json | 双轨转生 + cap 公式 |
| `progression-bars.json` | docs/progression-systems.md | 3 副进度条 + cap 曲线 |
| `qol.json` | docs/utilities.md + constants.json | 长按 / 监督 / flat / 数字格式 |
| `combat-multipliers.json` | docs/resources.md + combat-and-walls.md + production.md | 战斗 / 产出 / 资源 全部乘区链 |

**新增**：

- `cases/tower-wizard.md` — 完整 15 节实现式说明书
- `cases/README.md` — 改为 2 个 case（shelldiver + tower-wizard），无对比矩阵

**framework 文档恢复来源标注**：

- `patterns/pattern-e-status-stack.md` — 来源从"通用规律"改回 [cases/tower-wizard.md](cases/tower-wizard.md) — 5 状态实证
- `optional/o11-multi-region.md` — 来源从"通用规律"改回 Tower Wizard 12 区域实证
- `optional/o05-bottleneck-balance.md` — 数值参考标注"来自 Tower Wizard Balance 祝福"
- `schemas/multi-region.schema.json` — 字段名从 `region_level`/`challenge_threshold` 改回 `tower_level`/`broken_wall_level`（O11 实证字段名）
- `examples/configs/example-multi-region.json` — `_source` 改回 Tower Wizard 实证
- `examples/configs/example-status-effect.json` — 状态名改回 `weakened`/`frost`/`molten`/`cursed`/`resonance`（Tower Wizard 实证状态名）
- `examples/pseudocode/region-manager.md` — 字段名改回 `tower_level`/`broken_wall_level`

**framework 文档同步索引**：

- `README.md` — 应用案例章节追加 Tower Wizard 行；目录结构图改 2 个 case
- `patterns/README.md` — 来源标注改为"Shelldiver + Tower Wizard"
- `optional/README.md` — O5 / O11 行追加"Tower Wizard 实证"标签

**framework 覆盖度**（Tower Wizard 用到的模块）：

| 模块 | 实证方式 |
|------|---------|
| Pattern B / S / T / E | 5 脚本类型 + Doubling 祝福（跳 +2） + 80 技能 |
| O1 / O2 / O3 / O4 / O5 / O6 / O7 / O8 / O9 / O10 / O11 | 10 档塔层 + 3 副进度条 + 4 墙 + Destruction 跨轴 + Balance 双层瓶颈 + Supervision 0.2s + 双轨 Reset + 22 国家 / 4 训练 + 长按 + 5 阶段 + 12 区域 |
| core 1-6 | 完整循环 |

Tower Wizard 是 framework 的**高覆盖度案例**——除 Pattern D（双资源池）外几乎覆盖了所有模块。

---

## 上一轮迭代

### ⚠️ 案例合规修正（去虚构 + 去对比 + 数据真实化）

**核心变更**：删除无法核实数据的游戏案例；保留并重建 Shelldiver 案例（基于 `ShellDiversGameplay/gameplay.json` 真实数据）。

**关键约定**：

1. **case 数据必须基于真实可查的源**——游戏的逆向数据 / 官方 API / 源代码
2. **case 不需要做对比**——只写本 case 自己的内容

**删除**：

- `cases/tower-wizard.md` + `cases/data/tower-wizard/`（12 个 JSON）—— 数据源已丢失（**此判断有误，本轮已恢复**）
- 案例对比矩阵（`cases/README.md`）—— 本约定不要求做对比

**重写 Shelldiver 案例**（基于 `ShellDiversGameplay/gameplay.json` 真实字段）：

- 删去 5 个虚构数据文件：`biovalue.json`（虚构 Reset）/ `dual-pool.json`（虚构 oxygen 双资源池）/ `perm-upgrades.json`（虚构永久升级）/ `pacing.json`（虚构节奏表）/ `combat-multipliers.json`（虚构伤害公式）/ `jellyfish.json`（原 12 水母列表有错） / `upgrades.json`（与 skills.json 重叠）
- 新增 4 个真实数据文件：`metadata.json`（标题/引擎/Steam ID/数据源）/ `modules.json`（11 个模块 + 复杂度）/ `resources.json`（6 货币 + 4 技能生命周期）/ `fields.json`（87 个 bonus_* 字段按 module 归类）/ `objects.json`（17 对象 + 13 成就）
- 保留 3 个文件并基于真实数据重写：`biomes.json`（4 生态区 shallows/glacial/swamp/magma）+ `rarity.json`（3 档 Silver/Gold/Rainbow，无"普通"档）+ `skills.json`（88 个技能 = 4 core / 50 secondary / 33 toggle / 26 unlock）

**关键事实更正**：

| 之前 | 真实 |
|------|------|
| 4 生态区：shallows/kelp/deep/abyss | shallows/glacial/swamp/magma |
| 4 档稀有度：普通/Silver/Gold/Rainbow | **3 档** Silver/Gold/Rainbow（无"普通"档） |
| 12 水母 | 12 sprite + 沼泽 6 变体 = 18 种 |
| 核心轴跳 9→10 | 跳 8→10（`tiers = [1..8, 10]`） |
| 68 技能 | **88 技能** |
| 4 资源货币 | **4 资源货币 + flask = 5** + 主货币 = 6 总 |
| 双资源池 oxygen_max | oxygen 是单轴升级，非双资源池（虚构） |
| 双轨 Reset (Prestige + Biovalue) | **无 Reset 系统**（gameplay.json 无 reset/run_points/perm_/ascension 字段） |
| 8 永久升级项 | **无永久升级系统** |

**framework 文档同步清理**：

- `README.md` — 应用案例章节删去 Tower Wizard 行；目录结构改 `cases/shelldiver/shelldiver.md` + `cases/shelldiver/data/`
- `patterns/README.md` — 来源标注改为"Shelldiver + 通用规律沉淀"
- `optional/README.md` — 移除"Tower Wizard"题材示例
- `optional/o05-bottleneck-balance.md` — 数值参考改为"示例"，删除 Tower Wizard 来源标注
- `optional/o11-multi-region.md` — 来源改为"通用规律"，删除 11 区域列表引用，案例指向 Shelldiver 4 区
- `patterns/pattern-e-status-stack.md` — 来源改为"通用战斗增量设计规律"，删除 Tower Wizard 5 状态引用
- `examples/configs/example-status-effect.json` — `_source` 改为"理论沉淀"
- `examples/configs/example-multi-region.json` — `_source` 改为"理论沉淀"

---

## 上一轮迭代

### Pattern E · Status Stack 沉淀（通用规律）

配套新增：

- [schemas/status-effect.schema.json](schemas/status-effect.schema.json) — JSON Schema 定义
- [examples/configs/example-status-effect.json](examples/configs/example-status-effect.json) — 5 种状态配置示例
- [examples/pseudocode/apply-status-effect.md](examples/pseudocode/apply-status-effect.md) — Python + TypeScript 伪代码

### Optional O11 · Multi-region 沉淀（通用规律）

新增 [optional/o11-multi-region.md](optional/o11-multi-region.md) — **多区域子系统**：

- **设计原则**：区域独立性（专属资源 / 升级 / UI / 图腾）+ 跨区域全局性（训练 / 派系 / 遗物 / 祝福走全局乘区）
- **慢变量**：区域数 = 节奏控制旋钮，建议 ≤ 8 个活跃区域
- **解锁 Gate**：资源 Gate / 成就 Gate / 复合 Gate（多条件 AND）
- **区域监督**：点击区域激活 0.2s 监督（与 O6 区域焦点互补）

配套新增：

- [schemas/multi-region.schema.json](schemas/multi-region.schema.json) — JSON Schema 定义（含 region / gate / global_multiplier 三个 definition）
- [examples/configs/example-multi-region.json](examples/configs/example-multi-region.json) — 6 个区域 + 4 个跨区域乘区配置示例
- [examples/pseudocode/region-manager.md](examples/pseudocode/region-manager.md) — Python + TypeScript 伪代码

### 强化 O5 · Bottleneck Balance（两档乘区）

[optional/o05-bottleneck-balance.md](optional/o05-bottleneck-balance.md) 强化为**两档乘区（Focus + Broad）**：

- **Focus（焦点）**：当前最缺资源的专属大幅加成 — **复合乘区**（focus × broad 同时生效）
- **Broad（广谱）**：当前活跃资源集合的温和加成 — **单层乘区**
- **数值参考（示例）**：Wood/Stone/Magic/Ore focus=150%/级，Knowledge focus=100%/级，广谱=30%/级
- **永久项配置示例**：JSON 格式，含 `resource_focus` 和 `resource_broad` 两个永久升级

新增反模式段（O5 单层乘区、focus × broad 加法、瓶颈只看单一资源、广谱按主流资源配等）。

### 主 README 更新

- 实战模式索引追加 Pattern E（6 个 Pattern）
- Optional 模块索引追加 O11（11 个 Optional）
（原应用案例章节中 Tower Wizard 行已删除）
- 目录结构图同步更新（patterns/、optional/、examples/、schemas/ 4 个模块各 +1~2 文件）
- 阅读路径补 Pattern E + O11
- 反模式表追加 4 条新模式反模式（Pattern E 加法、DOT 独立伤害链；O5 单层乘区、focus × broad 加法；O11 区域独立引用、区域数 >10）
- 落地 Checklist MVP 段追加 Pattern E 建议

### patterns/README.md 更新

- 命名约定段补 Pattern E 命名含义
- 模式索引表追加 E 行（依赖 o03-challenge-axis）
- 模式依赖图扩展（追加 Pattern E 节点 + 来自 o11 的箭头）
- 启用建议段补 MVP / 进阶 / 终局三档建议（Pattern E 标注"强烈推荐"）
- 反模式表追加 2 条 Pattern E 反模式

### optional/README.md 更新

- 模块索引追加 O11 行（"系统规模与多区域"分类）
- 推荐引入顺序：战斗增量 / 资源采集 / 复杂战斗多区域三类新增 Pattern E + O11 建议
- 实战 Pattern 集成表追加 O5（Pattern C）+ O11（Pattern E）2 行
- 反模式表追加 O5 / O11 反模式共 5 条

### schemas/README.md / examples/README.md 更新

schemas 与 examples 索引同步追加新条目。

---

## 目录重组（历史）

按用户意图，从扁平结构重组为分层目录：

**之前**（扁平结构）：
```
incremental_game_framework/
├── README.md
├── 02-resources.md
├── 03-production-lines.md
├── 04-upgrade-economy.md
├── 05-reset-systems.md
├── 06-permanent-upgrades.md
├── optional-o1-chapter-gates.md
├── optional-o2-endgame-progress-bars.md
├── ...（共 16 个 .md 扁平放置）
└── （无 cases / examples / schemas）
```

**之后**（分层结构）：
```
incremental_game_framework/
├── README.md
├── CHANGELOG.md                    # 新增
├── CONTRIBUTING.md                 # 新增
├── core/                            # 新目录
│   ├── README.md                    # 新增
│   ├── 02-resources.md
│   ├── 03-production-lines.md
│   ├── 04-upgrade-economy.md
│   ├── 05-reset-systems.md
│   └── 06-permanent-upgrades.md
├── patterns/                        # 新目录
│   ├── README.md                    # 新增
│   ├── pattern-r-rarity.md          # 从 02 抽出
│   ├── pattern-d-dual-pool.md       # 从 03 抽出
│   ├── pattern-s-skill-tiers.md     # 从 04 抽出
│   ├── pattern-b-binary-unlock.md   # 从 04 抽出
│   └── pattern-t-tier-jump.md       # 从 06 抽出
├── optional/                        # 新目录（重命名）
│   ├── README.md                    # 新增
│   ├── o01-chapter-gates.md         # 重命名 optional-o1-...
│   ├── o02-endgame-progress-bars.md
│   ├── o03-challenge-axis.md
│   ├── o04-cross-axis-feedback.md
│   ├── o05-bottleneck-balance.md
│   ├── o06-area-focus.md
│   ├── o07-dual-reset-track.md
│   ├── o08-support-systems.md
│   ├── o09-interaction-qol.md
│   └── o10-pacing-milestones.md
├── cases/                           # 新目录
│   ├── README.md                    # 新增
│   └── shelldiver.md                # 从 README 抽出
├── examples/                        # 新目录
│   ├── README.md                    # 新增
│   ├── pseudocode/                  # 新增
│   │   ├── add-resource.md
│   │   ├── gain-xp.md
│   │   └── purchase.md
│   └── configs/                     # 新增
│       ├── example-upgrades.json
│       ├── example-permanent.json
│       ├── example-rarity.json
│       └── example-tier-jump.json
└── schemas/                         # 新目录
    ├── README.md                    # 新增
    ├── upgrade.schema.json
    ├── permanent-upgrade.schema.json
    ├── rarity.schema.json
    └── constants.schema.json
```

### 破坏性变更

#### 文件重命名

| 旧 | 新 |
|----|----|
| `optional-o1-chapter-gates.md` | `optional/o01-chapter-gates.md` |
| `optional-o2-endgame-progress-bars.md` | `optional/o02-endgame-progress-bars.md` |
| `optional-o3-challenge-axis.md` | `optional/o03-challenge-axis.md` |
| `optional-o4-cross-axis-feedback.md` | `optional/o04-cross-axis-feedback.md` |
| `optional-o5-bottleneck-balance.md` | `optional/o05-bottleneck-balance.md` |
| `optional-o6-area-focus.md` | `optional/o06-area-focus.md` |
| `optional-o7-dual-reset-track.md` | `optional/o07-dual-reset-track.md` |
| `optional-o8-support-systems.md` | `optional/o08-support-systems.md` |
| `optional-o9-interaction-qol.md` | `optional/o09-interaction-qol.md` |
| `optional-o10-pacing-milestones.md` | `optional/o10-pacing-milestones.md` |
| `02-resources.md` | `core/02-resources.md` |
| `03-production-lines.md` | `core/03-production-lines.md` |
| `04-upgrade-economy.md` | `core/04-upgrade-economy.md` |
| `05-reset-systems.md` | `core/05-reset-systems.md` |
| `06-permanent-upgrades.md` | `core/06-permanent-upgrades.md` |

#### 内容提取（从 Core 抽出 Pattern）

| 原文档 | 抽出内容 | 新位置 |
|--------|---------|--------|
| `core/02-resources.md` | Pattern R 概率叠加资源 | `patterns/pattern-r-rarity.md` |
| `core/03-production-lines.md` | Pattern D 双资源池共享 | `patterns/pattern-d-dual-pool.md` |
| `core/04-upgrade-economy.md` | Pattern S 成长轴分档 | `patterns/pattern-s-skill-tiers.md` |
| `core/04-upgrade-economy.md` | Pattern B 二进制开关 | `patterns/pattern-b-binary-unlock.md` |
| `core/06-permanent-upgrades.md` | Pattern T 等级跳跃 | `patterns/pattern-t-tier-jump.md` |
| `optional/o04-cross-axis-feedback.md` | 稀有度概率叠加案例 | 替换为引用 patterns/ |
| `optional/o09-interaction-qol.md` | 等级跳跃 UX 提示 | 保留并指向 patterns/ |
| `optional/o10-pacing-milestones.md` | Shelldiver 节奏表 | 简化为引用 cases/ |
| `README.md` | Shelldiver 完整映射表 | `cases/shelldiver.md` |

### 新增

- `CHANGELOG.md` — 本文档
- `CONTRIBUTING.md` — 贡献指南
- `core/README.md`、`patterns/README.md`、`optional/README.md`、`cases/README.md`、`examples/README.md`、`schemas/README.md` — 子目录索引
- `examples/pseudocode/{add-resource, gain-xp, purchase}.md` — 关键算法伪代码
- `examples/configs/example-*.json` — 数据配置示例（4 个）
- `schemas/*.schema.json` — JSON Schema 定义（4 个）
- `cases/shelldiver.md` — Shelldiver 完整案例

---

## 历史

### 实战 Pattern 沉淀

首次沉淀来自 [Shelldiver 案例](cases/shelldiver.md)（原逆向数据保存在 framework 外部，现已迁移到 `cases/data/shelldiver/`）：

- **Pattern R**（稀有度叠加）：4 级稀有度 + biovalue 元倍率
- **Pattern D**（双资源池）：oxygen_max → 时长 + 武器伤害
- **Pattern S**（成长轴分档）：16 核心 / 35 次要 / 17 开关
- **Pattern B**（二进制开关）：1-2 级机制解锁
- **Pattern T**（等级跳跃）：跳 9→10 的质变点

### 框架原档（5 篇 Core + 10 个 Optional）

继承自先前版本：
- 资源分层（DAG）
- 统一入库（add_resource + global_multiplier）
- 5 种产线触发器（T1-T5）
- 6 种成本曲线（C1-C6）
- 3 种 Reset Cap 模式（Cap-1/2/3）
- 4 种永久加成类型 + Pattern C 条件专精
- 10 个 Optional 模块（O1-O10）
