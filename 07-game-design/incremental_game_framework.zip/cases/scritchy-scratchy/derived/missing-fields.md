# scritchy-scratchy — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## resources.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `xp_cap` | 局内有卡牌/玩家等级感（Mini Scratch XP），但无 framework xp_cap 表 |
| `tier_costs` | 无统一 tier_costs；升级用相对 cost_band |

## upgrades.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 3

| 字段 | 说明 |
|------|------|
| `cost` | 仅 cost_band（low/medium/high/very_high），无原始 Cash 数值 |
| `currency` | 全部用 cash；framework 视图需补 currency=cash |
| `tiers` | 多数为线性 1-time 节点，非 Pattern T 多层 stack |

## prestige.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `stacking` | 各节点 1 次购买，无 stack |
| `effect_value_schema` | effect 为自然语言字符串 |

## cards.json

- **Schema**: `../../../schemas/rarity.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `drop_weights` | 无公开权重表；Luck 只描述性影响 |
| `prize_tables` | Addressables 未提取 |

## gadgets.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | gadget 解锁成本在升级树/成就路径，未单独表 |
| `effect_value` | 角色描述级 |

## achievements.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 1

| 字段 | 说明 |
|------|------|
| `api_name` | Steam API name 未抓取（仅展示名） |
