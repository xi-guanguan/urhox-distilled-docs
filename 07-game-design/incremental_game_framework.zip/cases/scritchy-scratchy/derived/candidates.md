# Scritchy Scratchy — Framework 候选贡献评估（Stage 3–4）

> 由 [docs/case-to-framework-contribute.md](../../../docs/case-to-framework-contribute.md) 流程生成。  
> **评估日期**: 2026-07-13  
> **决策原则**: 1 实证不足不上 Optional；题材皮肤不进 core。

---

## 候选 1: Scratch-Card Peek / Trap Reveal

- **来源**: `cards.json` — worm / black cat / plastic bag；peek 后 trash 免罚
- **framework 现状**: 无「部分揭示 + 条件惩罚」schema；O9 仅交互 QoL
- **评分**:
  - 通用性: 2/3（赌场/刮卡/盲盒题材常见；纯矿工 idle 少见）
  - 复杂度: 2/3（zone + symbol + full_reveal_trigger）
  - 已实证 case: 1/3（仅本 case）
  - 文档成本: 2/3
  - **总分**: 7/12
- **决策**: **推迟**
- **理由**: 可先用 case 内 `shared_mechanics.peek_technique` 文档化；等第 2 个「可 peek 的惩罚符号」case 再考虑 Optional。
- **影响范围**: 0

---

## 候选 2: Risky Automation NPC（Mundo）

- **来源**: `gadgets.json` — Mundo 可破产玩家或打出 super jackpot
- **framework 现状**: automation 假定正收益；无「助手有破产风险」抽象
- **评分**:
  - 通用性: 2/3
  - 复杂度: 2/3
  - 已实证 case: 1/3
  - 文档成本: 2/3
  - **总分**: 7/12
- **决策**: **不沉淀**
- **理由**: 高度绑定「猫助手」题材与成就设计；用 README + 成就描述即可。与 DEM calamity 类似，优先不膨胀 framework。
- **framework_evidence**: `intentionally-not-contributed`

---

## 候选 3: Final Chance as Prestige Ticket

- **来源**: `prestige.json` — 用一张「必刮转生票」触发 reset
- **framework 现状**: core/05 prestige 已覆盖「触发器 + 货币 + 永久树」
- **评分**:
  - 通用性: 3/3（触发器皮肤多样）
  - 复杂度: 1/3（已有模型）
  - 已实证 case: 3/3（多 case 已有 prestige）
  - 文档成本: 1/3
  - **总分**: 8/12（但**无需新模块**）
- **决策**: **不沉淀（复用）**
- **理由**: 票面只是 trigger UX；写入 case README 作为 prestige trigger 变体即可，不新开 Pattern。

---

## 候选 4: O9 Desk UI（已覆盖）

- **来源**: `ui-layout.json` 1920×1080
- **决策**: **已沉淀路径 — 复用 O9**
- **理由**: 桌面 + 多面板 + Spacebar/Fan 正是 O9 实证，补 case 不补新 Optional。

---

## Stage 4 汇总

| 候选 | 决策 |
|------|------|
| Peek / trap reveal | 推迟 |
| Mundo risky NPC | 不沉淀 |
| Final Chance trigger | 不沉淀（复用 core prestige） |
| Desk UI | 复用 O9 |

**Stage 5**: 本 case **不执行** framework 文件新增。
