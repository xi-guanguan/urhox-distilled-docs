# Scritchy Scratchy — 刮刮卡增量 + 自动化桌面 + JP Prestige 游戏设计指南

> **来源 / `_source`**: `D:\Program Files (x86)\Steam\steamapps\common\Scritchy Scratchy\` (Unity IL2CPP GameAssembly.dll + ScritchyScratchy_Data/StreamingAssets/aa Addressables + Unity Localization bundles) + community wiki scritchyscratchy.wiki + Steam App 3948120 public data  
> **data_source**: `D:\Program Files (x86)\Steam\steamapps\common\Scritchy Scratchy\`  
> **提取方法**: 本地安装实测分辨率；玩法/卡牌/JP 树/成就交叉核对公开 wiki 与 Steam 成就表（IL2CPP 托管名已剥离，无法 dnfile）  
> **案例版本**: 增量游戏框架 case Stage 1–4；游戏 2026-03-18 Steam 正式版

| 字段 | 值 |
|---|---|
| title | Scritchy Scratchy — 刮刮卡增量 + 自动化桌面 + JP Prestige 游戏设计指南 |
| engine | Unity (IL2CPP) + Addressables + Unity Localization |
| 开发者 | Lunch Money Games |
| 发行商 | Funday Games |
| Steam App ID | 3948120 |
| 发布 | 2026-03-18 |
| 商店 | https://store.steampowered.com/app/3948120/Scritchy_Scratchy/ |
| main_modules | 8 |
| 刮刮卡（已文档） | 11 |
| Catalogue | 4 |
| 局内升级类 | 6 |
| 永久 JP 升级 | 8 |
| Steam 成就 | 34 |
| UI 分辨率 | 1920×1080 |
| 预计时长 | 5–7h 主线 / 15–20h 全成就 |

---

## 1. 游戏概述

**Scritchy Scratchy** 是一款以**真实鼠标拖拽刮涂层**为核心操作的增量 / idle 游戏：买票 → 刮开 → 获奖或踩陷阱 → 买局内升级与自动化 → 刮 **Final Chance** 转生换 **Jack Points (JP)** → 永久树加速下一局。

与纯点击器不同，**peek（边角预览）+ Trash** 让陷阱卡成为技术层，而不是纯 RNG。

## 2. 核心循环（实现视角）

```text
[Cash] buy ticket → scratch (manual / Bot / Mundo)
        → prize | trap penalty | trash
        → spend Cash on 6-category upgrades + gadgets
        → farm jackpots (esp. Scratch My Back jellyfish) for JP yield
        → full-scratch Final Chance → reset run → spend JP on 8 permanents
        → faster next run (Head Start / Luck / Bot from start / …)
```

Headless 重建时：**刮擦几何可抽象为「揭示进度 + 区符号表」**；peek = 读区符号而不触发 full-reveal penalty；Bot = 队列消费者。

## 3. 系统一览（8 modules）

详见 [`metadata.json`](./metadata.json) `main_systems`。

| # | 系统 | 数据文件 | Framework |
|---|------|----------|-----------|
| 1 | 货币 Cash / JP / Tokens | [`resources.json`](./resources.json) | core/02 |
| 2 | 4 Catalogue 刮刮卡 | [`cards.json`](./cards.json) | rarity 近似 + 风险态 |
| 3 | 6 类局内升级 | [`upgrades.json`](./upgrades.json) | upgrade.schema |
| 4 | Bot / Mundo / Fan… | [`gadgets.json`](./gadgets.json) | automation + O9 |
| 5 | Final Chance → JP 树 | [`prestige.json`](./prestige.json) | permanent-upgrade.schema |
| 6 | 34 成就 | [`achievements.json`](./achievements.json) | constants |
| 7 | 破产 / 贷款 / 结局分支 | README + prestige/cards | risk gate |
| 8 | 桌面 UI | [`ui-layout.json`](./ui-layout.json) | **O9** |

### 3.1 资源

- **Cash**：局内主货币；陷阱扣款、贷款、破产都作用于此。  
- **JP**：仅 Final Chance prestige 与 jackpot 加成产出；买 8 永久节点。  
- **Night Market Tokens**：外观（成就 Visit the Night Markte / Walk-in-closet）。

### 3.2 卡牌

公开可核：Quick Cash（S / 无陷阱）、Apple Tree / Lucky Cat（蠕虫 / 黑猫）、Scratch My Back（水母 / 塑料袋）、Snake Eyes、The Bomb、Final Chance。社区票库另列 Two Win / Mini Scratch / Sand Dollars 及 Catalogue 1–2 成本（见 `cards.json` `_source`）。Catalogue 3–4 名称表不完整 → `data_completeness` 已标。

### 3.3 局内升级（prestige 重置）

优先序（wiki）：**Luck → Scratch Power → Area → Auto Scratcher → Multipliers → QoL**。Spacebar Confirm 在**最右升级树底部左侧**。

### 3.4 自动化

Scratch Bot 队列 + Mundo（可破产 / 超巨奖）+ Fan/Trash 风控。永久 **Scratch Memory** 让第二局起手即有 Bot。

### 3.5 Prestige（8 JP 节点）

| 节点 | JP | 效果摘要 |
|------|-----|----------|
| Head Start Capital | 10 | 开局 $500 |
| Lucky Legacy | 15 | +15% 永久 Luck |
| Scratch Memory | 20 | 开局解锁 Auto Scratcher |
| Speed Demon | 20 | 开局 Scratch Power tier 2 |
| Golden Hands | 25 | +25% 奖金 |
| Jackpot Magnet | 30 | 巨奖频率 ×2 |
| Banco | 35 | 转生后首局禁破产 |
| Recycler Pro | 15 | 丢弃返还 10% |

### 3.6 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑画布 | 1920×1080 | Unity player `globalgamemanagers` / level 资产 |
| UI 栈 | uGUI + Addressables | `ScritchyScratchy_Data` |
| 主隐喻 | 桌面刮卡台 | 中央刮区 + 侧栏目录/升级树 |

```text
+---------------------------- 1920 x 1080 -----------------------------+
| HUD: Cash | Jack Points                                              |
+--------+----------------------------------------------+--------------+
| Cat.   |           SCRATCH STAGE（鼠标拖拽刮涂层）      | Upgrade     |
| 1–4    |           [confirm / trash / Space]            | trees ×4    |
| buy    |                                                |             |
+--------+----------------------------------------------+--------------+
| Gadgets |           Scratch Bot queue / stack                         |
+----------------------------------------------------------------------+
| （模态）JP Prestige 树 / Night Market / Settings                      |
+----------------------------------------------------------------------+
```

组件树（catalogue / scratch_stage / upgrade_trees / bot_queue / prestige）见 `ui-layout.json → components`。对照 **O9**；与 DEM 侧栏战场不同，本作为 **中央交互台 + 双则栏**。

不入库截图 / sprite；部分 panel `rect` 为 **inferred**（须读 `basis`）。

## 4. 映射与派生

- 桥接表：[`mapping.json`](./mapping.json)  
- 生成：`python scripts/case-to-framework.py scritchy-scratchy --report`  
- 覆盖报告：[`derived/coverage-report.md`](./derived/coverage-report.md)  
- 沉淀候选：[`derived/candidates.md`](./derived/candidates.md)

## 5. 数据完整度诚实声明

| 项 | 状态 |
|----|------|
| 引擎 / 1920×1080 | complete（measured） |
| 8 JP 永久升级 + 费用 | complete（wiki） |
| 34 成就名+描述 | complete（公开表） |
| 卡牌成本 | partial（社区 DB） |
| 局内升级精确 Cash 价 | incomplete（仅 cost_band） |
| Catalogue 3–4 全名 | incomplete |
| IL2CPP 类型 / Addressables 实例 | incomplete |

## 6. Framework 反模式自检

- 未把「刮涂层手感」升格为独立 Pattern（输入层，属 O9/引擎）。  
- 未虚构 Catalogue 3–4 卡名或未核对数值。  
- Night Market 外观不进 core 货币模型。

## 7. 文件清单

```text
cases/scritchy-scratchy/
├── README.md
├── metadata.json
├── resources.json
├── cards.json
├── upgrades.json
├── gadgets.json
├── prestige.json
├── achievements.json
├── ui-layout.json
├── mapping.json
└── derived/
    ├── coverage-report.md
    ├── candidates.md
    ├── missing-fields.md
    └── framework-view/
```
