﻿# 案例 · Tower Wizard

> **目标**：演示**如何用本框架从零实现 Tower Wizard 这类巫师建塔 + 魔法召唤 + 破墙终局游戏**。
> 所有数值、字段、技能清单均来自 `Tower Wizard.pck` 解包后的 GDScript 脚本 + `.res` 资源（真实可查的逆向数据），详见 [./metadata.json](./metadata.json) §data_files。

| 元信息 | 值 | 来源 |
|--------|----|------|
| 标题 | Tower Wizard | metadata.title |
| 开发商 | Barribob | overview.md |
| 发售 | 2025-06-19 | overview.md |
| 引擎 | Godot 4.2.3 | extraction.md |
| 资源 | 80 技能 / 40 祝福 / 22 国家 / 4 训练 / 112 其它 | data/*.json |
| 塔层 | 10 档（NO_TOWER → FINAL_TOWER） | tower-progression.md |
| 区域 | 12 个（Orb/Study/Forest/Building/Prestige/Academy/Alchemy/Embassy/Sorcery/Temple/Observatory/Dragon Nest） | tower-progression.md |
| 资源货币 | 11 个（Magic/Spirits/Knowledge/Wood/Building Points/Magic Gold/Blank Rune/Cosmic Dust/Cosmic Analysis/Totems/Trade Agreements） | resources.md |
| 状态效果 | 5 种（Cursed/Molten/Frost/Weakened/Resonance） | combat-and-walls.md |
| 墙体 | 4 堵（云墙 20M / 太阳墙 5B / 宇宙墙 ×2 INF） | constants.json |
| 转生 | 双轨（Magic Prestige 16 上限 + Damage Prestige） | prestige.md |
| 副进度条 | 3 个（Alchemy / Temple / Rune Tree） | progression-systems.md |
| 界面布局 | 640×330 结构可复原（O9） | [./ui-layout.json](./ui-layout.json) |

---

## 1. 塔层系统（10 档 + 升塔成本）

完整 → [./tower-progression.json](./tower-progression.json)

```text
tower_level 0  NO_TOWER              仅法球
tower_level 1  FIRST_TOWER           第一座塔
tower_level 2  TOWER_WITH_STUDY      书房（知识）
tower_level 3  TOWER_WITH_FORESTRY   森林（木材）
tower_level 4  TOWER_WITH_PRESTIGE   转生区域
tower_level 5  TOWER_WITH_BUILDING   建造（建筑点）
tower_level 6  TOWER_WITH_ALCHEMY    炼金（魔法金）
tower_level 7  TOWER_WITH_SORCERY    巫术；第一堵墙（云墙）可攻击
tower_level 8  TOWER_WITH_RUNES      符文；第二堵墙（太阳墙）
tower_level 9  TOWER_WITH_TEMPLE     神殿；第三堵墙（宇宙墙）
tower_level 10 FINAL_TOWER           最终升天 / 结局
```

**升塔成本表**（来自 `constants.json → tower_costs`）：

| 升层 | 成本 | 额外条件 |
|------|------|---------|
| 0→1 | 30 magic | — |
| 1→2 | 1,300 magic | — |
| 2→3 | 13,000 magic | — |
| 3→4 | 350,000 magic + 20,000 wood | — |
| 4→5 | 4,000,000 magic + 150,000 wood | — |
| 5→6 | 500,000,000 magic + 15,000,000 wood | — |
| 6→7 | 1,000,000,000,000 magic + 500 magic_gold | — |
| 7→8 | 免费 | 需破云墙 (broken_wall_level ≥ 1) |
| 8→9 | 免费 | 需破太阳墙 (broken_wall_level ≥ 2) |
| 9→10 | 42 cosmic_dust | 需 broken_wall_level == 2 |
| 9→10 (Final Ascension) | 50 cosmic_dust | 需 broken_wall_level == 3 |

**升塔奖励**：每升一层获 4 building_points（Final Ascension 3× 倍率）。

**framework 映射**：

- 用 `optional/o01-chapter-gates.md` 实现 — `tower_level` 抽象为 O11 的 `region_level`
- 7→8 / 8→9 是**复合 Gate**：资源 = 0 + 破墙条件 = O1 复合 Gate
- 9→10 是**双条件 Gate**：cosmic_dust 资源 + broken_wall_level 状态

---

## 2. 区域子系统（O11 完整版 — 12 区域）

完整 → [./regions.json](./regions.json)

```text
tower_level 0  orb                    法球、灵体环绕、云灵
tower_level 2  study                  法术书 → 知识
tower_level 3  forest                 德鲁伊 → 木材
tower_level 4  prestige               本 run 转生经验
tower_level 5  building               小房/树屋/书屋、建筑点
tower_level 5  academy                贤者、训练
tower_level 6  alchemy                炼金 → Magic Gold
tower_level 6  embassy                外交、贸易协定
tower_level 7  sorcery                符文、战斗单位
tower_level 7  observatory_warden     分析与守墙
tower_level 9  temple                 神殿 → Cosmic Dust
tower_level 9  dragon_nest            龙能力、龙息
```

**关键观察**：本案例是 O11 的**完整实证**——12 个活跃区域、每个有独立解锁、独立产线、独立 UI、专属资源。同时**跨区域乘区**（训练 / 派系 / 符文 / 祝福）走 `global_multipliers`（详见 [./regions.json](./regions.json)）。

**framework 映射**：

- 用 `optional/o11-multi-region.md` 实现
- 12 个区域是 O11"≥10 条产线时按区域分组"的明确案例
- 22 国家是 O11 跨区域乘区的实证（每个国家绑定 1 个区域的产出线）

---

## 3. 资源系统（11 个货币）

完整 → [./resources.json](./resources.json)

```text
primary
  └─ magic           Magic           法球 / 云灵 / 龙息
intermediate
  ├─ spirits         Spirits         消耗 Magic 召唤
  ├─ knowledge       Knowledge       书房法术书
  └─ wood            Wood            森林砍树
advanced
  ├─ building_points Building Points 升塔 / 部分技能
  ├─ magic_gold      Magic Gold      炼金满级
  ├─ blank_rune      Blank Rune      符文树满级
  ├─ cosmic_dust     Cosmic Dust     神殿满级
  └─ cosmic_analysis Cosmic Analysis 分析墙体等技能
tactical
  ├─ totems          Totems          雕刻
  └─ trade_agreements Trade Agreements 外交
```

**通用入库**（来自 `resources.md §通用入库`）：

```text
add_resource(resource, base_amount):
    若 base_amount <= 0 → 0
    若 no_bonuses == false:
        actual = base_amount × get_resource_bonuses(resource)
    累加到 _accumulated_resources（下一帧结算并触发 resource_added 信号）
```

**第一个灵体成本 = 201 magic**（来自 `constants.json → spirit_cost_first_level`），这是开局的"硬门槛"。

**Spirit Debt 祝福**（来自 `blessings.json → spirit_debt_blessing`）：开局 `Spirits = -spirit_debt.debt_amount`（负数起手）。

**framework 映射**：

- 用 `core/02-resources.md` 实现
- 11 资源按 4 类分层（primary/intermediate/advanced/tactical）
- 资源 4 技能链结构在 **Skills 章节** 体现

---

## 4. 战斗与墙体（O3 实证）

完整 → [./walls.json](./walls.json)

### 4.1 4 堵墙

| broken_wall_level | 名称 | max_health | 可攻击条件 |
|-------------------|------|-----------|----------|
| 0 | 云墙 | 20,000,000 | tower_level ≥ 7（Sorcery） |
| 1 | 太阳墙 | 5,000,000,000 | tower_level ≥ 8（Runes） |
| 2 | 宇宙墙 | INF | tower_level ≥ 9（Temple） |
| 3 | 宇宙墙（终局） | INF | tower_level ≥ 9 + Warden 恢复 |

**重要**：**宇宙墙 HP = INF**（来自 `constants.json`）—— 这是与 Shelldiver 完全不同的设计：

- **Shelldiver**：水母是密度挑战，**无 HP 墙**（gameplay.json 无 wall/boss/HP 字段）
- **Tower Wizard**：前 2 墙是 HP 墙（20M / 5B），**后 2 墙 HP=INF**（靠 Cosmic Dust 资源体系）

### 4.2 伤害乘区链

来自 `combat-and-walls.md §伤害乘区 get_damage_multiplier()`：

```text
damage_multiplier =
    (1 + midway_blessing.damage_increase/100 × 等级)
  × (1 + weakened.stacks × weakened.percent_increase/100)         # Pattern E
  × (1 + combat_magic等级 × combat_magic.percent_increase/100)
  × Janand国家（若有外交）                                          # O11 跨区域
```

**framework 映射**：

- HP 墙（云墙 / 太阳墙）用 `optional/o03-challenge-axis.md` 实现
- INF 墙用 `O3` + `O11` 复合——HP 不可破，但 cosmic_dust 资源可推进
- 伤害乘区链 = 祝福 × 状态 × 技能 × 国家（4 个乘区相乘）

---

## 5. 状态效果系统（Pattern E 实证 — 5 种）

完整 → [./status-effects.json](./status-effects.json)

```text
cursed     Cursed
molten     Molten
frost      Frost
weakened   Weakened
resonance  Resonance
```

**添加逻辑**（`combat-and-walls.md §添加`）：

```text
add_status_effect(def, stacks):
    effect.stacks += stacks
```

**衰减公式**（`combat-and-walls.md §衰减` + `constants.json → status_effect_decay`）：

```text
decay_start = blessing_of_effects.decay × 祝福等级      # constants: 75
若 effect != Frost:
    decay_start += Frost层数                              # Frost 不被 Frost 衰减

decay = ((max(0, stacks - decay_start)) / 100) ^ 1.15
stacks = max(0, stacks - decay)

每 0.1s tick 跑一次衰减
```

**伤害乘区集成**（状态叠加在战斗乘区链上）：

```text
damage_multiplier ×= (1 + weakened.stacks × weakened.percent_increase/100)
```

**framework 映射**：

- 用 `patterns/pattern-e-status-stack.md` 实现（直接实证）
- 5 种状态对应 5 个 `StatusEffectDef`（在 `other.json` 中）
- Frost 是**特殊状态**：自身不被 Frost 衰减，但叠加到其他效果的 decay_start

---

## 6. 技能系统（80 个 — Pattern S/T/B 全覆盖）

完整 → [./skills.json](./skills.json)

### 6.1 5 种技能脚本类型

| 脚本 | 数量（估计） | 公式 | framework 映射 |
|------|------------|------|---------------|
| `SkillDefScaling` | 多数 | `base × multiplier^level` | core/04 C1-C3 曲线 |
| `SkillDefSingle` | 多个 | `max_level=1`（固定成本） | Pattern B 一次性 |
| `SkillDefSpirit` | 灵体召唤 | `level=1: 201 magic；level≥2: 200 + 0.7 × L^(2.1+0.23×L^0.4) × 0.9` | Pattern S 特殊曲线 |
| `SkillDefGold` | 金币型 | `round(1,000,000 × (1 + level²))`，max_level=100,000 | core/04 C1 慢成长 |
| `RuneSkillDef` | 符文 | `cost = depth`（树深度） | Pattern T 跳级 |

### 6.2 Spirit 召唤成本曲线

来自 `skill-costs.md`：

| 灵体等级 | 约消耗 Magic |
|---------|-------------|
| 1 | 201（固定） |
| 10 | ~1,400 |
| 50 | ~8,500 |
| 100 | ~28,000 |

成本指数增长，**单靠单 run 约在 ~100 灵体附近触顶**，需转生抬高天花板。

### 6.3 Pattern T 跳级 — Doubling 祝福

来自 `blessings.md §Doubling 祝福`：

- Cloudling / Spirit Tome / Druid 每次 purchase 等级 +2 而非 +1
- 这等同于**Pattern T 跳级**（每升 1 次跳 2 级）

**framework 映射**：

- `SkillDefScaling` → `core/04-upgrade-economy.md`（C1-C3 曲线）
- `SkillDefSingle` → `patterns/pattern-b-binary-unlock.md`
- `SkillDefSpirit` → `patterns/pattern-s-skill-tiers.md`（特殊曲线）
- `Doubling` → `patterns/pattern-t-tier-jump.md`（跳级）

---

## 7. 祝福系统（40 个 — Pattern C 实证）

完整 → [./blessings.json](./blessings.json)

### 7.1 40 个祝福

| 分类 | 代表 |
|------|------|
| 线性 percent | `magic_gain_blessing`, `knowledge_blessing`, `forestry_blessing`, `prestige_blessing` |
| 复合 ^% | `blessing_of_compounding`, `blessing_of_compounding_2` |
| Population / N / Few | `blessing_of_population`, `blessing_of_n`, `blessing_of_few`, `blessing_of_n_2` |
| Tower 套装 | `blessing_of_the_tower` / `_2` / `_3` / `_4` |
| Destruction | `blessing_of_destruction`, `blessing_of_destruction_2` |
| Supervision | `blessing_of_supervision`, `blessing_of_oversight` |
| Doubling | `doubling_blessing` |
| Totems | `sage_totem_blessing`, `crafting_totem_blessing` |
| 特殊 | `spirit_debt_blessing`, `blessing_of_curses`, `midway_blessing`, `runecraft_blessing`, `alchemy_blessing` |

### 7.2 祝福结构

```text
cost = 1                    # 每级消耗转生点
max_level                   # 可点满级数
point_requirement           # 解锁所需已花转生点
automatic                   # 自动生效、不可手动点
is_sorcery                  # 巫术相关 UI 分类
```

### 7.3 Destruction 祝福

来自 `blessings.md §毁灭祝福`：

```text
damage_level = floor(log10(DPS))     # DPS ≤ 0 → 0
percent_bonus = damage_level × blessing_of_destruction.percent_increase
若 Compounding祝福 > 0:
    percent_bonus ×= (1 + blessing_of_compounding.percent_increase/100) ^ damage_level
last_bonus = 1 + percent_bonus / 100
```

`last_bonus` 乘入：云灵魔法、木材、知识、炼金 XP、符文 XP 等多条产出链（**O4 跨轴反馈**实证）。

### 7.4 Supervision 祝福

来自 `blessings.md §监管祝福` + `constants.json → supervision.bless_duration`：

```text
点击某区域后 bless 该区域；0.2s 内该区域获得 supervision
sorcery 区域: 1 + Supervision等级 × blessing_of_supervision.sorcery_increase/100
其他: 1 + Supervision等级 × blessing_of_supervision.percent_increase/100
```

**framework 映射**：

- 40 个祝福 = `core/06-permanent-upgrades.md`（祝福 = 转生点购买的永久升级）
- Population / N / Few = `patterns/pattern-c-permanent-upgrades.md`（条件专精）
- Destruction 跨轴反馈 = `optional/o04-cross-axis-feedback.md`
- Supervision = `optional/o06-area-focus.md`（O11 让 O6 区域化）

---

## 8. 训练系统（4 个 — 跨区域乘区）

完整 → [./trainings.json](./trainings.json)

```text
magic_101      Magic 101        → 云灵魔法（Orb）
herbology      Herbology        → Forest（木材乘区）
alchemy_101    Alchemy 101      → Alchemy（炼金 XP）
dragon_bond    Dragon Bond      → Dragon Nest（龙能力）
```

**公式**（来自 `progression-systems.md §训练`）：

```text
1 + get_training_level(training) × training.percent_increase / 100
```

**framework 映射**：

- 用 `o11-multi-region.md` 跨区域乘区实现
- 4 个训练分别绑定 1 个区域的产出链（Orb / Forest / Alchemy / Dragon Nest）

---

## 9. 国家系统（22 个 — O11 跨区域实证）

完整 → [./nations.json](./nations.json)

### 9.1 22 个国家

`axel / tempestus / tedora / netus / xara / starting / istesha / ceha / peace_land / wedol / verdania / maristella / fel / chronara / lapis / tenebris / arcanis / odantis / janand / prismara / luscana / lilon`

### 9.2 国家绑定产出

| 国家 | 绑定产出 |
|------|---------|
| Verdania / Tedora | Forest（木材） |
| Tempestus / Lilon | Orb（云灵魔法） |
| Maristella / Odantis | Study（知识） |
| Janand | 墙伤（combat） |
| Starting | 开局默认 |

### 9.3 公式

```text
若 has_relations(nation):
    bonus ×= 1 + nation.meta.percent_increase / 100
```

**解锁条件**：`Trade Agreements ≥ diplomacy_points_threshold`

**framework 映射**：

- 用 `o11-multi-region.md` 跨区域乘区实现
- 22 国家 > 12 区域 = "**少区域 / 多派系**" 结构
- 每个国家绑定 1 个区域的产出线，跨区域乘区走全局链

---

## 10. 转生系统（双轨 — O7 实证）

完整 → [./prestige.json](./prestige.json)

### 10.1 Magic Prestige（魔法转生）

- **经验来源**：每获得 1 点 Magic → `add_exp_instantly(value)`
- **升级循环**：current_experience ≥ cap() → level += 1，points += 1
- **max_level = 16**（来自 `constants.json → prestige.max_level`）
- **cap 公式**：`cap = 7000 × mult × pow(4.1 - 0.05, pow(L, 1 + 0.0062 × L))`

### 10.2 Damage Prestige（伤害转生）

- **经验来源**：墙受到 final_damage → `add_exp_instantly(final_damage)`
- **门槛**：`blessings.total_blessing_points > damage_level + prestige.level` 才能累积
- **cap 公式**（level 0-2）：`{0: 40000, 1: 900000, 2: 15000000}`
- **cap 公式**（level ≥ 3）：`1,500,000 × 4.5^(20.9 - (20.9/42²) × (level - 42)²)`

### 10.3 祝福分配

- 转生结束后进入 Blessings 界面
- `cost = 1`（每级 1 转生点）
- `automatic` 祝福 cost = 0

### 10.4 转生节奏

来自 `walkthrough.md`：

| 次序 | 建议祝福点 | 目的 |
|------|-----------|------|
| 1 | ~5 | 突破 early 灵体/魔法墙 |
| 2 | 10-11 | 进入 Building / Alchemy / Sorcery |
| 3 | 21+ | 宇宙墙与终局 |

**framework 映射**：

- 用 `core/05-reset-systems.md` + `optional/o07-dual-reset-track.md` 实现（**双轨 Reset 实证**）
- Magic Prestige = 资源转生
- Damage Prestige = 伤害转生（与资源转生独立）
- 16 等级上限 = O5/7 的 cap 设计

---

## 11. 副进度条（O2 实证 — 3 条）

完整 → [./progression-bars.json](./progression-bars.json)

### 11.1 炼金（Alchemy → Magic Gold）

```text
cap = 20 × 1.175^(level^0.7)
level += 1 → add_resource(Magic Gold, 1)
```

| 等级 | cap（约） |
|------|----------|
| 1 | 23.5 |
| 5 | 49.5 |
| 10 | 79.7 |

### 11.2 神殿（Temple → Cosmic Dust）

```text
cap = 3.5 × 1.23^(level^1.03)
level += 1 → add_resource(Cosmic Dust, 1)
```

| 等级 | cap（约） |
|------|----------|
| 1 | 4.3 |
| 5 | 9.0 |
| 10 | 17.5 |

### 11.3 符文树（Rune Tree → Blank Rune）

```text
cap = 450 × 1.51^(level^0.74)
level += 1 → Blank Rune += 1 + Runecraft祝福.amount × Runecraft祝福等级
符文技能 cost = depth（树深度）
```

| 等级 | cap（约） |
|------|----------|
| 1 | 681 |
| 5 | 4,178 |
| 10 | 11,507 |

**framework 映射**：

- 用 `optional/o02-endgame-progress-bars.md` 实现（**直接实证**）
- 3 个副进度条各自 cap 曲线不同（power 函数，level^x）
- level up 注入终局资源

---

## 12. QoL 机制（O9 实证）

完整机制 → [./qol.json](./qol.json)。**界面结构（区域几何 + 组件树）** → [`ui-layout.json`](./ui-layout.json)（验收：[附录 C 结构可复原](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

### 12.0 界面布局锚点（Steam `Tower Wizard.pck`）

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑 viewport | **640×330** | `display/window/size/viewport_width/height`（pck 内嵌 settings） |
| UI 栈 | Godot 4 Control / CanvasLayer | `Options.gd` / `AreaUI.gd` / `BuildTowerUI.gd` |
| 区域导航 | 14 个 GoTo* 按钮 + InputMap | `NavigationButtons.gd` / `CameraShortcuts.gd` |
| 浮动区域面板 | `Run.uis[ui_id]` + `UIArea` | `UIArea.gd` / `AreaUI.gd` |
| Options | Save / Sound / Credits / Remap / Scale / Language×8 | `Options.gd` + `LocalizationConfig.gd` |
| Tooltip | DescriptionPanel 130–200 × 50–125 | `DescriptionPanel.gd` 常量 |

```text
+---------------------------- 640 x 330 -----------------------------+
| HUD: resources · BuildTower(+TowerResource costs) · attention     |
+--------------------------------------------------------------------+
|           WORLD (Camera2D pan/zoom across tower island)            |
|   UIArea hotspots → floating AreaUI (Orb/Study/Forest/…/Temple)  |
|                                              [WallHP + statuses]   |
+--------------------------------------------------------------------+
| Nav: Orb·Study·Forest·Prestige·Build·Academy·Dragon·Alchemy·…     |
|      (ShortcutBar: top nav / bottom / hidden)                      |
+--------------------------------------------------------------------+
| Options CanvasLayer · Blessings overlay · StartScreen · Tooltip    |
+--------------------------------------------------------------------+
```

布局定位：**单岛相机导航 + 世界热点浮动面板**（对比 Shelldiver 房间切换、Agrivore 底栏 Hub、DEM 侧栏）。

### 12.1 长按加速（HoldableButton）

来自 `utilities.md` + `constants.json → holdable_button`：

```text
long_press_duration = 0.5
rapid_press_min = 0.05
rapid_press_scale_up_time = 3

按住超过 LONG_PRESS_DURATION / long_press_speed（默认 0.5s）进入连发
连发间隔：RAPID_PRESS_MIN × max(RAPID_PRESS_SCALE_UP_TIME / long_press_time, 1) / long_press_speed
最短约 0.05s/次
```

### 12.2 监管祝福（Supervision 0.2s）

来自 `blessings.md §监管祝福` + `constants.json → supervision.bless_duration = 0.2`：

- 点击某区域后 0.2s 内该区域获得 supervision 加速
- sorcery 区域用 `blessing_of_supervision.sorcery_increase` 字段
- 其他区域用 `blessing_of_supervision.percent_increase` 字段

### 12.3 点击 flat bonus（按塔层递减）

来自 `constants.json → click_speed_flat_bonus`：

| max_tower_level | flat 加值 |
|-----------------|----------|
| 1 | 0.25 |
| 2 | 0.20 |
| 3 | 0.15 |
| 4 | 0.10 |
| 6 | 0.05 |
| 10 | 0.00 |

**重要**：flat 加值**随塔层递减排**（0.25 → 0.00）—— 塔层越高，flat 越不重要；后期由乘区链主导。

### 12.4 数字格式化

来自 `utilities.md §数字格式化`：

- < 1：一位小数
- < 10,000：整数显示
- 更大：K / M / B / T… 或科学计数
- 中文 locale：万 / 亿制

**framework 映射**：

- 用 `optional/o09-interaction-qol.md` 实现（**直接实证**）
- 长按 / 监督 / flat bonus / 数字格式 4 类 QoL 全部覆盖

---

## 13. 战斗乘区链

完整 → [./combat-multipliers.json](./combat-multipliers.json)

### 13.1 资源通用加成（`get_resource_bonuses`）

```text
bonus = 1.0
若 resource == Magic:    bonus ×= get_magic_bonuses()
若 resource == Knowledge: bonus ×= get_knowledge_bonuses()
若 resource == Magic Gold: bonus ×= get_magic_gold_bonuses()

# Balance 祝福（O5 双层瓶颈）
furthest = 升塔 UI 当前最缺的那项资源
若 resource == furthest:
    bonus ×= 1 + balance_blessing.percent_increase/100 × 等级       # Focus
elif 升塔按钮可用 或 塔层 >= SORCERY，且 resource 为 Magic/Wood/Magic Gold:
    bonus ×= 1 + balance_blessing.all_increase/100 × 等级            # Broad
```

**O5 双层瓶颈平衡实证**：

- **Focus（焦点）**：当前最缺资源的专属大幅加成
- **Broad（广谱）**：升塔按钮可用或塔层 ≥ Sorcery 时，对 Magic / Wood / Magic Gold 温和加成

### 13.2 Magic 全局加成

```text
blessing = (1 + magic_gain_blessing.percent_increase/100 × 等级)
若 塔层 >= PRESTIGE: blessing ×= (1 + prestige_blessing.percent_increase/100 × 等级)
若 BuildAcademy祝福 > 0 且 SpiritTome等级 >= requirement:
    build_academy = 1 + build_academy.percent_increase/100 × 等级

relic = 1 + MagicGold数量 × magic_gold.percent_increase/100
      + ManaStone数量 × mana_stone.percent_increase/100
      + HolyGrail数量 × holy_grail.magic_increase/100
      + PhilosopherStone数量 × philosopher_stone.magic_increase/100

house = (1 + build_house.percent_increase/100) ^ BuildHouse等级

return blessing × relic × house × build_academy
```

**framework 映射**：

- 5 个乘区相乘：祝福 × 遗物 × 房屋 × 学院 × （状态效果）
- 4 层嵌套 = 完整 O11 跨区域乘区链

---

## 14. framework 覆盖度（本 case 实际用到的模块）

| framework 模块 | 本 case 是否用到 | 用到的方式 |
|--------------|-----------------|----------|
| `core/README.md`（核心循环总览） | ✅ | 资源 → 产出 → 祝福 → 战斗完整循环 |
| `core/02-resources.md` | ✅ | 11 个资源 + 通用 add_resource |
| `core/03-production-lines.md` | ✅ | Cloudling / Study / Forest / Alchemy 等 12 区 |
| `core/04-upgrade-economy.md` | ✅ | SkillDefScaling（指数）+ SkillDefSingle（一次性）+ SkillDefSpirit（特殊曲线） |
| `core/05-reset-systems.md` | ✅ | Magic Prestige 16 上限 |
| `core/06-permanent-upgrades.md` | ✅ | 40 祝福（Pattern C 条件专精实证） |
| `patterns/pattern-b-binary-unlock.md` | ✅ | SkillDefSingle（unlock_dragon_bond 等） |
| `patterns/pattern-s-skill-tiers.md` | ✅ | SkillDefSpirit 201 → 28000 曲线 |
| `patterns/pattern-t-tier-jump.md` | ✅ | Doubling 祝福（Cloudling / Tome / Druid 每次 +2） |
| `patterns/pattern-e-status-stack.md` | ✅ | 5 种状态效果（直接实证 — Cursed / Molten / Frost / Weakened / Resonance） |
| `optional/o01-chapter-gates.md` | ✅ | 10 档塔层 Gate（其中 7→8 / 8→9 是复合 Gate） |
| `optional/o02-endgame-progress-bars.md` | ✅ | 3 个副进度条（炼金 / 神殿 / 符文）— 直接实证 |
| `optional/o03-challenge-axis.md` | ✅ | HP 墙（云墙 20M / 太阳墙 5B）+ INF 墙（宇宙墙） |
| `optional/o04-cross-axis-feedback.md` | ✅ | Destruction 祝福（DPS → 多条产出链） |
| `optional/o05-bottleneck-balance.md` | ✅ | Balance 祝福 — Focus（最缺资源）+ Broad（其他资源）双层（直接实证） |
| `optional/o06-area-focus.md` | ✅ | Supervision 祝福（点击区域 0.2s 加速） |
| `optional/o07-dual-reset-track.md` | ✅ | 双轨转生（Magic Prestige + Damage Prestige）— 直接实证 |
| `optional/o08-support-systems.md` | ✅ | 图腾 / 训练 / 国家 跨区域乘区 |
| `optional/o09-interaction-qol.md` | ✅ | 长按 / 监督 / flat bonus / 数字格式 + **UI 布局**（[`ui-layout.json`](./ui-layout.json)：640×330） |
| `optional/o10-pacing-milestones.md` | ✅ | 5 阶段 walkthrough |
| `optional/o11-multi-region.md` | ✅ | 12 区域 + 22 国家（少区域 / 多派系）— 直接实证 |

**Tower Wizard 是 framework 的高覆盖度案例** — 除 `core/03 T1-T5 标识`和 `Pattern D 双资源池`外，几乎覆盖了 framework 的所有模块。

---

## 15. 工程化交付清单

```text
✅ ./metadata.json        — 案例元信息（标题/引擎/数据源）
✅ ./resources.json       — 11 个资源 + add_resource 流程
✅ ./tower-progression.json — 10 档塔层 + 11 条升塔成本
✅ ./regions.json         — 12 区域 + 跨区域绑定
✅ ./status-effects.json  — 5 状态效果 + 衰减公式
✅ ./walls.json           — 4 堵墙 + HP + 破墙逻辑
✅ ./skills.json          — 80 技能 ID + 5 脚本类型
✅ ./blessings.json       — 40 祝福 + 9 分类
✅ ./nations.json         — 22 国家 + 绑定产出
✅ ./trainings.json       — 4 训练 + 跨区域乘区
✅ ./prestige.json        — 双轨转生 + cap 公式
✅ ./progression-bars.json — 3 副进度条 + cap 曲线
✅ ./qol.json             — 长按 / 监督 / flat / 数字格式
✅ ./ui-layout.json       — HUD/导航/区域面板/Options（O9，640×330 结构可复原）
✅ ./combat-multipliers.json — 战斗 / 产出 / 资源 全部乘区链
✅ ./mapping.json         — 原生字段 → 框架 schema 桥接（含 UI）
```

每个 JSON 都引用 `gameplay.json` 真实字段（不是估算），可通过 framework 校验工具验证。
