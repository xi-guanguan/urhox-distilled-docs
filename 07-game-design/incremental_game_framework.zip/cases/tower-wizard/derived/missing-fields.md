# tower-wizard — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## regions.json

- **Schema**: `../../../schemas/multi-region.schema.json`
- **缺字段数**: 1

| 字段 | 说明 |
|------|------|
| `primary_resource` | 由 role 推断（如 Study→knowledge, Forest→wood, Alchemy→magic_gold） |

## status-effects.json

- **Schema**: `../../../schemas/status-effect.schema.json`
- **缺字段数**: 4

| 字段 | 说明 |
|------|------|
| `max_stacks` | implicit stack（每次 +stacks 累加），见 add_status_effect |
| `duration` | 见 decay_formula（0.1s tick 衰减） |
| `stacking_policy` | stack（implicit） |
| `tag` | 按效果类型推断（cursed=curse, molten/frost=elemental, weakened=physical, resonance=magical） |
