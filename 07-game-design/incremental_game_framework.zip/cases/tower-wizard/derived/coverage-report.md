# tower-wizard · framework 覆盖度报告

> 由 `scripts/case-to-framework-coverage.py` 自动生成.
> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)
> 共 17 个 system.

| Case System | Framework 覆盖 | 备注 |
|------------|--------------|------|
| regions (regions) | ✅ | 已映射到 1 个 schema: multi-region |
| tower-progression (regions) | ✅ | 已映射到 1 个 schema: multi-region |
| status-effects (effects) | ✅ | 已映射到 1 个 schema: status-effect |
| ui-layout | ⚠️ | 映射不充分: (无强制 schema — Optional O9 Interaction QoL) |
| 塔层系统（10 档 + 升塔成本） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 区域子系统（O11 完整版 — 12 区域） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 资源系统（11 个货币） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 战斗与墙体（O3 实证） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 状态效果系统（Pattern E 实证 — 5 种） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 技能系统（80 个 — Pattern S/T/B 全覆盖） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 祝福系统（40 个 — Pattern C 实证） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 训练系统（4 个 — 跨区域乘区） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 国家系统（22 个 — O11 跨区域实证） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 转生系统（双轨 — O7 实证） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 副进度条（O2 实证 — 3 条） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| QoL 机制（O9 实证） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 战斗乘区链 | 🆕 | 无对应 framework schema (README 章节, 待评估) |

## 统计

- ✅ 已覆盖: **3**
- 🆕 未覆盖 (新): **13**
- ⚠️ 部分覆盖: **1**
- ❌ 不适用: **0**

## 🆕 候选贡献 (Candidate for Contribution)

以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **塔层系统（10 档 + 升塔成本）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **区域子系统（O11 完整版 — 12 区域）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **资源系统（11 个货币）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗与墙体（O3 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **状态效果系统（Pattern E 实证 — 5 种）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **技能系统（80 个 — Pattern S/T/B 全覆盖）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **祝福系统（40 个 — Pattern C 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **训练系统（4 个 — 跨区域乘区）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **国家系统（22 个 — O11 跨区域实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **转生系统（双轨 — O7 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **副进度条（O2 实证 — 3 条）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **QoL 机制（O9 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗乘区链** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估

## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件

- 🆕 数: **13** (≥ 1: 必进入)
- ⚠️ 数: **1** (< 2: 可跳过)
- 🔗 Reverse-link 缺失: **0**
