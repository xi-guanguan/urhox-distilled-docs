# cell-to-singularity — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## resources.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `xp_cap` | 无 XP 系统. 时代解锁由 Cell.RowData 状态机推动, 不用 XP 表 |
| `tier_costs` | 无 framework tier_costs 表. Cubits/Megastars/Sagan 的 cap/cost 在 SO 实例, 需 AssetRipper 提取 |

## buildings.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | 每个 building 的 cost_base/cost_e 在 LTE_Tree.nodes ScriptableObject 中, 需 AssetRipper 二次提取 |
| `currency` | 默认 'entropy' (主货币); DNASpenders 用 'dna'; MegastarGated 用 'megastars' |

## upgrades.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | upgradeType/upgradeSubType enum 在 IL 中找到, 但具体节点 cost 数值在 SO 实例, 需 AssetRipper |
| `tier` | 每个 upgrade 的 tier (1/2/3) 由 unlock_era 推断 |

## achievements.json

- **Schema**: `../../../schemas/rarity.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `base_probability` | 成就 rarity 不基于概率, 而是固定 1 触发 |
| `value_multiplier` | rarity 决定 unlock prestige reward multiplier (legendary > epic > rare > common) |

## prestige.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | prestige loop 没有 cost — 玩家主动 trigger reset 换 reward |
| `tier` | 3 tier (Big Bang < Madness < Kardashev) 通过 'is_hard_reset' 区分 |

## creatures.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | creature card upgrade cost 是 DNA 货币 (variable amount per tier) |
| `currency` | 默认 'dna' |

## eras.json

- **Schema**: `../../../schemas/multi-region.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `primary_resource` | 每个 era primary_resource = 'entropy' (主货币), 但 unlocks 字段 (DNA/Replicanti/Sagan) 区分 sub-currency 出现 |
| `unlock_gate` | 没有显式 unlock_gate, 玩家通过推进 producer count 解锁下一 era |

## events.json

- **Schema**: `../../../schemas/status-effect.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `duration` | 每个 event 持续时间在 EventTuningTracker ScriptableObject, 需 AssetRipper 提取 |
| `effect_value` | Event effect 强度 (entropy multiplier / producer speed bonus) 在 IL 中以 ldc.r4 字面量存在, 需 IL 字节码级反编译 |
