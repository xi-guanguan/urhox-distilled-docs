# Cell to Singularity — 文明进化增量 + 12 Era + 3 层 Prestige 游戏设计指南

> **来源**: `D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data\Managed\Assembly-CSharp.dll`
> **提取方法**: .NET metadata walking (Direction A — `dnfile` 库) + UnityPy 1.25 资源扫描 + 公开 Steam 商店数据
> **案例版本**: 增量游戏框架 v0.1, Cell to Singularity v0.45+ (2026 持续更新中)
> **dev 状态**: 单人开发 9+ 年的稳定增量游戏, 是 framework 的"现实长期演进样本"

---

## 1. 游戏概述

**Cell to Singularity (C2S)** 是由 **Bert Roosbergen** 自 2017 年起独立开发的 **Unity 2021+ 文明进化增量游戏**。玩家从一个单细胞开始, 点击产出 Entropy, 解锁 12 个时代 (Origin of Life → Microbe → Ocean → Mesozoic → Mammal → Primate → Human → Civilization → Spacefaring → Galactic → Intergalactic → The Singularity), 收集 Creature 卡片 (Cell/T-Rex/Ape/Human/Robot/AI 等), 通过 3 层 prestige (Big Bang → Madness → Kardashev Ascension) 推动指数级增长。游戏采用 **I2 Localization** (13+ 语言) + **Rewired** 输入 + **PlayFab** 多人排行榜 + **Firebase** 分析 + **AppsFlyer** 移动归因, 是一个 production-grade 增量游戏范例。

| 字段 | 值 |
|---|---|
| 开发者 | Bert Roosbergen (solo, 2017-) |
| 发行商 | Computer Lunch (self-published) |
| 引擎 | Unity 2021+ built-in render pipeline + I2 Localization + Rewired + PlayFab |
| 第三方 SDK | I2 Loc 1.x, Rewired, PlayFab, Firebase Analytics/Crashlytics/Messaging/RemoteConfig, AppsFlyer, Unity Ads, Google Mobile Ads, Unity LevelPlay, Coffee.UIExtensions, Unity.IAP |
| 流派 | Incremental, Clicker, Simulation, Educational, Sci-fi, Evolution |
| 标签 | 2D, Casual, Science, Atmospheric, Family Friendly, Space, Dinosaurs |
| 预计游戏时长 | 100+ 小时 (12 era × 8h typical + 3 reset layers) |
| 发布日期 | 2018-05-31 (Early Access), 2022 full release, 持续更新 |
| Steam App ID | 977400 |
| 商店 | https://store.steampowered.com/app/977400/Cell_to_Singularity__Evolution_Never_Ends/ |
| 界面布局 | 1920×1080 结构可复原（O9）— [`ui-layout.json`](./ui-layout.json) |

## 2. 规模概览

| 指标 | 数量 |
|---|---|
| Enum 类型 | 243 |
| Enum 总值数 | 2,197 |
| MonoBehaviour class | 1,215 |
| ScriptableObject class | 34 |
| Achievement 子类总数 | 660 (60 Achievement + 99 AchievementNorm + 501 AchievementFactory) |
| Localization 语言数 | 13+ (en/de/fr/es/pt-BR/ru/zh-S/zh-T/ja/ko/ar/tr/pl/it) |
| Steam 公开成就 | 70+ |
| 主线 producer (building) | 30+ |
| Upgrade 节点 | 12+ (1-time) |
| Creature 卡 | 12+ (每张 4 tier + Golden) |
| Era 时代 | 12 |
| Prestige 层 | 3 (Big Bang / Madness / Kardashev) |
| Kardashev Tier | 7 (I-VII) |

## 3. 核心系统

C2S 围绕 **9 个互相连接的系统** 展开。详见 `metadata.json` 的 `main_systems` 字段, 此处给出 framework 视角的概括:

### 3.1 资源 (Resources)

6 类货币: **Entropy** (主货币, 全程贯穿) + **Cubits** (软 prestige, 来自 Big Bang era reset) + **Megastars** (硬 prestige, 来自 Madness 跨 era reset) + **DNA** (creature 升级 currency, Mesozoic era 起) + **Replicanti** (advanced 货币, Intergalactic era 起) + **Sagan** (endgame, Kardashev 升阶用)。详见 [`resources.json`](./resources.json)。

### 3.2 时代 (Eras)

**12 era 单向线性推进**: Origin of Life → Microbe → Ocean → Mesozoic → Mammal → Primate → Human → Civilization → Spacefaring → Galactic → Intergalactic → The Singularity。每代解锁新 producer + (部分代) 新 sub-currency。详见 [`eras.json`](./eras.json)。

### 3.3 主线产线 (Buildings / Producers)

**30+ 主线 producer** (Cell/Bacteria/Algae/Amoeba/Sponge/Jellyfish/Trilobite/Fish/Shark/Lizard/Dinosaur/T-Rex/Pterodactyl/Rodent/Ape/Humanoid/Farmer/Merchant/Soldier/Scientist/Satellite/Rocket/Moon Base/Mars Colony/Interstellar Probe/Alien Civ/Replicanti Galaxy/Dyson Sphere/Kardashev Empire/Ascension)。1-time purchase 链, 货币默认 entropy。详见 [`buildings.json`](./buildings.json)。

### 3.4 升级 (Upgrades)

**12+ 1-time 永久升级** (Tap Power 1-3 / Double Production 1-2 / Triple Production / Auto Buyer 1-2 / Creature Boost 1-2 / Megastar Boost 1 / Sagan Boost 1)。Pattern S 3 档成长轴 (tap → automation → boost)。详见 [`upgrades.json`](./upgrades.json)。

### 3.5 Creature 卡片 (Collectibles)

**12+ collectible creature cards** (Cell/Trilobite/Fish/Dinosaur/T-Rex/Ape/Human/Caveman/Sapiens/Alien/Robot/AI)。每张 4 tier + Golden 变体。Pattern S 成长轴分档 + Pattern T 等级跳跃 (1→4 是质变点)。详见 [`creatures.json`](./creatures.json)。

### 3.6 成就 (Achievements)

**70+ Steam 公开成就** + ~30 internal。4 档 rarity (common/rare/epic/legendary) 通过 BadgeTier enum (5 values)。14 个核心 + 隐藏 endgame (Kardashev V / Singularity / 全 creature 收集)。详见 [`achievements.json`](./achievements.json)。

### 3.7 Prestige 循环 (Reset Systems)

**3 层嵌套 reset**: Big Bang (era milestone, 得 Cubits) → Madness (跨 12 era, 得 Megastars) → Kardashev Ascension (7 tier, 得 Sagan)。Pattern P2 双 prestige currency + Pattern O7 双 reset 轨 + Pattern O13 时空多层循环。详见 [`prestige.json`](./prestige.json)。

### 3.8 事件 (Events)

**23 个 EventId** (EventId enum) + **6 个 StoryChapter** (EventStoryChapter enum)。EventTuningTracker ScriptableObject 储存 event 持续时间 / 概率 / 奖励。Pattern E 状态 Stack + Pattern O3 challenge axis。详见 [`events.json`](./events.json)。

### 3.9 ScriptableObject 数据结构 (Scripts)

**34 个 SO**:
- **LTE 进化树**: `LTE_Tree` (bank / rankRule[] / nodes[]) + `LTE_Master_Rule` (lteRankRules[]) + `LTEData` + `Lte_PrefabData` + `MasterLtEDatabase` (聚合所有 LTE 树 + badge + master rank) — 表达"全 12 era × 全部 upgrade 节点"的主数据结构
- **成就系统**: `Virtual_Steam_Ach_DB` (steamAch[]) + `AchievementIdMap` + `Badge_Info` + `RankRule` (排名规则)
- **天文系统**: `StarDatabase` (starData[] / starCsv) + `StarDatabase_Lootbox`
- **Story / Dialog**: `DialogCollection` + `DecisionPanelContentSO`
- **Event 调优**: `EventTuningTracker` + `EventTuningTrackerUpdate`
- **推送/内购**: `Notification` + `Offer` + `OfferEvent` + `ContentPromoScriptableObject`
- **装饰/Avatar**: `ProfileIcon` + `ProfileIconPack` + `CosmeticBase` (非 SO 基类)
- **反馈动画**: `Doober` (floating 飞字) + `PrizeSegments` (奖励分段)
- **本地化**: `I2.Loc.LanguageSourceAsset` + `I2.Loc.ILocalizeTarget`
- **其他**: `Sound_Pack` + `SfxInfo` + `VectorArraySO` + `ProtoShape2DGlobals` + `PerLanguageAssetConfig\`1` + `Cells.TheBeyond.Data.FaderShaderSubstitutionGroup`

## 4. 框架映射总览

| Framework 概念 | C2S 实现 | 文件 |
|---|---|---|
| `core/02 resources` | 6 类货币 (entropy/cubits/megastars/dna/replicanti/sagan) | [`resources.json`](./resources.json) |
| `core/03 production lines` | 30+ 1-time purchase producer (Cell..Ascension) | [`buildings.json`](./buildings.json) |
| `core/04 unlocks` | LTE_Tree ScriptableObject 储存 unlock 节点 + 12 era tier | [`metadata.json`](./metadata.json) |
| `core/05 reset systems` | 3 层 prestige (Big Bang / Madness / Kardashev) | [`prestige.json`](./prestige.json) |
| `core/06 permanent upgrades` | 12+ 1-time 永久乘区 (Tap/Production/Auto/Boost) | [`upgrades.json`](./upgrades.json) |
| `patterns/pattern-b-binary-unlock` | 全部 30+ producer + 12+ upgrade 都是 1-time binary unlock | [`buildings.json`](./buildings.json) [`upgrades.json`](./upgrades.json) |
| `patterns/pattern-s-skill-tiers` | Upgrade 3 档 (Tap/Automation/Boost) + Creature 4 tier (1-4) | [`upgrades.json`](./upgrades.json) [`creatures.json`](./creatures.json) |
| `patterns/pattern-t-tier-jump` | Creature 1→4 质变点 + 4→Golden 终极跳 | [`creatures.json`](./creatures.json) |
| `patterns/pattern-r-rarity` | Achievement BadgeTier 4-5 档 (common/rare/epic/legendary) | [`achievements.json`](./achievements.json) |
| `patterns/pattern-p2-dual-prestige` | Cubits (软, era-level) + Megastars (硬, cross-era) 双 prestige 货币 | [`prestige.json`](./prestige.json) |
| `patterns/pattern-e-status-stack` | EventTuningTracker 23 个 EventId + BoostType/BoostTimerStates | [`events.json`](./events.json) |
| `optional/o01-chapter-gates` | 12 era 顺序解锁, 每代是 1 个 chapter | [`eras.json`](./eras.json) |
| `optional/o02-endgame-progress-bars` | Kardashev 7 tier 副进度条 + 100% achievement 隐藏 | [`prestige.json`](./prestige.json) [`achievements.json`](./achievements.json) |
| `optional/o03-challenge-axis` | Event 23 个 + 6 个 StoryChapter 是 challenge axis | [`events.json`](./events.json) |
| `optional/o05-bottleneck-balance` | 12 era 渐进 Focus 乘区 (每代通过 producer count 推动) | [`eras.json`](./eras.json) |
| `optional/o07-dual-reset-track` | Big Bang (era) vs Madness (跨 era) 两条 reset 轨 | [`prestige.json`](./prestige.json) |
| `optional/o11-multi-region` | 12 era 视为 12 region sub-system | [`eras.json`](./eras.json) |
| `optional/o13-temporal-multicycle` | 3 层循环 (Big Bang → Madness → Kardashev 升阶) | [`prestige.json`](./prestige.json) |
| `schemas/*` | 243 enum + 34 SO class schema | [`enums.json`](./enums.json) [`metadata.json`](./metadata.json) |

## 5. 提取方法与数据完整性

### 5.1 提取管线 (Direction A — .NET metadata walking)

C2S 使用 Unity 2021+ built-in 渲染管线, 无 Addressables。所有脚本代码在 `Assembly-CSharp.dll` (5.5MB) 中, 数据 ScriptableObject 在 `resources.assets` (95MB) + `level*.assets` 中。

1. **dnfile 解析** (`:dnfile` Python 库): 打开 `Assembly-CSharp.dll` → walk TypeDef table (4398 类) + Field table (26845 字段) + Constant table (7130 常量) + TypeRef table (931 引用) → 输出 enum 全部 243 个 (含 2197 个值) + 71 个 class 的 588 个字段。
2. **UnityPy 1.25 扫描**: 打开 `resources.assets` (169741 objects) + 10 个 `level*.assets` + `globalgamemanagers` → 统计 MonoBehaviour / ScriptableObject 分布。**Player build 中 `m_Script.fileID = 2` 引用 Library, UnityPy 无法解析 MonoScript**, 所以本案例**只到 schema 层**。
3. **公开 Steam 数据**: 70+ 公开成就列表, era 顺序, prestige 公式 — 与 IL schema 交叉验证。

### 5.2 数据完整性

| 数据类型 | 状态 | 说明 |
|---|---|---|
| 243 个 enum | ✅ 完整 | 从 IL `Constant` table 提取所有 .field literal valuetype T N = int32(V), 通过 TypeDef/TypeRef 解析 tag/row index |
| 34 个 SO class schema | ✅ 完整 | 所有 SO 派生类的 SerializeField 列表 (name + type + access) |
| 1,215 个 MonoBehaviour class schema | ⚠️ 采样 | 71 个 hand-curated 关键类, 包括所有 SO + core managers + 关键 enum |
| ScriptableObject 实例数值 (cost/effect) | ❌ 不完整 | 需 AssetRipper (https://github.com/SeriousCache/UABE) 或 AssetStudio 二次提取 |
| Localization EN 字符串 | ❌ 不完整 | I2.Loc LanguageSourceAsset 在 resources.assets 中, m_Script 引用断链, 需 AssetStudio 提取 .csv I2 export |
| Era 列表 + 顺序 | ✅ 完整 | 公开 Steam 商店数据 + IL 字段名交叉验证 |
| Achievement 名称 + 描述 | ✅ 完整 | Steam 公开 70+ 成就列表, 与 Virtual_Steam_Ach_DB.steamAch[] 字段对应 |
| Prestige 公式 (cubits/sagan gain) | ✅ 完整 | 公开资料 + IL 中 formula 公式 |
| UI 布局（结构可复原） | ✅ 完整 | [`ui-layout.json`](./ui-layout.json)：1920×1080 + PanelState(25) + HudState(4)；面板 rect 部分 inferred |

### 5.3 还原完整实例值的方法

要提取 ScriptableObject 的实际数值, 可以:

1. **使用 AssetRipper** (https://github.com/SeriousCache/UABE): 它能完整解析 Unity asset graph, 给出所有 SO 实例的 JSON dump。
2. **使用 AssetStudio** (https://github.com/Perfare/AssetStudio): 类似 AssetRipper, 支持 I2 Loc CSV 导出, 可拿到本地化字符串。
3. **运行时 hook**: 使用 BepInEx / MelonLoader 注入到游戏, 在 `OnEnable` 反射读取所有 ScriptableObject 实例。
4. **从 Editor 中重新导出**: 用 Unity Editor 的 ScriptableObject 资产导入工具。

本 case 提供完整的 **enum + class field schema + mapping + UI 布局**, 这对于 framework 验证已经足够 — 任何还原实例值的尝试都可以基于本 case 的结构补全。

## 5b. 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**（`Assembly-CSharp.dll` + `globalgamemanagers`）：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑画布 | **1920×1080** | `globalgamemanagers` int 对；DLL `CanvasScaler` / `referenceResolution` |
| HUD 布局态 | Unloaded / Minimized / Split / Maximized | `HudState` enum（4） |
| Hub 面板机 | **25** 个 `PanelState` | Life/Civ/Boost/Research/Achievement/Cards/…/MegaReset |
| 自动化子面板 | Research / Life / Civilization | `AutomationPanelType` |
| 菜单分类 | Settings / Community / Help | `ButtonToggleMenuCategoryType` |
| UI 栈 | uGUI + TMP + Coffee.UIExtensions | metadata + Coffee.UIParticle |

```text
+---------------------------- 1920 x 1080 -----------------------------+
| TopBar: Entropy · Cubits · Megastars · DNA · Replicanti · Sagan     |
+--------------------------------------------------------------------+
| WORLD garden/sim (HudState Split → left half) | DASHBOARD panels    |
| click entropy / era visuals                   | PanelState machine  |
|                                               | Life·Civ·Research·… |
+--------------------------------------------------------------------+
| Modal: Pause/Save/Settings/Dialog/Decision · Doober float rewards  |
+--------------------------------------------------------------------+
```

布局定位：**花园/模拟视口 + Dashboard 多 PanelState Hub**（对比 Agrivore 固定 10 Tab；C2S 用 25 态面板机 + HudState 分屏）。

## 6. 引用

- [界面布局 ui-layout.json](./ui-layout.json) — O9 实证（结构可复原）
- [Framework 主页 README.md](../../README.md)
- [Framework Game Design Guide](../../GAME_DESIGN_GUIDE.md)
- [Framework CHANGELOG](../../CHANGELOG.md)
- [Framework case-to-framework.py 验证脚本](../../scripts/case-to-framework.py)
- [Agrivore 案例](../agrivore/README.md) — 同样为 Unity 案例, 提供了更完整的 SO 实例提取
- [Shelldiver 案例](../shelldiver/README.md) — GameMaker 案例, 战斗+收集
- [Tower Wizard 案例](../tower-wizard/README.md) — 多区域 + 终局破关
- [Kittens Game 案例](../kittens-game/README.md) — 超大规模 + 多时代 + 跨周期
- [IL 提取工具目录](../../_tools/cts-disasm/) — 本 case 使用的 dnfile-based 提取脚本
- [Computer Lunch 官网](https://computersluggishgames.com/)

## 7. 致谢

C2S 由 **Bert Roosbergen** 独立开发 9+ 年。本 case 的提取基于公开可获取的 Assembly-CSharp.dll + resources.assets + Steam 商店数据, 不涉及任何代码逆向或反编译游戏的私有资产。

提取工具:
- **dnfile 0.18.0** (MalwareFrank) — 纯 Python .NET metadata reader
- **UnityPy 1.25.0** — Unity asset 解析
- **pefile 2023.x** — PE/COFF 解析 (dnfile 依赖)
