# space-rock-breaker — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## resources.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `xp_cap` | 无 XP 等级表；推进用 Sector 配额 |
| `tier_costs` | 矿石价值/Plinko 乘数表未提取 |

## upgrades.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 3

| 字段 | 说明 |
|------|------|
| `cost` | Credits 成本未从 Addressables 导出 |
| `currency` | 隐式 credits |
| `tiers` | 多档以 ID 后缀/空格变体出现，非统一 tiers[] |

## prestige.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | Universal Ore 费用未提取 |
| `effect_value` | 仅有节点名 |

## weapons.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | 武器解锁挂在 UD_ 树 |
| `dps_tables` | 未提取 |

## achievements.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 1

| 字段 | 说明 |
|------|------|
| `api_name` | Steam API name 未抓取 |
