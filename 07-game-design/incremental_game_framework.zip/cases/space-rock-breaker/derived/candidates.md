# Space Rock Breaker — Framework 候选贡献评估（Stage 3–4）

> **评估日期**: 2026-07-13

---

## 候选 1: Plinko / Pachinko Ore Processor

- **来源**: `plinko.json` — 矿石 → peg → score-zone 乘数 → Credits
- **framework 现状**: 无物理弹珠/Plinko schema；最接近「转化产线」叙事
- **评分**:
  - 通用性: 2/3（赌场/弹珠题材常见；纯 idle 少见完整 Plinko）
  - 复杂度: 3/3（peg 布局 + 乘数袋 + 升级 peg）
  - 已实证 case: 1/3
  - 文档成本: 3/3
  - **总分**: 9/12
- **决策**: **推迟**
- **理由**: 通用性尚可但仅 1 实证且实现重。先在 case 内完整文档化；若再出现 Plinko/pachinko 增量 case，再升 Optional。
- **影响范围**: 0

---

## 候选 2: Fuel-as-Run-HP + Idle Drain

- **来源**: `resources.json` Fuel；5s 不采集急降
- **framework 现状**: 可用 status/资源衰减表达；无独立 Optional
- **评分**: 通用性 2/3；复杂度 1/3；实证 1/3；文档 1/3 → **6/12**
- **决策**: **不沉淀**
- **理由**: 用 README + resources 即可；避免为单 meter 行为新开编号。

---

## 候选 3: Prestige Keep-* Retention Nodes

- **来源**: `PD_KeepUpgrades` / `KeepPlinko` / `KeepArtifacts` / `KeepAmmoUnlocks`
- **framework 现状**: permanent-upgrade 可表达；多 case 已有「保留部分进度」
- **决策**: **不沉淀（复用 permanent-upgrade）**
- **理由**: 记为 prestige 变体文档，不新 Pattern。

---

## 候选 4: O9 Dual-View Combat + Plinko UI

- **来源**: `ui-layout.json`
- **决策**: **复用 O9**
- **理由**: 双面板 + Space warp + 技能树正是 O9 实证。

---

## Stage 4 汇总

| 候选 | 决策 |
|------|------|
| Plinko processor | 推迟 |
| Fuel idle drain | 不沉淀 |
| Keep-* prestige | 复用 |
| Dual-view UI | 复用 O9 |

**Stage 5**: 本 case **不执行** framework 文件新增。
