# space-rock-breaker · framework 覆盖度报告

> 由 `scripts/case-to-framework-coverage.py` 自动生成.
> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)
> 共 12 个 system.

| Case System | Framework 覆盖 | 备注 |
|------------|--------------|------|
| resources (currencies) | ✅ | 已映射到 1 个 schema: constants |
| upgrades (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| prestige (permanent_upgrades) | ✅ | 已映射到 1 个 schema: permanent-upgrade |
| weapons (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| artifacts | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| achievements (achievements) | ✅ | 已映射到 1 个 schema: constants |
| ui-layout | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| plinko | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| sectors | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 系统一览（8 modules） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 映射与派生 | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 文件清单 | 🆕 | 无对应 framework schema (README 章节, 待评估) |

## 统计

- ✅ 已覆盖: **5**
- 🆕 未覆盖 (新): **7**
- ⚠️ 部分覆盖: **0**
- ❌ 不适用: **0**

## 🆕 候选贡献 (Candidate for Contribution)

以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:

- 🆕 **artifacts** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **ui-layout** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **plinko** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **sectors** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **系统一览（8 modules）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **映射与派生** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **文件清单** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估

## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件

- 🆕 数: **7** (≥ 1: 必进入)
- ⚠️ 数: **0** (< 2: 可跳过)
- 🔗 Reverse-link 缺失: **0**
