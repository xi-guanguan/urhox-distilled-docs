# Space Rock Breaker — 太空采矿射击 + Plinko 炼金 + 技能树 / Prestige 游戏设计指南

> **来源 / `_source`**: `D:\Program Files (x86)\Steam\steamapps\common\Space Rock Breaker\` (Unity IL2CPP GameAssembly.dll + SPACEROCKBREAKER_Data/level0 + sharedassets0 + StreamingAssets/aa Addressables + Unity Localization) + Steam App 4035270 public achievements + community guides  
> **data_source**: `D:\Program Files (x86)\Steam\steamapps\common\Space Rock Breaker\`  
> **提取方法**: `globalgamemanagers` 实测分辨率；`level0`/`sharedassets0` 收获 `UD_*`/`PD_*` 升级 ID；成就来自 Steam Community Stats  
> **案例版本**: 增量游戏框架 case Stage 1–4；游戏 2025-12-19 Steam 正式版

| 字段 | 值 |
|---|---|
| title | Space Rock Breaker — 太空采矿射击 + Plinko 炼金 + 技能树 / Prestige 游戏设计指南 |
| engine | Unity (IL2CPP) + URP + Addressables + Unity Localization + UpgradeTreeKit + DOTween + TextMeshPro |
| 开发者 / 发行 | WAKA WAKA |
| Steam App ID | 4035270 |
| 发布 | 2025-12-19 |
| 商店 | https://store.steampowered.com/app/4035270/Space_Rock_Breaker/ |
| main_modules | 8 |
| 局内升级 ID (UD_) | ~100 |
| Prestige 节点 (PD_) | 19 |
| 矿石材料（已文档） | 10+ |
| 武器系统 | 8 |
| Steam 成就 | 15 |
| UI 分辨率 | 1920×1080 |
| 预计时长 | 2.5–4h 全成就 |

---

## 1. 游戏概述

**Space Rock Breaker** 是一款短时长增量游戏：俯视角飞船**自动开火**打碎小行星 → 收集矿石 → 在基地用 **Plinko** 加工换 **Credits** → 投入 **UpgradeTreeKit 技能树** → 每 5 Sector 打 **Boss** 拿 **Universal Ore** 做 **Prestige**。

与纯点击器不同，核心节奏是 **Sector 配额跃迁 + Fuel 生存条 + Plinko 乘数**。

## 2. 核心循环

```text
[Fuel] fly & auto-fire asteroids
  → collect ore / crates / artifacts
  → fill quota (~400–500) → Space warp → next Sector
  → every 5 sectors: Boss asteroid → Universal Ore
  → process ore in Plinko → Credits
  → buy UD_ skill tree (guns, fuel, ores, plinko, …)
  → optional Prestige (PD_): KeepUpgrades / KeepPlinko / KeepArtifacts / damage…
  → late: clear 5 boss boxes → To Infinity And Beyond endgame nodes
```

## 3. 系统一览（8 modules）

| # | 系统 | 数据文件 | Framework |
|---|------|----------|-----------|
| 1 | Credits / Fuel / ores / Universal Ore | [`resources.json`](./resources.json) | core/02 |
| 2 | Sector / Boss / TIAB | [`sectors.json`](./sectors.json) | O1/O10 节奏 |
| 3 | 武器与弹药 | [`weapons.json`](./weapons.json) | combat 产线 |
| 4 | Plinko + lootbox | [`plinko.json`](./plinko.json) | ⚠️ 题材（见 candidates） |
| 5 | UD_ 技能树 | [`upgrades.json`](./upgrades.json) | upgrade.schema + UpgradeTreeKit |
| 6 | PD_ Prestige | [`prestige.json`](./prestige.json) | permanent-upgrade.schema |
| 7 | Artifacts | [`artifacts.json`](./artifacts.json) | permanent / collectible |
| 8 | UI | [`ui-layout.json`](./ui-layout.json) | **O9** |

### 3.1 资源

- **Credits**：Plinko 主产出；买技能树。  
- **Fuel**：顶栏生存条；不采集约 5s 急降。  
- **矿石链**：Stone → Iron/Copper/Silver/Gold/Cobalt/Platinum + 宝石级节点 + Unobtainium（prestige）。  
- **Universal Ore / Universe Essence**：Boss prestige 货币。

### 3.2 战斗与 Sector

自动开火；Space 在配额满时跃迁。Boss 为巨型小行星。`UD_TIAB` / 五格轨道对应成就 **To Infinity And Beyond**。

### 3.3 Plinko

矿石落入 peg 场，score zone 乘数（成就 x2 / x10）。Lootbox 与 DoubleDip/Megabox 等节点强化。

### 3.4 Prestige（19 PD_）

关键保留类：`PD_KeepUpgrades`、`PD_KeepPlinkoUpgrades`、`PD_KeepArtifacts`、`PD_KeepAmmoUnlocks`。社区称树较线性；全成就可不碰 Prestige，但前两次大幅加速。

### 3.5 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑画布 | 1920×1080 | `globalgamemanagers` int pair 1920→1080 |
| UI 栈 | uGUI + TMP + UpgradeTreeKit + Plinko RT | ScriptingAssemblies + level0 对象名 |
| 主隐喻 | 俯视角战斗 + 基地 Plinko | combat viewport ↔ Plinko panel |

```text
+---------------------------- 1920 x 1080 -----------------------------+
|                    Fuel 条（顶）                                      |
+----------------------------------------------------------------------+
| 战斗视口（飞船自动开火 / 小行星 / 箱子）     | Plinko RT / 投矿面板   |
|  [BossHealthBar 出现时叠顶]                  |                       |
|  Artifacts 入口                              |                       |
+----------------------------------------------------------------------+
| 配额条（底） · TIAB 五格 · Space=跃迁下一 Sector                      |
+----------------------------------------------------------------------+
| （全屏叠层）UpgradeTreeKit 技能树 / EndOfRun / Prestige PD_ 树       |
+----------------------------------------------------------------------+
```

组件树（combat / plinko / skill_tree / end_of_run）见 `ui-layout.json → components`。对照 **O9**；双视口节奏适合 M8 抄「主战场 + 副加工面板」。

部分 panel `rect` 为 **inferred**；画布为 **measured**。

## 4. 映射与派生

- [`mapping.json`](./mapping.json)  
- `python scripts/case-to-framework.py space-rock-breaker --report`  
- [`derived/coverage-report.md`](./derived/coverage-report.md) · [`derived/candidates.md`](./derived/candidates.md)

## 5. 数据完整度

| 项 | 状态 |
|----|------|
| 1920×1080 | complete（measured） |
| UD_/PD_ ID 列表 | complete（string harvest） |
| 15 成就 | complete（Steam stats） |
| 升级费用/效果数值 | incomplete |
| Artifact 个体表 | incomplete |
| Plinko peg 数值表 | incomplete |

## 6. Framework 反模式自检

- 未把 Plinko 升格为已上线 Optional（仅 1 实证 → candidates **推迟**）。  
- 未虚构未收获的 artifact 名或精确 Credits 价。  
- Fuel 记为 run meter，不塞进 prestige 货币。

## 7. 文件清单

```text
cases/space-rock-breaker/
├── README.md / metadata.json / mapping.json / ui-layout.json
├── resources.json / sectors.json / weapons.json / plinko.json
├── upgrades.json / prestige.json / artifacts.json / achievements.json
└── derived/ (coverage / candidates / missing-fields / framework-view/)
```
