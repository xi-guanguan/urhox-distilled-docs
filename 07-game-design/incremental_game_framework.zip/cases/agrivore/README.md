# Agrivore — 增量农场 + 战斗 + 技能树游戏设计指南

> **来源**: `D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\Managed\Assembly-CSharp.dll`
> **提取方法**: IL 反汇编 (`monodis`) + Unity Addressables bundle 解析
> **案例版本**: 增量游戏框架 v0.1, Agrivore v1.0 (2026-04-27 发布)

---

## 1. 游戏概述

**Agrivore** 是一款由 **verty** 独自开发, **Rogue Duck Interactive / Gamersky Games** 发行的 **Unity 6 增量农场 + 战斗 + 技能树游戏**。玩家扮演一个在永无止境的田野中种植、收割、升级作物的同时与一波波敌人战斗的角色, 跨越多个 **"七宗罪" (Sin) 主题**的 run, 收集 **Crown** 货币推进跨 run 的 **Treasury Skill Tree**。

| 字段 | 值 |
|---|---|
| 开发者 | verty (solo) |
| 发行商 | Rogue Duck Interactive, Gamersky Games |
| 引擎 | Unity 6 + Addressables 2.7.3 + LocalizedString |
| MCP for Unity | com.IvanMurzak.Unity.MCP + Unity MCP for Unity (Runtime + TestFiles) |
| 第三方插件 | MoreMountains.Feedbacks/Tools, SpriteShadersUltimate, Gaskellgames, LeanPool, Lofelt.NiceVibrations, Steamworks.NET |
| 流派 | Incremental, Idler, Roguelite, Farming, Strategy, Roguelike, Loot, Arcade |
| 标签 | 2D, Colorful, Medieval, Fantasy, Retro, Casual, Capitalism |
| 预计游戏时长 | 4-6 hours per run |
| 发布日期 | 2026-04-27 |
| Steam App ID | 4045540 |
| 商店 | https://store.steampowered.com/app/4045540/Agrivore_Incremental_Farming/ |

## 2. 规模概览

| 指标 | 数量 |
|---|---|
| Enum 类型 | 38 |
| Enum 总值数 | 478 |
| MonoBehaviour class | 736 |
| 主要数据 class (SO + key MB) | 50 |
| 本地化字符串 (英文) | 625 |
| 本地化语言数 | 13 |
| CropType | 26 |
| ItemType | 13 |
| EquipmentType | 7 |
| SigilType | 4 |
| SinType | 7 + None |
| EvolutionId | 35 + None |
| UniqueSkillType | 6 + None |
| QuestType | 8 |
| QuestDifficulty | 4 |
| LifetimeStatType | 5 |
| RunStatType | 3 |
| SetBonus (active) | 1 (Farmer) |
| UI 参考分辨率 | 1920×1080 |
| Hub 主 Tab | 10（Inventory…Castle） |
| Settings Tab | 4（Audio/Video/Gameplay/Credits） |

## 3. 核心系统

Agrivore 围绕 **10 个互相连接的系统** 展开（含 UI）。详见 `metadata.json` 的 `main_systems` 字段, 此处给出 framework 视角的概括:

### 3.1 资源 (Resources)

3 类货币: **Coins** (主货币, 来自作物收获转化) + 4 种 **Seeds** (Carrot/Corn/Potato/Beetroot, 用于 skill tree 节点) + **Gems** (终局货币, 来自 KingFeed + Quest + Run summary) + **Crowns** (跨 run 货币, 来自 Boss 击败 / PBAR_Reward)。详见 [`resources.json`](./resources.json)。

### 3.2 物品 + 装备 (Items & Equipment)

- **13 个 ItemType** (SWORD/BOW/HELMET/.../LASER) × **7 个 EquipmentType** (Hand/Offhand/Helmet/Chestplate/Boots/Potion/Accesory)
- **ItemSO** (22 字段): rarity, itemType, 6 类 damage stat, sigils, tierEntries, ...
- **ItemData** (59 字段, runtime): statModifiers List<ItemData/StatModifier>, currentTier, statTierOverride, ...
- 详见 [`items.json`](./items.json)

### 3.3 作物 (Crops)

- **26 个 CropType** (Carrot/Corn/Cauliflower/.../DarkMatter/HellFarmKing)
- **8 个 Tier** (Tier1..Tier4 + 4 个 Golden 变体) — Tier 决定 base coinValue, Golden 变体有 yield bonus
- **CropData** (14 字段): health, coinValue, cropValueBonusDefault, goldenYield, ...
- **12 个 CropRespawnSource** 决定 crop 被什么动作重新生成 (Default/SunBurn/Bow/Sword/Gun/Tractor/PotatoElectricChain/CornPopcorn/DroneBomb/StarfruitRain/StarDustDyingStar/StarDustSpores)
- 详见 [`crops.json`](./crops.json)

### 3.4 原罪 (Sins)

- **7 个 SinType** (Pride/Greed/Lust/Envy/Gluttony/Wrath/Sloth) + None
- **7 个 SinEvolutionUnlockNode** 子类 (与 EvolutionId 29-35 一一对应)
- **11 个 SinRunEffectKind** 决定 sin 触发的 stat 修饰
- 详见 [`sins.json`](./sins.json)

### 3.5 进化 (Evolutions)

- **35 个 EvolutionId** (PhalanxFormation..SinSloth) + None
- **3 个 EvolutionTargetType** (UniqueSkill/CropSkill/Equipment)
- **4 个 EvolutionModifierType** (Add/Multiply/Replace/SetFlag)
- **17 个 EvolutionUnlockNode** 子类 (4 个 CropUnlockNode + EquipmentUnlockNode + UniqueSkillUnlockNode + 7 个 SinEvolutionUnlockNode)
- 详见 [`evolutions.json`](./evolutions.json)

### 3.6 唯一技能 (Unique Skills)

- **6 个 UniqueSkillType** (Sunburn/Tractor/SpearShot/FarmingDrone/StardustCover/GreenHouse) + None
- 每个 CropType 关联 1 个 UniqueSkill — 作物提供特殊能力
- 详见 [`unique-skills.json`](./unique-skills.json)

### 3.7 印记 (Sigils)

- **4 个 SigilType** (ELECTRIC/POISON/FLAME/TEMPO)
- 每个 ItemSO 持 0..N 个 Sigil {sigilType, level}
- 4 个 BaseSigil 子类 (FlameOnHitSigil/HasteOnAttackSigil/...)
- 详见 [`sigils.json`](./sigils.json)

### 3.8 套装奖励 (Set Bonus)

- **1 个 SetBonus** (Farmer) — 玩家装备 2+ 件 Farmer 套装物品时触发
- 详见 [`set-bonus.json`](./set-bonus.json)

### 3.9 任务 + 成就 + 威望 (Quests, Achievements, Prestige)

- **8 个 QuestType** + **4 个 QuestDifficulty** (Farmivore.Quests 命名空间)
- **13 个 AchievmentManager** SerializeField 字段跟踪成就
- **7 个 PrestigeSO** 对应 7 个 SinType — sin-based prestige
- **TreasuryManager** (41 fields) + **TreasurySkillTree** (31 fields) 跨 run 资源池
- 5 个 LifetimeStatType + 3 个 RunStatType
- 详见 [`quests.json`](./quests.json) + [`achievements.json`](./achievements.json)

### 3.10 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑画布 | 1920×1080 | `globalgamemanagers` + `level0` CanvasScaler float 对 |
| UI 栈 | uGUI + TextMeshProUGUI | `TextMeshProUGUI` / CanvasGroup API |
| 左下选择区 | Bottom Left Selection UI | DLL 标签字符串 |
| Hub Tabs | 10 个 `*TabButton` | `InventoryTabsManager` |

```text
+---------------------------- 1920 x 1080 -----------------------------+
| HUD: Coins | Seeds×4 | Gems | Crowns · Health/DPS/KingMood/Sacrifice |
+----------------------------------------------------------------------+
|                     WORLD FARM FIELD (crops + combat)                |
|  + Bottom-Left Selection +                      [Hub content]        |
|  | Crops/Weapons/Sin     |                                           |
+----------------------------------------------------------------------+
| Tabs: Inv·Equip·Seeds·Shop·SkillTree·Treasury·Stats·Farmhouse·…     |
+----------------------------------------------------------------------+
```

组件树（PersistentHUD / Hub / Settings / Shop / Quests / Sacrifice / Tooltips）见 `ui-layout.json → components`。对照 **O9**；与 DEM 侧栏战场不同，本作为 **田野主视口 + 底栏多 Tab Hub**。

## 4. 框架映射总览

| Framework 概念 | Agrivore 实现 | 文件 |
|---|---|---|
| `core/01 design philosophy` | 单人开发 + 数据驱动 + Addressables 加载 | (此 README) |
| `core/02 resources` | 3 类货币 + 4 类 seed (详见 §3.1) | [`resources.json`](./resources.json) |
| `core/03 production lines` | 26 个 CropType + 12 个 RespawnSource (Pattern B + C) | [`crops.json`](./crops.json) |
| `core/04 unlocks` | SkillTreeNode (48 fields) + NodeSO (12) + 5 类 currency cost | [`metadata.json`](./metadata.json) |
| `core/05 unique abilities` | 6 个 UniqueSkill + 35 个 EvolutionId | [`unique-skills.json`](./unique-skills.json) [`evolutions.json`](./evolutions.json) |
| `core/06 quests` | 8 个 QuestType + 4 个 QuestDifficulty | [`quests.json`](./quests.json) |
| `core/07 cross-run progression` | 7 个 PrestigeSO + TreasuryManager + 5 个 LifetimeStatType | [`achievements.json`](./achievements.json) |
| `optional/o09-interaction-qol.md` | Hub 多 Tab + Settings + Tooltip 四段作物提示 + SkillTree 缩放 | [`ui-layout.json`](./ui-layout.json) |
| `optional/o06-area-focus.md` | ❌ **未使用** — 7 个 SinType 是永久 meta 倍率槽（无短时加速 + 冷却），不符合 O6 定义 | — |
| `patterns/pattern-r-rarity` (variant) | 7 个 SinType 作为跨种类 meta 倍率（与 rarity 同构）| [`sins.json`](./sins.json) |
| `patterns/pattern-r-rarity` | 5 个 Rarity 值 (Common..Legendary) | [`items.json`](./items.json) |
| `patterns/pattern-s-sigil-slot` | 4 个 SigilType + List<Sigil> | [`sigils.json`](./sigils.json) |
| `patterns/pattern-e-evolution` | 35 个 EvolutionId + 17 个 UnlockNode 子类 | [`evolutions.json`](./evolutions.json) |
| `schemas/*` | 38 个 enum + 50 个 SO schema | [`enums.json`](./enums.json) [`metadata.json`](./metadata.json) |

## 5. 提取方法与数据完整性

### 5.1 提取管线

1. **IL 反汇编**: `monodis Assembly-CSharp.dll > Assembly-CSharp.il` (12 MB, 254k 行)
2. **Enum 提取**: `_tools/il-disasm/extract_enums.py` → `_tools/il-disasm/extracted/enums.json` (38 enums / 478 values) — **完整**
3. **Class field schema 提取**: `_tools/il-disasm/extract_class_fields.py` → `_tools/il-disasm/extracted/class_fields_v2.json` (~50 main classes) — **完整 (字段名 + 类型 + tooltip + header + 序列化状态)**
4. **English localization**: `UnityPy` + `AddressablesTools` 解析 `localization-string-tables-english(en)_assets_all.bundle` → `_tools/il-disasm/extracted/locale_en_flat.json` (625 entries) — **完整**

### 5.2 数据完整性

| 数据类型 | 状态 | 说明 |
|---|---|---|
| 38 个 enum | ✅ 完整 | 从 IL 提取所有 .field public static literal |
| 50 个 SO/MB class schema | ✅ 完整 | 字段名 + 类型 + tooltip + 序列化状态 |
| English localization 625 strings | ✅ 完整 | ID -> text 映射 |
| ItemSO 实例数值 (price/attackSpeed/...) | ❌ 不完整 | ScriptableObject 字段在 Unity scene asset 中以 external ref 形式存在, UnityPy 1.25 无法解析 |
| CropData 实例数值 (health/coinValue/...) | ❌ 不完整 | 同上 |
| EvolutionUnlockNode 子类实例数值 (amount) | ❌ 不完整 | Editor serialize 的数据 |
| StatManager (57 fields) 累加公式 | ⚠️ 部分 | IL 中 4120 处 ldc.r4 字面量, 提供 IL 字节码级反编译可完整还原 |
| UI 区域几何 + 组件树 | ✅ 结构可复原 | [`ui-layout.json`](./ui-layout.json)；画布 1920×1080 measured；Hub/HUD rect 部分 inferred |
| RectTransform 绝对锚点 | ❌ 不完整 | 未反编译场景序列化坐标 |

### 5.3 还原完整实例值的方法

要提取 ItemSO/CropData 等 ScriptableObject 的实际数值, 可以:

1. **使用 AssetRipper**: 它能完整解析 Unity asset graph, 给出所有 SO 实例的 JSON
2. **使用 ilspycmd**: 完整反编译 Assembly-CSharp.dll 到 C# 源码, 可看到 literal default 值
3. **从 Unity Editor 中重新导出**: 用 UnityPy 配合更完整的 asset graph 解析

本 case 提供完整的 **schema + enum + field 映射**, 这对于框架验证已经足够 — 任何还原实例值的尝试都可以基于本 case 的结构补全。

## 6. 引用

- [界面布局 ui-layout.json](./ui-layout.json) — O9 实证（结构可复原）
- [Framework 主页 README.md](../../README.md)
- [Framework Game Design Guide](../../GAME_DESIGN_GUIDE.md)
- [Framework CHANGELOG](../../CHANGELOG.md)
- [Framework case-to-framework.py 验证脚本](../../scripts/case-to-framework.py)
- [Shelldiver 案例](../shelldiver/README.md) — 同为增量游戏案例, 提供了类似结构
- [Gnorp 案例](../gnorp/README.md) — 另一个 case reference
- [IL 提取工具目录](../../_tools/il-disasm/) — 本 case 使用的提取脚本和原始数据
- [Kittens Game 案例](../kittens-game/README.md) — 又一个 case reference

## 7. 致谢

- **monodis** (Mono 工具集) — IL 反汇编
- **UnityPy** (Python library) — Unity asset 解析
- **AddressablesTools** (Python library) — Addressables catalog 解析
- **ilty** (Agrivore 开发者) — 单一开发者构建了这种规模的复杂游戏, 是 framework 的良好案例
