# agrivore — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## resources.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `xp_cap` | 无 xp cap — Agrivore 不用 XP 等级, 用作物 Tier (Tier1..4) 作 progression 阶梯 |
| `tier_costs` | 无 framework tier_costs 表 — Agrivore 通过 SkillTreeNode.{carrotCost, cornCost, potatoCost, beetrootCost, coinCost, gemCost} 字段按 node 表达 |

## items.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | ItemSO.price 不在 framework 视图（从 IL 提取实例值缺失, 见 metadata.json/data_completeness） |
| `currency` | ItemSO 通过 ShopManager.DetermineRarity 用 coins 购买, framework 视图需补 'coins' 货币类型 |

## items.json

- **Schema**: `../../../schemas/rarity.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `base_probability` | ShopManager.DetermineRarity 是 runtime function, 静态 drop_weight 未知（IL 中以 ldc.r4 字面量形式存在） |
| `value_multiplier` | rarity 不直接影响 coinValue, 而是通过 ItemSO.price 调整 — framework 视图的 value_multiplier 需要从 26 CropType coinValue 推算 |

## crops.json

- **Schema**: `../../../schemas/multi-region.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `primary_resource` | 每个 crop 的 primary_resource 都是 'coins'（coinValue 字段） |
| `unlock_gate` | GoldenUnlockRule (5 values) + NextCropUnlockRule (5 values) 决定 crop 何时出现, framework 用 unlock_gate |

## sins.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | SinRunEffect 没有显式 cost — 玩家通过 1+ 个 SinEvolutionUnlockNode (EvolutionId 29-35) 解锁, 解锁 cost 走 SkillTreeNode |
| `tier` | 每个 sin 对应 1 个 tier, framework 用 sin.id (1-7) 表示 |

## evolutions.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | Evolution 解锁 cost 走 SkillTreeNode (coinCost/gemCost/carrotCost/...), 没有 standalone evolution cost |
| `target_type` | EvolutionTargetType (3 values) 是 framework 期望的 'modifies' 字段, 已映射到 evolutions[i].target_type |

## quests.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | Quest 完成得 gemReward (int), 不是 cost — framework 视图需把 gemReward 映射为 'gain' 而非 'cost' |
| `target_count` | QuestDefinitionSO.targetCount (int) 是 framework 期望的 'level' 字段 |

## sigils.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | Sigil 不单独 cost — 玩家通过装备带 sigil 的 item 来获得 sigil 效果 |
| `effect_value` | Sigil.level 决定 affix 强度, 但具体数值在 BaseSigil 子类实例中, IL 提取不到 |

## set-bonus.json

- **Schema**: `../../../schemas/cross-building-inspiration.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `bonus_count` | SetBonus.itemsInSet 是 List<ItemSO>, framework 期望 '需 2 件触发' 的固定数量 |
| `effect` | FarmerSet 只有一个 SerializeField, 具体效果从 IL 看不到（需 Unity asset 解析） |

## achievements.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `cost` | Lifetime stat 累积是自动的, 玩家通过 7 个 PrestigeSO 主动 'spend' 资源推进 |
| `current_value` | LifetimeStat 跨 run 累加, 当前值存在 LifetimeStatManager (10 fields) 运行时 |
