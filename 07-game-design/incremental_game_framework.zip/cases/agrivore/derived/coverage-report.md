# agrivore · framework 覆盖度报告

> 由 `scripts/case-to-framework-coverage.py` 自动生成.
> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)
> 共 10 个 system.

| Case System | Framework 覆盖 | 备注 |
|------------|--------------|------|
| resources (currencies) | ✅ | 已映射到 1 个 schema: constants |
| items (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| crops (regions) | ✅ | 已映射到 1 个 schema: multi-region |
| sins (upgrades) | ✅ | 已映射到 1 个 schema: permanent-upgrade |
| evolutions (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| quests (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| sigils (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| set-bonus (buildings) | ✅ | 已映射到 1 个 schema: cross-building-inspiration |
| achievements (upgrades) | ✅ | 已映射到 1 个 schema: permanent-upgrade |
| ui-layout | ⚠️ | 映射不充分: (无强制 schema — Optional O9 Interaction QoL) |

## 统计

- ✅ 已覆盖: **9**
- 🆕 未覆盖 (新): **0**
- ⚠️ 部分覆盖: **1**
- ❌ 不适用: **0**

## ⚠️ 框架映射过载提示 (Lossy Mapping)

以下 framework 概念被 ≥ 3 个不同 case system 复用 — 暗示该概念太宽, 需新 pattern:

- `upgrade` 被 4 个 case system 复用

## 🆕 候选贡献 (Candidate for Contribution)

以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)

→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估

## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件

- 🆕 数: **0** (< 1: 可跳过)
- ⚠️ 数: **1** (< 2: 可跳过)
- 🔗 Reverse-link 缺失: **0**
