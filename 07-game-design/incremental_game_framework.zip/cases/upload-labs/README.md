﻿# Upload Labs — Implementation Case

> Source code: `github.com/Official-Husko/LibreSeed-Labs` (community open-source reimagining of the Steam title *Upload Labs* by Enigma Studio, based on Upload Labs v1.0.9).
> Data files in `./`.
> This case describes what Upload Labs does and how its mechanics map onto the framework.

Upload Labs is a Godot 4 single-player node-based automation / idle game. The player opens a desktop metaphor, places window-style nodes (Downloader, Processor, Verifier, Storage, …) on it, and wires their output ports to input ports of other windows using connector lines. Files flow through the pipeline as **bandwidth (bps)**, get verified, get stored, get uploaded, and finally sold for `money` or fed to an `AI` node that returns a stronger currency. The codebase is **~103 distinct window/node types** (`data/windows.json`) backed by a single **3-tuple attribute model** `scripts/attribute.gd` and a **6-type resource-transfer engine** `scenes/resource_container.gd`. State is held in `scripts/globals.gd` (~410 lines, single-file state schema). All progression systems — money, research, hack, code, prestige — are uniformly described as 3-tuples `[additive, multiplicative, exponential]` that the engine aggregates idempotently.

The framework-relevant parts of this case are:

1. **A node-pipeline game where the placement of nodes IS the build**, not a tab/grid, with a single transfer engine that scales with N nodes of M types.
2. **A unified 3-tuple attribute model `[a, m, e]`** that handles every multiplier in the game (positive buff, negative debuff, percent, exponential), with one ~15-line class.
3. **A prestige economy split into two distinct currency tracks** (`token` from requests/achievements → perks; `max_research` → milestones), with `cost_inc:100` milestones that are an order of magnitude steeper than the `cost_inc:10` perks.
4. **A service-driven soft-reset system** where tokens refund specific upgrade categories (`hack_reset`, `optimization_reset`, `application_reset`) — neither a hard prestige nor a perk tree, but a third path.
5. **Bitflag file-variation products**: 6 base file types × 15 variation flags = 90 distinct sellable items in the storage tab.
6. **Tick-engine with three time tracks**: real time, time-played, elapsed-time-multiplied-by-offline-multiplier (with a 5× toggle for "resting" while away).
7. **UI layout (O9, structure-rebuildable)**: desktop canvas + side menus ×8 + window palette ×7 + connector tools — see [`ui-layout.json`](./ui-layout.json).

| 元信息 | 值 | 来源 |
|--------|----|------|
| 界面布局 | 1920×1080 结构可复原（O9 + Pattern N） | [`ui-layout.json`](./ui-layout.json) |

---

## 1. The 8-Currency Economy

The game has 8 currencies in `data/currencies.json` (each has `name`, `icon`, `production` flag, `level` gate, `requirement` gate):

| id | role | production | gate |
|---|---|---|---|
| `money` | primary buy currency | yes | level 0 |
| `research` | science/research currency | yes | level 9 |
| `token` | cross-system soft-prestige currency | yes (from requests/achievements) | level 0 |
| `hack_point` | hacking subsystem currency | no | research.hacking |
| `corporation_data` | mid-tier breach currency | no | research.breach_corporation |
| `government_data` | late-tier breach currency | no | research.breach_government |
| `optimization_point` | code-optimization currency | no | research.optimizations |
| `application_point` | code-application currency | no | research.applications |

5 of 8 currencies (`hack_point`, `corporation_data`, `government_data`, `optimization_point`, `application_point`) are **non-produced**: they are *earned only* by the respective gameplay loop and *spent* in tightly-scoped upgrade categories (`data/upgrades.json` -> `currency: "<x>"`). The 5 currencies form a **per-subsystem gating mechanism** — the player cannot "buy their way past" a research tree by accumulating `money`. This is enforced in `scenes/upgrade_panel.gd:74-77` (`can_purchase` checks `Globals.currencies[Data.upgrades[name].currency]`).

**No explicit cap field exists.** Caps are emergent:
- `attributes.json:storage_size` (default `1e24`) caps total uploaded files in storage.
- `attributes.json:max_rest_time` (default `600s`, +30s per `max_rest_time` perk level) caps offline progress.
- Each window has a per-port `limit` (e.g. `storage_size: 100` per file-type bucket).

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Core C1** (multi-currency) | 8 currencies with explicit per-spend domains. |
| **Pattern B** (binary unlock) | `requirement` field on upgrades/research gates via either research-tree reach or per-subsection currency accumulation. |
| **Pattern C** (permanent upgrade) | `data/perks.json` (18 entries, all `currency:"token"`) — every level purchased *survives* `Signals.reboot.emit()`. |

---

## 2. The Cost Formula Engine (4 forms, 1 schema)

Every cost-bearing item in the game — upgrades, research, perks, milestones, in-window add/upgrade buttons, achievement requirements — is described by a **3-field shape**: `cost`, `cost_e`, `cost_inc`. The actual price formula is one line in `scenes/upgrade_panel.gd:38`:

```gdscript
var price = Data.upgrades[name].cost * pow(10, Data.upgrades[name].cost_e) * pow(Data.upgrades[name].cost_inc, level) * Attributes.get_attribute("price_multiplier")
```

So `price(level) = base × 10^cost_e × cost_inc^level × price_multiplier`. The same shape is used in `scripts/globals.gd:188-191` for milestones and `scripts/research_screen.gd:73` for research (single-shot, no level). The four cost-bearing tables — `data/upgrades.json` (86 items), `data/research.json` (47 items), `data/perks.json` (18 items), `data/milestones.json` (3 items) — all use this 3-field shape verbatim.

**Cost bearing tables at a glance** (from `./upgrades.json` etc.):

| table | items | typical `cost_inc` | comment |
|---|---|---|---|
| `upgrades.json` | 86 | 10 (main), 2000 (breach) | by-category: `_uncategorized: 9, main: 31, hacking: 8, breach: 6, optimizations: 22, applications: 10` |
| `research.json` | 47 | n/a (single-shot) | tree with 1 root (`research`), 4 main branches, max chain depth ~10 |
| `perks.json` | 18 | 1 | `cost_inc:1` is the linear variant |
| `milestones.json` | 3 | 100 | `cost_inc:100` is the steepest by an order of magnitude |

**The `price_multiplier` attribute** is itself a `[a, m, e]` tuple, e.g. `breach_price_multiplier` is `[-0.05, 0, 0]` — a *negative* additive discount. This means the *same* attribute system that handles "+0.2 multiplier" also handles "-0.05 discount" without any special-cased discount field. The framework pattern for this is **Optional O5 (bottleneck balance) — the "discount as additive" variant** that we will document separately; here it is just one tuple among many.

In-window add/upgrade buttons (`scenes/windows/window_processor.gd:50-51`) re-use the same shape but with **hard-coded exponents**:

```gdscript
add_cost = 1 * pow(10, 6) * pow(1000, count) * Attributes.get_attribute("price_multiplier")
upgrade_cost = 4 * pow(10, 3) * pow(4, level + 1) * Attributes.get_attribute("price_multiplier")
```

i.e. adding a core is `1000×` per count, upgrading a level is `4×` per level. These are two more cost-curve primitives (C-tier: ×1000, ×4) that are *not* in the JSON data tables.

**Achievements use a flat form** (`scripts/achievements/achievement_stat.gd:9`):

```gdscript
amount = Data.achievements[name].requirement * (10 ** Data.achievements[name].requirement_e)
```

i.e. `requirement × 10^requirement_e` — same shape, no `level` (achievements are one-shot gates).

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern C1–C6** (cost curves) | The 4 cost-bearing tables each tune `(base, cost_e, cost_inc)` to a different family: `cost_inc=1` (linear), `cost_inc=10` (main), `cost_inc=100` (milestone), `cost_inc=2000` (breach). |
| **Core C1** (multi-currency) | The `currency` field on each cost-bearing item picks which of 8 currencies the price is paid in. |
| **Optional O5** (bottleneck balance) | The discount side: `breach_price_multiplier` is `[-0.05, 0, 0]` — a *negative* additive that aggregates through the same 3-tuple engine. |

---

## 3. The 3-Tuple Attribute Model `[a, m, e]`

`scripts/attribute.gd` is the **single source of truth for every multiplier in the game** — 15 lines:

```gdscript
class_name Attribute
extends RefCounted

var multiplier: float = 1
var exponent: float = 1
var raw: float = 0

func add(a: float, m: float, e: float = 0, e_count: float = 0) -> void :
    raw += a * (1.0 + (m / multiplier)) * multiplier * exponent
    multiplier += m
    if e > 0:
        var exp: float = pow(e, e_count)
        raw *= exp
        exponent *= exp
    changed.emit()
```

Every multiplier in the entire game is one of these 3-tuples in JSON:

```json
"attributes": {
    "download_speed_multiplier": [0.2, 0, 0],
    "storage_size":              [0, 0, 4],
    "price_multiplier":          [-0.05, 0, 0],
    "bandwidth_multiplier":      [0, 0, 1.2]
}
```

The `add(a, m, e)` method is **idempotent** (order-independent): `add([0, 0, 2])` and `add([0, 0, 1.5])` compose into `×3.0` final, regardless of which one was applied first. The dispatcher in `scripts/attributes.gd:42-91` (95 lines) pushes every JSON table — `Data.upgrades`, `Data.research`, `Data.perks`, `Data.milestones`, `Data.boosts`, `Data.windows` — through this single method. So a programmer wanting to "add a +20% bandwidth milestone" writes:

```json
{ "name": "system", "cost": 1, "cost_e": 6, "cost_inc": 100,
  "attributes": { "bandwidth_multiplier": [0, 0, 2] } }
```

…and the engine handles the rest. The `e_count` parameter (default 0) lets the same attribute be applied as `pow(e, e_count)` for *fractional* exponent contributions (e.g. 1.2 × 1.2 × 1.2 stacks as `pow(1.2, 3)`).

**Three negative-tuple cases in the data** (proving the model is symmetric):

| item | tuple | meaning |
|---|---|---|
| `breach_price_multiplier` | `[-0.05, 0, 0]` | discount: -0.05 to price each level |
| `cheapskate` perk | `[-0.05, 0, 0]` | discount: -0.05 to all prices per level |
| `overclock` resource | (SETTING type, broadcast) | not a tuple — broadcast through a different transfer rule |

**The dispatcher (`scripts/attributes.gd:42-91`)** has exactly 5 entry points, one per JSON table:

1. `apply_attribute_dict(upgrade.attributes, level)` for `Data.upgrades` — uses the `level` parameter.
2. `apply_attribute_dict(research.attributes)` for `Data.research` — single-shot.
3. `apply_attribute_dict(perk.attributes, level)` for `Data.perks` — uses the `level` parameter.
4. `apply_attribute_dict(milestone.attributes, level)` for `Data.milestones` — uses the `level` parameter.
5. `apply_windows_attribute_dict(boost.window_attributes, time)` for `Data.boosts` — uses the `time` parameter and a `Signals.boost_removed` listener to *un*-apply when the timer expires.

This is a **drop-in framework pattern**: any incremental game can lift this 15-line class + 95-line dispatcher verbatim and have all 5 progression tables share one multiplier engine.

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern E** (status effect stack) | The 3-tuple `[a, m, e]` is the *economic-axis* variant of status stacking — but unlike `Pattern E` it has a single fixed class with one method. |
| **Pattern C** (permanent upgrade) | All 5 tables are data; one method aggregates them. |
| **Core C4** (multiplicative composition) | The `pow(e, e_count)` step is **multiplicative-of-multiplicative** — gives log-scale compounding without writing it explicitly. |

---

## 4. The Node-Pipeline Game (95 Windows, 1 Transfer Engine)

`data/windows.json` defines 103 distinct window/node types across 7 categories (`data/derived/windows_by_category.json`):

| category | count | examples |
|---|---|---|
| `cpu` | 22 | `processor`, `verifier`, `cluster`, `ram`, `cooling` |
| `network` | 15 | `downloader`, `uploader`, `storage`, `network_exchanger`, `synchronizer` |
| `gpu` | 16 | `gpu`, `ai`, `data_lab` |
| `hacking` | 12 | `hacker`, `breach_anonymous`, `breach_corps`, `breach_bank`, `payload_launcher` |
| `coding` | 18 | `coder`, `ide`, `commit`, `build`, `code_optimization`, `variable_combiner` |
| `research` | 5 | `data_lab`, `agi`, plus 3 boost-windows |
| `utility` | 13 | `collector`, `auto_clicker`, `redownload`, `mine_tether`, `crypto_seller` |

(2 windows have empty `category` field — those are `data_lab` and `agi` placed into the `research` palette via scene, not category. See `data/windows.json` raw.)

**The canonical window shape** (`data/windows.json` `processor` entry):

```json
{ "name": "window_processor", "icon": "processor", "description": "window_processor_desc",
  "scene": "window_processor", "group": "", "category": "cpu", "level": 0,
  "requirement": "upgrade.processor", "hidden": false,
  "attributes": { "limit": -1, "minimum_level": 0, "minimum_cores": 1, "maximum_cores": 99,
                  "extra_cores": 0, "main_core_multiplier": 1 },
  "data": {}, "guide": "window_processor" }
```

Fields:
- `scene` — Godot scene path; the engine instantiates this and looks up the script.
- `requirement` — `upgrade.X`, `research.X`, or `perk.X` id that gates this window's palette appearance.
- `attributes.limit` — `-1` unlimited, `1` unique (e.g. `data_lab`, `agi`, `coder`, `hacker`, `drain`), `0` no-by-default.
- `data` — persistent state (e.g. `breach_*` windows keep `{level, max_level}`).
- `group` — used by services (`service.hack_reset` destroys all `group:"breach_skills"` windows).

**The connector engine** (`scripts/connectors.gd:25-32` + `scripts/connector_button.gd:185-243`) is the wiring logic:

```gdscript
# scripts/connectors.gd:25-32
func _on_connection_created(output: String, input: String) -> void :
    var connector: Connector = load("res://scenes/connector.tscn").instantiate()
    connector.output_id = output
    connector.input_id = input
    ...
    add_child(connector)
```

The user clicks an `OUTPUT` button on a window, then clicks an `INPUT` button on a different window; the `connection_droppped` signal resolves into a `Connection` node. The `Connectors` class is the container that listens for `connection_created` and spawns a `Connector` scene between the two resource-container ids.

**The 6-type transfer engine** (`scenes/resource_container.gd:84-161`) is what makes the wiring *meaningful*:

| type | name | behaviour | example use |
|---|---|---|---|
| 0 | `MATERIAL` | integer splitting, `floor(count)/N` per output, `pick_random()` for remainder | file resources, hack_points |
| 1 | `FLOW` | bandwidth-style: fill outputs up to `limit` then divide remainder | download_speed, clock_speed, ai |
| 2 | `BOOST` | `count/N` pure divisor | bandwidth_multiplier, overclock |
| 3 | `MATERIAL_LIMITED` | type 0 but bounded by each receiver's `limit` | storage (per-file bucket) |
| 4 | `SETTING` | pure broadcast | overclock (the resource, not its multiplier) |
| 5 | `FLUID` | bounded push | heat dissipation |

So when the player wires `processor.output[0] (clock_speed, type=1) → verifier.input[0] (clock_speed, type=1)`, the transfer engine reads type 1 from the source container, finds N outputs, fills them up to their `limit`, and divides the remainder — regardless of *which* downstream node the line goes to. **Any node with a matching `type` on its input slot is a valid downstream**; the engine does not know or care about node identity.

**Tick rate is global, not per-node** (`scenes/windows/window_base.gd:83-86`):

```gdscript
func _on_tick() -> void :
    if !paused:
        process(0.05 * Attributes.get_attribute("time_multiplier") * Attributes.get_attribute("offline_time_multiplier"))
```

A central `Signals.tick` fires every 0.05s (20 Hz). Each window runs `_on_tick` at this base rate scaled by `time_multiplier × offline_time_multiplier`. The `process(delta)` method on each window then reads its own input containers, advances its own state, and pushes to its own output containers. The whole game state is the union of every window's `data` field, plus the global `currencies` and `attributes` dicts.

**Resource examples** (from `data/resources.json`):

```json
"download_speed": { "type": 1, "suffix": "bps", "connection": "circle",  "color": "lime"   },
"overclock":      { "type": 4, "suffix": "%",   "connection": "octagon", "color": "yellow" },
"heat":           { "type": 5, "suffix": "K",   "connection": "octagon", "color": "red"    },
"vulnerability":  { "type": 2, "suffix": "x",   "connection": "pentagon","color": "violet" },
"trojan":         { "type": 0, "suffix": "",    "connection": "triangle_down","color":"red" }
```

The `connection` field is the visual shape of the connector line (circle for FLOW, octagon for BOOST/SETTING/FLUID, pentagon for combat, triangle for materials). The `color` is one of the 11 keys in `data/connectors.json` (`white, black, lime, cyan, orange, red, yellow, violet, green, blue, pink`).

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Optional O11** (multi-region subsystem) | The desktop is *one* region; `group` field on windows (e.g. `breach_skills`) lets services isolate a subset. |
| **Pattern R** (rarity tier) | `category` and `group` are 2 orthogonal axes of classification, not power tiers. |
| **Pattern T** (tier jump) | `level: 0` field in window — but here it gates the *tab* in the palette, not the building itself. |
| **Core C6** (geometric cost) | `pow(1000, count)` for in-window add (cores), `pow(4, level+1)` for in-window upgrade. |

---

## 5. The Research Tree (47 nodes, 1 root, max depth ~10)

`data/research.json` defines 47 research items; `data/derived/research_tree.json` materialises parent→child adjacency. The tree has **exactly one root** (`research`) and four main branches, with longest chain ~10 deep.

**Canonical research shape** (excerpts from `data/research.json`):

```json
{ "name": "research",        "requirement": [],   "effect": "Discover science" }
{ "name": "synchronizer",    "requirement": ["research"], "effect": "Sync files" }
{ "name": "verifier",        "requirement": ["research"], "effect": "Validate files" }
{ "name": "scheduler",       "requirement": ["synchronizer"], "effect": "Multi-task" }
{ "name": "hacking",         "requirement": ["research"], "effect": "Unlock hack tab" }
{ "name": "breach_corporation", "requirement": ["hacking"], "effect": "Unlock corp data" }
{ "name": "breach_government",  "requirement": ["breach_corporation"], "effect": "Unlock gov data" }
{ "name": "breach_bank",        "requirement": ["breach_government"], "effect": "Bank breach" }
{ "name": "trojan",          "requirement": ["breach_bank"], "effect": "Inject trojan" }
{ "name": "agi",             "requirement": [..., "coding", "hacking"], "effect": "AGI" }
```

**A single research can unlock many things at once** through the `unlocks` object (not always present, but used in `Data.upgrades.<name>.requirement` style — see §6 for upgrades with multi-requirement chains).

**Research is single-shot, not levelable** (`scripts/research_screen.gd:73`):

```gdscript
var price = Data.research[name].cost * pow(10, Data.research[name].cost_e)
```

i.e. `price = cost × 10^cost_e` with **no `cost_inc` and no level** — research is bought once. Compare with the 4-level table in §2.

**One entry has an empty `category`**: `agi` is reachable when *multiple* research paths converge (`hacking` AND `coding` AND likely `tier_3`); its cost is the highest of the prerequisites. This is the framework's "**AND-gate**" pattern encoded in data: the array `requirement: ["hacking", "coding", "tier_3"]` (with implicit AND) is exactly the same shape as `and` achievement conditions (see §8).

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern B** (binary unlock) | Strict binary tree of 47 nodes — each is either researched or not. |
| **Pattern S** (skill tier ladder) | The 4-branch structure (network / cpu / gpu / hack-and-code) is the *tier ladder*: each tier's "head" research unlocks a tab. |
| **Optional O3** (bottleneck gate) | `agi` is an AND-gate; you cannot buy AGI research until you have researched *all* of hacking, coding, and tier_3. |
| **Optional O1** (multi-system unlock) | The `requirement` array is multi-target: it can list multiple research names that must ALL be done. |

---

## 6. Upgrades (86 items, 6 categories)

`data/upgrades.json` defines 86 upgrades; `data/derived/upgrades_by_category.json` groups them:

| category | count | currency | role |
|---|---|---|---|
| `_uncategorized` | 9 | mixed | meta upgrades (`storage_size`, `optimization`, `application`, `driver`, 5× `research_*_multiplier`) |
| `main` | 31 | `money` | core progression: `processing_value_multiplier`, `mining_multiplier`, `premium_texts`, … |
| `hacking` | 8 | `hack_point` | per-currency-tier upgrades: `hack_money_multiplier`, `hack_speed_multiplier`, … |
| `breach` | 6 | `corporation_data` / `government_data` | breach-tier: `breach_price_multiplier`, `breach_layers`, `breach_government_layers`, … |
| `optimizations` | 22 | `optimization_point` | code sub-track |
| `applications` | 10 | `application_point` | code sub-track |

**The 9 uncategorized items are the most interesting structurally**:

```json
"storage_size":     { "cost": 1, "cost_e": 42, "cost_inc": 16,  "currency": "money",
                      "attributes": { "storage_size": [0, 0, 4] }, "category": "" }
"optimization":     { "cost": 5, "cost_e": 1,  "cost_inc": 2,   "currency": "",
                      "attributes": {}, "category": "" }
"application":      { "cost": 6, "cost_e": 2,  "cost_inc": 4,   "currency": "",
                      "attributes": {}, "category": "" }
"driver":           { "cost": 1, "cost_e": 4,  "cost_inc": 5,   "currency": "",
                      "attributes": { "bandwidth_multiplier": [0, 0, 1.2],
                                      "clock_multiplier":     [0, 0, 1.2],
                                      "gpu_multiplier":       [0, 0, 1.2] }, "category": "" }
"research_bandwidth_multiplier":  { "cost": 5, "cost_e": 2, "cost_inc": 5, "currency": "", ... }
"research_clock_multiplier":      { "cost": 5, "cost_e": 2, "cost_inc": 5, "currency": "", ... }
"research_gpu_multiplier":        { "cost": 5, "cost_e": 2, "cost_inc": 5, "currency": "", ... }
"research_hack_power_multiplier": { "cost": 5, "cost_e": 2, "cost_inc": 5, "currency": "", ... }
"research_code_speed_multiplier": { "cost": 5, "cost_e": 2, "cost_inc": 5, "currency": "", ... }
```

Three distinct sub-patterns here:

1. **`storage_size`** — single 4× exponential attribute with `cost_e=42, cost_inc=16`. The highest-cost single item in the game; this is the "soft cap" item that *enables* higher production.
2. **`optimization`, `application`** — empty `attributes`, paid in no currency, only `cost × 10^cost_e × cost_inc^lvl`. These are **counter windows** that *unlock* the code sub-track (their `requirement` is read by `data/windows.json`).
3. **`driver`, `research_*_multiplier`** — empty `currency`, exponential-only `attributes`, cheap cost. These are the **research-replicated upgrades**: each one is a *free* multiplier the player buys with research. So `driver` (paid by some currency) gives `×1.2` on bandwidth/clock/gpu, and then `research_*_multiplier` (no currency) gives another `×1.2` *via research* — i.e. the same attribute has two independent upgrade paths, one economic and one research-based. This is a **parallel attribute-stack** pattern.

**`breach_price_multiplier` is `[-0.05, 0, 0]`** — a *negative* additive tuple. It reduces the breach price by 5% per level. The tuple composes with positive tuples (`[+0.2, 0, 0]` etc.) through the same `add()` method. This proves the model is **symmetric**: discounts and buffs share the same schema, no separate `discount` field needed.

**Two distinct cost_inc scales** appear in this table:

- `cost_inc: 2000` for `breach_*` (e.g. `breach_money_multiplier: 4*10^2*2000^lvl cur=corporation_data`). Each breach level costs `2000×` the previous — a 3.3-level jump per magnitude.
- `cost_inc: 10` for `main` (e.g. `mining_multiplier: 8*10^7*10^10^lvl`). Each main level costs `10^10 = 10 billion` times the previous — i.e. a true **per-decade** jump.

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern C1–C6** (cost curves) | `cost_inc` ranges from 2 (linear-ish counter) through 10 (main), 16 (storage), 100 (milestone), 2000 (breach). The framework documents these as the C1–C6 ladder. |
| **Pattern C** (permanent upgrade) | 86 items across 6 categories — all share the 3-tuple attribute schema. |
| **Optional O5** (bottleneck balance) | `breach_price_multiplier` and `cheapskate` are negative tuples — discount-as-data. |
| **Optional O1** (multi-system unlock) | The `requirement` field on upgrades can be `research.X` *or* `upgrade.X` (i.e. research OR an upgrade chain), so the upgrade graph is a DAG not a tree. |

---

## 7. The 3-Milestone Prestige Layer

`data/milestones.json` defines 3 milestones — the **steepest cost_inc in the game** (`cost_inc: 100`):

| key | cost | cost_e | cost_inc | permanent effect |
|---|---|---|---|---|
| `system`  | 1 | 6  | 100 | `bandwidth_multiplier: [0,0,2]`, `clock_multiplier: [0,0,2]`, `gpu_multiplier: [0,0,2]` |
| `hacking` | 1 | 8  | 100 | `hack_power_multiplier: [0,0,2]` |
| `coding`  | 1 | 10 | 100 | `code_speed_multiplier: [0,0,2]` |

i.e. **level 1 system = 1×10^6 = 1,000,000 `token` (or `max_research`)**; level 2 = 100,000,000; level 3 = 10,000,000,000; … Each level doubles the multiplier in 3-tuples. The 3 milestones cover the 3 main system branches (network/cpu/gpu, hack, code).

**The milestone currency is `max_research`**, the lifetime total of `research` produced (`scripts/globals.gd:48-49`):

```gdscript
money_level = floori(log(max_money + 1) / log(10))
research_level = floori(log(max_research + 1) / log(10))
```

So `max_research` is not stored as a counter but as a *log-derived level* — each decade of lifetime research is one level. Buying the level-1 system milestone costs 1×10^6 `max_research`-equivalent; this is the framework's **"lifetime-currency prestige"** encoded as a log level.

**Perks are the parallel track** (`data/perks.json`, 18 entries, all `currency: "token"`):

| perk | cost (level 1) | effect |
|---|---|---|
| `auto_collect` | 40 token | window auto-collects its output |
| `groups` | 50 token | window groups tab |
| `download_manager` | 200 token | parallel downloads |
| `network_limiter` | 200 token | bandwidth cap |
| `thread_manager` | 200 token | multi-thread |
| `cheapskate` | varies | `[-0.05, 0, 0]` price discount per level |
| `token_multiplier` | varies | `[+0.2, 0, 0]` token gain per level |
| `system_upgrade` | varies | `[0, 0, 1.2]` bandwidth/clock/gpu per level |
| `max_rest_time` | varies | `+30s` offline cap per level |
| `rest_time_multiplier` | varies | `+0.1` offline-multiplier per level |
| `hack_specialization` | varies | `[0, 0, 1.2]` hack_power per level |
| `code_specialization` | varies | `[0, 0, 1.2]` code_speed per level |
| `plus_network` / `plus_laboratory` | varies | `limit: [1,0,0]` perk that bumps a category cap |
| `antivirus_pro` | varies | disables hack counter-attack |
| `mine_tether` | varies | auto-mines on idle |
| `automated_crypto_seller` | varies | auto-sells crypto |
| `ide` | varies | unlocks `coder` window |

**Perks and milestones share the `3-tuple` schema** — `cheapskate: [-0.05, 0, 0]` and `system_upgrade: [0, 0, 1.2]` are *literally the same data type* as the main upgrades' `attributes` field. The engine does not distinguish "permanent buff" from "discount" from "milestone" — they all go through `Attribute.add()`.

**The two prestige tracks** in contrast:

| aspect | perks | milestones |
|---|---|---|
| currency | `token` (request/achievement rewards) | `max_research` (lifetime research, log-derived) |
| `cost_inc` | 1 (linear) | 100 (two-decade jump per level) |
| persistence | survives `Signals.reboot.emit()` | survives `Signals.reboot.emit()` |
| count | 18 | 3 |
| role | QoL + small multipliers | large end-game multipliers |
| unlock gate | none (any time) | `Signals.reboot` from `scripts/portal_popup.gd:25-28` |

**The reboot flow** (`scripts/portal_popup.gd:25-28`):

```gdscript
func _on_enter_pressed() -> void :
    Signals.popup.emit("")
    Signals.reboot.emit()
    Sound.play("click2")
```

`Signals.reboot` is the *single* reset signal. It wipes `currencies`, `Data.upgrades`-level counters, and active windows — but **not** perks, **not** milestones, **not** achievements. This is the "**hard prestige layer**" — distinct from the soft-reset services in §9.

**Achievement-token loop** (`scripts/globals.gd:271-276`): claiming an achievement adds its `reward` to `currencies["token"]` and to `stats.max_tokens`. The achievement `reborn` (`stat: "reborns" ≥ 1 → 50 tokens`) explicitly tracks portal cycles. So the loop is: **play → achieve → claim token → spend token on perk → unlock more windows → play more → reboot → repeat**.

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern P** (prestige currency) | Two distinct prestige tracks: `token` (perks) and `max_research` (milestones). |
| **Pattern C** (permanent upgrade) | Perks and milestones survive reboot and stack with main-game upgrades. |
| **Pattern O13** (temporal multi-cycle) | (Not present in Upload Labs — but `token_multiplier` perk + achievement `reborn` counter is the closest analogue: cycle number is in the `stats` dict, not in a calendar.) |
| **Optional O5** (bottleneck balance) | Milestone level 1 = 1M, level 2 = 100M, level 3 = 10B — the steep cost curve is itself the balance mechanism. |

---

## 8. Achievements (16) and Requests (28) as Cross-System Objectives

`data/achievements.json` defines 24 achievements; each has a `requirement` (stat, window, research, upgrade, perk, or all-of), an `amount`, an `amount_e`, and a `reward` (in `token`). `data/requests.json` defines 42 contract-style requests — each request wants a specific **file × variation** product, paid in `token` on completion.

**Achievement shape** (4 types of `requirement`):

```json
{ "name": "research",   "requirement": "stat.research",   "amount": 1, "amount_e": 0,  "reward": 1 }   // 1 research
{ "name": "max_windows","requirement": "window",          "amount": 10, "amount_e": 0, "reward": 10 }  // 10 windows
{ "name": "reborn",     "requirement": "stat.reborns",    "amount": 1, "amount_e": 0,  "reward": 50 }  // 1 reboot
{ "name": "requests",   "requirement": "request",         "amount": 1, "amount_e": 0,  "reward": 5 }   // 1 request complete
{ "name": "requests_and","requirement": ["request_a","request_b"], "amount": 1, "amount_e": 0, "reward": 30 }  // BOTH
{ "name": "trojan",     "requirement": "resource.trojan", "amount": 1, "amount_e": 0,  "reward": 30 }  // 1 trojan
{ "name": "quarantined","requirement": "event",           "amount": 1, "amount_e": 0,  "reward": 20 }  // event-fired
```

The `requirement` field is **typed by string-prefix**: `stat.X` (stat counter), `window` (count), `request` (count), `event` (signal-fired), `resource.X` (resource counter), `["...","..."]` (AND-array). The dispatcher in `scripts/achievements/achievement_*.gd` (one custom script per achievement) reads the type and dispatches to the right counter.

**The AND-gate achievement** (`requests_and`) takes an array — the player must complete **both** request A and request B. This is the same data shape as `research.agi`'s multi-requirement (see §5). The engine re-uses the array-as-AND pattern across two systems.

**Requests** (`data/requests.json`, 28 entries) are the contract system: each request wants a specific file variation, e.g.:

```json
{ "name": "text_ai",         "file": "text",   "variation": "ai",        "amount": 100, "amount_e": 0, "reward": 50 }
{ "name": "image_validated", "file": "image",  "variation": "validated", "amount": 50,  "amount_e": 0, "reward": 30 }
{ "name": "video_compressed","file": "video",  "variation": "compressed","amount": 10,  "amount_e": 0, "reward": 200 }
```

**File-variation bitflag** (`scripts/utils.gd:10-13` + `data/symbols.json`):

| bitflag | meaning | bitflag | meaning |
|---|---|---|---|
| `0b1` | SCANNED | `0b10000` | ENHANCED2 |
| `0b10` | VALIDATED | `00b100000` | ENHANCED3 |
| `0b100` | COMPRESSED | `0b1000000` | INFECTED |
| `0b1000` | COMPRESSED2 | `0b10000000` | REFINED |
| `0b10000` | ENHANCED | `0b100000000` | DISTILLED |
| `0b100000` | ENHANCED2 (actually COMPRESSED3) | `0b1000000000` | ANALYZED |
| `0b1000000` | INFECTED | `0b10000000000` | HACKED |
| `0b10000000` | REFINED | `0b100000000000` | CORRUPTED |
| `0b100000000` | DISTILLED | `0b1000000000000` | AI |

(15 bitflags = 14 variation levels + 1 base SCANNED.) The **base file type** (`text`, `image`, `sound`, `video`, `program`, `game`) is the *file* axis, the **variation** is the *processing* axis. A file with 3 variation flags set has been through 3 different windows (e.g. downloaded → verified → compressed).

`data/storage.json` keeps `storage[file][variation]` as nested dicts; a request completion checks the matching storage bucket. The `symbols.json` file is the bitflag→glyph map (one symbol per bit).

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Optional O1** (multi-system unlock) | Achievements with `requirement: [...]` arrays are AND-gates that span stat, window, request, event, resource. |
| **Pattern C** (permanent upgrade) | Achievement rewards are `token`, which is itself a permanent currency. |
| **Pattern E** (status effect stack) | The 14-bit variation bitflag is a *product-axis* status stack — the same product, different processing history. |
| **Optional O5** (bottleneck balance) | Requests are the *bottleneck-balance mechanism* — they specify *exactly* which file × variation the player should target, which prevents the player from spam-clicking one path. |

---

## 9. Services — Token-Paid Soft-Resets

`data/services.json` defines 3 services — each is **spend tokens to refund a specific upgrade category + destroy a specific window group**:

| service | currency | cost | effect |
|---|---|---|---|
| `hack_reset` | token | varies | refunds all `hack_*` upgrades (8 items) |
| `optimization_reset` | token | varies | refunds all `optimization_*` upgrades (22 items) |
| `application_reset` | token | varies | refunds all `application_*` upgrades (10 items) **and** destroys 10 application windows |

**Service shape** (from `data/services.json`):

```json
{ "name": "hack_reset",       "currency": "token", "cost": <varies>, "cost_e": <varies>,
  "upgrades": ["hack_money_multiplier", "hack_speed_multiplier", ...],   // 8 items
  "windows":  [], "window_groups": [] }
{ "name": "optimization_reset","currency": "token", ...,
  "upgrades": ["<22 optimization_* upgrades>"], "windows": [], "window_groups": [] }
{ "name": "application_reset", "currency": "token", ...,
  "upgrades": ["<10 application_* upgrades>"],
  "windows":  ["<10 application windows>"],
  "window_groups": [] }
```

Each service is **backed by a 1-script implementation** (`scripts/services/service_hack_refund.gd`, `service_optimization_refund.gd`, `service_application_refund.gd`). The script iterates the JSON array and calls `Attributes.apply_attribute_dict(attrs, -level)` to *un-apply* each level (i.e. `add([a, m, e], -level)`). This is **negative-tuple arithmetic on a 3-tuple engine** — the same `add()` method handles refunds.

**The window-destroy hook** (`scenes/windows/window_indexed.gd:48-52`):

```gdscript
func _on_service_purchased(service: String) -> void :
    if Data.services[service].windows.has(window) or !Data.services[window].group.is_empty() and \
Data.services[service].window_groups.has(Data.windows[window].group):
        propagate_call("close")
```

So `application_reset` looks at *both* the `windows` array (specific window names) and the `window_groups` array (any window whose `group` field matches). A new service that wants to wipe a category only needs (a) a JSON entry, (b) a 30-line script that does the iteration.

**Why services and not perks or milestones?**

- **Perks** add to the player.
- **Milestones** add to the player.
- **Services** *subtract* from the player in exchange for a one-time currency spend. The refund gives the player the cost back as `currencies[currency]`, which lets them re-buy the same upgrades in a different order.

This is a **third prestige path** distinct from hard reboot (which keeps only `token`-paid perks) and milestone (which keeps milestones). Services let the player *reverse a single sub-tree* without rebooting the whole game.

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern P** (prestige currency) | `token` is the "soft-reset currency" — different from `max_research` (milestone) and from `money` (game). |
| **Pattern C** (permanent upgrade) | The reverse: applying `add([a, m, e], -level)` un-does the upgrade. |
| **Optional O1** (multi-system unlock) | A single service spans *both* `upgrades` and `windows` arrays — the cross-system refund is encoded in data. |
| **Core C4** (multiplicative composition) | Negative-tuple arithmetic proves the attribute engine is symmetric under sign. |

---

## 10. The Offline-Progress / "Rest" Subsystem

`scripts/rest_tab.gd:28-33` toggles a 5× offline multiplier:

```gdscript
func _on_toggle_pressed() -> void :
    if $PortalContainer/MainPanel/Toggle.button_pressed:
        Globals.set_offline_multiplier(5)
    else:
        Globals.set_offline_multiplier(1)
```

The "rest" tab is the offline-progress panel: while the player is *away from the game*, `offline_time` accumulates at `online_rest_time_gain × rest_time_multiplier / 72` per second (`scripts/globals.gd:160-208`). The player can manually toggle a 5× multiplier so the offline progress is computed faster (effectively *fast-forwarding* the catch-up after returning). The catch-up itself is capped by `Attributes.get_attribute("max_rest_time")` (default 600s, +30s per `max_rest_time` perk level).

**Three time tracks** are kept (`scripts/globals.gd:205-208`):

```gdscript
var time_multiplier: float = Attributes.get_attribute("time_multiplier") * Attributes.get_attribute("offline_time_multiplier")
stats.time_played += delta        # real time
stats.elapsed_time += delta * time_multiplier   # game-world time
time_elapsed += delta * time_multiplier         # mirror of elapsed
```

- `stats.time_played` — wall-clock (paused when window is closed).
- `stats.elapsed_time` / `time_elapsed` — game-world time, scaled by `time_multiplier × offline_time_multiplier`.
- `offline_time` — accumulated while away, capped by `max_rest_time`.

A central `Signals.tick` fires every 0.05s (20 Hz). Each window runs `_on_tick` at this base rate, scaled by the same `time_multiplier`. The player's "play time" is real-time; the game's "progress time" is `time_multiplier × real-time`; the offline cap is `max_rest_time` of game-world time.

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern S** (skill tier ladder) | The 5× toggle is the "tier ladder" of the offline subsystem — 1× by default, 5× on rest, with the toggle being the trigger. |
| **Core C1** (multi-currency) | `time_multiplier` and `offline_time_multiplier` are *two distinct* multipliers, each stacking with the other. |
| **Optional O1** (multi-system unlock) | `rest_time_multiplier` perk and `max_rest_time` perk are *both* perks, but they modify *different* aspects of the same rest flow. |

---

## 11. Boosts (8) — Timed Global Multipliers

`data/boosts.json` defines 7 boosts; each is a timed `[0, 0, e]` exponential that *auto-removes* when its timer expires. The lifecycle is in `scripts/boost.gd:16-28`:

```gdscript
func process(delta: float) -> void :
    boost.time -= delta
    if boost.time <= 0:
        remove()

func apply() -> void :
    Attributes.apply_attribute_dict(Data.boosts[name].attributes, 1)
    Attributes.apply_windows_attribute_dict(Data.boosts[name].window_attributes, 1)
    boost.applied = true
```

`remove()` calls `apply_attribute_dict(attrs, -1)` — the same negative-tuple trick as services. The `time` field is the duration; the dispatcher in `scripts/attributes.gd:42-91` has a fifth entry point `apply_windows_attribute_dict(boost.window_attributes, time)` that takes the *time* parameter (not level) and registers a `Signals.boost_removed` listener.

**Boost shape** (representative, from `data/boosts.json`):

```json
{ "name": "boost_bandwidth",   "duration": 600, "attributes": { "bandwidth_multiplier": [0, 0, 2] } }
{ "name": "boost_research",    "duration": 600, "attributes": { "research_speed_multiplier": [0, 0, 2] } }
{ "name": "boost_hack_power",  "duration": 600, "attributes": { "hack_power_multiplier": [0, 0, 2] } }
{ "name": "boost_code_speed",  "duration": 600, "attributes": { "code_speed_multiplier": [0, 0, 2] } }
```

The 7 boosts are organized as 7 axes × 1 duration (600s = 10 min each): `money` (`income_multiplier`), `bandwidth` (`bandwidth_multiplier`), `clock` (`clock_multiplier`), `gpu` (`gpu_multiplier`), `research` (`research_speed_multiplier`), `hack_power` (`hack_power_multiplier`), `code_speed` (`code_speed_multiplier`). They are triggered by specific gameplay events (e.g. `boost_research` fires when a research is completed, `boost_hack_power` fires when a breach is completed).

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern E** (status effect stack) | Boost is a *time-bounded* status effect — same 3-tuple schema, but with auto-removal. |
| **Core C4** (multiplicative composition) | Boost composes with all other `[0, 0, e]` contributions idempotently. |
| **Optional O1** (multi-system unlock) | `boost_research` boosts *both* global research and per-research progress — one effect, multiple targets. |

---

## 12. Stats, Storage, and the AI Subsystem

**Stats** (`data/stats.json`, 28 entries) are tracking counters with `type: 0` (number), `hidden: false`, and an i18n key for the display name. They cover lifetime totals (`max_money`, `max_research`, `max_tokens`, `reborns`), per-currency production rates (`money_per_second`, `research_per_second`), window counts (`active_windows`, `max_windows`), hack metrics (`hack_levels`, `breach_layers`), code metrics (`code_levels`, `contributions`), and many more. Each one can be `stat.X`-referenced by achievements and requests.

**Storage** (`data/storage.json`) has 6 entries, one per base file type:

```json
{ "text":   { "requirement": 1, "requirement_e": 18, "upgrade": "storage_text" } }
{ "image":  { "requirement": 1, "requirement_e": 18, "upgrade": "storage_image" } }
{ "sound":  { "requirement": 1, "requirement_e": 18, "upgrade": "storage_sound" } }
{ "video":  { "requirement": 1, "requirement_e": 18, "upgrade": "storage_video" } }
{ "program":{ "requirement": 1, "requirement_e": 18, "upgrade": "storage_program" } }
{ "game":   { "requirement": 1, "requirement_e": 18, "upgrade": "storage_game" } }
```

So a `text` storage slot is unlocked by reaching `1 × 10^18` lifetime `text` production. The framework pattern here is **lifetime-threshold unlock** — distinct from research-gate and currency-gate.

**The AI subsystem** is a `data_lab` window that converts `text` resources into `ai` resources via the `ai` output container, with a configurable learning rate and progress bar. Once `ai` reaches a threshold, the `agi` window unlocks and produces `agi` — a top-tier currency that boosts the `ai` *attribute* (i.e. higher `ai` attribute means `agi` produces more). This is the framework's **multi-stage conversion pipeline** (text → ai → agi), encoded as 3 separate windows with `requirement: research.agi` gating the third.

This maps to the framework as:

| Framework element | Realisation in Upload Labs |
|---|---|
| **Pattern D** (dual-pool coupling) | `text → ai → agi` is a 3-pool conversion chain; each pool feeds the next via connector. |
| **Pattern C** (permanent upgrade) | The `ai` attribute is itself a 3-tuple that boosts downstream conversion. |
| **Optional O3** (bottleneck gate) | `agi` research gates the third pool; storage `1e18` gates the storage slot. |

---

## 13. Frame-to-UL Pattern Cross-Reference

A summary of the framework patterns Upload Labs realises, and the file(s) that prove each:

| Framework element | Realisation in Upload Labs | file(s) |
|---|---|---|
| **Core C1** (multi-currency) | 8 currencies with per-spend domains | `data/currencies.json` |
| **Core C2** (cost formula) | `cost × 10^cost_e × cost_inc^level × price_multiplier` | `scenes/upgrade_panel.gd:38` |
| **Core C3** (income formula) | `rate = base × prod_attr × speed_attr / 10^cost_e` | `scenes/windows/window_processor.gd:38-45` |
| **Core C4** (multiplicative composition) | 3-tuple `[a, m, e]` engine with idempotent `add()` | `scripts/attribute.gd:14-21` |
| **Core C5** (geometric cost) | `pow(1000, count)` for in-window add, `pow(4, level+1)` for in-window upgrade | `scenes/windows/window_processor.gd:50-51` |
| **Core C6** (production curve) | `download_speed × file.size / cost_per_file` | `scenes/windows/window_verifier.gd:28-49` |
| **Pattern B** (binary unlock) | research tree of 47 nodes | `data/research.json` |
| **Pattern C** (permanent upgrade) | 86 upgrades across 6 categories | `data/upgrades.json` |
| **Pattern D** (dual-pool coupling) | `text → ai → agi` 3-stage conversion | `data/windows.json: data_lab, agi` |
| **Pattern E** (status effect stack) | 3-tuple `[a, m, e]` shared by upgrades/perks/milestones/boosts | `scripts/attribute.gd` |
| **Pattern P** (prestige currency) | 2 distinct tracks: `token` (perks) and `max_research` (milestones) | `data/perks.json`, `data/milestones.json` |
| **Pattern R** (rarity tier) | `category` (7) × `group` (per-window) orthogonal classification | `data/windows.json` |
| **Pattern S** (skill tier ladder) | 4 main research branches each gated by a "head" research | `data/derived/research_tree.json` |
| **Pattern T** (tier jump) | `level: 0` field on windows (gates palette tab appearance) | `data/windows.json` |
| **Optional O1** (multi-system unlock) | AND-gate arrays in research/achievement requirements | `data/research.json: agi`, `data/achievements.json: requests_and` |
| **Optional O3** (bottleneck gate) | `agi` AND-gate; storage `1e18` lifetime-threshold | `data/research.json`, `data/storage.json` |
| **Optional O5** (bottleneck balance) | `breach_price_multiplier: [-0.05, 0, 0]` and `cheapskate: [-0.05, 0, 0]` | `data/upgrades.json: breach_price_multiplier`, `data/perks.json: cheapskate` |
| **Optional O11** (multi-region subsystem) | `group` field on windows lets services isolate subsets | `data/windows.json: breach_skills group` |
| **Pattern AME** (NEW) | The `[a, m, e]` 3-tuple attribute model — single source of truth for every multiplier | `scripts/attribute.gd`, `scripts/attributes.gd` |
| **Pattern N** (NEW) | The 6-type transfer engine — one class, 6 transfer rules, scales with N windows of M types | `scenes/resource_container.gd:84-161` |
| **Pattern PR** (NEW) | The token-paid service-driven soft-reset — `data/services.json` + `scripts/services/*.gd` | `data/services.json` |

The three NEW patterns are described in detail in the next three sections.

---

## 14. NEW Pattern — AME (Additive-Multiplicative-Exponential 3-tuple)

**AME** is the pattern of representing *every* multiplier in the game as a 3-tuple `[a, m, e]` aggregated by a single class. The class has one method `add(a, m, e, e_count)` that is **idempotent** (order-independent) and **symmetric under sign** (a negative `a` is a discount, a positive `a` is a buff — no separate field needed).

**Reference implementation** (`scripts/attribute.gd:1-15`):

```gdscript
class_name Attribute
extends RefCounted

var multiplier: float = 1
var exponent: float = 1
var raw: float = 0

func add(a: float, m: float, e: float = 0, e_count: float = 0) -> void :
    raw += a * (1.0 + (m / multiplier)) * multiplier * exponent
    multiplier += m
    if e > 0:
        var exp: float = pow(e, e_count)
        raw *= exp
        exponent *= exp
    changed.emit()
```

**Why a 3-tuple and not 1?**

| axis | symbol | operation | example |
|---|---|---|---|
| additive | `a` | added to `raw` | `+0.2` bandwidth per level |
| multiplicative | `m` | added to `multiplier` (which scales future `a`s) | `+0.1` (10% buff, scaled by current `multiplier`) |
| exponential | `e` | `pow(e, e_count)` applied to `raw` and tracked in `exponent` | `×1.2` per level (compounds across levels) |

The `e_count` parameter is the **level** at which this tuple is being applied. So `add([0, 0, 1.2], level=3)` is `pow(1.2, 3) = 1.728×` of `raw`. This means the same tuple written in JSON can be applied at *any* level without the JSON needing to know the level.

**The dispatcher** (`scripts/attributes.gd:42-91`) has 5 entry points, one per JSON table. Each entry point calls `Attribute.add()` with the right `e_count` (level for upgrades/perks/milestones, 1 for boosts, 0 for research single-shot).

**Frame-to-AME**: This pattern is a stricter version of `Pattern E` (status effect stack). Where `Pattern E` allows arbitrary per-system schemas, AME enforces that **all** effects share one schema. The cost of the strict schema is that some effects are awkward to express (e.g. an "add 10% of current value" effect is `[0, 0, 1.1]` with a custom wrapper) — the benefit is that the *engine* is 15 lines.

**When to use AME vs Pattern E**:
- Use AME when *all* your effects are positive buffs, negative debuffs, and percent multipliers. The 3-tuple handles ~95% of incremental-game effects.
- Use Pattern E (per-system schemas) when you need side effects (e.g. "this buff also unlocks a tab") that don't fit the 3-tuple.

---

## 15. NEW Pattern — N (Node Pipeline Graph)

**N** is the pattern of a *node-graph game* where the player places window-style nodes on a desktop and wires their output ports to input ports of other windows using connector lines. A single transfer engine reads the *type* of the source resource container and applies a type-specific transfer rule.

**Reference implementation** (`scenes/resource_container.gd:84-161`):

| type | name | behaviour | example use |
|---|---|---|---|
| 0 | `MATERIAL` | integer splitting, `floor(count)/N` per output, `pick_random()` for remainder | file resources, hack_points |
| 1 | `FLOW` | bandwidth-style: fill outputs up to `limit` then divide remainder | download_speed, clock_speed, ai |
| 2 | `BOOST` | `count/N` pure divisor | bandwidth_multiplier, overclock |
| 3 | `MATERIAL_LIMITED` | type 0 but bounded by each receiver's `limit` | storage (per-file bucket) |
| 4 | `SETTING` | pure broadcast | overclock (the resource, not its multiplier) |
| 5 | `FLUID` | bounded push | heat dissipation |

**Why a type-dispatched engine and not per-node custom code?**

- **Scalability**: adding a new window type is one JSON entry; the engine re-uses the same 6 transfer rules.
- **Composability**: any node with a matching `type` on its input slot is a valid downstream — the engine doesn't know or care about node identity.
- **Visualisation**: the `connection` field (circle/octagon/pentagon/triangle) is the visual shape of the connector line, derived from the type.
- **Tick rate is global**: one `Signals.tick` per 0.05s fires all windows at once; each window reads its own input containers, advances its own state, pushes to its own output containers.

**Frame-to-N**: This pattern is a *generalisation* of the place-and-wire builder pattern. It is distinct from:
- **Optional O11** (multi-region subsystem) — N is *within* one region (one desktop); O11 is *across* regions.
- **Pattern T** (tier jump) — N is about *placement* of nodes, not about tier transitions.

**When to use N**:
- Use N when the player build is *spatial* (place X near Y) and the player expression is *graph topology* (wire A→B, A→C, B→D).
- Don't use N when the build is *linear* (A then B then C) — a tab-based UI is simpler.
- Don't use N when the build is *parameter tuning* — a settings page is simpler.

**Existing case parallels**:
- Kittens Game: most progression is parameter tuning; no node graph.
- Shelldiver: skill tree is a binary-tree unlock; not a node graph.
- Tower Wizard: status effects are a *layer* system, not a node graph.

Upload Labs is the **first case in the framework** to use N as the primary build expression. It is the canonical example.

---

## 16. NEW Pattern — PR (Prestige-Reset Service)

**PR** is the pattern of a *token-paid soft-reset* where a service consumes a specific currency to refund a specific upgrade category *and optionally destroy a specific window group*. It is **distinct from** hard prestige (which wipes all game state) and perks (which add to the player).

**Reference implementation** (`data/services.json` + `scripts/services/service_*.gd`):

```json
{ "name": "hack_reset", "currency": "token", "cost": <varies>, "cost_e": <varies>,
  "upgrades": ["hack_money_multiplier", "hack_speed_multiplier", ...],   // 8 items
  "windows": [], "window_groups": [] }
{ "name": "application_reset", "currency": "token", ...,
  "upgrades": ["<10 application_* upgrades>"],
  "windows":  ["<10 application windows>"],   // <-- spans windows too
  "window_groups": [] }
```

The service script iterates the JSON arrays and calls `Attributes.apply_attribute_dict(attrs, -level)` to *un-apply* each level (negative-tuple arithmetic on the AME engine). The window-destroy hook (`scenes/windows/window_indexed.gd:48-52`) checks both the `windows` array and the `window_groups` array.

**Why a service and not a perk or milestone?**

| | perks | milestones | services |
|---|---|---|---|
| effect | add to player | add to player | subtract from player |
| persistence | survives reboot | survives reboot | refunds the cost |
| trigger | any time | after first reboot | any time |
| currency | `token` | `max_research` (log) | `token` |
| role | QoL + small multipliers | large end-game multipliers | mid-game re-specialisation |

Services are the **mid-game re-specialisation** mechanism. The player spends `token` to refund a category, takes the currency back, and re-buys in a different order. This is the "respec" pattern from ARPGs applied to incremental games.

**Frame-to-PR**: This pattern is a *third prestige path* distinct from:
- **Pattern P** (prestige currency) — P is the *currency* design (what you keep across reset); PR is the *action* design (what you do with that currency).
- **Pattern C7** (opt-in permanent debuff) — C7 is *self-imposed* (challenges); PR is *currency-paid*.

**When to use PR**:
- Use PR when the game has 3+ sub-trees of progression and the player needs to re-specialise without rebooting.
- Don't use PR when the game has a single linear progression tree (no sub-trees to refund).
- Don't use PR when hard prestige already provides the re-specialisation path (PR becomes redundant).

**Existing case parallels**:
- Kittens Game: prestige is *hard* (transcendence resets all), no soft service refund.
- Shelldiver: no prestige layer at all.
- Tower Wizard: no soft service refund.

Upload Labs is the **first case in the framework** to use PR as a *first-class* progression mechanism. The framework's Pattern P (single prestige currency) is the closest existing analogue, but PR specifically addresses the *soft-reset-without-reboot* need.

---

## Appendix A — File Map

| path | size | role |
|---|---|---|
| `data/currencies.json` | 1.4 KB | 8 currencies |
| `data/attributes.json` | 7.8 KB | 57 named attributes (type 0/1/2) |
| `data/resources.json` | 24.9 KB | ~70 resources with type/connection/color |
| `data/files.json` | 2.1 KB | 6 base file types |
| `data/storage.json` | 0.6 KB | 6 per-file storage unlocks (1e18 lifetime) |
| `data/symbols.json` | 0.5 KB | 14-bit variation bitflag → glyph |
| `data/windows.json` | 41.5 KB | 103 window/node types |
| `data/connectors.json` | 0.7 KB | 11 connector line colors |
| `data/upgrades.json` | 41.6 KB | 86 upgrades across 6 categories |
| `data/research.json` | 17.0 KB | 47 research items |
| `data/perks.json` | 7.0 KB | 18 token-paid perks |
| `data/milestones.json` | 1.2 KB | 3 milestone-prestige entries |
| `data/boosts.json` | 2.3 KB | 8 timed global multipliers |
| `data/services.json` | 2.7 KB | 3 token-paid soft-resets |
| `data/achievements.json` | 7.5 KB | 24 achievements (multi-type requirements) |
| `data/requests.json` | 7.7 KB | 28 file×variation contracts |
| `data/stats.json` | 3.2 KB | 28 tracking stats |
| `data/themes.json` | 0.5 KB | 4 cosmetic themes |
| `data/guides.json` | 23.4 KB | in-game documentation |
| `data/metadata.json` | 1.1 KB | case metadata |
| `data/source_code.json` | 4.5 KB | scripts/ summary + canonical formulas |
| `data/derived/research_tree.json` | 4.1 KB | parent→child adjacency (1 root) |
| `data/derived/windows_by_category.json` | 2.2 KB | index |
| `data/derived/windows_by_group.json` | 2.1 KB | index |
| `data/derived/upgrades_by_category.json` | 2.5 KB | index |

## Appendix B — Canonical Formulas

| formula | source |
|---|---|
| upgrade cost | `scenes/upgrade_panel.gd:38` → `base × 10^cost_e × cost_inc^level × price_multiplier` |
| milestone cost | `scripts/globals.gd:188-191` → `cost × 10^cost_e × cost_inc^level` |
| research cost | `scripts/research_screen.gd:73` → `cost × 10^cost_e` (single-shot) |
| in-window add | `scenes/windows/window_processor.gd:50` → `1 × 10^6 × 1000^count × price_multiplier` |
| in-window upgrade | `scenes/windows/window_processor.gd:51` → `4 × 10^3 × 4^(level+1) × price_multiplier` |
| achievement requirement | `scripts/achievements/achievement_stat.gd:9` → `requirement × 10^requirement_e` |
| hack XP | `scripts/globals.gd:398-399` → `8 × 4^level` |
| code XP | `scripts/globals.gd:402-403` → `20 × 3^level` |
| tick rate | `scenes/windows/window_base.gd:83-86` → `0.05s × time_multiplier × offline_time_multiplier` (default 20 Hz) |
| AME add | `scripts/attribute.gd:14-21` → `raw += a*(1+m/multiplier)*multiplier*exponent; multiplier += m; if e>0: raw *= pow(e, e_count); exponent *= pow(e, e_count)` |
| milestone level | `scripts/globals.gd:48-49` → `floori(log(max_money + 1) / log(10))` |

## Appendix C — Enum Snapshots

| enum | values | source |
|---|---|---|
| `resource_types` | `MATERIAL=0, FLOW=1, BOOST=2, MATERIAL_LIMITED=3, SETTING=4, FLUID=5` | `scripts/utils.gd:7-13` |
| `file_variations` | 15-bit bitflag (SCANNED, VALIDATED, COMPRESSED, COMPRESSED2/3, ENHANCED, ENHANCED2/3, INFECTED, REFINED, DISTILLED, ANALYZED, HACKED, CORRUPTED, AI, +2 reserved) | `scripts/utils.gd:10-13` |
| `window_menus` | `NETWORK, CPU, GPU, RESEARCH, HACKING, CODING, UTILITY` | `scripts/utils.gd:6` |
| `tabs` | `UPGRADES, STORAGE, TOKENS, PORTAL, SUPPORT, GUIDE, ACHIEVEMENTS, SETTINGS` | `scripts/utils.gd:5` |
| `menus` | `UPGRADES, STORAGE, TOKENS, PORTAL, SUPPORT, GUIDE, ACHIEVEMENTS, SETTINGS` | `scripts/utils.gd:5` |

---

## Appendix D — UI Layout (O9 实证)

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[框架附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**（Steam `Upload Labs.exe` + LibreSeed `project.godot` / `utils.gd`）：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑 viewport | **1920×1080** | exe `viewport_width/height`；project.godot 同值 |
| 默认窗口覆盖 | 1366×768 | `window_*_override` |
| 工具模式 | CURSOR / MOVE / SELECT / CONNECTION | `Utils.tools` |
| 菜单类型 | NONE / SIDE / WINDOWS / SCHEMATICS | `Utils.menu_types` |
| 侧栏 Tabs | 8（UPGRADES…SETTINGS） | `Utils.menus` |
| 窗口分类 | 7（NETWORK…UTILITY） | `Utils.window_menus` |
| 主题桌面 | 4（default/green/squared/light） | `themes.json` |

```text
+---------------------------- 1920 x 1080 -----------------------------+
| Currency HUD (money/research/token/…)          [notifications]      |
| [tools]     DESKTOP: window nodes + connector wires (Camera2D)      |
|             Pattern N graph build                                    |
|                                                    | SIDE menus ×8  |
|                                                    | Upgrades/Store |
| [window palette: Network·CPU·GPU·Research·Hack·Code·Util]           |
+--------------------------------------------------------------------+
```

布局定位：**桌面节点图即玩法 UI**（Pattern N）；侧栏承载升级/存储/声望/设置。对照 Tower Wizard 区域面板、Agrivore Hub Tab、Gnorp 建筑悬停均不同。
