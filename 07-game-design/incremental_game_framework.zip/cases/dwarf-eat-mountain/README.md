# Dwarf Eats Mountain — 矮人挖山增量 + 反派主塔塔防设计指南

> **来源**: `D:\program files (x86)\steam\steamapps\common\Dwarf Eat Mountain\data.win` (GMS GEN8 IFF)
> **本地化**: `DEM_loc.json` (1236 keys, 7 语言)
> **案例版本**: 增量游戏框架 v0.1, Dwarf Eats Mountain v0.8.x (2025 Early Access)
> **提取方法**: GMS data.win 的 IFF/FORM 块结构解析 + JSON 本地化 (Direction A — 唯一可访问的 game data)

---

## 1. 游戏概述

**Dwarf Eats Mountain (DEM)** 是由 **Green Wizard** 独自开发的 **GameMaker Studio 2.3+** 增量 + 塔防游戏。
玩家扮演一群矮人, 一边挖山 (mining) 一边抵御山的反扑 (calamities), 终局目标是把山吃到只剩核心,
然后挑战 6 个 **特殊山 (Special Mountains)**。游戏采用 **GMS inline struct literal** 作数据存储
(类似 Agrivore 的 SO 但更内联), 所有游戏文本/字符串通过 **JSON localization** 提供。

| 字段 | 值 |
|---|---|
| 开发者 | Green Wizard (solo) |
| 引擎 | GameMaker Studio 2.3+ (GEN8 IFF) |
| 第三方库 | Juju Adams ImGui, Juju Adams Gooey shader library |
| 流派 | Incremental, Tower Defense, Base Building, Strategy, Clicker, Resource Management |
| 标签 | 2D, Pixel Graphics, Dwarves, Fantasy, Mining, Singleplayer, Atmospheric |
| 发布日期 | 2025 (Early Access) |
| Steam App ID | 2909850 |
| 商店 | https://store.steampowered.com/app/2909850/Dwarf_Eats_Mountain/ |

## 2. 规模概览

| 指标 | 数量 |
|---|---|
| 建筑 (Buildings) | 14 |
| 建筑升级节点 (Building Upgrades) | 199 |
| 神器 (Artifacts) | 124 |
| 威望节点 (Prestige Nodes) | 102 |
| 矿石 (Ore) | 27 |
| 巢穴 (Dens) | 5 |
| 灾变 (Calamities) | 30 |
| 特殊山 (Special Mountains) | 6 |
| 矮人类型 (Dwarves) | 10 |
| 本地化字符串 (英文) | 1236 |
| 本地化语言数 | 7 (en/ch/de/fr/pt-BR/ru/sp) |
| UI 本地化键 (`ui.*`) | 283 |
| UI 面板对象 (data.win) | ~35（含 boss narrative 套件） |
| 面板皮肤 | 10 |
| 逻辑分辨率 | 640×360（F4 可切 HD） |

## 3. 核心系统

DEM 围绕 **10 个互相连接的系统** 展开（含 UI）。详见 `metadata.json` 的 `main_systems` 字段, 此处给出 framework 视角的概括:

### 3.1 资源 (Resources)

6 类货币: **Gold** (主货币, 来自 ore 销售) + **Ore** (27 种, primary resource) + **Mithril** (跨 run, 来自 den 销毁) + **PP/Prestige Points** (跨 run, 来自 mountain 击杀) + **Faith** (priest 祈祷产生) + **Soul** (Forge 仪式消耗)。详见 [`resources.json`](./resources.json)。

### 3.2 建筑 + 升级 (Buildings & Upgrades)

**14 建筑, 199 升级节点**。DEM 的建筑系统是 framework upgrade 概念的**线性 1-time 扩展** (不同于 Pattern T 的 tier-stack):
- 每个建筑 8-21 个线性升级
- Khazad Greathold (HQ) 起始 → 7 个 tier 1 建筑 (Artillery Hall/Ballistics Workshop/etc.) → 各有 2 轮 8-21 升级
- 5 个 tier 2 建筑 (Manufactorum/Spelunker's Guild/etc.) 是 prestige-unlock
- 详见 [`buildings.json`](./buildings.json)

### 3.3 神器 (Artifacts)

**124 个 artifact**, 是 DEM 的标志性系统。3 类 effect:
- **Collect-only (24)**: 拾取时立即触发 (e.g., `+5 PP`, `+0-3000 gold`, `trigger 5 calamities`)
- **Passive-only (83)**: 持续生效 (e.g., `+10% speed`, `+20% gold from ores`)
- **Collect + Passive (14)**: 双阶段效果
- **Required to access (3)**: 解锁特殊山的钥匙 (e.g., Goblin Crown → Goblin King Spire)
- 详见 [`artifacts.json`](./artifacts.json) — **这是 framework 应记的新模式 O14 (multi-phase artifact)**

### 3.4 威望 (Prestige)

**102 个 prestige 节点**, 跨 run 永久升级, 消耗 PP。
- 节点类型: stat_multiplier / new_building_unlock / new_upgrade_unlock / new_dwarf_unlock
- 节点间有 gating 关系 (e.g., Manufactorum 节点需要先 unlock 某个建筑)
- 详见 [`prestige.json`](./prestige.json)

### 3.5 矿石 (Ores)

**27 种 ore**, 分 5 类:
- **普通 gold** (3 size): small/medium/large gold ore
- **Pure gold** (5 size): small → massive (8 tiers 严格递增)
- **特殊矿** (5): adamantine / eonite / coreheart / oathgold / sungold
- **Gem family** (10): diamond / ruby / emerald / sapphire / topaz / amethyst / ametrine / peridot / deep_pearl / watermelon_tourmaline / deep_sapphire / mystical_diamond
- **Mithril** (1) — 跨 run 货币
- 详见 [`ores.json`](./ores.json)

### 3.6 巢穴 (Dens)

5 种 den (goblin_den / dark_castle / troll_cave / mithril_vein / ancient_vault) — spawned enemy,
必须被 dwarves/cannons 击败。击败 reward 包含 artifact/mithril/calamity trigger。
详见 [`dens.json`](./dens.json)。**framework 候选 O15 (巢穴产怪)** — 评估见 [`derived/candidates.md`](./derived/candidates.md)。

### 3.7 灾变 (Calamities)

**30 种 calamity event** (rockfall / troll / goblin / gem 类等), 触发后会 attack mountain/dwarves/runners。
玩家可主动 trigger 应对 (e.g., Chaos Orb artifact trigger 0-3 calamities)。
详见 [`calamities.json`](./calamities.json)。

### 3.8 特殊山 (Special Mountains)

6 种 special mountain (triple_seal_gate / goblin_king_spire / dragons_peak / architects_summit / balrogs_pit / great_world_spire) — 终局内容, 每个有 unique intro / boss mechanic, 部分需要特定 artifact 才能进入 (Required to access)。
详见 [`mountains.json`](./mountains.json)。

### 3.9 矮人 (Dwarves)

10 种 dwarf 类型, 每种是 unique unit:
- **Runner** (khazad_greathold) — 搬运工, 可被 rocks stun
- **Miner** (miners_guild) — 挖山工
- **Demodwarf** (demolition_shack) — 爆破手
- **Brewmaster** (meadhall) — 酿造增益酒
- **Priest** (shrine) — 祈祷产生 Faith
- **Scientist** (laboratory) — 高级研究
- **Stonecaller** (geode_sanctum) — 矿石召唤
- **Runesmith** (the_great_forge) — 仪式执行
- **Bulldozer** (manufactorum) — 推土机 (manufactured)
- **Cyberdwarf** (prestige unlock) — 高级科学家

详见 [`dwarves.json`](./dwarves.json)。**framework 候选 O16 (矮人兵种)** — 评估见 [`derived/candidates.md`](./derived/candidates.md)。

### 3.10 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（区域几何 + 组件清单；不要求截图/皮相资产）。

**已测几何锚点**（SPRT/ROOM）：

| 项 | 尺寸 | 用途 |
|---|---|---|
| `rGame` / `sBackground1` | 640×360 | 逻辑画布 |
| `sGroundBackground` | 640×60 | 底边地面带（推得 y=300） |
| `sGround` | 640×30 | 地面叠层 |
| `sHealthBarFrame` / `sCalamityBarFrame` | 146×13 / 90×13 | 山体/灾厄条 |
| `sMainPanel*` | 32×32 × 10 皮 | MainPanel chrome tile |
| 资源图标 | Gold 16 / Mithril 22×20 / PP 22 / Soul 20 / Faith 20 / Dwarf 16 | TopBar chips |

DEM **不是**多 Tab idle，而是 **侧栏建筑网格 + 中心山体战场**：

```text
+----------------------------- 640 ------------------------------+
| TopBar h≈28: 资源 chips + Gallery/Stats/Options 入口           |
+--------+-------------------------------------------+----------+
| Main   | WORLD（山 51–111×681 裁剪）               | GPM/DPS  |
| ~120w  | dens / rocks / dwarves / 建筑             | /OPM     |
| 热键格 | [UpgPanel 在选中建筑时展开]               |          |
+--------+-------------------------------------------+----------+
| Health 146 + Calamity 90（山脚附近）                           |
+-------------------- ground y=300 h=60 -------------------------+
```

组件树（TopBar / MainPanel / UpgPanel / Prestige / Gallery / Options / Stats / Tooltip / Boss）见 `ui-layout.json → components`。区域 `rect` 中标 `confidence: inferred` 的可按实测微调；`measured` 为硬数据。

**热键要点**：建筑格映射**已放置槽**；`Shift+Click`×3 批量买；主 HUD 为 GMS panel（非 ImGui）。

## 4. 提取方法

### 4.1 GameMaker data.win 解析

DEM 使用 GameMaker Studio 2.3+ 编译, `data.win` 是 IFF/FORM 格式二进制 (1.5MB):
- 文件头: `FORM` (4) + size (4 LE) + `GEN8` (4 type) = 12 bytes
- 内部: 28 个 chunk (STRG/SCPT/OBJT/FUNC/...)
- 关键 chunk: **STRG** (56% of file, string pool) + **SCPT** (script bytecode) + **OBJT** (object definitions)

**重要发现**: GMS data 中**没有 enum class** 和 **typed ScriptableObject** (与 Unity 不同)。
数据通过 **inline struct literal** 存储: `function initializePrestige() { return [{name: "p_x", pp_cost: 1, ...}, ...]; }`

### 4.2 DEM_loc.json (唯一可访问的 game data)

DEM 的所有游戏文本 (artifact/building/prestige/ore/den/calamity/mountain/dwarf) 通过 **JSON localization** 提供:
- `DEM_loc.json` (1236 keys, 178KB) — 英文主本地化
- `loc/{ch,de,fr,pt-BR,ru,sp}.json` — 6 种翻译

**这个 case 的数据完整性严重依赖 DEM_loc.json** — GMS bytecode 解析只能提供函数名, 不能提供数值。

界面层额外用到：`ui.*` 283 keys（面板文案）+ data.win 中的 panel 对象名（`MainPanel` / `TopBarPanel` / `PrestigePanel` / …）与 `sMainPanel*` 皮肤 sprite 名。详见 [`ui-layout.json`](./ui-layout.json)。

### 4.3 提取工具

- `_tools/dem-extract/extract_chunks.py` — 解析 IFF/FORM chunk 结构
- `_tools/dem-extract/extract_strings.py` — 解析 STRG string pool (15,263 declared strings)
- `_tools/dem-extract/extract_taxonomy.py` — 从 DEM_loc.json 提取完整游戏内容分类
- `_tools/dem-extract/analyze_*.py` — 各种 game content 分析脚本

## 5. 数据完整性

| 字段 | 状态 | 说明 |
|---|---|---|
| 本地化字符串 (en) | ✅ complete | 1236 keys, 全部 game text |
| Ore/Den/Calamity/Mountain 名 | ✅ complete | 27 + 5 + 30 + 6 = 68 实体 |
| Building 升级 name/desc | ✅ complete | 14 building + 199 upgrade (loc 完整) |
| Artifact name/desc | ✅ complete | 124 artifact, loc 完整 (effect type 已分类) |
| Prestige node name/desc | ✅ complete | 102 node, loc 完整 |
| Ore/Building/Artifact 数值 | ❌ incomplete | 具体数值 (cost/damage/HP/drop_rate) 在 GMS bytecode 中, loc 不可见 |
| Prestige 节点 cost (PP) | ❌ incomplete | PP 花费在 code 中, 节点 unlock gates 同 |
| Den HP/loot table | ❌ incomplete | 在 code 中 |
| Calamity effect | ❌ incomplete | 30 个 calamity 名字已知, 具体 effect/duration 在 code 中 |
| UI 面板 / 热键 / 皮肤 / 组件树 | ✅ complete | [`ui-layout.json`](./ui-layout.json) `components` + `geometry` |
| 区域几何（画布/地面/条/图标尺寸） | ✅ measured + inferred | 640×360、地面 640×60、条/图标 SPRT 已测；部分 panel x/y 为 inferred |
| 绝对像素锚点常量（bytecode） | ❌ incomplete | `mainPanelFirstRowTop` 等未反编译 |

## 6. 引用

- Steam: https://store.steampowered.com/app/2909850/Dwarf_Eats_Mountain/
- Juju Adams GameMaker libraries: https://github.com/JujuAdams
- 框架文档: [`../../docs/case-to-framework-contribute.md`](../../docs/case-to-framework-contribute.md)
- 映射到 framework schema: [`mapping.json`](./mapping.json)
- 界面布局: [`ui-layout.json`](./ui-layout.json)（O9 实证）
- 覆盖度报告: [`derived/coverage-report.md`](./derived/coverage-report.md) (auto-generated)
- framework view: [`derived/framework-view/`](./derived/framework-view/) (auto-generated)

## 7. 致谢

DEM 由 **Green Wizard** 独立开发。本 case 的提取基于公开可获取的 data.win 与 DEM_loc.json, 不涉及任何代码逆向或反编译游戏的私有资产。
