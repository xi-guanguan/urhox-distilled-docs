# dwarf-eat-mountain · framework 覆盖度报告

> 由 `scripts/case-to-framework-coverage.py` 自动生成.
> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)
> 共 10 个 system.

| Case System | Framework 覆盖 | 备注 |
|------------|--------------|------|
| resources (currencies) | ✅ | 已映射到 1 个 schema: constants |
| buildings (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| artifacts (permanent_upgrades) | ✅ | 已映射到 1 个 schema: permanent-upgrade |
| prestige (permanent_upgrades) | ✅ | 已映射到 1 个 schema: permanent-upgrade |
| ores (rarity_tiers) | ✅ | 已映射到 1 个 schema: rarity |
| dens | ⚠️ | 映射不充分: (无直接 schema — 反派主体) |
| calamities | ⚠️ | 映射不充分: (无直接 schema — 事件系统) |
| mountains | ⚠️ | 映射不充分:  终局内容) |
| dwarves | ⚠️ | 映射不充分: (无直接 schema — 工人类型) |
| ui-layout | ⚠️ | 映射不充分: (无强制 schema — Optional O9 Interaction QoL) |

## 统计

- ✅ 已覆盖: **5**
- 🆕 未覆盖 (新): **0**
- ⚠️ 部分覆盖: **5**
- ❌ 不适用: **0**

## 🆕 候选贡献 (Candidate for Contribution)

以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:

- ⚠️ **dens** (mapping.json) — 映射不充分: (无直接 schema — 反派主体)
- ⚠️ **calamities** (mapping.json) — 映射不充分: (无直接 schema — 事件系统)
- ⚠️ **mountains** (mapping.json) — 映射不充分:  终局内容)
- ⚠️ **dwarves** (mapping.json) — 映射不充分: (无直接 schema — 工人类型)
- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)

→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估

## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件

- 🆕 数: **0** (< 1: 可跳过)
- ⚠️ 数: **5** (≥ 2: 必进入)
- 🔗 Reverse-link 缺失: **0**
