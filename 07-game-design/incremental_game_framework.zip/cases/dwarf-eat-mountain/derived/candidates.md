# Dwarf Eats Mountain — Framework 候选贡献评估

> 由 [docs/case-to-framework-contribute.md § 阶段 3-4](../../../docs/case-to-framework-contribute.md) 流程生成。
> **评估日期**: 2026-07-01
> **评估人**: framework 维护者 (审计 P2/P3 跟进)

---

## 候选 1: O14 — Multi-Phase Artifact (多阶段神器 effect)

- **来源**: `cases/dwarf-eat-mountain/artifacts.json` — 124 artifacts, 3+1 类 effect
- **framework 现状**: `permanent-upgrade.schema.json` 只覆盖单一 trigger; 无 collect/passive/access 分阶段
- **评分**:
  - 通用性: 3/3 (loot + idle + TD 题材均常见"拾取触发 + 被动 + 钥匙"三段式)
  - 复杂度: 2/3 (effect_type 枚举 + 可选 stacking 规则, ~8 字段)
  - 已实证 case: 1/3 (仅 DEM)
  - 文档成本: 2/3 (新 1 个 optional O14 + 扩展 permanent-upgrade schema 或新 schema)
  - **总分**: 8/12
- **决策**: **推迟**
- **理由**: 通用性高但仅 1 个实证。先在 DEM case 内完整文档化 3 类 effect 分类; 等第 2 个带 multi-phase loot 的 case (如 Melvor 遗物 / Clicker Heroes 神器变体) 出现后再升格为 Optional O14。避免 framework 为单游戏发明编号。
- **影响范围**: 0 个新 framework 文件 (暂缓)
- **副作用**: DEM README 已标注 O14 候选, 维护者需防止被误读为"已上线 Optional"
- **下次评估触发**: 任意新 case 出现 ≥2 种 artifact effect phase 时

---

## 候选 2: O15 — Den as Spawnable Enemy (巢穴产怪)

- **来源**: `cases/dwarf-eat-mountain/dens.json` — 5 种 den, 击败 reward = artifact/mithril/calamity
- **framework 现状**: O3 挑战轴覆盖 boss/wave, 但无"地图实体 spawn point"抽象
- **评分**:
  - 通用性: 2/3 (TD / 生存 / 基地建造常见, 纯点击增量少见)
  - 复杂度: 2/3 (den HP + loot table + spawn rate, ~10 字段)
  - 已实证 case: 1/3 (仅 DEM)
  - 文档成本: 2/3 (新 optional + 可能需 combat spawn schema)
  - **总分**: 7/12
- **决策**: **推迟**
- **理由**: 题材偏 TD, 与 O3 有重叠但抽象层不同。等 Shelldiver 式"区域敌人"或第二个 TD incremental case 再评估是否独立 O15, 或强化 O3 子节。
- **影响范围**: 0
- **下次评估触发**: 第 2 个 case 有 persistent spawn point + destroy reward 机制

---

## 候选 3: O16 — Dwarf as Combat Unit (矮人兵种)

- **来源**: `cases/dwarf-eat-mountain/dwarves.json` — 10 种 unique unit (runner/miner/priest/...)
- **framework 现状**: O8 辅助系统有"同伴能力"但无"单位类型 + 建筑绑定 + 战斗角色"三元组
- **评分**:
  - 通用性: 2/3 (RTS/基地/TD 常见, 纯 idle 少见)
  - 复杂度: 3/3 (10 单位 × 建筑 unlock × 独特 ability, 高)
  - 已实证 case: 1/3 (仅 DEM)
  - 文档成本: 3/3 (新 pattern 或 O8 大扩展 + unit schema)
  - **总分**: 8/12
- **决策**: **不沉淀**
- **理由**: 高度绑定 DEM 矮人题材; 抽象为"worker unit types"会与 Kittens Game 的 kitten jobs / Upload Labs 的 window types 产生三套平行概念。保留在 case 内作为 `dwarves.json` 数据 + README 描述即可。若未来有第 2 个"多工种战斗单位"case, 再考虑 Pattern 而非 Optional。
- **影响范围**: 0
- **framework_evidence**: `intentionally-not-contributed` (case 独有, 1 实证不足)

---

## 候选 4: Calamities (灾变事件系统)

- **来源**: `calamities.json` — 30 种 event, 可主动/被动 trigger
- **framework 现状**: 无对应 optional; 接近 O3 + O10 节奏但无"随机灾难"抽象
- **评分**:
  - 通用性: 2/3
  - 复杂度: 2/3
  - 已实证 case: 1/3
  - 文档成本: 2/3
  - **总分**: 7/12
- **决策**: **不沉淀**
- **理由**: 与 O3 挑战轴 + O10 节奏里程碑的组合可表达大部分需求; 单独抽象"calamity"对非 TD 题材价值低。
- **framework_evidence**: `intentionally-not-contributed`

---

## 候选 5: Special Mountains (终局山 / Boss Gate)

- **来源**: `mountains.json` — 6 种 special mountain, 部分需 artifact 钥匙
- **framework 现状**: O1 章节门 + O2 终局进度条可部分覆盖; artifact "required_to_access" 与 O14 绑定
- **评分**:
  - 通用性: 2/3
  - 复杂度: 1/3
  - 已实证 case: 1/3
  - 文档成本: 1/3
  - **总分**: 5/12
- **决策**: **不沉淀**
- **理由**: 总分 < 6, 属 case 终局内容包装, 非通用机制。O1 tier gate + O14 (若未来上线) 足够表达。
- **framework_evidence**: `intentionally-not-contributed`

---

## 汇总

| 候选 | 决策 | 总分 |
|------|------|------|
| O14 Multi-Phase Artifact | 推迟 | 8/12 |
| O15 Den Spawn | 推迟 | 7/12 |
| O16 Dwarf Units | 不沉淀 | 8/12 |
| Calamities | 不沉淀 | 7/12 |
| Special Mountains | 不沉淀 | 5/12 |

**无立即沉淀项** — 符合审计结论: DEM 价值在 case 数据与 O14 候选识别, 不在 framework 膨胀。
