# dwarf-eat-mountain — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## resources.json

- **Schema**: `../../../schemas/constants.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `xp_cap` | 无 xp cap — DEM 不用 XP 等级, 用 mountain kill 作 progression 阶梯 (类似 Pattern T 的 tier 0/1/2/3) |
| `tier_costs` | 无 framework tier_costs 表 — DEM 通过 building.X.upg.Y 的实际 cost (code 中) 按 upgrade 表达, loc 中只显示效果 |

## buildings.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 3

| 字段 | 说明 |
|------|------|
| `cost` | upgrade cost 在 code 中, loc 不可见 (需运行时观察或反编译 GMS bytecode) |
| `currency` | DEM 全部 upgrade 用 gold 购买, framework 视图需补 'gold' 货币类型 |
| `tiers` | DEM upgrade 一次性购买无 tiers, 不同于 Pattern T (Agrivore/SHELLDIVER 用 tier 1-4) |

## artifacts.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 4

| 字段 | 说明 |
|------|------|
| `cost` | artifact 来自 den 销毁/dig/ritual, 不是直接购买 |
| `effect_value` | artifact 效果数值 (e.g., '+20% damage') 在 desc_en 里以 '[#8ccafa]20[c_white]%' 形式内嵌, framework 视图需 regex 提取 |
| `stacking` | artifact 之间通常不可叠加, 只有少数可累积 (e.g., Demodwarf's BIG BAD BOMB chance) |
| `slot_system` | DEM artifact 无固定 slot 数, 通过 'found'/'equipped' 状态存在 inventory |

## prestige.json

- **Schema**: `../../../schemas/permanent-upgrade.schema.json`
- **缺字段数**: 3

| 字段 | 说明 |
|------|------|
| `cost` | prestige 节点 cost 在 PP (prestige points) 中, 节点 cost 表 (1-10 PP) 在 code 中 |
| `tiers` | prestige 节点大多有 4 tier (e.g., '+4/+8/+12/+16 Luck'), 在 desc_en 里以 '+[#8ccafa]4[c_white]/.../[#8ccafa]16[c_white]' 形式内嵌 |
| `unlock_gates` | prestige 节点之间有 unlock requirement (e.g., Manufactorum 节点需要先 unlock 某个 building) |

## ores.json

- **Schema**: `../../../schemas/rarity.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `base_probability` | ore drop 概率由 mountain depth + miner level 动态决定, loc 不存 |
| `value_multiplier` | ore 价值在 code 中, 27 种 ore 的具体 value 表未提取 |
