﻿# Kittens Game (猫国建设者) — Implementation Case

> Source code: `gitee.com/likexia/cat-zh` (v 1.4.6.2d, 2019-05-29 upstream, gitee mirror 2026).
> Data files in `./`.
> This case describes what Kittens Game does and how its mechanics map onto the framework.

| 元信息 | 值 | 来源 |
|--------|----|------|
| 标题 | Kittens Game (猫国建设者) | [./metadata.json](./metadata.json) |
| 引擎 | JavaScript + Dojo 1.7 (no ES6, IE6-compatible) | metadata.engine |
| 数据源 | gitee.com/likexia/cat-zh + js/*.js v1.4.6.2d | metadata.data_source |

Kittens Game is a single-page browser incremental where you run a village of cats. It has parallel progression tracks (resources → workshops/techs → religion → space → chronoforge/voidspace → transcendence → challenges → diplomacy → time/void), and a price/bonus engine that fans out into 137 workshop upgrades + 62 techs + 39 buildings + 10 religion upgrades + 10 transcendence upgrades + 13 space programs + 7 chronoforge + 6 voidspace + 37 prestige perks + 8 races = **329 unlockable items**. The codebase is **~778 KB of plain ES5 JavaScript** (the `js/` directory, 19 files) with no build step (the project explicitly bans ES6 for IE6 support), and the game state is a flat dictionary on `window.game` with a dojo.js UI layer.

The framework-relevant parts of this case are:

1. **One giant `resourceData` array** describing 58 resources, where every key is the *unique id* the rest of the game references by name.
2. **Building effects as a flat dotted key system** — `"catnipPerTickBase": 0.125`, `"sattelite-observatoryRatio": 2` — never a typed enum.
3. **A single `getEffect("…")` call that aggregates every modifier** in the game, so the entire balancing pass is a question of "what keys does every system push into this bag?".
4. **A prestige layer that lives in its own per-run currency (`paragon`) plus an across-runs currency (`burnedParagon`)**, with **separate caps** and **different formulas**.
5. **A 4-season × N-year-color × N-cycle calendar** that injects multiplicative season modifiers on top of every effect.
6. **A 9-system unlocks network** where a single tech can unlock a tab, a building, a workshop upgrade, a job, a craft, a policy, and another tech at once.

---

## 1. The Resource Dictionary (58 entries)

The game treats resources as a flat list in `js/resources.js` (the `resourceData` array, 58 entries, 11.7 KB extracted to `./resources.json`). Every resource has exactly one unique `name` field which is also its id. The remaining fields are flags:

```js
{ name: "catnip",      title: $I("resources.catnip.title"), type: "common",
  visible: true, calculatePerTick: true, aiCanDestroy: true }
{ name: "furs",        title: $I("resources.furs.title"),   type: "uncommon", … }
{ name: "unicorns",    title: $I("resources.unicorns.title"), type: "rare",   … }
{ name: "relic",       title: $I("resources.relic.title"),  type: "exotic",  … }
```

`type` is **not** a numeric tier, it is one of four "rarity bands" (`common`, `uncommon`, `rare`, `exotic`) used only for UI grouping and AI heuristics (the `aiCanDestroy` flag — does the AI "Hunt" event burn this resource). Resources of higher type are not stronger, they are *rarer*: `furs` is unlocked after the player has a Hunter, `unicorns` only after Theology, `relic` only after the player has a Ziggurat and Theology.

A subset of resources have a `craftable: true` flag (e.g. `wood`, `steel`, `alloy`, `compedium`, `blueprint`). Those appear in the *bottom* "craft" table in addition to the *top* "resource" table, because they can be produced from recipes in `js/workshop.js`.

**Storage caps** (`maxValue`) come from two places: a static default on the resource itself (extracted into `./resources.json`, e.g. `catnip: 5000`, `wood: 200`, `titanium: 2`), and a dynamic per-resource cap that is computed live by `game.resPool.getMaxValue(name)` from `warehouse`/`barn` buildings and a `XXXMax` effect key (`barn-titaniumMax`, `warehouse-coalMax`, …). This is a **two-level cap system**: the static default is the *baseline* (e.g. catnip starts at 5000), the storage buildings multiply that baseline by their `XxxMax` effect.

**Live state in the running game** (extracted from the page `https://lolitalibrary.com/maomao/`):

```json
{ "catnip":     { "type": "common",   "maxValue": 5000 },
  "furs":       { "type": "uncommon", "maxValue": 0     },
  "unicorns":   { "type": "rare",     "maxValue": 0     },
  "relic":      { "type": "exotic",   "maxValue": 0     } }
```

The 58 resources fall into these counts (extracted from `./resources.json`): 43 `common`, 3 `uncommon`, 5 `rare`, 7 `exotic`. The split is by **rarity band, not power** — `common` is "appears in the top resource bar at all times", `uncommon` is "trade-good / rare drop", `rare` is "magic / unicorn-tier", `exotic` is "prestige / transcendence / void only". The 7 `exotic` are: `relic`, `void`, `present box` (elderBox), `wrapping paper`, `blackcoin`, `bloodstone`, `T-Mythril`.

This maps to the framework as:

| Framework element         | Realisation in KG                                        |
|---------------------------|----------------------------------------------------------|
| **Pattern C** (perma-upgrade) | `type: "exotic"` resources are earned only through prestige/transcendence and never replenished by gameplay — they are "permanent currency" with a soft cap |
| **Pattern R** (rarity)    | The four `type` strings drive UI tab grouping and AI behaviour but **not** power scaling. |
| **Resource flag system**  | `visible`, `craftable`, `transient`, `persists` together implement a 4-quadrant matrix: "top resource bar" × "bottom craft bar" × "carries over reset" × "magnetisable". |

---

## 2. Buildings (39) and the Price-Formula Engine

The `buildingsData` array in `js/buildings.js` (extracted to `./buildings.json`, 39 entries) is the heart of the early game. Each building has:

```js
{ name: "field",
  unlockRatio: 0.3, defaultUnlockable: true,
  prices:    [ { name: "catnip", val: 10 } ],
  priceRatio: 1.12,
  effects:   { "catnipPerTickBase": 0.125 },
  unlockScheme: { name: "catnip", threshold: 56 } }
```

Three things are non-obvious:

**a) The unlock scheme is a separate gate from the price.** `unlockScheme: { name: "catnip", threshold: 56 }` means "this building is *not* buyable until your *catnip stored* has reached 56" — i.e. the building is hidden until the player has *demonstrated* they have at least one barn (which stores 50). This implements the framework's **bottleneck-gating pattern** explicitly: a building can be affordable but not unlockable.

**b) The price formula is one line in `buildings.js` (line 2268):**

```js
prices.push({
  val: bldPrices[i].val * Math.pow(ratio, bld.get("val") + fakeBought) * priceModifier * resPriceModifier,
  name: bldPrices[i].name
});
```

i.e. `cost = base × ratio^(current_val + fakeBought) × (1 - bldCostReduction) × (1 - resCostReduction)`. The `fakeBought` term is the sum of the `XxxFakeBought` effect plus `additionalBought` (an integer passed in by the buy-N UI). The `priceRatio` field of each building is *not* the cost curve multiplier — that is the *global* price-ratio effect `priceRatio` from prestige perks (e.g. `engeneering` perk adds -0.01 to global price ratio). Each building's own `priceRatio` is its **per-building growth rate**, ranging 1.10–2.50 across the 39 buildings.

**c) Effect blocks use a flat dotted key.** `"catnipPerTickBase": 0.125` says: when a player owns 1 field, the `catnipPerTickBase` effect is +0.125; when they own 10 fields, it is +1.25. There is no `for each building: …` — the engine just sums every effect of that key from every owned building. This is the same convention as the resource dictionary.

This maps to the framework as:

| Framework element              | Realisation in KG                                          |
|--------------------------------|------------------------------------------------------------|
| **Pattern C1–C6** (cost curves) | `priceRatio` ranges 1.10 (slow) to 2.50 (steep) across the 39 buildings (verified in `./buildings.json`). Buildings used to break a bottleneck have low `priceRatio`; buildings that *are* the bottleneck have high `priceRatio`. |
| **Optional O3** (bottleneck gate) | `unlockScheme` enforces "this is locked until you have demonstrated a related capability". |
| **Pattern D** (multi-pool coupling) | The early-game *barn*→*mine*→*smelter* chain: a barn unlocks `unlockScheme` for a mine; a mine outputs iron; a smelter consumes iron and outputs steel; the steel *itself* unlocks a new tech. |

---

## 3. Techs (62) as the Unlocks Network

The `techs` array in `js/science.js` (62 entries, `./techs.json`) is the *only* way the player unlocks new tabs, new buildings, new jobs, new crafts, new policies, and new workshop upgrades. A single tech can unlock many things at once:

```js
{ name: "agriculture",
  prices: [ { name: "science", val: 100 } ],
  unlocks: { buildings: ["barn"], jobs: ["farmer"], tech: ["mining"] } }
```

The shape of `unlocks` is an object where **each key is itself an array of ids that point to a different system** (`buildings`, `tabs`, `tech`, `upgrades`, `policies`, `jobs`, `crafts`). The engine processes the object by iterating keys and calling each respective manager (`game.bld.unlock(...)`, `game.workshop.unlock(...)`, etc.). The dependency tree is therefore encoded *only* by the data, not by code: a new tech added in `techs` with a `tech: [...]` entry automatically becomes a prereq for whatever is in that array.

**Pricing for techs is not `priceRatio^val` like buildings — it is fixed-cost** in the early game and *inherits from prestige* later. There is a global `techPriceRatio` effect that can be raised by the `learning` prestige perk (+10%) and the `electronics` tech. There is no per-tech price curve: the cost is a single number that scales with that global effect.

This maps to the framework as:

| Framework element         | Realisation in KG                                                |
|---------------------------|------------------------------------------------------------------|
| **Pattern B** (binary unlock) | The early-game *agriculture* → *mining* → *electricity* → *electronics* → *computation* → *space* chain is a strict binary tree where each tech is either researched or not. |
| **Pattern S** (skill tier ladder) | The *Industrial* era (mining, metalWorking, machinery) → *Global* era (oilProcessing, uranium) → *Space* era (orbital, terraforming) is a tier ladder where the next tier is gated by a single tech. |
| **Optional O1** (multi-system unlock) | `unlocks: { buildings, tabs, tech, upgrades, policies, jobs, crafts }` is the explicit encoding. |

---

## 4. Workshop Upgrades (137) and Effect Stacking

The `upgrades` array in `js/workshop.js` (137 entries, `./upgrades.json`, 49 KB) is the late-game "fine tuning" layer. Each upgrade has one or two `effects: { "<key>": <value> }` blocks and a price list:

```js
{ name: "mineralHoes",
  effects: { "catnipJobRatio": 0.5 },
  prices:  [ { name: "minerals", val: 275 }, { name: "science", val: 100 } ],
  unlocks: { upgrades: ["ironHoes"] } }
```

Effect keys follow a strict namespace convention (visible in the source):

- `XxxPerTickBase` — adds a flat per-tick amount to a resource (e.g. `catnipPerTickBase` from `field`).
- `XxxPerTick` — adds a flat per-tick amount *regardless* of jobs (e.g. `unobtainiumPerTick` from `moonOutpost`).
- `XxxRatio` — a *multiplicative* bonus to the per-tick amount (e.g. `catnipRatio` from `hydroponics`).
- `XxxMax` — a multiplier to a resource's storage cap (e.g. `barn-catnipMax` from `barn`).
- `XxxCostReduction` — additive *discount* (NOT multiplier) on a building's price (e.g. `fieldCostReduction`).
- `XxxJobRatio` — bonus to how much of a resource a single worker produces (e.g. `farmerJobRatio` from `mineralHoes`).

This 6-key namespace lets the engine sum them correctly with one `getEffect(name)` call, because the `getEffect` aggregator is just a `for (key in effects) sum += …; return sum` over a global `effects` dictionary that every system pushes into. The 137 upgrades each push 1–3 effect keys (totalling ~300 effect keys across the workshop tree alone).

This maps to the framework as:

| Framework element            | Realisation in KG                                       |
|------------------------------|--------------------------------------------------------|
| **Pattern E** (effect stack) | Every system pushes *additive* values into the same `getEffect` namespace. The 6 key-prefixes (`PerTickBase`, `PerTick`, `Ratio`, `Max`, `CostReduction`, `JobRatio`) define the *type* of effect without an enum. |
| **Pattern S** (skill tier)   | The upgrade tree is gated by a chain of *prereq upgrades*: `mineralHoes` → `ironHoes` → `steelHoes` → `alloyHoes` → `titaniumHoes` — each `unlocks.upgrades: ["<next>"]`. The `unlocks` field is an object whose key is a system name and whose value is an array of ids in that system. |

---

## 5. Religion and Transcendence (10 + 10)

`./religion.json` contains two arrays. **Religion upgrades** (10) are bought with `faith`, the resource that converts every 100 `faith` into 1 `religion` (a separate multiplier resource). **Transcendence upgrades** (10) are bought with `karma` (a different rare resource earned by leaving the game running with positive effects).

The interesting part is that **religion upgrades are gated by the religion cycle**: the 10 entries appear in a fixed *rotation order* in the UI, but the player can only buy the upgrade whose slot matches the current religion. The slot is set by `game.calendar.cycleEffectsReligion(...)` and resets each year. The player must therefore plan ahead: e.g. if it is currently Solarchant, only the Solarchant upgrade is buyable this year.

Transcendence upgrades (10 entries in `js/religion.js:transcendenceUpgrades`) are bought *across runs* with karma, and persist through reset. The full list of effect keys for these 10 entries is in `./religion.json` under `transcendenceUpgrades`.

---

## 6. Space Programs (13) and Planets (8)

`./space.json` contains 13 space programs. Space is the *third resource era* after Early (catnip/wood/minerals) and Industrial (iron/coal/oil). The program data structure is:

```js
{ name: "moonMission",
  prices: [ { name: "titanium", val: 5000 }, { name: "oil", val: 2500 }, { name: "uranium", val: 50 } ],
  unlocks: { spaceBuilding: ["moonOutpost"] } }
```

The player launches programs to unlock *space buildings*, which then have *planet-gated* multipliers. There are 8 planets (`charon`, `helios`, `cath`, `redmoon`, `dune`, `piscine`, `terminus`, `kairo`), each with its own `effects` and `festivalEffects` (extracted from `js/calendar.js:planets`). The current "space mission" picks one planet and the player gets that planet's bonus until the next one. A planet is the framework's **multiplier tab** that re-arranges the same effects into different strengths.

| Planet   | Effect values (extracted verbatim from `js/calendar.js:planets`) |
|----------|------------------------------------------------------------|
| Charon   | `moonOutpost-unobtainiumPerTickSpace: 0.9`, `entangler-gflopsConsumption: 2` |
| Helios   | `cryostation-woodMax: 0.9`, `cryostation-mineralsMax: 0.9`, `cryostation-coalMax: 0.9`, `cryostation-ironMax: 0.9`, `cryostation-titaniumMax: 0.9`, `cryostation-oilMax: 0.9`, `cryostation-uraniumMax: 0.9`, `cryostation-unobtainiumMax: 0.9`, `sunlifter-energyProduction: 1.5` |
| Cath     | `spaceStation-scienceRatio: 1.5`, `sattelite-observatoryRatio: 2`, `sattelite-starchartPerTickBaseSpace: 2`, `spaceBeacon-starchartPerTickBaseSpace: 0.1`, `spaceElevator-prodTransferBonus: 2` |
| Redmoon  | `moonOutpost-unobtainiumPerTickSpace: 1.2`, `entangler-gflopsConsumption: 0.5` |
| Dune     | `hydrofracturer-oilPerTickAutoprodSpace: 1.5`, `planetCracker-uraniumPerTickSpace: 1.1`, `hrHarvester-energyProduction: 0.75` |
| Piscine  | `hydroponics-catnipRatio: 0.5`, `researchVessel-starchartPerTickBaseSpace: 1.5` |
| Terminus | `cryostation-woodMax: 1.2`, `cryostation-mineralsMax: 1.2`, `cryostation-coalMax: 1.2`, `cryostation-ironMax: 1.2`, `cryostation-titaniumMax: 1.2`, `cryostation-oilMax: 1.2`, `cryostation-uraniumMax: 1.2`, `cryostation-unobtainiumMax: 1.2`, `sunlifter-energyProduction: 0.5` |
| Kairo    | `spaceStation-scienceRatio: 0.75`, `sattelite-observatoryRatio: 0.75`, `sattelite-starchartPerTickBaseSpace: 0.75`, `spaceBeacon-starchartPerTickBaseSpace: 5`, `spaceElevator-prodTransferBonus: 0.5` |

This is **Pattern R (rarity/multiplier tab)** from the framework, with an extra layer: each planet has *two* effect groups — a permanent `effects` and a temporary `festivalEffects` that double the chosen resource during a festival.

---

## 7. Time and Voidspace (Chronoforge)

`./time.json` contains 7 chronoforge upgrades and 6 voidspace upgrades. Chronoforge is the *time-reversal* mechanic: the player can spend `timeCrystal` to rewind the calendar, gaining a "year skip" effect that resets the season cycle to a chosen year. The 7 chronoforge upgrade ids (extracted from `js/time.js:chronoforgeUpgrades`) are:

`temporalBattery`, `blastFurnace`, `timeBoiler`, `temporalAccelerator`, `temporalImpedance`, `ressourceRetrieval`, `temporalPress`.

The full effect values are in `./time.json`.

Voidspace is the *post-endgame* system: 6 upgrades bought with `void` resource (unlocked after reset at "burned paragon" level 5+). The 6 ids (from `js/time.js:voidspaceUpgrades`) are:

`cryochambers`, `usedCryochambers`, `voidHoover`, `voidRift`, `chronocontrol`, `voidResonator`.

The voidspace mechanic itself is a *speedrun* mode where the player has 1 in-game day to do as much as possible.

---

## 8. Prestige (37 Perks) and the Dual-Cap System

`./prestige.json` contains 37 prestige perks, the most data-rich of any system. Perks are bought with `paragon`, which is a *per-run* currency that the player gains by resetting. After reset, `paragon` is converted (partially) to `burnedParagon` which is a *permanent* across-runs currency.

The two formulas live in `js/prestige.js`:

- `getParagonProductionRatio` (line 501) returns `productionRatioParagon + productionRatioBurnedParagon`:
  - `productionRatioParagon = min(paragon.value * 0.01 * paragonRatio, 2 * paragonRatio)` (capped at 2)
  - `productionRatioBurnedParagon = min(burnedParagon.value * 0.01 * paragonRatio, ratio * paragonRatio)` where `ratio = 4` in dark-future, else `1`.
- `getParagonStorageRatio` (line 514) returns `paragon.value / 1000 * paragonRatio + burnedParagon.value / 500 * paragonRatio` (in dark-future) or `+ / 2000` (otherwise).

The 37 perks (verbatim from the source) are:

```
engeneering, codexVox, codexLogos, codexAgrum, megalomania, blackCodex,
codexLeviathanianus, goldenRatio, divineProportion, vitruvianFeline, renaissance,
diplomacy, zebraDiplomacy, zebraCovenant, navigationDiplomacy,
chronomancy, astromancy, unicornmancy, anachronomancy,
carnivals, willenfluff, pawgan,
numerology, numeromancy,
malkuth, yesod, hod, netzach, tiferet, gevurah, chesed, binah, chokhmah, keter,
voidOrder, adjustmentBureau, ascoh
```

They cluster into the following UI groups (visible in the live game):

| Group                | Count | Example perks                          |
|----------------------|-------|----------------------------------------|
| **codex / engineering** | 7   | `codexVox`, `codexLogos`, `engeneering` |
| **diplomacy / races**   | 4   | `diplomacy`, `zebraDiplomacy`, `zebraCovenant`, `navigationDiplomacy` |
| **magic / sci-magic**   | 4   | `chronomancy`, `astromancy`, `unicornmancy`, `anachronomancy` |
| **kabbalah tree**       | 10  | `malkuth`, `yesod`, `hod`, `netzach`, `tiferet`, `gevurah`, `chesed`, `binah`, `chokhmah`, `keter` |
| **other**               | 12  | `carnivals`, `megalomania`, `renaissance`, `voidOrder`, ...              |

This is **Pattern P (prestige layer)** from the framework with an *extra* per-run cap, an *extra* cross-run cap, and a hard *group* structure (perks in the same group share a UI panel).

---

## 9. Challenges (9) and the Iron-Will Mode

`./challenges.json` contains 9 challenges. The 9 challenge ids (verbatim from the source) are: `ironWill`, `blackSky`, `pacifism`, `postApocalypse`, `energy`, `atheism`, `crowded`, `lethargic`, `ninetyNine`.

The challenges are *runs with a permanent debuff*: each one enables a set of constraints (no ironWill, no titanium, no hunting, no religion, etc.) and grants a bonus on completion. The "Iron Will" challenge is the *default* for veteran players and gives +25% paragon on every run (visible in the `js/challenges.js` source).

The other 8 are *opt-in* permanent toggles: once the player completes one, the game remembers and offers to apply that debuff for the next run *in addition to ironWill*. This is the framework's **Pattern C (permanent upgrade)** but applied to *debuffs*.

---

## 10. Diplomacy (8 Races) and the Trade Cycle

`./diplomacy.json` contains 8 races the player can befriend (extracted from `js/diplomacy.js:races`): `lizards`, `sharks`, `griffins`, `nagas`, `zebras`, `spiders`, `dragons`, `leviathans`. Each race has:

- a `standing` (initial friendliness, 0.25 for lizards, -0.15 for griffins, …),
- an `embassyPrices` array (always `culture` in the data),
- a `buys` / `sells` resource list (not captured in `diplomacy.json` because it's deep-nested).

The embassy is unlocked by paying the embassy cost in `culture`. Once built, the player can trade *manpower* (catpower) for *furs / ivory / spice* and back. The trade mechanic is gated by `culture` (the `culture` resource is consumed to *build* the embassy), and by `manpower` (the per-tick cost of trading). The races' own stats are encoded as a flat `name: { standing, embassyPrices, … }` dictionary.

---

## 11. Calendar and Season Cycle (4 Seasons × N Years)

`./calendar.json` contains 4 seasons. The calendar is the framework's **Pattern Pacing Milestones (7-stage rhythm)** with a *literal* implementation: a year is 4 seasons, a cycle is some years, an era is some cycles. The current season applies a *multiplier* to certain resources:

| Season   | Effect on resources (catnip modifier only) |
|----------|------------------------------------------------|
| Spring   | ×1.5 catnip                                    |
| Summer   | ×1.0 catnip                                    |
| Autumn   | ×1.0 catnip                                    |
| Winter   | ×0.25 catnip                                   |

These modifiers are *multiplicative* on top of the per-tick from buildings, and the calendar cycles every real-time tick (it does *not* gate resource collection). The player can pay `timeCrystal` to *skip* a season: 1 crystal to skip a single season, 5 to skip a year, 25 to skip an era. This is the framework's **Optional O13 (temporal multi-cycle)** — the temporal analogue of O11's spatial multi-region: the "layer" is the current season, and each season carries its own `catnip` modifier.

The game also has a **cycle year color** (5 colors: `blue`, `green`, `orange`, `red`, `purple`) that gives *additional* multipliers in `js/calendar.js:cycleYearColors`. A full cycle is 5 years, and an *era* is 3 cycles = 15 years. The framework's **Pattern O5 (bottleneck balance blessing)** is partially implemented as the `numerology` prestige perk (which gives bonuses to cycle year effects, per `js/calendar.js:cycleEffectsBasics`).

---

## 12. The Village, Kittens, and Death

`./village.json` contains 8 jobs and 8 kitten traits. The job system is the *only* place in the game where the player does *not* have 100% control over what gets built: a job is a *fraction* of total kittens assigned, and the *actual output* is a per-tick rate times a kitten trait multiplier.

Kittens are born and die based on formulas in `js/village.js`. The death formula scales with the *number* of kittens, so the population naturally plateaus. The `paragonModifier` is the across-runs prestige modifier that slows kitten death as the player progresses.

The 8 traits are: `scientist`, `manager`, `engineer`, `merchant`, `farmer`, `miner`, `hunter`, `cleric`. Each trait gives a bonus to a job's per-cat output. Traits are assigned at birth and the player has no control over which kitten gets which trait. The framework's **Pattern S (skill tier ladder)** is therefore also applied to *individual units*, not just unlocks.

---

## 13. The Price-Formula Engine (Single Line)

The price formula in `js/buildings.js:2268` is the single line that powers the entire game balance:

```js
val: bldPrices[i].val * Math.pow(ratio, bld.get("val") + fakeBought) * priceModifier * resPriceModifier
```

Which expands to:

```
price = base × ratio^(current_count + simulated_count) × (1 - bldCostReduction) × (1 - resCostReduction)
```

The four components are:

1. **Base** — the static cost in the building data.
2. **Ratio^count** — geometric cost curve. `ratio` = global `priceRatio` effect, modified by per-building `priceRatio` field and the `engeneering`/`goldenRatio` prestige perks.
3. **`fakeBought`** — sum of the `XxxFakeBought` effect plus `additionalBought` (an integer passed in by callers). It allows the engine to pre-price any number of additional buys in one calculation.
4. **Discount multipliers** — additive discounts, not multiplicative. This is the framework's anti-pattern for O5: the project README explicitly says *"Don't use price reduction effects. (If you do, be *extremely* careful.)"*. The `XxxCostReduction` keys (one per discount-producing source) are all capped at 1.0 by `game.getLimitedDR()`.

This is the framework's **Pattern C1–C6** with one hard rule: *all discounts are additive in the (0, 1) interval, never multiplicative*. The game balance literally cannot break the 0–100% discount band, so a player can never get a free building.

---

## 14. The `getEffect()` Aggregator

The single most important function in the game is `game.getEffect(name)`, which lives in `core.js`. It returns the sum of *every* effect of that name pushed by *every* manager (resources, buildings, techs, upgrades, religion, space, time, prestige, challenges, calendar, village, voidspace).

The convention is that **the key encodes the type and the unit**: `"catnipPerTickBase"` is a flat per-tick amount, `"catnipRatio"` is a multiplier on the per-tick amount, `"barn-catnipMax"` is a multiplier on a storage cap, `"farmerJobRatio"` is a per-worker bonus. The engine does not type-check the key, it just sums. This means a balance change is *always* a `+0.05` to a key — never a refactor of an enum.

The framework's **Pattern E (status stack)** generalises this convention with a typed schema. KG does it *without* a schema — the project README explicitly bans adding new code without using existing patterns, and the effect-key convention is a "code-as-schema" approach.

---

## 15. Frame-to-KG Pattern Cross-Reference

| Framework Pattern        | Where in KG                                                           | Concrete data                                       |
|--------------------------|-----------------------------------------------------------------------|-----------------------------------------------------|
| **Pattern C** (perma-upgrade) | `paragon` / `burnedParagon` dual currency, transcendence upgrades    | `religion.transcendenceUpgrades` (10 entries)        |
| **Pattern C1–C6** (cost curves) | Geometric price with global `priceRatio` effect                       | `buildingsData[].priceRatio` (range 1.10–2.50)        |
| **Pattern B** (binary unlock)   | 62 techs in a strict DAG                                              | `techs[].unlocks` (one of {tabs,buildings,tech,...}) |
| **Pattern S** (skill tier)      | 137 workshop upgrades in chains (e.g. `mineralHoes` → `ironHoes` → `steelHoes`) | `upgrades[].unlocks.upgrades: [...]`                 |
| **Pattern R** (rarity tier)     | 4 `type` bands in resources, 8 planets in space                        | `resources[].type`, `calendar.planets[].effects`     |
| **Pattern D** (dual-pool)       | barn→mine→smelter chain; catnip field + science technology            | `techs.agriculture.unlocks.jobs: [farmer]`          |
| **Pattern E** (status stack)    | Single `getEffect(name)` aggregator summing all system effects       | `core.js: getEffect()`                                |
| **Pattern P** (prestige layer)  | 37 perks in 5 UI groups, dual cap (per-run + across-runs)                  | `prestige.perks` (37 entries)                        |
| **Pattern T** (tier jump)       | `unlockScheme: { name, threshold }` gating on resources               | `buildingsData[].unlockScheme`                       |
| **Optional O1** (multi-system unlock) | `unlocks: { buildings, tabs, tech, upgrades, policies, jobs, crafts }` | `techs[].unlocks`                                  |
| **Optional O3** (bottleneck gate) | `unlockScheme` thresholds (e.g. 56 catnip → 1 barn)                    | `buildingsData[].unlockScheme.threshold`             |
| **Optional O5** (bottleneck balance blessing) — *partial* | `numerology` perk 给 cycle 年色加成（**部分实现**：完整 O5 的"瓶颈均衡 focus × broad"在 KG 中体现为多资源产线的均衡推进，而非单一 perk） | `prestige.perks.numerology` |
| **Optional O11** (multi-region subsystem) — *spatial* | 8 planets, 8 races（空间多区域子系统） | `calendar.planets`, `diplomacy.races` |
| **Optional O13** (temporal multi-cycle) — *temporal* | 4 seasons × 5 year-colors × 3 cycles per era（时间多周期分层） | `calendar.seasons`, `calendar.cycleYearColors` |
| **Optional O4** (rate-change advisory) | `paragon.value * 0.01` cap to `2 * paragonRatio`; `burnedParagon` dark-future multiplier 4× | `js/prestige.js: getParagonProductionRatio` (lines 501-512) |

---

## 16. New Patterns Surfaced by KG (now formalized in the framework)

Three patterns first surfaced from this case and **have since been formalized into the framework** (KG was the driving case):

1. **Dual-Cap Prestige Currency → [Pattern P2](../../patterns/pattern-p2-dual-prestige.md)** — `paragon` (per-run) and `burnedParagon` (across-runs) with *different* formulas and *different* caps. The framework's Pattern P is a single-currency system; KG proved a *dual-currency* design works (`paragon` for short-term perks, `burnedParagon` for long-term perks). Now formalized as **Pattern P2**.

2. **Permanent Debuff Challenges → [Pattern C7](../../patterns/pattern-c7-opt-in-debuff.md)** — there are **9 challenges total**, of which **8 are opt-in permanent debuffs** the player takes on for *bonus paragon* (the 9th, `ironWill`, is the *default* for veterans and gives +25% paragon on every run rather than being a debuff to opt into). Now formalized as **Pattern C7** (*opt-in debuffs that gate bonus rewards*).

3. **Cycle-of-Cycles Calendar → [Optional O13](../../optional/o13-temporal-multicycle.md)** — seasons × year-colors × cycles × eras, all multiplying. O11 (multi-region) handles the *spatial* case (e.g. Tower Wizard's 12 regions); KG proved the *temporal* version: 4 seasons × 5 year-colors × 3 cycles = 60 distinct "calendar states", each with its own multiplier. Now formalized as **Optional O13** (*temporal multi-cycle*).
