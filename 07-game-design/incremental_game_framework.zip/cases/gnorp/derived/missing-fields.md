# gnorp — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## upgrades.json

- **Schema**: `../../../schemas/upgrade.schema.json`
- **缺字段数**: 1

| 字段 | 说明 |
|------|------|
| `tier` | 由 formula_class / 升级性质推断（核心轴=core，Zybe 解锁=toggle） |

## status-effects.json

- **Schema**: `../../../schemas/status-effect.schema.json`
- **缺字段数**: 3

| 字段 | 说明 |
|------|------|
| `max_stacks` | no upper limit（implicit），见 stack_system |
| `tag` | fire/ice/acid=elemental, zybe=neutral, vulnerability=physical |
| `duration` | fire=tick-based, ice=4s shatter, vulnerability=15s, zybe=charge-based |
