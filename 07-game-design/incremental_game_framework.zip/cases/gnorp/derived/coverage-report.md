# gnorp · framework 覆盖度报告

> 由 `scripts/case-to-framework-coverage.py` 自动生成.
> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)
> 共 16 个 system.

| Case System | Framework 覆盖 | 备注 |
|------------|--------------|------|
| buildings (regions) | ✅ | 已映射到 1 个 schema: multi-region |
| upgrades (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| status-effects (effects) | ✅ | 已映射到 1 个 schema: status-effect |
| resources | ✅ | 已映射到 1 个 schema: constants |
| ui-layout | ⚠️ | 映射不充分: (无强制 schema — Optional O9 Interaction QoL) |
| 资源系统(3 个货币) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 建筑系统(14 个) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| Gnorp 单位系统(8 个类型) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 状态效果系统(5 种) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| Compression 机制(10 级 + Finale) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| Prestige / Talent Points 系统 | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| Talents 系统(41 个,6 档) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| Inspirations 系统(11 个跨建筑 modifier) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 升级 / 永久购买经济(各建筑 ~70+) | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| Achievements(17 个)与 Hats | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 15b. 界面布局与交互 (UI Layout) — O9 实证 | 🆕 | 无对应 framework schema (README 章节, 待评估) |

## 统计

- ✅ 已覆盖: **4**
- 🆕 未覆盖 (新): **11**
- ⚠️ 部分覆盖: **1**
- ❌ 不适用: **0**

## 🔗 Pattern Reverse-Link 完整性 (P2 检查)

每个 pattern 文档在 header 标注的『来源 case』应在 case README 中被反向引用。
正向声明 (pattern → case) 和反向引用 (case → pattern) 都齐全才算闭环。

**本 case 贡献的 Pattern** (2 个):

- ✅ `C` — 已在 case README 中引用
- ✅ `E` — 已在 case README 中引用

## 🆕 候选贡献 (Candidate for Contribution)

以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **资源系统(3 个货币)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **建筑系统(14 个)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Gnorp 单位系统(8 个类型)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **状态效果系统(5 种)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Compression 机制(10 级 + Finale)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Prestige / Talent Points 系统** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Talents 系统(41 个,6 档)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Inspirations 系统(11 个跨建筑 modifier)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **升级 / 永久购买经济(各建筑 ~70+)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Achievements(17 个)与 Hats** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **15b. 界面布局与交互 (UI Layout) — O9 实证** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估

## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件

- 🆕 数: **11** (≥ 1: 必进入)
- ⚠️ 数: **1** (< 2: 可跳过)
- 🔗 Reverse-link 缺失: **0**
