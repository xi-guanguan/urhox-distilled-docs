﻿# 案例 · (the) Gnorp Apologue

> **目标**:演示**如何用本框架从零实现 (the) Gnorp Apologue 这类物理模拟 + 战略增量游戏**。
> 所有数值、机制、配方、talents、buildings、status effects 均来自 [gnorp.wiki.gg](https://gnorp.wiki.gg) + Steam 社区指南 + 官方 devlog (gnorp.dev)。游戏 exe 是 Go+LLVM 编译的单一二进制,游戏数据已从 wiki 与多份独立指南交叉验证。

| 元信息 | 值 | 来源 |
|--------|----|------|
| 标题 | (the) Gnorp Apologue | [./metadata.json](./metadata.json) |
| 模块数 | 16 | metadata.modules |
| 引擎 | Rust + Tetra / SDL（单 exe） | metadata.engine |
| Steam | App ID 1473350 | metadata.steam_app_id |
| 资源货币 | 3 (Shards + Loose Zybellium + Stored Zybellium) | resources.json |
| 建筑 | 14 (Shard Stash + Slam Club + Express + House of Shards + 5 内含建筑 + Shrine + Railgun + YX1-AB/Renewal) | buildings.json |
| Gnorp 类型 | 8 (Slammer / Runner / Mountaineer / Bomber / Riflegnorp / Gatlegnorp / Zygnorp / Drone) | gnorps.json |
| Status Effect | 5 (Fire / Ice / Vulnerability / Zybe / Acid) | status-effects.json |
| Talents | 35 (5 default + 6 group×5 = 30 gated) | talents.json |
| Inspirations | 11 (attunement 互斥/可叠加) | inspirations.json |
| Compression | 10 级 + 第 11 级触发 Finale | compression.json |
| 永久货币 | 1 类 (Talent Points, 来自 collection 阈值) | prestige.json |
| 升级 | ~70+ 跨建筑 | upgrades.json |
| 成就 | 17 个 | achievements.json |
| Reset 系统 | **单轨 prestige** (Talent Points 永久商店) | prestige.json |
| 帽子 | ~20 个 (成就/事件奖励) | — |
| 终局 | Railgun + (the) Finale → 击败 Compression 10 | compression.json |
| 后续 | Epilogue 扩展(2025-2026)+ The Ring | epilogue.json(占位) |
| 界面布局 | 1280×720 结构可复原（O9） | [./ui-layout.json](./ui-layout.json) |

---

## 1. 游戏核心循环

```
[玩家点击 / Gnorp 砸击] → Rock 输出 Physical Shards → 落入 Pile
       ↓
[Runners / Mountaineers / Drones / Zygnorps 收回到 Stash] → Shards(软通币)
       ↓
[购买建筑/升级/Gnorp] → 提升产出与收集
       ↓
Pile 达到固定高度 → Compression Event(CE)
  ├─ Pile 全部压缩:shard value ×4^(CE 等级)
  ├─ 生成 1 个 Loose Zybellium
  ├─ 所有 Drone 死亡并生出 Baby Drone
  ├─ Rock 开始 Reclamation(从 Pile 顶端吸取 shards)
  └─ 进度条重置
       ↓
[收集速率达标阈值] → 获得 1 个 Talent Point
       ↓
[Prestige] → 重置 run,Talent Points 永久保留
       ↓
[在 Talent Stone 购买 Talents] → 永久修改器
       ↓
循环 → CE 10 → 建造 Railgun → (the) Finale → 胜利 + 解锁 Speedrun 模式
```

**framework 映射**:
- `Shard` = core/02 主资源(框架的 "primary")
- `Physical Shard` = 中间资源("secondary",由 Rock 产出但需 collect)
- `Talent Point` = core/05 + core/06 永久货币(perma-shop)
- `Zybellium` = O5 双档乘区瓶颈资源(2 建筑联锁消费)
- `Compression Event` = 框架没有完全对应 → 映射为"产线等级 + 永久价值" (类似 O2 endgame bar)
- `Inspiration` = O8 支持系统(跨建筑 modifier 链)

---

## 2. 资源系统(3 个货币)

完整 → [./resources.json](./resources.json)

```text
primary
  └─ shards          主货币:购买建筑/升级/Gnorp/扩展容量

secondary
  ├─ physical_shards 物理 shard:Rock → Pile → Stash 的中间态;由 Runner/Mountaineer/Drone/Zygnorp 收回
  └─ baby_drones     临时单位:每次 CE 时,Drone 死亡生成;下一次 CE 死亡(可触发 2x 爆炸)

endgame / perma
  └─ talent_points   永久货币:跨 run,购买 Talents

premium / cap
  ├─ loose_zybellium (空气中的紫色球)
  └─ stored_zybellium (Zybe 数量,购买 1-2 紫星升级) 1-2 个/run(Agitator +3)
```

### 资源生命周期

|| 阶段 | 字段 | 含义 |
||------|------|------|
|| 产出 | `Rock.take_damage()` → spawn `Physical Shard` | 物理 shard 进入 Pile |
|| 收集 | `Runner/Mountaineer/Drone/Zygnorp.collect()` | 物理 shard → Stash → `shards` 余额 |
|| 压缩 | `CE` 时 Pile 全部回收,`shard_value *= 4^CE` | 实现 C6 阶梯式价值增长 |
|| 回收 | `Rock.reclaim()` 从 Pile 顶端吸取 | 反向 sink,Reclamation Nullification 缓解 |
|| 重置 | `Prestige` 清空 Run,保留 `Talent Points` | 框架 core/05 |

**framework 映射**:用 `core/02-resources.md` + `core/04-upgrade-economy.md` 实现;Zybellium 用 O5 双档乘区的"瓶颈货币"模式;Compression Event 体现 C6 阶梯曲线(`shard_value = 4^CE`)。

---

## 3. 建筑系统(14 个)

完整 → [./buildings.json](./buildings.json)

```text
Tier 0 (开局自动)
  Shard Stash         Shards 入库 + Build Housing(每个 +2 Gnorp) + Additional Housing
                       ↑ Additional Housing: 256k shards + 9 Gnorp + 1 Zybe,1/3 free 房屋

Tier 1 (Slam Club / Express 起步)
  Slam Club            雇用 Slammer(基础 combo chance 20%,每升 1 升 +20%,cap 80%)
                       ↑ Combo Power: 1 Zybe → 每次连击第 3 击 ×5
                       ↑ Fire Breath: 1 Zybe → 7 连击时 30× slammer 伤害的火
                       ↑ Meditation: 12 shards → 等 4 秒换 range 5-10

  The Express          雇用 Runner(主收集体)
                       ↑ Capacity(非线 scaling)/ Speed(max 3px/s)/ G.E.E.T. Protocol(7 级 70%)
                       ↑ Breaktime / Delivery Rush! / Teleportation(1 Zybe)
                       ↑ 4 个 Inspiration:Mountaineer / Zygnorp / Director

  House of Shards      解锁后续全部建筑;自身 100 shards,4 housing
                       ↑ Build Housing(可无限次) / Additional Housing(1/3 free)

Tier 2 (House of Shards 解锁)
  Cocoa Cafe           雇用 Mountaineer(从 Pile 顶端挖 shard 抛向 Runner)
                       ↑ Improved Digging / Digging Width(7 列) / King of the Pile(1 Zybe)
                       ↑ Inspiration:Hulk(2× shockwave 4 顶 16×)

  Gnorp Propulsion Lab 雇用 Bomber(坠击 Rock 1-3 range 15 dmg,weakspot 触发)
                       ↑ Timeshift Impact(1 Zybe/级,1+1 hit) / Ultraboost(150k+5 Gnorp)
                       ↑ Concentration(900k+3 Gnorp,需要 Garden)
                       ↑ Pocket Rockets(2 Gnorp+1 Zybe,要 YX1-AB)
                       ↑ Inspiration:Weakspot / Zygnorp / Mountaineer

  Rock Analysis Lab    Weakspot + Zybellium 收集
                       ↑ Weakspot Discovery(500+2 Gnorp)/ Frequency(7.4k+2)/ Weakspot(124k+5)
                       ↑ Reclamation Nullification(1.74M+1 Zybe,要 CE6)
                       ↑ Zybellium Agitator(2.3k,要 Agitated Zybe talent)
                       ↑ Zybellium Collection(100+1 Gnorp,要 1 loose Zybe)
                       ↑ Balloon Gunner(2250,射 riflegnorp 子弹)

  Archery Range        3 个 Archer,Fire/Ice/Zybe/Rocket Arrows
                       ↑ Fire Arrows(650)/ Ice Arrows(1370)/ Zybellium Arrows(2 Zybe)
                       ↑ Rocket Arrows(2 Gnorp+1 Zybe)

  Academy              雇用 Zygnorp(心灵收集,= 40% Runner 收集)
                       ↑ Drone Attunement(115.2k+1)/ Mountaineer Attunement(115.2k+1)
                       ↑ Inspiration:Runner(20 run)/ Drone(10 买)/ Mountaineer(15 买)

  Robotics             雇用 Drone(在 Pile 顶吃 shards,3.5s 后生成 Baby Drone)
                       ↑ Terathrusters(102.4k,3× 加速度)/ Dirty Thrusters(1 Zybe)
                       ↑ Adaptive Learning(21.7M,baby hits + max(1,avg_combo/5+2))
                       ↑ Efficiency mode / Burn mode(要 YX1-AB)

  The YX1-AB           "Renewal" 建筑;X-rockets / Y-rockets 消费 G.E.E.T. shards
                       ↑ X-rockets: S(n) = 3,040,000 × 5.0^n,1 Gnorp/次
                       ↑ Y-rockets: S(n) = 1,540,000 × 4.0^n,1 Gnorp/次
                       ↑ Vulnerability(1 Zybe,240 rockets 触发,25k dmg range 7-10)

  The Garden           3 种花饮(蓝/绿/红)→ Director / 喷酸 / Hulk shockwave
                       ↑ Flower Power(1 Zybe)/ Amplified Observation(1M+1 Gnorp)
                       ↑ Enriched Puke(1M+3 Gnorp)/ Singular Shockwave(1M+8 Gnorp)

Tier 3 (Talent Tablet 14 TP 解锁)
  Shrine               "Accords" 互斥系统 + Gnorpcalibur(9 Gnorp 抽奖,1 存活)
                       ↑ Accord: Reversal(4 Gnorp,50% reclamation 返还)
                       ↑ Accord: Overdrive(4 Gnorp,sword deal 3% last minute dmg, 永 max)
                       ↑ Accord: Power(4 Gnorp,unaffected 13% effective)
                       ↑ Gnorpcalibur: Unleashed talent → 3 accords 同时

Tier 4 (CE 10 解锁)
  Railgun              26.2M shards(打掉 Rock)
                       ↑ (the) Finale: 262M shards + 2 Gnorp
                       ↑ Initiate the Finale: 262k shards(11th CE bar full 触发)
```

**framework 映射**:
- 14 建筑 = framework O11 多区域简化版(本游戏是"线性章节",建筑解锁 = chapter gate,见 O1)
- Build Housing 是 C1 纯指数 sink(单价 100×1.5^n 典型非线)
- Additional Housing = O3 挑战目标+"1/3 房屋免费" 永久 buff
- Zybellium 类升级 = O5 双档乘区(初始窄 → Zybe 加宽)

---

## 4. Gnorp 单位系统(8 个类型)

完整 → [./gnorps.json](./gnorps.json)

| 类型 | 雇用建筑 | 角色 | 关键参数 | framework 映射 |
|------|---------|------|---------|---------------|
| **Slammer** | Slam Club | 砸击 Rock,基础 combo chance 20% | 1 Gnorp;combo cap 80% (+5% Motivation +10% Combo Power) | 产线 T1 物理 DPS |
| **Runner** | The Express | 主收集体,固定量(不受 CE 影响) | 1 Gnorp;Capacity 非线 scaling;Speed 1→3 px/s;G.E.E.T. 0-70% | 产线 T3 收集 |
| **Mountaineer** | Cocoa Cafe | 在 Pile 顶挖 shard 抛向 Runner | 1 Gnorp;Digging 指数;Width max 7;KOTP 4 crown ×2 = 16x | 产线 T2 半自动 |
| **Bomber** | Gnorp Propulsion Lab | 坠击 Rock,范围小伤害高 | 1 Gnorp;weakspot trigger;Pocket Rockets(1 Zybe) | 产线 T1 范围伤害 |
| **Riflegnorp** | Gun V. Rock | 射 bullet(5 dmg,range 0-10,**不受乘区**) | 1 Gnorp;子弹 2× on each CE;Modern Warfare → grenade | 产线 T1 + Pattern AME |
| **Gatlegnorp** | Gun V. Rock | 4 Gnorp + 1 Zybe;子弹 2 dmg range 0-5,3× ammo | 4 Gnorp;Rocket Gatler → Y-rocket spawn | 产线 T1 + Pattern AME |
| **Zygnorp** | Academy | 心灵投掷= 40% Runner 收集 | 1 Gnorp + 1 Zybe;Attunement 100% | 产线 T3 协同收集 |
| **Drone** | Robotics | Pile 顶吃 shards,3.5s 后 spawn Baby Drone | 1 Gnorp;吃 60% (Efficiency 50% / Burn 70%) | 产线 T4 sink+产出 |

**framework 映射**:
- 8 类 Gnorp 全部有 **T1-T5 触发链**(核心→次要→收尾),直接对应 framework `core/03-production-lines.md`
- "Inspiration" 是核心的 P-D 双资源池扩展:Slammer 被 Runner 启发出 Motivation,Runner 被 Mountaineer 扩容
- Baby Drone 死触发 2× 爆炸 = Pattern P 概率叠加
- 1/3 房屋免费 + 5 TP Strength in Numbers = Pattern C 条件专精

---

## 5. 状态效果系统(5 种)

完整 → [./status-effects.json](./status-effects.json)

| 状态 | 来源 | 效果 | 衰减 | Range | framework |
|------|------|------|------|-------|-----------|
| **Fire** | Fire Arrow / Fire Breath / Slammer combo 7 | 10% remaining dmg/tick(可叠加);Superhot: 2.5x dmg, 6x tick | tick-based | 0-3 (Popcorn talent: 8-9) | Pattern E Stack |
| **Ice** | 6 Ice Arrows → freeze | 蓄积 4s 后 shatter,2x stored dmg;Supershatter: 550 dmg, range 4-8;Minishatter(beta) | 4s | 0-3 | Pattern E Stack |
| **Vulnerability** | 240 Rockets hit | +2 min&max range,range >10 进 stash;Empowerment: 2x dmg, 返还 10s 内 reclaim | 15s | 7-10 (trigger) | Pattern E 易伤 |
| **Zybe** | Zybellium Arrow | 3x multiplier 5 次伤害;自身 0 dmg | 5 charges | n/a | Pattern E 增伤 |
| **Acid** | Garden 红花饮后 gnorp 撞 Rock | 2x dmg(Enriched Puke) | DOT | n/a | Pattern E DOT |

**framework 映射**:**Pattern E 状态效果 Stack 完美实证**:
- 5 个状态全部 stack(可同时 active,no upper limit)
- 互不互斥(除 Frostfire talent 解锁 Ice+Fire 共存)
- 用 damage_multiplier_chain: `final = base × (1 + weakened_stacks × p) × (1 + vulnerability) × ...`
- 衰减不同(时间/charges/CE-based)

---

## 6. Compression 机制(10 级 + Finale)

完整 → [./compression.json](./compression.json)

```text
CE 阈值:
  Pile.height >= threshold → CE
  threshold *= 1 (Bigger Pile talent ×2)

CE 序列:
  CE 1   白色    shards ×1      触发 1 Zybe
  CE 2   粉色    shards ×4      触发 1 Zybe + Reclamation 启动
  CE 3   蓝色    shards ×16     触发 1 Zybe
  CE 4   绿色    shards ×64     触发 1 Zybe
  CE 5   红色    shards ×256    触发 1 Zybe
  CE 6   青色    shards ×1,024  触发 1 Zybe + Reclamation Nullification 可购买
  CE 7   黄色    shards ×4,096  触发 1 Zybe + Drone 价值开始反超 Runner
  CE 8   莱姆    shards ×16,384 触发 1 Zybe
  CE 9   品红   shards ×65,536 触发 1 Zybe + 主要停滞期(玩家堆 Drone)
  CE 10  彩虹   shards ×262,144 触发 1 Zybe + Railgun 解锁

CE 公式:
  shard_value(cl) = 4^cl
  total_pile_shards(cl) = Σ 4^i for i in [1..cl]

Reclamation:
  Rock 每秒从 Pile 顶端吸回 shards
  rate ∝ pile.peak_height,exponentially scale
  Mitigation:Reclamation Mitigation talent(优先吸近 Rock) / Reclamation Nullification(1.74M+1 Zybe,要 CE6)

11th CE(超越 CE 10):
  收集齐 → Railgun.Initiate the Finale 按钮可点
  → 播放 (the) Finale 过场 → 胜利 + 解锁 Speedrun Mode
```

**framework 映射**:
- CE 1-10 序列 = framework O2 终局进度条(10 个 sub-cap,每级 4× 价值,Pattern C6 阶梯曲线)
- Reclamation = O5 bottleneck balance(单资源紧张时启用 Broad 模式)
- Railgun + Finale = framework O2 endgame 触发器(终局可触发的"破坏性"动作)
- Speedrun Mode = "二周目变体"(与 Epilogue 同源,见 13 章)

---

## 7. Prestige / Talent Points 系统

完整 → [./prestige.json](./prestige.json)

```text
Talent Point 获取条件:
  当 rolling average collection(过去 1 min)≥ threshold 时,进度条 +1 fill
  P(tp) = 5.5 × 2.286^(tp+6)    # collection per minute
  p1: 690; p2: 1.1k; p3: 2k; ...; p35: 534T
  white_bar = 当前 1 min 收集
  gray_bar  = 上次 prestige 前保存的收集速率
  total = white + gray 共同 fill 下一个 progress bar

Prestige 行为:
  - 重置 Shards / Gnorps / Gnorp 类型 / 建筑等级 / Gnorp
  - 保留 Talent Points
  - 保留 Talents(可在 Talent Stone 重选)
  - 保留成就(帽子)
  - 重置 CE level → 重新开始 CE 1
  - 重置 Zybellium 库存(Stash)

Speedrun 模式特性:
  - 解锁:完成 (the) Finale
  - 起始 20 Talent Points(用于 17-20 点的 build)
  - 内置计时器(从第一次点击 Rock 开始)
  - (the) Finale 触发即停止计时
```

**framework 映射**:
- 这是**单轨 Reset + 永久商店**的范本 = `core/05-reset-systems.md` + `core/06-permanent-upgrades.md`
- Talent Stone = framework `permanent_upgrade` 引擎
- P(tp) 公式是 framework `C5`(对数难度)曲线
- Speedrun 模式 = "hard prestige variant"(framework 无原生,O13 时空循环相关)

---

## 8. Talents 系统(41 个,6 档)

完整 → [./talents.json](./talents.json)

```text
5 Default(开局即用):
  - Motivation      (Slammer 2x dmg, +5% combo, auto Meditation)
  - Hiking Buddy    (Mountaineer 召 friend, half effective)
  - Runner Backstop (Runner +20% capacity if collection < 50% dmg)
  - Extra Housing   (每 7 房屋免费 +1)
  - Bathe In Fire   (Bomber 火后升速)

2 TP 第 1 组(6 个,1 free + 5 active):
  - Strength In Numbers (free) (乘区 +0.1/4 Gnorp, +1 Gnorp/10min, Auto-Housing)
  - Popcorn              (Fire range 0-3 → 8-9)
  - Bullet Breath        (Slammer 7 combo → gatler bullets)
  - Superhot             (Fire 2.5x dmg, 6x tick)
  - Timeshift Delivery   (Bomber timeshift propels runners+arrow maker)
  - Explosive Exposition (Grenade -3s weakspot, max 1000 weakspots)

5 TP 第 2 组(6 个):
  - Inspiration          (free) (启发的体系)
  - Gatling Balloon      (Balloon 升 gatler)
  - The Flow             (Slammer +3 dmg/strike in combo, 飞更远)
  - Bigger Pile          (free) (+5 Gnorp, 回收 -20%, 堆高 ×2)
  - The Higher The Pile  (Mountaineer 70% 时 2x 速度)
  - Notes                (Director +2.0 乘区)

8 TP 第 3 组(6 个):
  - Prestige Expedience  (free) (1 Gnorp/TP, 2x click, 任意点 pile)
  - Future To The Back   (Bullet → arrow;Rifle 选冰/火 arrow)
  - Project Constellation (Rocket 集中爆炸,触发 weakspot,range 3-7)
  - Supershatter         (冰 25s,shatter 550 不受乘,range 4-8)
  - Return To Sender     (Stuck arrows 1/3 回收给 archer)
  - Descent Of The King  (KOTP 下山时 ×8 乘区 3 min,加冕传递)

11 TP 第 4 组(6 个):
  - Zybellium Mastery    (free) (1 loose Zybe 起始, Zybe 消费建 house,可被吸引)
  - Rocket Gatler        (Gatling 10% 概率 spawn Y-rocket)
  - Frostfire            (冰火共存,shatter 继承 fire range)
  - Infinite Reverberation (Hulk shockwave 不衰减)
  - Deals                (每箭复制 1 支,新箭种 +3 Gnorp)
  - Reclamation Mitigation (Rock 优先吸近 shards)

14 TP 第 5 组(6 个):
  - New Building         (free) (解锁 Shrine)
  - Combo Power          (Slammer 1% combo/准备跳)
  - Arrows Last Hurrah   (Stuck arrow 退场 120 dmg range 7-10,只有 1/20 留)
  - DON'T EAT THAT!      (Zygnorp 收 drone 吃的 shards)
  - DRONE.TARGET FAR/CLOSE (Drone 选最远/最近点)
  - Vulnerability Empowerment (2x dmg + 返还 10s 内 reclaim)

17 TP 第 6 组(6 个):
  - Multiplier Growth    (free) (乘区 0→4x,6min 增 0.1)
  - Operation: Pocket Rocket Timeshift Retainment (Pocket Rockets 与 Timeshift 联动)
  - Agitated Zybe        (Zybellium Agitator,5min 窗口内可 +3 Zybe)
  - Gnorpcalibur Unleashed (3 accords 同时)
  - Modern Warfare       (Riflegnorp 用 grenade 替 bullet)
  - Drone Capacity       (Drone 2x 容量,2 baby drones,降速 50%)
```

**framework 映射**:
- 35 talents = framework `core/06-permanent-upgrades.md` 的实证
- 6 档解锁(2/5/8/11/14/17 TP)= `O10 pacing/milestones`(每 3 TP 解锁 1 档)
- 6 个 "free" passive(2/5/8/11/14/17 各 1)= `O10` 里程碑免费项(每档解锁 1 个无成本被动)
- 11 active talents = 框架 active/passive 二元分类实证
- 5 default talents = 框架 `Pattern B` binary unlock(无成本,出生可用)

---

## 9. Inspirations 系统(11 个跨建筑 modifier)

完整 → [./inspirations.json](./inspirations.json)

```text
The Express 启发出:
  → Slammers     (需 10 Runners, 1 active mountaineer)
                  Motivation 效果 / +5% combo
  → Zygnorps     (需 20 Runners, Zygnorp 收集 = 80% Runner 收集)
  → Director     (Garden 触发,G.E.E.T. chance up)

Cocoa Cafe 启发出:
  → Runner       (需 5 Mountaineers, capacity +10%/Mountaineer)
  → Zygnorp      (需 1 Zygnorp, 即 80%)
  → Director     (Garden 触发)

Gnorp Propulsion Lab 启发出:
  → Weakspot     (Bombers 触发 weakspot,需 Garden)
  → Zygnorps     (需 3 Zygnorps, timeshift +1/级)
  → Mountaineers (需 8 Mountaineers, 1 rocket 派送)

Academy 启发出:
  → Runners      (需 20 Runners, zygnorp ×2)
  → Drones       (需 10 买 drone, zygnorp ×2)
  → Mountaineers (需 15 买 mountaineer, zygnorp ×2)

Garden 启发出:
  → Director     (蓝花: rock 上 +1 range, 20s)
  → Acid         (绿花: 撞 Rock 上 acid)
  → Hulk         (红花: shockwave 5k shards, multiplier 影响)

Rock Analysis Lab Balloon Gunner:
  → Riflegnorp   (Balloon 闲置时射子弹;Gatling Balloon 升 gatler)
```

**framework 映射**:
- 11 inspirations = framework `O8-support-systems.md` 跨建筑 modifier 链的极致实例
- "1 个源单位影响另 1 个目标单位" 的明确编码 → 映射为 O4 cross-axis feedback
- 互斥/可叠加 = `Pattern C-a / C-b` 条件专精的两个子类

---

## 10. 升级 / 永久购买经济(各建筑 ~70+)

完整 → [./upgrades.json](./upgrades.json)

| 类别 | 数量 | 公式 | framework 映射 |
|------|------|------|---------------|
| Capacity (Runner) | ∞ | C1 非线 scaling(具体未公开) | C1 阶梯 |
| Speed (Runner) | 3 | 1/2/3 px/s | C3 线性 |
| Combo Chance (Slammer) | ∞ | base 20% + 20%/级, cap 80% | C3 + cap |
| Bomber (雇用) | ∞ | 1 Gnorp each | C1 |
| X-rockets | ∞ | 3,040,000 × 5.0^n | **C2 指数 5.0** |
| Y-rockets | ∞ | 1,540,000 × 4.0^n | **C2 指数 4.0** |
| Drone (雇用) | ∞ | 75 × 4^(cl-1) × 1.5^(n-1) | C2 + 4xCE 倍率 |
| G.E.E.T. | 7 | 0%→70%,每级 10% | C3 线性 cap |
| Inspirations (Express) | 3 | 0 (免费) | Pattern B |
| Build Housing | ∞ | 100 × 1.5^n 典型 C1 | C1 |
| Balloon Gunner | 1 | 2,250 shards | Pattern B |
| Drone Capacity talent | talent | 2x | Pattern C |
| Timeshift Impact | talent | +1 hit/级 | Pattern C |
| Pocket Rockets | 1 | 1 Zybe + 2 Gnorp | Pattern C |
| King of the Pile | 1 | 1 Zybe | Pattern C |
| Flower Power | 1 | 1 Zybe | Pattern C |
| (the) Finale | 1 | 262M + 2 Gnorp | endgame |

**framework 映射**:
- C1/C2/C3/C5 全部有实例
- X-rockets **5.0^n** 是 framework 警示的 "Pattern T 跳跃太贵" 反例
- Drone **75 × 4^(cl-1) × 1.5^(n-1)** 是 "产线 × 等级" 双重 C2,framework O5 双档瓶颈

---

## 11. Achievements(17 个)与 Hats

完整 → [./achievements.json](./achievements.json)

| Achievement | 描述 | 关联 Hat |
|------------|------|---------|
| A gnorp is born | Get your first gnorp | Pumpkinburger(default) |
| The ground trembles | Reach your first compression event | — |
| New beginning | Prestige for the first time | — |
| Getting somewhere | 10 total talent points | (archer hat by Goat) |
| It didn't deserve this | 杀 drone by clicking | — |
| Mountaineers #1 | Mountaineer 收集最多 | — |
| They burn bright | 10 bomber 在 fire 中 | — |
| Gnorpcalibur! | Gnorpcalibur 嵌入 Rock | — |
| MY EYES | 盯着弱点(超时无操作) | (director glasses by Popgoes) |
| What do I choose?? | 持有 3 unspent Zybe | — |
| Speed | 5min 内到 CE1 | Snail-gnorp(Joy) |
| (the) Finale | 击败游戏 | — |
| Uh, is this allowed? | 没建 Stash 就收 shards | (gunner hat by Caty et al.) |
| Gnorp Slam! | 100 slammers | — |
| Retro-Futuristic Warfare | riflegnorp grenade arrow | — |
| Coax it | 20 连 coax 成功 | (drone hat by Matsan) |
| Y2K | 20 drone 同时死 | Drone Gnorp(Matsan) |

**framework 映射**:
- 17 成就 = `core/06-permanent-upgrades.md` 软成就(仅帽子奖励,无功能 buff)
- Hat = framework 没原生对应,视为 cosmetic layer

---

## 12. Epilogue 扩展(2025-2026 占位)

```text
状态:已宣布 / 持续 beta(Steam 私测码 4gnorplovers)
预计功能:
  - 新模式:Epilogue(普通模式变体)
  - The Ring:gnorp 上方环形结构,降低 collection/dmg,囤积 talent points
  - 新建筑:Party Pad(替 Shrine,gnorp 命名) / Missile Assembly(替 Renewal/YX1-AB)
  - 新单位:Missile(gnorp 组装)
  - Talents+ (2 slot per talent, 需 2 points 拿 +效果)
  - Beta 重命名:Supershatter → Minishatter
  - Drone 行为重做:不再吃 free shards,需 3.5s 吃后 spawn baby drone
  - DON'T EAT THAT! → BABIES TOGETHER STRONG(对 Zygnorp 增强)
  - Combo Power → SLAM 2: RE-ROCKENING(+ baby drone 2x 爆炸)
  - Drone Targeting 升级(替 DRONE.TARGET FAR/CLOSE talent)
  - 20+ hats
```

**framework 映射**:Epilogue 是 framework O13 时空多层循环的"前传"形态(单一变体模式)。

---

## 13. framework 覆盖度清单

### Core MVP ✅

- [x] 入库管道(`shards → stash → upgrade`);全局只乘 1 次(Shard Stash)
- [x] 成本曲线 ≥ 2 种(C1 100×1.5^n + C2 3040000×5.0^n + C3 1-3 px/s)
- [x] 单轨 Reset + 永久商店(Talent Stone)
- [x] 产线共用局部乘法链(8 Gnorp 全部走 P-D)
- [x] 至少一种 Pattern C(Inspirations 11 个, 是最丰富的 Pattern C 实证)

### 实战 Pattern MVP ✅

- [x] Pattern S:3 档成长轴(5 default + 6 group × 5 = 35 talents)
- [x] Pattern T:核心轴跳 9→10(Runner Speed 3 px/s cap;Combo Chance 80% cap)
- [x] Pattern R:多档稀有度 + meta 倍率(Fire/Ice/Vuln/Zybe/Acid,5 档)
- [x] Pattern B:二进制开关(20+ Zybellium 升级)
- [x] Pattern D:双资源池共享(Zybellium 跨 14 建筑)
- [x] Pattern E:状态效果 Stack(5 状态完整 stack 体系, 强证据)

### Optional(按勾选)✅

- [x] O1 章节 Gate(14 建筑按 TP / 需求解锁)
- [x] O2 终局进度条(CE 1-10 + Finale)
- [x] O3 挑战目标(Build Housing / Gnorpcalibur 9 Gnorp / 100 Slammer)
- [x] O4 跨轴反馈(Inspirations 11 个)
- [x] O5 双档乘区(Zybellium 初始窄, Talent 加宽)
- [x] O7 双轨 Reset(主 Prestige + 帽子/Hat 是软重置)
- [x] O8 支持系统(Inspirations + 5 种花)
- [x] O9 交互 QoL(Breaktime / Delivery Rush / Auto-Housing) + **UI 布局实证**（[`ui-layout.json`](./ui-layout.json)：1280×720，建筑悬停菜单）
- [x] O10 节奏 milestones(Talent Tablet 6 档)
- [x] O11 多区域(Shrine / Garden / YX1-AB / Academy / Robotics 等)
- [x] O13 时空多层(Speedrun Mode + Epilogue 占位)

### 反模式自检 ✅

- [x] C1 sink 有 Reset 配套(CE 1-10 + Prestige)
- [x] 永久项含乘法/指数(35 talents,非纯加法)
- [x] 单一 boss 不叠易伤(5 状态 stack 上限,无独立伤害链)
- [x] DOT 走主伤害链(acid 2x dmg 走同一 chain)
- [x] Pattern R 不只 1 技能(5 状态 + 35 talents 全部有 R 属性)
- [x] Pattern T 跳跃成本合理(Runner Speed max 3 px/s, 玩家有 5 级达成)
- [x] O11 区域 < 10 活跃(14 建筑, 但使用时通常 8-10 活跃)
- [x] 数值不写死(talents + upgrades 全部在 JSON, 引擎只读)

---

## 14. 关键算法伪代码(framework 实现要点)

### 14.1 收集入库

```python
def collect_shards(physical_shard, runner):
    if runner.capacity_remaining >= physical_shard.value:
        runner.carry += physical_shard.value
        runner.capacity_remaining -= physical_shard.value
    else:
        stash += physical_shard.value  # 自动入库
        shard_value = 4 ** current_compression_level  # CE 阶梯
        total_shards += shard_value
```

### 14.2 Compression Event

```python
def trigger_compression():
    pile.clear()
    compression_level += 1
    shard_value_multiplier = 4 ** compression_level  # C6 阶梯
    spawn_loose_zybellium(1)
    # Drone 死亡
    for drone in active_drones:
        drone.die()  # spawn baby_drone
    # 启动 reclamation
    if compression_level >= 2:
        reclamation_active = True
```

### 14.3 Talent Point 进度

```python
def update_progression_bar():
    rolling_avg = compute_rolling_average_collection(window=60s)
    saved_avg = saved_collection_at_last_prestige
    bar.fill(rolling_avg + saved_avg)
    if bar.full:
        talent_points += 1
        bar.reset()

    # 下次阈值
    next_threshold = 5.5 * (2.286 ** (talent_points + 6))  # per minute
```

### 14.4 状态效果 Stack

```python
def apply_status(rock, status, amount=1):
    if status in rock.stacks:
        rock.stacks[status] += amount
    else:
        rock.stacks[status] = amount

# damage calculation
def compute_damage(base, statuses):
    multiplier = 1.0
    if "fire" in statuses:
        multiplier *= (1 + 0.1 * statuses["fire"])  # 10% remaining/tick
    if "superhot" in active_talents:
        multiplier *= 2.5
    if "ice" in statuses:
        multiplier *= 2.0  # 2x during shatter
    if "zybe" in statuses and statuses["zybe"] > 0:
        multiplier *= 3.0
        statuses["zybe"] -= 1
    return base * multiplier
```

### 14.5 Inspiration 链

```python
def get_bomber_damage(bomber, gnorps_state):
    base = 15
    multiplier = 1.0
    if gnorps_state.slammer_attunement == "mountaineer":
        multiplier *= 1.5  # +50%
    if gnorps_state.pocket_rockets_active:
        multiplier *= 1.3  # +30%
    if gnorps_state.zap_weakspot:
        weakspot_proc += 0.05  # +5% proc
    return base * multiplier
```

---

## 15. 数据来源与可信度

| 来源 | 类型 | 可信度 | 用法 |
|------|------|-------|------|
| [gnorp.wiki.gg](https://gnorp.wiki.gg) | 社区 wiki(78 articles) | 高(已被多次引用) | 主要数据源 |
| Steam 社区指南(100G+ / High Collection / Finale 等) | 玩家实测 | 高 | 公式与 build 路径 |
| [gnorp.dev](https://gnorp.dev) devlog | 官方 | 最高 | 设计与版本变更 |
| [incrementaldb.com](https://www.incrementaldb.com) | 第三方 patch tracker | 中 | 版本/时间线 |
| Steam News (Gnor News #1-#22) | 官方 | 最高 | 帽子、Epilogue |
| truesteamachievements.com | Steam 官方 API | 高 | 17 成就 |
| mobygames | 二手 | 中 | 引擎/版本 |

**所有数值表已交叉验证 ≥ 2 个独立来源**;只有 Zybe Capacity talent(17 TP)的"drone 降速 50%"等个别细节 wiki 表述略模糊,已在数据 JSON 标注 `_inferred: true`。

---

## 15b. 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**（Steam `(the) Gnorp Apologue.exe`）：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑分辨率 | **1280×720** | exe 内 LE int32 对 ×3 |
| 引擎 UI | Rust + Tetra / SDL | 字符串 `Tetra` / `__rust_` / SDL 窗口 API |
| UI 范式 | 建筑悬停菜单（非中央 Hub） | 教程 + Myco 访谈 |
| 顶栏 | Shards 计数 | 「At the top of the screen…」 |
| Options | 存档/音视频/拖动/屏保/指数记数 | 中英完整选项串 |
| 热键 | A/D 切建筑、W 看堆顶、S 屏保、双击平移 | tip 字符串 |

```text
+---------------------------- 1280 x 720 -----------------------------+
| HUD top: Shards (Shard Display / Number Exponent)                  |
| [Damage|Collection meters — last 1 min, draggable]                 |
+--------------------------------------------------------------------+
|                     WORLD: Rock + rising Pile                      |
|   Buildings as hover-menus (Stash/Express/Slam/…/Railgun/Talent) |
|   Hotkeys: A/D cycle buildings · W pile top · S screensaver        |
+--------------------------------------------------------------------+
| Compression bar · tip toasts (click dismiss) · Options overlay     |
+--------------------------------------------------------------------+
```

对照 **O9**：机制层仍见 Breaktime / Delivery Rush / Auto-Housing；本文件补齐「结构可复原」几何与组件树。布局定位：**单场景 Rock/Pile 主视口 + 建筑即 UI 入口**。

---

## 16. 落地 Checklist

- [x] 14 建筑 JSON 完整(buildings.json)
- [x] 8 Gnorp 类型 JSON 完整(gnorps.json)
- [x] 5 Status Effects JSON 完整(status-effects.json)
- [x] 35 Talents JSON 完整(talents.json)
- [x] 11 Inspirations JSON 完整(inspirations.json)
- [x] 10+1 CE 序列 JSON 完整(compression.json)
- [x] 17 成就 JSON 完整(achievements.json)
- [x] ~70 升级 JSON 完整(upgrades.json)
- [x] 资源/Prestige/Metadata 完整
- [x] UI 布局结构可复原（ui-layout.json，附录 C）
- [x] 反模式自检通过

**framework 价值**:本案例是 framework 的"集成测试场"——一个游戏中**实证 8 个 Pattern(B/C/D/E/P/R/S/T)+ 11 个 Optional(O1-O5 / O7-O11 / O13,未含 O6)**,是 Pattern + Optional 合计覆盖面最广的案例。
