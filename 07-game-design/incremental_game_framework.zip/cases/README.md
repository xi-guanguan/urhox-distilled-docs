# 应用案例（Cases）

> 每个 case 都是一份**用本框架从零重建该游戏的完整实现说明书**——包含真实可查的数值表、framework 映射、伪代码、framework 反模式自检。
>
> **关键约定**：每个 case 自成一个**子目录**（`cases/<game>/`），README + 数据 + mapping + 派生索引**全部自包含**。case 内**不外链**到任何 framework 外部目录。**case 数据必须基于真实可查的源**（游戏的逆向数据、官方 API、源代码等），不可虚构。

---

## 案例索引

| 案例 | 题材 | 引擎 | 主要 framework 模块 |
|------|------|------|-------------------|
| [shelldiver/](shelldiver/README.md) | 海底潜水 + 战斗 + 收集稀有水母 + 岛屿/技能树 UI | GameMaker 2024.x GEN8 | **core + Pattern R / S / T / B + O8 / O9（UI）/ O10 / O11** |
| [tower-wizard/](tower-wizard/README.md) | 巫师建塔 + 魔法召唤 + 破墙终局 + 岛屿相机 UI | Godot 4.2.3 | **core + Pattern B / S / T / E + O1-O11 + O9（UI）** |
| [kittens-game/](kittens-game/README.md) | 猫村管理 + 9 时代 + 跨周期转生 | ES5 JavaScript + Dojo 1.7 | core + Pattern B / C / D / E / P / R / S / T + O1 / O3 / O5 / O11 |
| [upload-labs/](upload-labs/README.md) | 节点流水线 + 文件下载验证 + AI 喂养 + 桌面节点 UI | Godot 4.x | **core + Pattern B / C / D / E / P / P2 / R / S / T / AME / N / PR + O1 / O3 / O5 / O9（UI）/ O11** | 8 货币 / ~103 window / connectors / menus×8 / UI 1920×1080 |
| [gnorp/](gnorp/README.md) | 物理模拟 + 战略增量 + 跨建筑 inspiration + 建筑悬停 UI | Rust + Tetra (单 exe) | **core + Pattern B / C / D / E / P / R / S / T + O1-O5 / O7-O11 / O13 + O9（UI）** | 3 货币 / 14 建筑 / 8 Gnorp / 5 status / 35 talents / 11 inspirations / 10+1 compression / 17 成就 / UI 1280×720 |
| [agrivore/](agrivore/README.md) | 增量农场 + 战斗 + 7 原罪 + 跨 run Treasury + Hub UI | Unity 6 + Addressables 2.7.3 | **core + Pattern B / C / E / R / S + O9（UI）** | 6 货币 / 26 crops / 13 item types / 7 sins / 35 evolutions / 4 sigils / 1 set bonus / 5 lifetime stats / UI 1920×1080 / Hub 10 Tab |
| [dwarf-eat-mountain/](dwarf-eat-mountain/README.md) | 矮人挖山 + 塔防 + 灾变 + 6 终局山 + 三类神器 effect + 侧栏战场 UI | GameMaker 2.3+ (GEN8 IFF) | **core + Pattern B / S / T + O5 + O9（UI）+ 候选 O14** | 6 货币 / 14 建筑 / 199 升级 / 124 artifacts / 102 prestige / 27 ore / 5 den / 30 calamity / 6 mountain / 10 dwarf / 283 ui keys / 10 panel skins |
| [cell-to-singularity/](cell-to-singularity/README.md) | 文明进化科普 + 12 era + 3 层 prestige 嵌套 + Creature 收集 + Dashboard UI | Unity 2021+ (built-in, 无 Addressables) + I2 Loc + PlayFab | **core + Pattern B / S / T / R / P2 / E + O1 / O2 / O3 / O5 / O7 / O9（UI）/ O11 / O13** | 6 货币 / 12 era / 30+ 产线 / 12+ 升级 / 12+ creature / 70+ 成就 / 243 enum / 34 SO / UI 1920×1080 / PanelState×25 |
| [scritchy-scratchy/](scritchy-scratchy/README.md) | 刮刮卡桌面 + peek/陷阱 + Bot/Mundo 自动化 + JP Prestige + Night Market | Unity IL2CPP + Addressables + Unity Localization | **core + Pattern S + O9（UI）** | 3 货币 / 4 catalogue / 11+ 卡 / 6 升级类 / 9 gadgets / 8 JP 永久 / 34 成就 / UI 1920×1080 |
| [space-rock-breaker/](space-rock-breaker/README.md) | 太空采矿射击 + Plinko 炼金 + UpgradeTreeKit 技能树 + Boss Prestige | Unity IL2CPP + URP + Addressables + UpgradeTreeKit | **core + Pattern S + O9（UI）** | Credits/Fuel/Universal Ore / ~100 UD_ / 19 PD_ / 8 武器 / 15 成就 / UI 1920×1080 |

> 数据源：见 `<game>/metadata.json` 的 `data_source` 字段（每个 case 自描述）。

---

## 案例目录结构

每个 case 子目录包含：

```text
cases/
├── README.md
├── shelldiver/                   # 11 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — GMS 潜水
│   ├── README.md                 # 实现式说明书
│   ├── metadata.json
│   ├── modules.json
│   ├── resources.json
│   ├── biomes.json
│   ├── jellyfish.json
│   ├── rarity.json
│   ├── skills.json
│   ├── fields.json
│   ├── objects.json
│   ├── ui-layout.json            # HUD/岛屿/技能树/Options（O9，640×360 结构可复原）
│   ├── mapping.json              # 原生字段 → 框架 schema 映射
│   └── derived/framework-view/   # 由 mapping.json 生成（脚本产物）
├── tower-wizard/                 # 16 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — Godot 建塔
│   ├── README.md
│   ├── metadata.json
│   ├── resources.json
│   ├── tower-progression.json
│   ├── regions.json
│   ├── status-effects.json
│   ├── walls.json
│   ├── skills.json
│   ├── blessings.json
│   ├── nations.json
│   ├── trainings.json
│   ├── prestige.json
│   ├── progression-bars.json
│   ├── qol.json
│   ├── combat-multipliers.json
│   ├── ui-layout.json            # HUD/导航/区域面板/Options（O9，640×330 结构可复原）
│   ├── mapping.json
│   └── derived/framework-view/
├── kittens-game/                 # 13 个真实数据 JSON
│   ├── README.md
│   ├── metadata.json
│   ├── resources.json
│   ├── buildings.json
│   ├── techs.json
│   ├── upgrades.json
│   ├── religion.json
│   ├── space.json
│   ├── time.json
│   ├── prestige.json
│   ├── challenges.json
│   ├── diplomacy.json
│   ├── calendar.json
│   └── village.json
├── upload-labs/                  # 22 源数据 JSON（含 ui-layout.json）+ 4 派生索引 — Godot 桌面节点
│   ├── README.md
│   ├── metadata.json
│   ├── currencies.json
│   ├── attributes.json
│   ├── resources.json
│   ├── files.json
│   ├── storage.json
│   ├── symbols.json
│   ├── windows.json
│   ├── connectors.json
│   ├── upgrades.json
│   ├── research.json
│   ├── perks.json
│   ├── milestones.json
│   ├── boosts.json
│   ├── services.json
│   ├── achievements.json
│   ├── requests.json
│   ├── stats.json
│   ├── themes.json
│   ├── guides.json
│   ├── source_code.json
│   ├── ui-layout.json            # 桌面/侧栏/工具/连接器（O9+N，1920×1080 结构可复原）
│   └── derived/                  # 派生索引（可由源数据生成）
│       ├── upgrades_by_category.json
│       ├── windows_by_category.json
│       ├── windows_by_group.json
│       └── research_tree.json
└── gnorp/                        # 13 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — (the) Gnorp Apologue
    ├── README.md
    ├── metadata.json
    ├── resources.json
    ├── buildings.json
    ├── gnorps.json
    ├── status-effects.json
    ├── compression.json
    ├── talents.json
    ├── prestige.json
    ├── inspirations.json
    ├── upgrades.json
    ├── achievements.json
    ├── ui-layout.json            # HUD/建筑悬停菜单/Options（O9，1280×720 结构可复原）
    ├── mapping.json
    └── derived/framework-view/
└── agrivore/                     # 15 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — Unity 6 增量农场
    ├── README.md                 # 实现式说明书（含 §3.10 UI）
    ├── metadata.json
    ├── enums.json                # 38 enum / 478 values
    ├── resources.json            # 6 货币（coins + 4 seed + gems + crowns）
    ├── items.json                # 13 ItemType + 7 EquipmentType + 5 Rarity + 9 EquipmentStatType
    ├── crops.json                # 26 CropType + 8 CropTier + 12 CropRespawnSource
    ├── sigils.json               # 4 SigilType
    ├── set-bonus.json            # 1 SetBonus（Farmer）
    ├── sins.json                 # 7 SinType + 11 SinRunEffectKind
    ├── evolutions.json           # 35 EvolutionId + 17 UnlockNode 子类
    ├── unique-skills.json        # 6 UniqueSkillType
    ├── quests.json               # 8 QuestType + 4 QuestDifficulty
    ├── achievements.json         # 5 LifetimeStat + 3 RunStat + 7 Prestige + Treasury
    ├── ui-layout.json            # HUD/Hub/Settings（O9，1920×1080 结构可复原）
    ├── mapping.json              # 11 mappings → 6 schemas + O9
    └── derived/
        ├── missing-fields.md
        ├── coverage-report.md
        └── framework-view/       # framework-view JSON
            ├── resources.json
            ├── items.json
            ├── crops.json
            ├── sins.json
            ├── evolutions.json
            ├── quests.json
            ├── sigils.json
            ├── set-bonus.json
            └── achievements.json
└── dwarf-eat-mountain/          # 11 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — GMS 矮人挖山
    ├── README.md                 # 实现式说明书（含 §3.10 UI 布局）
    ├── metadata.json
    ├── resources.json            # 6 货币（gold/ore×27/mithril/PP/faith/soul）
    ├── buildings.json            # 14 building + 199 upgrade (linear 1-time purchase)
    ├── artifacts.json            # 124 artifact, 3 类 effect_type
    ├── prestige.json             # 102 prestige node, PP-spend
    ├── ores.json                 # 27 ore (5 类)
    ├── dens.json                 # 5 den
    ├── calamities.json           # 30 calamity event
    ├── mountains.json            # 6 special mountain
    ├── dwarves.json              # 10 dwarf type
    ├── ui-layout.json            # HUD/面板/热键/皮肤（O9 实证，283 ui.* keys）
    ├── mapping.json              # 10 mappings → framework schemas / O9
    └── derived/
        ├── missing-fields.md     # data_file 缺口报告
        ├── coverage-report.md    # framework 覆盖度报告
        ├── candidates.md         # O14/O15/O16 候选决策
        └── framework-view/       # framework-view JSON
└── cell-to-singularity/         # 11 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — Unity 进化科普
    ├── README.md                 # 实现式说明书（含 §5b UI）
    ├── metadata.json
    ├── enums.json                # 243 enum / 2197 values（按 game system 分类）
    ├── resources.json            # 6 货币（entropy/cubits/megastars/dna/replicanti/sagan）
    ├── eras.json                 # 12 era 顺序解锁
    ├── buildings.json            # 30+ producer (Cell→T-Rex→Dyson Sphere→Ascension)
    ├── upgrades.json             # 12+ 1-time 永久升级
    ├── creatures.json            # 12+ collectible creature card (4 tier + Golden)
    ├── achievements.json         # 70+ Steam 成就 (4 档 rarity)
    ├── prestige.json             # 3 层 prestige (Big Bang / Madness / Kardashev)
    ├── events.json               # 23 EventId + 6 StoryChapter
    ├── ui-layout.json            # HUD/Dashboard PanelState×25（O9，1920×1080 结构可复原）
    ├── mapping.json              # 9 mappings → 6 schemas + O9
    └── derived/
        ├── missing-fields.md     # 8 个 data_file 的缺口报告
        ├── coverage-report.md    # framework 覆盖度报告
        └── framework-view/       # 8 个 framework-view JSON
└── scritchy-scratchy/           # 10 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — Unity 刮刮卡增量
    ├── README.md                 # 实现式说明书（含 UI / prestige）
    ├── metadata.json
    ├── resources.json            # 3 货币（cash / JP / night market tokens）+ 债务态
    ├── cards.json                # 4 catalogue / 11+ 刮刮卡 + peek/陷阱
    ├── upgrades.json             # 6 类局内升级（Luck…QoL）
    ├── gadgets.json              # Scratch Bot / Mundo / Fan / Day Job…
    ├── prestige.json             # Final Chance → 8 JP 永久升级
    ├── achievements.json         # 34 Steam 成就
    ├── ui-layout.json            # 桌面刮区/目录/升级树/Bot 队列（O9，1920×1080）
    ├── mapping.json              # 7 mappings → schemas + O9
    └── derived/
        ├── missing-fields.md
        ├── coverage-report.md
        ├── candidates.md         # peek/Mundo 推迟或不沉淀
        └── framework-view/
└── space-rock-breaker/          # 12 个源 JSON（含 mapping.json + ui-layout.json）+ derived/ — Unity 太空 Plinko 增量
    ├── README.md
    ├── metadata.json
    ├── resources.json            # Credits / Fuel / ores / Universal Ore
    ├── sectors.json              # Sector 配额 / Boss / TIAB
    ├── weapons.json              # Gun…Plasma / crates
    ├── plinko.json               # Plinko 加工 + lootbox 节点
    ├── upgrades.json             # UD_* ~100 技能树 ID
    ├── prestige.json             # PD_* 19 永久节点
    ├── artifacts.json            # 神器系统（个体表不全）
    ├── achievements.json         # 15 Steam 成就
    ├── ui-layout.json            # 战斗/Plinko/技能树/Prestige（O9，1920×1080）
    ├── mapping.json
    └── derived/
        ├── missing-fields.md
        ├── coverage-report.md
        ├── candidates.md         # Plinko 推迟；Keep-* / O9 复用
        └── framework-view/
```

---

## 每个 case 的目录约定

1. **`metadata.json`** 必含字段：`_source`（数据源 URL 或文件路径）、`title`、`engine`、关键规模数字（如 `modules: 11`）、`data_source`（具体文件 / chunk 名）
2. **实体 JSON 顶级为 dict 包装**——顶层是 `{ "_source": ..., "_comment": ..., <实体集合>: [...] }`。`_source` / `_comment` 是必含元信息；实体集合（如 `skills` / `regions` / `effects`）内每项带 `id`（或 `effect_id` 等）字段以便跨文件引用。顶层**不能直接是 list**。
3. **`mapping.json`**（可选但推荐）：当 case data 用游戏**原生字段名**（与 framework schema 概念名不一致）时，加一份 `mapping.json` 桥接原生字段 → framework schema 字段。见下方 [§ 原生字段 vs 框架概念](#原生字段-vs-框架概念)。
4. **不在 case data 里写 `$schema`**——case data 保留游戏原生形态，**不直接引用 framework schema**（字段名是原生的，强行校验会破坏真实性）。校验改走 `mapping.json` + `scripts/case-to-framework.py`。
5. **`derived/` 子目录** 放派生索引（如按 category 分组、按 parent→child 构树）——与源数据隔离
6. **不外链**——所有数据 / 引用都在 framework 内部
7. **不虚构**——任何数值都能在 `_source` 找到出处
8. **`ui-layout.json`（有可玩 UI 的 case 必含）**——须达「结构可复原」：区域几何 + 组件清单。截图与 sprite 像素**不要求**入库。标准全文见 [docs/case-to-framework-contribute.md 附录 C](../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)；实证见 [dwarf-eat-mountain/ui-layout.json](dwarf-eat-mountain/ui-layout.json)。

---

## 原生字段 vs 框架概念

case data 是从真实游戏**逆向**而来，字段名是游戏原生的（如 Shelldiver 的 `o_skill_bubble_damage`、Tower Wizard 的 `unlock_tower_level`、Gnorp 的 `formula_class`）。这些**不等于** framework schema 的概念名（`id` / `unlock_gate.tower_level` / `curve`）。

为保持 case data 真实性，**不把 framework schema 直接套在 case data 上**（这是历史上 10/12 个 case data 校验失败的根因）。改用 **桥接表 `mapping.json`**：

```text
cases/<case>/
├── README.md               # 实现式说明书
├── mapping.json            # 原生字段 → framework schema 字段的映射表
├── <实体>.json             # case data（原生字段，无 $schema）
└── derived/                # （可由 mapping.json 自动生成）framework-view/*.json
```

`mapping.json` 每条 mapping 说明：

| 字段 | 含义 |
|------|------|
| `data_file` | 对应的 case data 文件 |
| `framework_schema` | 转换后应符合的 framework schema |
| `native_collections` | case data 里的实体集合路径 |
| `wrapper_key` | framework schema 期望的包装 key（如 `upgrades` / `regions` / `effects`） |
| `field_map` | 原生字段 → framework 字段的逐项映射 |
| `missing_in_native` | framework 必填但原生没有的字段（说明从何推断） |

**校验流程**：`scripts/case-to-framework.py` 读 case data + `mapping.json` → 生成 `derived/framework-view/*.json`（符合 framework schema）→ 用 `scripts/validate-schemas.py` 校验。framework schema 只校验生成的 framework-view，不校验原生 case data。

> 已有 mapping：[shelldiver/mapping.json](shelldiver/mapping.json)、[tower-wizard/mapping.json](tower-wizard/mapping.json)、[gnorp/mapping.json](gnorp/mapping.json)、[agrivore/mapping.json](agrivore/mapping.json)、[dwarf-eat-mountain/mapping.json](dwarf-eat-mountain/mapping.json)、[cell-to-singularity/mapping.json](cell-to-singularity/mapping.json)、[scritchy-scratchy/mapping.json](scritchy-scratchy/mapping.json)、[space-rock-breaker/mapping.json](space-rock-breaker/mapping.json)。Kittens Game / Upload Labs 字段命名已接近框架概念，暂无需 mapping。

---

## 启动新项目的最小步骤

1. **复制整个 case 目录**到自己的项目：

   ```bash
   cp -r cases/shelldiver/ my-game/
   # 或
   cp -r cases/tower-wizard/ my-game/
   ```

2. **修改数值**：编辑 JSON 中的字段（如替换资源 ID、修改加成百分比）

3. **复用伪代码**：从 case `README.md` 中复制 Python / TypeScript 骨架到工程

4. **校验配置**：

   ```bash
   python -m jsonschema -i my-game/shelldiver/resources.json ../schemas/constants.schema.json
   ```

5. **framework 反模式自检**：按 case `README.md` § framework 覆盖度清单逐条验证

---

## 框架 vs 案例关系

- **framework** 是**通用设计语言**（核心机制 + 实战 Pattern + Optional 模块）
- **case** 是**用 framework 实现的具体游戏**

```text
framework core/  ─┐
framework patterns/ ─┼──→ cases/shelldiver/   ──→ cases/shelldiver/*.json
framework optional/ ─┤
framework schemas/  ─┤
framework examples/ ─┘
                     │
                     └──→ cases/tower-wizard/ ──→ cases/tower-wizard/*.json
```

每个 case 的数值表通过 `mapping.json` 映射到 framework 的 Schema 概念——**case data 本身不内嵌 `$schema`**（避免原生字段命名与 schema 冲突）。脚本 `scripts/case-to-framework.py` 据此生成 `derived/framework-view/`，再由 schema 校验，从而**在保留原生数据的同时强制 framework 的设计约束**。

---

## 添加新 case（流程）

参考 [CONTRIBUTING.md § 添加案例](../CONTRIBUTING.md)。

**最低要求**：

1. **真实可查的数据源**（游戏的逆向数据 / 官方 API / 源代码）
2. **完整的 `cases/<game>/*.json`** — 每个文件都引用 framework schema
3. **case `README.md`** — 包含元信息表、模块拆解、字段映射、framework 反模式自检
4. **不外链到 framework 外部**
5. **不虚构任何数值**（不基于"估算"或"行业经验"）

---

## 元数据同步约定

每个 case 有**两份元信息**，必须保持一致：

| 来源 | 位置 | 用途 |
|------|------|------|
| **结构化** | `cases/<game>/metadata.json` | 程序可读：`_source` / `engine` / `steam_app_id` / 规模数字 |
| **人类可读** | `cases/<game>/README.md` 头部元信息表 | 策划可读：App ID / 引擎 / 题材 / 规模 / 链接 |

**修改规则**：

- 改 `metadata.json` → 同步修改 `<game>/README.md` 头部
- 改 `<game>/README.md` 头部 → 同步修改 `metadata.json`
- 任何规模数字（资源数 / 升级数 / currency 数）必须**两边都改**，否则视为脱节
- 文档与数据冲突时，**以数据为准**（数据更接近源）——并修文档

---

## Pattern / Optional 引用约定

case README 在引用 framework 的 Pattern 或 Optional 时，**统一使用以下三种格式之一**，避免审计工具误报：

| 格式 | 例子 | 何时用 |
|------|------|--------|
| **代号 + 长名 + 链接** | `[Pattern D (dual pool)](../patterns/pattern-d-dual-pool.md)` | 引用单一 Pattern 时（推荐）|
| **纯代号** | `Pattern D`、`P-D`、`O11` | 表格或行内简短引用 |
| **文件名** | `patterns/pattern-d-dual-pool.md` | 引用 Schema 或脚本时 |

**禁止**的写法：

- ❌ **只写中文长名**（如"双资源池"）：审计脚本无法识别 → 误报 0 引用
- ❌ **混用多个 Pattern 的"Pattern C"**（如 Pattern C 是 condition specifier，但 Pattern C·跨建筑灵感链也是"Pattern C"）：会造成歧义 → 用全名
- ❌ **没有反向链接**（如直接说"使用 P-D"而不附文件路径）：读者无法追溯

### 反向链接（reverse-link）要求

每个 Pattern / Optional 文档的 header 都标注"来源 case"。**来源 case 的 README 必须至少在 framework 映射表中引用一次该 Pattern/Optional**，否则会被 [`scripts/case-to-framework-coverage.py`](../scripts/case-to-framework-coverage.py) 的 reverse-link 检查标记。

### 误用 O6 的样例（避免）

`optional/o06-area-focus.md` 定义的是"**短时加速 + 冷却**的区域焦点"（10-30s 窗口 + 30-60s 冷却）。**不要**把"7 个永久解锁的 meta 倍率槽"映射到 O6——后者更接近 Pattern R（多档 meta 倍率）或 Pattern P2（多 prestige currency）。错配会污染 O6 的实证证据。

判断规则：

| 你想做的是 | 映射到 |
|----------|--------|
| 玩家**短时主动选择**区域加速 → 短暂窗口后冷却 | **O6**（区域焦点）|
| 玩家**永久解锁**第 N 个 meta 倍率槽（不主动切换）| **Pattern R**（多档 meta）|
| 玩家**短时主动选择**类系天赋（每周/每 run 重置）| **Pattern C7**（自选 debuff 的镜像：buff 侧）|

---

## 案例维护

- 修改 case 不影响 framework
- 任何 framework 新增 Pattern / Optional 应**先**反映到相关 case 中（作为该 Pattern 的实证）
- 新增 case 时参考 CONTRIBUTING.md § 添加案例

---

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 把派生索引与源数据混在同级 | 看不出哪个是 source | 用 `derived/` 子目录隔离 |
| 顶层直接是 list `[...]` | id 无法稳定引用、无处放 `_source` | 顶层用 dict 包装，实体集合作为其中一个 key |
| `metadata.json` 缺 `_source` | 数值无法追溯 | 必含数据源 URL / 文件路径 |
| 在 case data 写 `$schema` 强校验原生字段 | 原生字段名 ≠ 框架概念名，校验必失败 | 去掉 `$schema`，用 `mapping.json` 桥接 |
| 跨 case 引用数据（如 `shelldiver/` 引用 `upload-labs/`） | 案例与案例互相耦合 | 每个 case 自包含 |
| 把 case 拆成顶层 md + data/ 子目录两份 | 同 case 文档与数据分离，不直观 | 一个 case 一个子目录（README + JSON + derived 全部内含） |
