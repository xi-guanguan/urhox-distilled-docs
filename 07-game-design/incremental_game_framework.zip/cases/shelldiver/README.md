﻿# 案例 · Shelldiver

> **目标**：演示**如何用本框架从零实现 Shelldiver 这类海底潜水 + 战斗 + 收集游戏**。
> 所有数值、字段、技能清单均来自 `ShellDiversGameplay/gameplay.json`（真实可查的逆向数据）。

| 元信息 | 值 | 来源 |
|--------|----|------|
| 标题 | Shelldiver — 增量玩法与数值设计指南 | [./metadata.json](./metadata.json) |
| 引擎 | GameMaker 2024.x GEN8 | metadata.engine |
| Steam | App ID 3862670 | metadata.steam_app_id |
| 模块数 | 11 | metadata.modules |
| 数据源 | data.win (STRG/OBJT/SCPT chunks) + localizations | metadata.data_source |
| 技能数 | 88 | gameplay.json 全部 modules.skills 之和 |
| 生态区 | 4（shallows / glacial / swamp / magma） | biomes |
| 资源货币 | 6（shell + 4 资源币 + flask） | modules.1_economy.fields |
| 字段 | 87 个 bonus_* | 全部 modules.*.fields |
| 对象 | 17 个 | modules.*.objects（去重） |
| 成就 | 13 个 | achievements |
| 稀有度 | 3 档（Silver / Gold / Rainbow，无"普通"档） | modules.8_resources_rarity |
| Reset 系统 | **无**（gameplay.json 无 reset / run_points / perm_* 字段） | — |
| 界面布局 | 640×360 结构可复原（O9） | [./ui-layout.json](./ui-layout.json) |

---

## 1. 模块结构（11 个）

完整 → [./modules.json](./modules.json)

```text
1_economy              经济与货币            shell_coins + 4 资源货币 + 炼金
2_player_basics        玩家基础属性          移动速度 + 无敌时间 + 减伤
3_oxygen               氧气系统              容量/速度/再生 + 战斗伤害钩子
4_inventory            库存系统              库存 + 容量 + 水母保留
5_bubble_gun           泡泡枪（战斗 A）      主 DPS + 容量 + 暴击/斩杀
6_plasma_gun           等离子枪（战斗 B）    DPS + charge + chain + lightning + overheat
7_zones                动态水域              4 生态区 + 12 水母 sprite + biodiversity
8_resources_rarity     资源与稀有度          4 资源 + 3 稀有度 + Biovalue 元倍率
9_stations_automation  站点/转生/自动化      卖水母 / 转生 / 炼金
10_allies              盟友/召唤兽           Puffle + Starfish + Robot
11_hidden_demo         隐藏 / Demo 元        5 类 *_final + Demo 道具
```

**framework 映射**：

- 模块 1-4 对应 `core/02-04`（资源 / 玩家基础 / 氧气支撑 / 库存）
- 模块 5-6 对应 `core/03-production-lines.md` 战斗链（双武器）
- 模块 7 对应 `o11-multi-region.md`（4 生态区）
- 模块 8 对应 `patterns/pattern-r-rarity.md`（稀有度 + Biovalue 元倍率）
- 模块 9 对应 `o08-support-systems.md`（站点自动化）
- 模块 10 对应 `o08 同伴`（Puffle/Starfish/Robot）

---

## 2. 资源系统（6 个货币）

完整 → [./resources.json](./resources.json)

```text
primary
  └─ shell_coins       主货币（贝壳币）

secondary
  ├─ scrap_coins       废料币（生态区 1 资源货币）
  ├─ crystal_coins     水晶币（生态区 2 资源货币）
  ├─ mushroom_coins    蘑菇币（生态区 3 资源货币）
  └─ obsidian_coins    黑曜石币（生态区 4 资源货币）

endgame
  └─ flask_coins       炼金药水（终局货币）
```

**资源生命周期**（来自 `modules.8_resources_rarity.resources`）：

每个非主货币绑定 **4 个技能**（scrap/crystal/mushroom/obsidian）或 **1 个技能**（flask）：

| 阶段 | 字段 | 含义 |
|------|------|------|
| frequency | `o_skill_<res>_increase` | 刷出频率 |
| amount | `o_skill_<res>_value` | 单次产量 |
| advanced | `o_skill_<res>_value_rare` | 稀有度叠加后的产量 |
| final | `o_skill_<res>_final` | 终局 cap 突破 |

**framework 映射**：用 `core/02-resources.md` 实现；资源 4 技能链对应 framework 的 `add_resource` pipeline（frequency → amount → rare → final）。

---

## 3. 生态区子系统（O11 简化版 — 4 区）

完整 → [./biomes.json](./biomes.json)

```text
biome_index 0  shallows   Ocean Shallows    ACH_DEPTH_01  jl_shallows_{green,pink,yellow}
biome_index 1  glacial    Glacial Depths    ACH_DEPTH_02  jl_glacial_{green,purple,red}
biome_index 2  swamp      Swamp Waters      ACH_DEPTH_03  jl_swamp_{green,purple,yellow}
                                                        + swamp_{green,purple,yellow}_{big,small}
biome_index 3  magma      Magma Abyss       ACH_DEPTH_04  jl_magma_{blue,red,yellow}
```

**解锁方式**：成就 `ACH_DEPTH_01-04` 标识深度阈值，对应 O1 章节 Gate 简化（无资源成本，按潜水深度解锁）。

**生态区共有的 2 个技能**（来自 `modules.7_zones.skills`）：

| object | name | tiers | max_tier | framework |
|--------|------|-------|----------|-----------|
| `o_skill_entity_arrival` | Faster Waters (arrival) | `[1]` | 1 | O9 长按/点击加速 |
| `o_skill_entity_spawn` | Faster Waters (spawn) | `[10]` | 10 | O9 + Pattern T 跳级 |

**每个生态区 1 个 biodiversity 技能**（无 tiers — Pattern B 机制解锁）：

| biome | object | name |
|-------|--------|------|
| shallows | `o_skill_biodiversity_shallows` | Shallows Biodiversity |
| glacial | `o_skill_biodiversity_glacial` | Glacial Biodiversity |
| swamp | `o_skill_biodiversity_swamp` | Swamp Biodiversity |
| magma | `o_skill_biodiversity_magma` | Magma Biodiversity |

**framework 映射**：用 `optional/o11-multi-region.md` 实现（简化版仅 4 区）；biodiversity 技能对应 framework 的 `Pattern C` 条件专精（C-c 多样性）。

---

## 4. 水母清单（12 sprite + 沼泽变体）

完整 → [./jellyfish.json](./jellyfish.json)

按颜色分组：

```text
green   3 sprite  shallows / glacial / swamp
pink    1 sprite  shallows
yellow  3 sprite  shallows / swamp / magma
purple  2 sprite  glacial / swamp
red     2 sprite  glacial / magma
blue    1 sprite  magma
```

沼泽水母额外有 big/small 两个尺寸变体（purple/yellow/green 各 big+small），所以**实际种类 12 + 6 = 18**。

**关键观察**：游戏**没有 HP 墙**——`modules.3-7` 没有 wall / boss / HP 字段。挑战来自水母密度而非 HP 阈值。

**framework 映射**：不适用 `o03-challenge-axis.md` 的 HP 墙模板；生态区本身就是挑战维度。

---

## 5. 稀有度系统（Pattern R — 3 档）

完整 → [./rarity.json](./rarity.json)

| 档位 | object | 名称 | tiers | max_tier |
|------|--------|------|-------|----------|
| Silver | `o_skill_biovalue_silver` | Biovalue Increase I | `[]` | null |
| Gold | `o_skill_biovalue_gold` | Biovalue Increase II | `[]` | null |
| Rainbow | `o_skill_biovalue_rainbow` | Biovalue Increase X | `[]` | null |

**元倍率技能**（自身即跳 1→10 — Pattern T）：

| object | name | tiers | max_tier |
|--------|------|-------|----------|
| `o_skill_biovalue_amount` | Biovalue Multiplication | `[1, 2, 10]` | 10 |

**重要：游戏无"普通"档** — 所有水母都进入 Silver/Gold/Rainbow 判定。稀有度对应字段：

| field | 含义 |
|-------|------|
| `bonus_jellyfish_silver_chance` | Silver 概率 |
| `bonus_jellyfish_golden_chance` | Gold 概率 |
| `bonus_jellyfish_rainbow_chance` | Rainbow 概率 |
| `bonus_jellyfish_value` | 价值（普通） |
| `bonus_jellyfish_value_rare` | 价值（稀有） |

**framework 映射**：用 `patterns/pattern-r-rarity.md` 实现；3 档稀有度对应 framework 的多档叠加（无需"普通"档）。

---

## 6. 技能系统（88 个 — Pattern S / T / B + D 全覆盖）

完整 → [./skills.json](./skills.json)

### 6.1 核心轴（4 个 — 全部跳 8→10）

| module | object | name | tiers | max_tier |
|--------|--------|------|-------|----------|
| 3_oxygen | `o_skill_oxygen_tank` | Oxygen Tank | `[1,2,3,4,5,6,7,8,10]` | 10 |
| 5_bubble_gun | `o_skill_bubble_damage` | Bubble Damage | `[1,2,3,4,5,6,7,8,10]` | 10 |
| 6_plasma_gun | `o_skill_plasma_damage` | Plasma Damage | `[1,2,3,4,5,6,7,8,10]` | 10 |
| 9_stations_automation | `o_skill_store_speed` | Store Speed | `[1,2,3,4,5,6,7,8,10]` | 10 |

**Pattern T 跳级**：`tiers = [1,2,3,4,5,6,7,8,10]` — 跳 8→10（**不是跳 9→10**）。

### 6.2 次要轴（50 个 — 短成长）

| module | object | name | tiers | max_tier |
|--------|--------|------|-------|----------|
| 2_player_basics | `o_skill_movement_speed` | Light Feet | `[1,2,10]` | 10 |
| 3_oxygen | `o_skill_oxygen_regen_amount` | Oxygen Regen Amount | `[1,2,3]` | 3 |
| 3_oxygen | `o_skill_oxygen_regen_speed` | Oxygen Regen Speed | `[1,2,3]` | 3 |
| 4_inventory | `o_skill_player_slots` | Shellpack Slots | `[1,2,3,4,5]` | 5 |
| 4_inventory | `o_skill_player_slot_capacity` | Shellpack Capacity | `[1,2,3,4,5]` | 5 |
| 4_inventory | `o_skill_jellyfish_insurance` | Shell Insurance | `[1,2,3]` | 3 |
| 5_bubble_gun | `o_skill_bubble_tank` | Bubble Tank | `[1,2,3,10]` | 10 |
| 5_bubble_gun | `o_skill_bubble_capacity` | Bubble Capacity | `[1,2,3,4]` | 4 |
| 5_bubble_gun | `o_skill_bubble_firerate` | Bubble Attack Speed | `[1,2,3]` | 3 |
| 5_bubble_gun | `o_skill_bubble_size` | Bubble Size | `[1,2,10]` | 10 |
| 5_bubble_gun | `o_skill_bubble_doppel` | Doppel Bubble | `[1,2,3]` | 3 |
| 5_bubble_gun | `o_skill_bubble_critical_chance` | Bubble Critical Chance | `[1,2,10]` | 10 |
| 5_bubble_gun | `o_skill_bubble_critical_damage` | Bubble Critical Damage | `[1,2,3]` | 3 |
| 6_plasma_gun | `o_skill_plasma_tank` | Plasma Tank | `[1,2,3,10]` | 10 |
| 6_plasma_gun | `o_skill_plasma_capacity` | Plasma Capacity | `[1,2,3,4]` | 4 |
| 6_plasma_gun | `o_skill_plasma_firerate` | Plasma Attack Speed | `[1,2,3]` | 3 |
| 6_plasma_gun | `o_skill_plasma_range` | Plasma Range | `[1,2,3,4]` | 4 |
| 6_plasma_gun | `o_skill_plasma_chain_number` | Plasma Chain | `[1,2,3]` | 3 |
| 6_plasma_gun | `o_skill_plasma_chain_damage` | Plasma Chain Damage | `[1,2,3,4]` | 4 |
| 9_stations_automation | `o_skill_store_slots` | Store Slots | `[1,2,3,4]` | 4 |

**Pattern S 表现**：次要轴 tier 数 3-5 为主，少数跳级（`[1,2,10]`）。

### 6.3 开关技能（33 个 — 1-2 tier）

| module | object | name | tiers | max_tier |
|--------|--------|------|-------|----------|
| 3_oxygen | `o_skill_oxygen_tank_extra` | Oxygen Effectiveness | `[1,2]` | 2 |
| 3_oxygen | `o_skill_oxygen_catch` | Oxygen Catch | `[1,2]` | 2 |
| 5_bubble_gun | `o_skill_bubble_reload` | Bubble Gun Reload | `[1,2]` | 2 |
| 5_bubble_gun | `o_skill_bubble_duration` | Bubble Duration | `[1]` | 1 |
| 5_bubble_gun | `o_skill_bubble_penetration` | Bubble Penetration | `[1,2]` | 2 |
| 5_bubble_gun | `o_skill_bubble_speed` | Bubble Speed | `[1,2]` | 2 |
| 5_bubble_gun | `o_skill_bubble_first_strike` | Bubble Strike | `[1,2]` | 2 |
| 5_bubble_gun | `o_skill_bubble_smite` | Bubble Smite | `[2]` | 2 |
| 5_bubble_gun | `o_skill_bubble_execute` | Hunter Bubbles | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_reload` | Plasma Gun Reload | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_charge` | Plasma Charge | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_lightning_chance` | Plasma Lightning Chance | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_lightning_damage` | Plasma Lightning Damage | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_explosion_chance` | Plasma Overflow | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_explosion_damage` | Plasma Overflow Damage | `[1,2]` | 2 |
| 6_plasma_gun | `o_skill_plasma_overheat_damage` | Plasma Overheat | `[1,2]` | 2 |
| 9_stations_automation | `o_skill_agile_hands` | Agile Hands | `[1,10]` | 10 |
| 9_stations_automation | `o_skill_chest_speed` | Chest Speed | `[1,2]` | 2 |
| 9_stations_automation | `o_skill_faster_output` | Output Speed | `[1,10]` | 10 |
| 10_allies | `o_skill_friendly_bubble_chance` | Puffle | `[1,2]` | 2 |
| 10_allies | `o_skill_starfish_number` | Starfish Friend | `[1,2]` | 2 |
| 10_allies | `o_skill_robot_number` | Robot Ally | `[1]` | 1 |
| 10_allies | `o_skill_robot_damage` | Robot Damage | `[1]` | 1 |
| 10_allies | `o_skill_robot_lightning` | Robot Overcharge | `[1]` | 1 |

### 6.4 解锁式技能（26 个 — 无 tiers）

| module | object | name |
|--------|--------|------|
| 3_oxygen | `o_skill_deep_breath` | Deep Breath |
| 3_oxygen | `o_skill_resource_oxygen` | Resource Incentive |
| 3_oxygen | `o_skill_jellyfish_oxygen` | Jellyfish Incentive |
| 5_bubble_gun | `o_skill_bubble_ultra_reload` | Bubble Gun Ultra Reload |
| 5_bubble_gun | `o_skill_bubble_smite_threshold` | Extra Smite |
| 5_bubble_gun | `o_skill_bubble_damage_oxygen` | Bubble O2'd |
| 5_bubble_gun | `o_skill_homing_bubbles` | Homing Bubbles |
| 6_plasma_gun | `o_skill_plasma_ultra_reload` | Ultra Plasma Gun Reload |
| 6_plasma_gun | `o_skill_plasma_ultra_charge` | Ultra Plasma Charge |
| 6_plasma_gun | `o_skill_double_plasma` | Double Laser |
| 7_zones | `o_skill_biodiversity_shallows` | Shallows Biodiversity |
| 7_zones | `o_skill_biodiversity_glacial` | Glacial Biodiversity |
| 7_zones | `o_skill_biodiversity_swamp` | Swamp Biodiversity |
| 7_zones | `o_skill_biodiversity_magma` | Magma Biodiversity |
| 9_stations_automation | `o_skill_transmutator_auto_output` | Transmuter Automation |

**framework 映射**：用 `core/04-upgrade-economy.md` + [patterns/pattern-s-skill-tiers.md](../../patterns/pattern-s-skill-tiers.md) + [pattern-t-tier-jump.md](../../patterns/pattern-t-tier-jump.md) + [pattern-b-binary-unlock.md](../../patterns/pattern-b-binary-unlock.md) 实现。

**Pattern D 实证**：Shelldiver 的 `o_skill_resource_oxygen` 和 `o_skill_jellyfish_oxygen`（§6.4 解锁式技能）让氧气（单一限制资源）同时挂 3_oxygen 模块（产线）+ 5_bubble_gun / 6_plasma_gun 战斗伤害（多链路放大器）—— 这是 [patterns/pattern-d-dual-pool.md](../../patterns/pattern-d-dual-pool.md) 的实证：1 个限制资源跨多链路放大器。

---

## 7. 战斗字段（87 个 bonus_*）

完整 → [./fields.json](./fields.json)

按模块归类：

| 模块 | 字段数 | 代表字段 |
|------|-------|---------|
| 2_player_basics | 3 | movement_speed / invulnerable_time / damage_resistance |
| 3_oxygen | 7 | oxygen_max / regen_amount / regen_speed / drain_resistance × 2 / oxygen_bubble_damage / oxygen_plasma_damage |
| 4_inventory | 3 | inventory_slot_number / slot_capacity / jellyfish_kept |
| 5_bubble_gun | 17 | damage / fire_rate / reload_speed / ammo / projectile_size / projectile_speed / penetration / armor_penetration / life_time / critical_chance / critical_damage / first_strike / smite / execute_threshold / extra_shot_chance / doppel_chance / chain_chance |
| 6_plasma_gun | 14 | damage / fire_rate / reload_speed / ammo / range / chain_number / chain_damage / lightning_chance / lightning_damage / lightning_range / explosion_chance / explosion_damage / overheat_speed / overheat_damage |
| 7_zones | 2 | jellyfish_frequency / entity_arrival_speed |
| 8_resources_rarity | 16 | resource_amount / 4×{amount,frequency} / pickup_range / multiply_amount / 3×rarity_chance / value / value_rare |
| 9_stations_automation | 14 | store_value / station_output / 3×sell_speed / 2×transmutate / 3×inventory / chest_speed / transmutate_speed / alchemy_speed / alchemy_double_chance |
| 10_allies | 8 | 3×friendly_bubble / 2×starfish / 3×robot |

**framework 映射**：所有字段对应 `core/02-resources.md` 中的 `bonus_*` 全局乘区字段。战斗链维度（5+6 模块 = 31 个字段）+ 资源 / 稀有度 / 辅助 / 同盟字段构成完整战斗乘区。

---

## 8. 战斗武器（A + B 双武器）

完整 → [./objects.json](./objects.json)

| 武器 | module | field | 关键技能 |
|------|--------|-------|---------|
| 泡泡枪（主） | 5_bubble_gun | `bonus_bubble_damage` | damage / fire_rate / critical / smite / execute / penetration |
| 等离子枪（副） | 6_plasma_gun | `bonus_plasma_damage` | damage / chain / lightning / explosion / overheat |

**两把武器的关键差异**：

- 泡泡枪：**点射 / 高 DPS / 高暴击**，对应短距离战斗
- 等离子枪：**链式 / 闪电 / 爆炸 / 过热**，对应范围战斗

实现上两把武器**共用同一个 dmg 字段名空间**（都是 `bonus_bubble_*` / `bonus_plasma_*`），但**互不冲突**——framework 视角下可视为两个独立的武器乘区。

---

## 9. 站点与自动化（9_stations_automation）

完整 → [./objects.json](./objects.json)

| 对象 | role | framework 映射 |
|------|------|--------------|
| `o_jellyfish_store` | 水母商店 | T2 自动化产线 |
| `o_jellyfish_transmutator` | 水母转生器 | T2 自动化 + 资源转化 |
| `o_alchemy_station` | 炼金站 | T2 自动化 + flask_coins 产出 |
| `o_alchemy_chest` | 炼金产物箱 | T2 自动化产物存储 |
| `o_hammock` | 吊床 | O9 休息机制 |
| `o_submarine_storage` | 潜艇仓库 | 资源仓库 |

**注意**：游戏中的"transmutator"（转生器）是**资源转化器**（把低级水母转为高级水母），**不是 Reset 系统**——见 §11 说明。

---

## 10. 盟友系统（10_allies）

| 盟友 | role | 关键字段 |
|------|------|---------|
| Puffle | 友方泡泡 | `bonus_friendly_bubble_{chance,damage,size}` |
| Starfish | 海星 | `bonus_starfish_{damage,fire_rate}` |
| Robot | 机器人 | `bonus_robot_{damage,fire_rate,penetration}` |

**framework 映射**：用 `optional/o08-support-systems.md` 同盟系统实现。3 类盟友对应 framework 的不同乘区字段。

---

## 11. ⚠️ 关于 Reset 系统

**重要事实**：根据 `ShellDiversGameplay/gameplay.json` 的全部字段检索：

```text
reset        : 0 occurrences
run_points   : 0 occurrences
perm_        : 0 occurrences
permanent    : 0 occurrences
ascension    : 0 occurrences
cap          : 22 occurrences（仅出现于 biovalue_* 字段名）
prestige     : 2 occurrences（仅出现于 transmutator 相关）
```

**结论**：本游戏**没有显式 Reset 系统**（无 run_points 字段、无永久商店、无 cap_breaker、无 ascension）。

**9_stations_automation 中的 transmutator 是资源转化器**（水母 → 货币），**不是 Reset**。

因此本案例**不展示 `core/05-reset-systems.md` / `o07-dual-reset-track.md` 的实现**——Shelldiver 本身不使用这些模块。框架的其他游戏案例若需要 Reset，需自行实现。

---

## 11b. 界面布局与交互 (UI Layout) — O9 实证

完整数据 → [`ui-layout.json`](./ui-layout.json)。**验收标准：结构可复原**（[附录 C](../../docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)）。

**已测锚点**（Steam 安装目录 `data.win` + loc）：

| 项 | 值 | 证据 |
|---|---|---|
| 逻辑画布 | 640×360 | `s_menu_background_*`、`rm_skill_tree` ROOM dims |
| 显示提示 | 1280×720 / 1366 | 多数 ROOM 显示对 |
| 技能树房间 | 全屏 640×360 | `rm_skill_tree` |
| 生物群系图标 | 128×40 ×4 | `s_ui_ocean_*_icon` |
| Options | Game / Audio / Video / Controls | loc `*_button` |
| 热键语义 | 背包 / 技能树 / 双枪 / 互动 | `input_*` loc |

```text
+---------------------------- 640 x 360 -----------------------------+
| HUD: shell·scrap·crystal·mush·obsidian·flask · depth(m) · oxygen   |
+--------------------------------------------------------------------+
|  ISLAND stations (store/transmute/alchemy/hammock/storage)         |
|  ──or── OCEAN dive viewport (jellyfishes + resources)              |
|  ──or── SKILL TREE room (prestige Lvl + 88 skills)                 |
| [tools 38×35]                                      [element 52×52] |
+--------------------------------------------------------------------+
| Inventory overlay (hotkey) · Biome select 4×128×40 · Pause/Options |
+--------------------------------------------------------------------+
```

组件树（MainMenu / Pause / Options / PersistentHUD / Inventory / SkillTree / BiomeSelect / IslandStations / ExpeditionEnd）见 `ui-layout.json → components`。对照 **O9**；与 DEM 侧栏战场、Agrivore 底栏 Hub 均不同——本作为 **岛屿世界站点 + 潜水房间 + 独立技能树房间**。

---

## 12. 进度阶段（11 个模块的 progression 字段汇总）

各模块在 `progression` 字段中给出了开发者注释的阶段。以下汇总：

| 模块 | 阶段 | 内容 |
|------|------|------|
| 1_economy | Phase 1-4 | shell → biovalue 稀有度经济 → 双货币 → 炼金 |
| 3_oxygen | Phase 1-5 | 容量提升 → 上限 1.5× → 容量+再生 → 战斗钩子 → 元 |
| 5_bubble_gun | Phase 1-4 | 基础 DPS 4 维 → 容量 → 暴击/斩杀 → 高级机制 |
| 6_plasma_gun | Phase 1-4 | 基础 DPS → charge/chain/lightning/overheat → 高级 |
| 7_zones | Phase 1-4 | Shallows → Glacial → Swamp（6 个水母 big/small）→ Magma |
| 8_resources_rarity | Phase 1-5 | 资源解锁（1 → 4）→ 稀有度 Silver → Gold/Rainbow → Biovalue 元 |

**framework 映射**：用 `optional/o10-pacing-milestones.md` 实现节奏模板。

---

## 13. 工程化交付清单

```text
✅ ./metadata.json   — 标题 / 引擎 / Steam ID / 模块数 / 数据源
✅ ./modules.json    — 11 个模块 + 复杂度 + incremental_value
✅ ./resources.json — 6 个货币 + 资源生命周期（frequency/amount/advanced/final）
✅ ./biomes.json     — 4 生态区 + 6 个区域相关技能
✅ ./jellyfish.json  — 12 sprite + 沼泽变体 + 颜色映射 + 稀有度字段
✅ ./rarity.json     — 3 档稀有度 + 元倍率（跳 1→10）
✅ ./skills.json     — 88 个技能（core 4 / secondary 50 / toggle 33 / unlock 26 的代表）
✅ ./fields.json     — 87 个 bonus_* 字段（按 module 归类）
✅ ./objects.json   — 17 个对象 + 13 个成就
✅ ./ui-layout.json — HUD/岛屿站点/技能树/Options（O9，640×360 结构可复原）
✅ ./mapping.json   — 原生字段 → 框架 schema 桥接（含 UI）
```

每个 JSON 都引用 framework `schemas/`，可直接用 framework 的校验工具验证。

---

## 14. framework 覆盖度（本 case 实际用到的模块）

| framework 模块 | 本 case 是否用到 | 用到的方式 |
|--------------|-----------------|----------|
| `core/README.md`（核心循环总览） | ✅ | 5+6 模块战斗链（产出链见 03-production-lines） |
| `core/02-resources.md` | ✅ | 6 个货币 + 87 个 bonus 字段 |
| `core/03-production-lines.md` | ⚠️ 部分 | T2 自动化（站点），但无显式 T1-T5 标识 |
| `core/04-upgrade-economy.md` | ✅ | 88 个技能的 C 曲线（具体公式在 .gml，未在 gameplay.json） |
| `core/05-reset-systems.md` | ❌ | 无 Reset |
| `core/06-permanent-upgrades.md` | ❌ | 无永久升级 |
| `patterns/pattern-r-rarity.md` | ✅ | 3 档稀有度 + Biovalue 元倍率 |
| `patterns/pattern-s-skill-tiers.md` | ✅ | 4 核心 + 50 次要 + 33 开关 |
| `patterns/pattern-b-binary-unlock.md` | ✅ | 26 个无 tier 解锁 + 4 个 biodiversity |
| `patterns/pattern-t-tier-jump.md` | ✅ | 4 个核心轴跳 8→10 + 元倍率技能跳 1→10 |
| `optional/o01-chapter-gates.md` | ⚠️ 简化 | 深度阈值（通过成就标识） |
| `optional/o02-endgame-progress-bars.md` | ❌ | 无 |
| `optional/o03-challenge-axis.md` | ❌ | 无 HP 墙 |
| `optional/o04-cross-axis-feedback.md` | ⚠️ 部分 | 氧气钩子到战斗伤害（`bonus_player_oxygen_bubble_damage`） |
| `optional/o05-bottleneck-balance.md` | ❌ | 无显式瓶颈平衡 |
| `optional/o06-area-focus.md` | ❌ | 无区域焦点 |
| `optional/o07-dual-reset-track.md` | ❌ | 无 Reset |
| `optional/o08-support-systems.md` | ✅ | 6 个站点 + 3 类盟友 |
| `optional/o09-interaction-qol.md` | ✅ | Faster Waters + **UI 布局实证**（[`ui-layout.json`](./ui-layout.json)：640×360 岛屿/潜水/技能树/Options） |
| `optional/o10-pacing-milestones.md` | ✅ | 11 个 progression 字段汇总 |
| `optional/o11-multi-region.md` | ✅ | 4 生态区 |

**Shelldiver 是一个资源 / 收集型增量** —— 重点在 Pattern R + Pattern S/T/B + O11，其他 framework 模块按需选用。