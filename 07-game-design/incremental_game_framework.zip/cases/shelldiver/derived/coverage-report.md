# shelldiver · framework 覆盖度报告

> 由 `scripts/case-to-framework-coverage.py` 自动生成.
> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)
> 共 19 个 system.

| Case System | Framework 覆盖 | 备注 |
|------------|--------------|------|
| skills (upgrades) | ✅ | 已映射到 1 个 schema: upgrade |
| rarity (rarity_tiers) | ✅ | 已映射到 1 个 schema: rarity |
| biomes (regions) | ✅ | 已映射到 1 个 schema: multi-region |
| resources | ✅ | 已映射到 1 个 schema: constants |
| modules | ⚠️ | 映射不充分: (无直接 schema — 元信息) |
| ui-layout | ⚠️ | 映射不充分: (无强制 schema — Optional O9 Interaction QoL) |
| 模块结构（11 个） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 资源系统（6 个货币） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 生态区子系统（O11 简化版 — 4 区） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 水母清单（12 sprite + 沼泽变体） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 稀有度系统（Pattern R — 3 档） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 技能系统（88 个 — Pattern S / T / B + D 全覆盖） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 战斗字段（87 个 bonus_*） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 战斗武器（A + B 双武器） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 站点与自动化（9_stations_automation） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 盟友系统（10_allies） | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| ⚠️ 关于 Reset 系统 | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 11b. 界面布局与交互 (UI Layout) — O9 实证 | 🆕 | 无对应 framework schema (README 章节, 待评估) |
| 进度阶段（11 个模块的 progression 字段汇总） | 🆕 | 无对应 framework schema (README 章节, 待评估) |

## 统计

- ✅ 已覆盖: **4**
- 🆕 未覆盖 (新): **13**
- ⚠️ 部分覆盖: **2**
- ❌ 不适用: **0**

## 🔗 Pattern Reverse-Link 完整性 (P2 检查)

每个 pattern 文档在 header 标注的『来源 case』应在 case README 中被反向引用。
正向声明 (pattern → case) 和反向引用 (case → pattern) 都齐全才算闭环。

**本 case 贡献的 Pattern** (5 个):

- ✅ `B` — 已在 case README 中引用
- ✅ `D` — 已在 case README 中引用
- ✅ `R` — 已在 case README 中引用
- ✅ `S` — 已在 case README 中引用
- ✅ `T` — 已在 case README 中引用

## 🆕 候选贡献 (Candidate for Contribution)

以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:

- ⚠️ **modules** (mapping.json) — 映射不充分: (无直接 schema — 元信息)
- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **模块结构（11 个）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **资源系统（6 个货币）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **生态区子系统（O11 简化版 — 4 区）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **水母清单（12 sprite + 沼泽变体）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **稀有度系统（Pattern R — 3 档）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **技能系统（88 个 — Pattern S / T / B + D 全覆盖）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗字段（87 个 bonus_*）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗武器（A + B 双武器）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **站点与自动化（9_stations_automation）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **盟友系统（10_allies）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **⚠️ 关于 Reset 系统** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **11b. 界面布局与交互 (UI Layout) — O9 实证** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **进度阶段（11 个模块的 progression 字段汇总）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估

## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件

- 🆕 数: **13** (≥ 1: 必进入)
- ⚠️ 数: **2** (≥ 2: 必进入)
- 🔗 Reverse-link 缺失: **0**
