# shelldiver — framework 视图缺口报告

> 由 `scripts/case-to-framework.py --report` 自动生成。
> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。

## rarity.json

- **Schema**: `../../../schemas/rarity.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `base_probability` | 来自 _rarity_field_map（bonus_jellyfish_*_chance），运行时由技能决定，非静态常量 |
| `value_multiplier` | 来自 meta_multiplier（biovalue_amount）跨档元倍率 |

## biomes.json

- **Schema**: `../../../schemas/multi-region.schema.json`
- **缺字段数**: 2

| 字段 | 说明 |
|------|------|
| `primary_resource` | 生态区主资源（scrap/crystal/mushroom/obsidian，见 resources.json currencies） |
| `unlock_gate` | biome_index + 成就 ACH_DEPTH_0N 作 Gate |
