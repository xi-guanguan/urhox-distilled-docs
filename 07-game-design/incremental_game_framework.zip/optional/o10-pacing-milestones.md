﻿# O10 · 节奏规划

**项目用规划表**，非框架默认值。模块索引见 [README.md](README.md)。

## 抽象阶段

入门 → 自动化 → 分支 → 首次 Reset → 复合 → 第二目标(O2/O3) → 终局

各阶段手段：C1/C2、T1–T4、O1–O8 等。

## 自填表

| 参数 | 你的项目 |
|------|----------|
| 无永久时 C1 触顶 level | |
| Reset #1 / #2 / … 目标永久点 | |
| O1 tier 数 | |
| 启用 O2 / O3 / O7 | |

## 示例：大型多区域（非默认）

O1 多 tier + 少量 Reset 解 C1 → 中期 O8/Pattern C → 后期 O3+O7+O4 → 终局 O2。具体数字单独数值文档。

## 误区

只堆 C1 不 Reset；O7 无防刷；O3 无 O4；多资源 Gate 无 O5；数值写死代码。

---

## 应用案例：Shelldiver 节奏表（参考应用，非默认）

完整案例见 [cases/shelldiver/README.md § 节奏表](../cases/shelldiver/README.md#节奏表)。

实战节奏：海底潜水 + 战斗 + 收集 题材，13 章模块、87 个字段、68 个技能。

### 阶段推进（速览）

| 阶段 | 解锁内容 | 持续时长 | 关键 Sink | 关键永久项 |
|------|---------|---------|----------|-----------|
| **Phase 1** 入门 | `shell_coins` + 1 个生态区（Shallows） + 3 种水母 | 30-60 分钟 | C2 指数（基础技能） | — |
| **Phase 2** 自动化 | 卖水母自动化（`store_speed`）+ 1 把武器基础 DPS | 1-2 小时 | C2 指数（自动化） | 5-8 个线性永久 |
| **Phase 3** 资源扩展 | 4 种资源货币（scrap / crystal / mushroom / obsidian） + 第 2-3 生态区 | 2-3 小时 | C4 多项式 | biodiversity_<biome>（O5 雏形） |
| **Phase 4** 稀有度 | Silver / Golden / Rainbow 概率叠加 | 1-2 小时 | C4 + [Pattern R](../patterns/pattern-r-rarity.md) | biovalue 概率技能 |
| **Phase 5** 高级武器 | 第 2 把武器（解锁 charge / chain / overheat）+ 友军（Puffle / Starfish / Robot） | 2-3 小时 | C2/C4 混合 | 跨模块联动技能 |
| **Phase 6** 终局 | 4 生态区全开 + Magma 精英变体 + 13 成就 | 持续 | C4 + [Pattern T](../patterns/pattern-t-tier-jump.md) 跳 10 | *_final 隐藏技能 |
| **Phase 7** Meta Reset | Prestige 5 阶 + 跨局 biovalue 倍率 | 持续 | O7 + 跨轴反馈 | meta_level 累积 |

### 关键节奏控制

- **每个 Phase 持续时长 1-3 小时** → 适合单机增量
- **每 Phase 至少 1 个"质变点"**（如稀有度出现、新武器解锁）
- **Phase 3→4 是关键中点**：玩家第一次感受"概率叠加"乐趣
- **Phase 6→7 是终局转折**：从"刷怪"到"刷自己"

### 复用到其他题材

将上表的"阶段内容"列替换为题材相关实体即可：

- **太空 / 卡牌**：Shallows → 第一星系 / 第一章卡组
- **建造 / 经营**：Shallows → 第一个产业
- **文字 / 解谜**：Shallows → 第一章节谜题

### 抽象到本框架

| Shelldiver 元素 | 框架映射 |
|----------------|---------|
| 4 生态区线性解锁 | [o01 章节 Gate](o01-chapter-gates.md) |
| 5 阶 Prestige + Biovalue | [o07 双轨 Reset](o07-dual-reset-track.md) + 跨轴 [o04](o04-cross-axis-feedback.md) |
| 13 成就 + ACH_ALL_* | [o02 副进度条](o02-endgame-progress-bars.md) + 多 milestone |
| 16 个核心技能跳 10 | [Pattern S](../patterns/pattern-s-skill-tiers.md) + [Pattern T](../patterns/pattern-t-tier-jump.md) |
| 4 级稀有度 + biovalue | [Pattern R](../patterns/pattern-r-rarity.md) |
| 氧气 → 武器伤害 | [Pattern D](../patterns/pattern-d-dual-pool.md) |

### 复用 CheckList

- [ ] Phase 1：1 个主货币 + 1 个最小生态 / 章节
- [ ] Phase 2：1 个自动化产线 + 1 个核心 DPS / 经济轴
- [ ] Phase 3：3-5 种资源 / 货币（DAG 形态）
- [ ] Phase 4：稀有度概率叠加（[Pattern R](../patterns/pattern-r-rarity.md)）或第二目标（O2/O3）
- [ ] Phase 5：第 2 条成长轴 / 第 2 把武器 / 友军系统
- [ ] Phase 6：终局 / 精英变体 / 成就墙
- [ ] Phase 7：Meta Reset + 跨局倍率

---

## 案例复用表（其他题材参考应用）

| 题材 | Phase 1 | Phase 3 | Phase 5 | Phase 7 |
|------|---------|---------|---------|---------|
| 太空探索 | 1 个星系 | 5 种矿藏 | 第 2 艘飞船 | 星系 Prestige |
| 卡牌 RPG | 1 个卡组 | 4 个派系 | 第 2 职业 | 章节 Prestige |
| 建造经营 | 1 条产线 | 5 种原料 | 第 2 工厂 | 时代 Prestige |
| 文字解谜 | 第 1 章 | 4 种线索 | 第 2 角色 | 章节 Prestige |

**核心原则**：阶段数 ≤ 7，每阶段 1-3 小时，每阶段至少 1 个质变点。
