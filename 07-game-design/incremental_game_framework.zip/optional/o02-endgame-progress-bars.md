# O2 · 副进度条

慢变量 **XP → 满级 +1 稀有资源**；与主货币并行，通常不可互换。

## 模板

```text
cap(L) = a × b^(L^c)

on_xp_gain(raw):
    xp = raw × exp_multipliers
    while xp >= cap(level):
        xp -= cap(level); level += 1
        add_resource(rare_type, grant_amount, apply_global=false)
```

## 经验乘区

```text
exp_multipliers = Π 训练/派系/遗物(O8) × Π 条件永久(06) × cross_axis(O4，默认1) × …
```

XP 来源由项目绑定（产线 tick、建筑、战斗等）。

## 科技树（可选）

副进度条产出树货币；节点消耗见 [../core/04-upgrade-economy.md](../core/04-upgrade-economy.md) C5。

## 终局组合

- 配合 O3：末档 ∞ HP 时，用本模块资源 + O1 tier 推进  
- 无 O3：O2 资源 + 最终 upgrade 作结局  

O8 乘区见 [o08-support-systems.md](o08-support-systems.md)。
