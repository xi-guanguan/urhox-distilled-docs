# O8 · 辅助系统

乘入产线链（03）或 O2 经验链；**子项全可选**。

## 训练

```text
mult = 1 + training_level × p/100
```

配置：`trainings.json`

## 派系 / 合同

```text
if relation_active(faction):
    mult ×= 1 + faction.p/100
```

配置：`factions.json`

## 遗物 / 收藏品

```text
coll = 1 + owned × relic.p_for(type) / 100
```

乘入 [../core/02-resources.md](../core/02-resources.md) `typed_bonuses`。配置：`relics.json`

## 放置物（T5 乘算）

不直接 `add_resource`；作为 `placed_modifier(tag)` 乘入 T1–T4：

```text
# 线性
mult = 1 + count × (base_percent/100)

# 分组复合
group = floor(count / units_per_group)
mult = (1 + group_percent/100) ^ group
```

配置：`upgrades.json` 或 `placements.json`

## 同伴能力

```text
1 + ability_value(id) / 100
```

## 开局负债

```text
on_run_start: add_resource(type, -amount, apply_global=false)
```

## 状态效果（配 O3）

```text
stacks += applied; each tick: stacks = decay(stacks, rules)
```

配置：`status_effects.json`
