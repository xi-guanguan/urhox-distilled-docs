﻿# O5 · 瓶颈平衡

**依赖 O1（多资源 Gate）时最有用。** 接入 [../core/02-resources.md](../core/02-resources.md) 的 `global_multiplier`。

## 逻辑

```text
bottleneck = gate_requirements 中完成度最低的资源

bottleneck_bonuses(type):
    if type == bottleneck:
        return 1 + focus_bonus × level
    if type in active_set and next_gate_available:
        return 1 + broad_bonus × level
    return 1.0
```

## 永久项

`focus_bonus`、`broad_bonus` 来自永久商店配置；无 O1 多资源 Gate 时可省略本模块。

---

## 两档乘区（Focus + Broad）实现细节

> **来源**：[cases/tower-wizard/README.md](../cases/tower-wizard/README.md) — Balance 祝福（Focus 焦点 + Broad 广谱）双层乘区实证

当玩家有 10+ 资源 / 多区域子系统（O11）时，**单层瓶颈乘区不够细**。需要分两档：

- **Focus（焦点）**：当前最缺资源的专属大幅加成
- **Broad（广谱）**：当前活跃资源集合的温和加成

### 公式

```text
bottleneck = argmin( progress(resource) / required(resource) )
                 for resource in gate_requirements

focus_level = player.upgrades["resource_focus"].level
broad_level = player.upgrades["resource_broad"].level

bonuses(resource_type):
    if resource_type == bottleneck:
        return (1 + focus_pct × focus_level) × (1 + broad_pct × broad_level)
    if resource_type in active_resources(next_gate):
        return 1 + broad_pct × broad_level
    return 1.0
```

**关键差异**：
- Focus 是**复合乘区**（focus × broad 同时生效），避免单一资源过强
- Broad 是**单层乘区**，对所有活跃资源温和加成

### 数值参考（来自 Tower Wizard Balance 祝福）

| 资源类型 | 焦点加成 | 广谱加成 |
|---------|---------|---------|
| 木（Wood） | +150% × 等级 | +30% × 等级 |
| 石（Stone） | +150% × 等级 | +30% × 等级 |
| 知识（Knowledge） | +100% × 等级 | +30% × 等级 |
| 魔法（Magic） | +150% × 等级 | +30% × 等级 |
| 矿（Ore） | +150% × 等级 | +30% × 等级 |

> ⚠️ 知识资源因为是"非主流资源"，focus 加成更温和（100% vs 150%），避免知识瓶颈导致其他资源全停。

### 永久项配置示例

```json
{
  "id": "resource_focus",
  "name": "资源焦点",
  "max_level": 50,
  "cost_curve": { "type": "C1", "base": 100, "growth": 1.5 },
  "effect": {
    "type": "focus_multiplier",
    "pct_per_level": 150,
    "applies_to": "bottleneck"
  }
},
{
  "id": "resource_broad",
  "name": "资源广谱",
  "max_level": 50,
  "cost_curve": { "type": "C1", "base": 100, "growth": 1.5 },
  "effect": {
    "type": "broad_multiplier",
    "pct_per_level": 30,
    "applies_to": "active_set"
  }
}
```

完整示例见 [examples/configs/example-upgrades.json](../examples/configs/example-upgrades.json)。

---

## 折扣上限规则（KG 实证）

> **来源**：[cases/kittens-game/README.md § 13](../cases/kittens-game/README.md) — `game.getLimitedDR(discount, 1.0)` 截断折扣到 100%

O5 关注"乘区向上"的平衡（Focus / Broad）。KG 实证了**乘区向下**的同类问题：折扣（`1 - reduction`）**相乘**会导致早期叠加 ×0.5、×0.5 = 0.25（75% off），继续叠加就免费。KG 用 `getLimitedDR(discount, 1.0)` 函数强制折扣 cap 在 100% off，**禁止负成本 / 0 成本**。

```text
# 反模式：折扣直接相乘
total_discount = Σ discounts                # 加法
final_price = base × (1 - total_discount)   # 可能 = 0 或负数

# 正确：折扣加法 + 上限截断
total_discount = min(Σ discounts, 1.0)      # 永远不会 > 100%
final_price = base × max(0, 1 - total_discount)
```

### 关键设计规则

- **折扣永远是加法，不是乘法**：乘法相乘会导致叠加失控（×0.5 × ×0.5 = ×0.25）
- **`getLimitedDR(discount, 1.0)` 强制 cap**：KG 项目 README 明确写 *"Don't use price reduction effects. (If you do, be *extremely* careful.)"*
- **折扣 = (1 - reduction) 形式**：reduction 是 0~1 之间的数；多个 reduction 累加后取 min(sum, 1.0)
- **乘区向上（focus）用乘法，折扣向下（cost）用加法**：两类方向用不同公式

### 反模式（折扣方向）

| 反模式 | 后果 |
|--------|------|
| 折扣直接相乘 | 50% × 50% = 25%（设计师失算时叠加失控） |
| 折扣 cap 缺失 | 多个 50% 叠加 → 0 成本 → 游戏崩溃 |
| 折扣当乘区写 | 玩家数值预期错误（折扣 "100% 减" 实际是 50% 减） |
| 折扣 vs 乘区混用 | 公式混乱，平衡难做 |

## 配套

- **基础**：O5 上半部分 Focus + Broad 双层乘区
- **相关**：[core/04-upgrade-economy.md § C3 C4](../core/04-upgrade-economy.md) — 成本曲线（C3 = 一次性折扣 vs C4 = 持续折扣）
- **跨轴**：[patterns/pattern-e-status-stack.md § 经济轴变体](../patterns/pattern-e-status-stack.md) — `XxxCostReduction` 键的截断规则
- **数据**：[cases/kittens-game/buildings.json](../cases/kittens-game/buildings.json) `effects.XxxCostReduction` 字段

---

## 反模式

| 反模式 | 后果 |
|--------|------|
| 单层乘区（只有 focus 没有 broad） | 多资源时玩家只刷一个，其他资源停滞 |
| focus × broad = 加法 | 高等级时乘区爆炸，破坏平衡 |
| 瓶颈判定只看单一资源 | 多区域时其他区域停滞 |
| broad 也享受 focus 倍率 | focus 等级越高，broad 加成越高 → 失控 |
| 知识 / 特殊资源按主流资源配 | 知识囤积型玩家无解 |

---

## 适用场景

- 战斗增量（boss 战多种伤害类型）
- 资源增量（5+ 种核心资源）
- 多区域增量（O11）— 区域资源不均时
- 模拟经营（多种建筑同时升级）

---

## 配套

- **依赖**：[o01-chapter-gates.md](o01-chapter-gates.md)（多资源 Gate 是前提）
- **扩展**：[o11-multi-region.md](o11-multi-region.md)（多区域时更需两档乘区）
- **跨轴**：[o04-cross-axis-feedback.md](o04-cross-axis-feedback.md)（资源乘区影响战斗 / 产出）
- **模式**：[Pattern C · 条件专精](../core/06-permanent-upgrades.md#pattern-c--条件专精)（聚焦 / 广谱作为 Pattern C 实例）

---

## 与其他 O 的关系

| Optional | 关系 |
|---------|------|
| [o01-chapter-gates.md](o01-chapter-gates.md) | O5 需要 O1 的多资源 Gate 才能识别瓶颈 |
| [o11-multi-region.md](o11-multi-region.md) | O5 + O11 = 多区域瓶颈平衡 |
| [o10-pacing-milestones.md](o10-pacing-milestones.md) | O5 在 Phase 2 之后开始作用明显 |
| [o08-support-systems.md](o08-support-systems.md) | O5 的广谱加成常被 O8 的训练 / 派系覆盖 |