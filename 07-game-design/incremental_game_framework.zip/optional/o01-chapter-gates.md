﻿# O1 · 章节 Gate

分阶段解锁内容与 UI。**非所有增量需要**。

## 设计问题

1. 阶段表示：tier / 章节 / 时代 / 区域  
2. 每阶段解锁：产线、资源、UI、Reset 入口  
3. 进阶条件：资源 / 成就 / 挑战进度（O3）  
4. Reset 是否重置 tier：常见为 **不** 降 tier  

## Gate 类型

| 类型 | 机制 |
|------|------|
| 软 | 成本极高 |
| 硬 | 前置未满足不可点 |
| 零资源 | cost=0，需里程碑 |

```text
can_advance(from, to): …
advance_cost(from, to): lookup(tier_costs) or empty
```

## Meta 奖励

```text
on_advance: meta_points += per_tier_reward
```

## 与 O3 联动（可选）

```text
challenge_interactive(stage) := tier >= config.min_tier[stage]
```

映射表放项目 constants，框架不写死对应关系。

## Pattern 示例 A：5 阶小型

0 主动+自动化 → 1 第二资源 → 2 双资源 Gate → 3 Reset UI → 4 终局/软顶

## Pattern 示例 B：多区域大型

tier 控制区域开放顺序；区域名与数量由题材定义。

## Grant 永久项（可选）

```text
on_reset or on_milestone(tier):
    set_upgrade_level(target, grant_level)
```

配置：`constants.tier_costs`、`constants.tier_prerequisites`；成本型 Gate 见 [../core/04-upgrade-economy.md](../core/04-upgrade-economy.md) C6。

---

## 字段约定（必含 vs 可选）

框架的解锁条件**统一用 `unlock_gate` 对象**（与 [schemas/multi-region.schema.json](../schemas/multi-region.schema.json) 的 `region.unlock_gate` 一致），不要在框架侧混用 `unlock_requirement` / `unlock_scheme` 等别名。

| 字段 | 必含？ | 类型 | 含义 |
|------|-------|------|------|
| `unlock_gate.tier` / `tower_level` / `region_level` | 必含其一 | int | 章节 / 塔层 / 区域阶段索引 |
| `unlock_gate.resources` | 可选 | `{资源: 数量}` | 资源门槛（存储型，达量解锁） |
| `unlock_gate.prerequisite` | 可选 | string | 前置对象 id（建筑 / 科技 / 区域） |
| `unlock_gate.achievement_id` | 可选 | string | 成就 / 里程碑标识（零成本 Gate） |
| `unlock_gate.threshold_mode` | 可选 | `"stored"` / `"per_tick"` | 资源门槛是按"存储量"还是"单 tick 产出"判定，默认 `stored` |

> **命名区分**：本文档引用游戏原生数据时保留其原生字段名（如 KG 的 camelCase `unlockScheme`、`threshold`）；这些**只出现在"XX 实证"小节的引用块里**，框架侧示例一律用 snake_case 的 `unlock_gate`。`key` / `tier` / `flag` 仅在描述原生数据结构时出现，不是框架字段。

---

## 资源门槛 Gate（KG 实证）

> **来源**：[cases/kittens-game/README.md § 2](../cases/kittens-game/README.md) — `unlockScheme: { name: "catnip", threshold: 56 }` 作为建筑解锁前置

O1 默认 Gate 形式是"前置建筑 / 前置科技 / 前置章节"——**前置对象必须存在**。但 KG 实证了**资源门槛 Gate**：建筑**已解锁但不显示**（隐藏），直到玩家**累积到指定资源量**才出现。

```text
# 引擎逻辑
can_buy(building):
    if not building.unlockScheme: return true     # 无门槛 = 默认可买
    resource = building.unlockScheme.name          # 例: "catnip"
    threshold = building.unlockScheme.threshold    # 例: 56
    return game.resPool.get(resource).value >= threshold
```

### 两种资源门槛的差异

| 类型 | 含义 | 玩家体验 |
|------|------|---------|
| **存储门槛**（`unlockScheme`） | 玩家在**仓库**里持有 ≥ threshold 资源 | "我得先盖个 barn 存 50 猫薄荷，才能盖第 2 个 barn" |
| **产出门槛** | 玩家在**单 tick 内**产出 ≥ threshold | "我得每秒产 5 木，才能解锁第 3 类建筑" |

KG 用的是**存储门槛**：玩家需要先有一个 barn（容量 50），存到 56 时第 2 个 barn 出现——这是框架的"瓶颈前置于内容"。

### 三种 Gate 的对比

```text
# O1 默认：技术/对象 Gate
unlock_requirement: { tech: "agriculture" }       # 解锁对象存在

# O1 资源门槛：存储 Gate
unlock_scheme: { name: "catnip", threshold: 56 }  # 累积到 N 才显示

# O1 资源门槛：产出 Gate（变体）
unlock_scheme: { name: "catnip", threshold: 5,
                 mode: "per_tick" }                # 每秒产出 ≥ N
```

### 关键设计规则

- **门槛值应 > 前置建筑容量**：KG 的 catnip 门槛 56 > barn 容量 50，意味着玩家必须**至少有一个 barn** 才能开始看到第 2 个 barn 的选项。
- **门槛值应 ≤ 1 个 tick 的累积**：避免玩家需要等几十秒才能解锁。
- **隐藏而非灰显**：KG 的建筑在未达门槛时**完全不可见**——避免玩家看到买不起的东西感到挫败。
- **资源门槛 + 技术 Gate 应组合使用**：先 tech 解锁 tech 树 → 资源门槛控制"何时能实际买"。

### 反模式

| 反模式 | 后果 |
|--------|------|
| 门槛值 < 前置建筑容量 | 玩家可绕过前置直接解锁 |
| 门槛值过大（> 1h 累积） | 玩家等待时无事可做 |
| 用灰显而非隐藏 | 玩家盯着买不起的东西挫败 |
| 仅用资源门槛（无 tech Gate） | 缺少"为何要攒这个"的剧情 |
| 门槛触发后无视觉反馈 | 玩家不知道建筑何时出现 |

## 案例引用

- **来源**：[cases/kittens-game/README.md § 2 unlockScheme](../cases/kittens-game/README.md)
- **数据**：[cases/kittens-game/buildings.json](../cases/kittens-game/buildings.json) `unlock` 字段
