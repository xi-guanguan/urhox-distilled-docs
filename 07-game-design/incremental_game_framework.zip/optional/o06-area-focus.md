# O6 · 区域短时加成

保留主动操作收益；乘入 T2/T3/T4 的 `speed_multipliers`（[../core/03-production-lines.md](../core/03-production-lines.md)）。

## 数值

```text
on_area_focused(area_id):
    for duration D:
        speed_multipliers[area_id] ×= 1 + p/100 × permanent_level
```

- `D`、是否区分区域类型：项目自定  
- 可仅做 UI 焦点提示，数值见 [o09-interaction-qol.md](o09-interaction-qol.md)

## 永久项

专用永久项提供 `p`；未启用时 `speed_multipliers` 恒为 1.0。

---

## 参考形态（应用模式，非默认）

> O6 没有从零发明的案例参考（Gnorp 案例 README 反模式表已标「未含 O6」）。
> 下面的形态是从 O10（节奏）+ O11（多区域）的「通用区域短时加速」抽出。
> **不是默认数值**——不同题材需重写。

### 模板

- 1 个区域 + 1 个 focus window（10–30s）
- focus window 内：区域产线 × 2.0
- focus window 后：进入 60s 冷却，期间其他区域不补足
- 玩家选择 focus = 资源全压当前区域 → 短期爆发

### 数值（参考，非默认）

| 参数 | 参考值 | 备注 |
|------|--------|------|
| `D`（持续时间） | 10–30s | 题材相关：动作类短、放置类长 |
| `p` 倍率基础值 | +50%/level | 项目自定 |
| 冷却 | 30–60s | 防全时焦点失去意义 |

---

## 状态

**草案** — 等待 1 个具有"多区域 + 短时加速"特征的 case 来实证后正式启用。

### 触发条件

满足以下**全部**特征的真实 case 出现时，本 O6 从"草案"升格为"实证"：

1. 游戏同时存在 **≥ 3 个独立区域/产线集群**（与 O11 多区域配套）
2. 玩家被允许**主动选择 1 个区域**作为短期聚焦目标
3. focus 行为带来**时间受限**的产能乘区（不是永久升级）
4. 焦点切换有**冷却/惩罚**机制（避免"永远只点最强区域"）

### 候选 case 状态

| Case | 是否有 focus 机制 | 升格条件 |
|------|------------------|---------|
| Shelldiver | ❌（使用「区域升级」永久系统） | 不适用 O6 |
| Tower Wizard | ❌（O11 多区域但无 focus） | 不适用 O6 |
| Kittens Game | ❌（O1 章节门线性） | 不适用 O6 |
| Upload Labs | ❌（节点流水线无焦点） | 不适用 O6 |
| Gnorp | ❌（跨建筑 inspiration，无 focus） | 不适用 O6 |
| Agrivore | ❌（未明） | 待审 metadata |
| Dwarf Eat Mountain | ⚠️（O6 短时加成的雏形，O14 多阶段神器可视为变体） | 需更多 game data 实证 |

### 当前建议

如果你的新游戏满足上述 4 条,可以直接使用本 O6 文档作为参考形态——**不强制要求已存在的 case 实证**。
只要在 `metadata.json` 的 `framework_evidence` 字段标注 "O6: practical use" 即可（参见 [cases/agrivore/metadata.json](../cases/agrivore/metadata.json)）。

### 升格流程

1. 在新 case 的 README 中显式标注"O6 已使用"并附游戏内机制说明
2. 提交 PR 时在 PR 描述中写明"O6 实证"
3. 维护者审阅后将 O6 状态从"草案"改为"实证"，并在 CHANGELOG 记录

> **历史备注**：本段「状态」于 2026-07-01 框架审计后新增，目的是明确「参考形态」在框架中的生命周期。
