# O4 · 跨轴反馈

**依赖 O3。** 将挑战强度映射为产出链中的 `cross_axis`（[../core/03-production-lines.md](../core/03-production-lines.md) 默认 1.0）。

## Pattern（择一）

```text
# 分档
tier = floor(log10(power))   # 或 sqrt、阶位表
cross_axis = 1 + tier × p / 100

# 里程碑
cross_axis = (1 + p/100) ^ gates_cleared
```

`power` / DPS 口径须与 O3 汇总一致。

## 作用范围

通常乘入主货币、副产物、O2 经验等；范围由项目配置。

## 永久项

跨轴可来自 **专用永久项** 或 **自动公式**；二者勿重复乘算。

---

## 相关实战模式

- [Pattern R · 概率叠加资源](../patterns/pattern-r-rarity.md) — 多档稀有度作为跨轴信号源
