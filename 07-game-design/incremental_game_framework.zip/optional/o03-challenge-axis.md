# O3 · 挑战轴

可度量目标：Boss、墙、波次、关卡 HP。纯点击增量可省略。

## 目标类型

| 类型 | 说明 |
|------|------|
| 分段 HP | 多档，HP 跃迁 |
| 波次 | 计数型 |
| 无限 HP（可选） | 不可扣穿 → 须并行 O2/O1 推进 |
| 全有限 | 均可击破 |

## 伤害

```text
apply_damage(raw, target):
    final = raw × damage_multipliers
    target.hp -= final
    if target.hp <= 0: on_target_cleared(target)
    emit damage_for_xp(final)    # 若 O7
```

```text
damage_multipliers = Π 战斗升级 × Π 状态 × Π O8 × Π 永久(06)
```

## DPS 汇总

供 O4 读取；来源：周期伤害、召唤、投射物、技能等。

## 依赖关系

| 模块 | 关系 |
|------|------|
| O1 | tier 与挑战阶段映射（项目配置） |
| O4 | `cross_axis` ← 强度指标 |
| O7 | 伤害 → 挑战轨 XP |

**反模式：** 有 O3 无 O4 且无独立奖励 → 战斗与挂机分裂。
