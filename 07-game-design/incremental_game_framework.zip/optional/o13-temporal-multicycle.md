﻿# O13 · 时空多层循环（Temporal Multi-cycle Layering）

> **代号**：O13
> **来源**：[cases/kittens-game/README.md § 11](../cases/kittens-game/README.md) — 4 季节 × 5 年色 × 3 周期 = 60 个日历状态，每状态有独立乘区
> **首次出现**：原框架 O11 是**空间分区**（Tower Wizard 12 区域），KG 证明**时间多层**也是必要补充

实战沉淀：当游戏需要"在主循环之外提供持续的节奏变化"时，把"时间"本身分成多层（季节 → 年色 → 周期 → 时代），每层有独立乘区。玩家通过"读懂时间位置"获得小幅乘区，不需要新增内容，但持续改变最优决策。

---

## 与 O11（多区域）的对照

| 维度 | O11（空间分区） | **O13（时间多层）** |
|------|----------------|---------------------|
| 域 | 空间（区域 / 章节 / 塔层） | 时间（季节 / 年色 / 周期 / 时代） |
| 数量 | 通常 5-12 个区域 | 通常 2-5 层 × 2-7 状态 = 60+ 组合 |
| 切换 | 解锁进入新区域 | 实时切换（per-tick / per-year） |
| 乘区 | 区域专属乘区 | 每"时间位置"是独立乘区组合 |
| 解锁 | 区域 Gate | 通常无需解锁，自然循环 |
| 玩家操作 | 选区域 | 选时间（如跳过季节、用 crystal 倒带） |

## 设计形态（KG 实证）

```text
# 4 层时间结构
seasons:        ["spring", "summer", "autumn", "winter"]    # 4 状态
cycle_year_colors: ["blue", "green", "orange", "red", "purple"]  # 5 状态
cycles:         ["cycle1", "cycle2", "cycle3"]                # 3 状态
eras:           ["era1", "era2", "era3"]                      # 3 状态

# 当前时间位置
current_time = (season=winter, year_color=blue, cycle=2, era=1)

# 每层独立乘区
season_modifiers = { "winter": { "catnip": 0.25 } }  # 减益
year_modifiers   = { "blue":  { "culture": 1.5 } }   # 加成
cycle_modifiers  = { "cycle2": { "all_effects": 0.1 } }
era_modifiers    = { "era1":   { "all_prices": 0.95 } }

# 当前总乘区（4 层相乘）
active_modifier = product(season, year_color, cycle, era)
```

**关键**：4 层相乘意味着 `season=winter(-75%) × year=blue(+50%) × cycle=cycle2(+10%) × era=era1(-5%) = -45%` —— 玩家必须**理解当前时间位置**才能预判最优决策。

## 关键设计规则

### 1. 每层必须有独立语义（不能 4 层都用同一种分类）

```text
# ✅ 4 层各有侧重
season:        资源乘区（影响 catnip、wood 产量）
year_color:    文化乘区（影响 culture、festival）
cycle:         周期乘区（影响 prestige currency 收益）
era:           时代乘区（影响全局价格、unlock 顺序）

# ❌ 4 层都是资源乘区 → 玩家只看一层
```

### 2. 总组合数应 < 100（认知负担上限）

```text
# 4 × 5 × 3 × 3 = 60  ← KG 实证
# 7 × 7 × 5 × 5 = 1225 ← 玩家会放弃理解
#
# 一般规则：组合数 ≤ 玩家能记忆的"日历预判"数量
#   - 玩家只需要知道"我现在是 cycle2 的 blue year 冬季"
#   - 4-5 个 token 是记忆上限
```

### 3. 允许玩家"跳过"（消耗 currency）

KG 实证：玩家可以花 `timeCrystal` 跳过：
- 1 crystal 跳 1 个季节
- 5 crystals 跳 1 年
- 25 crystals 跳 1 个 era

**没有"跳过"按钮的 O13 会被弃用** —— 玩家会被强迫接受不利季节。

### 4. dark-future / late-era 是隐性 prestige 加速器

KG：dark-future 时代让 burnedParagon 生产 ×4、storage /500（vs /2000）。这是**不需要新 currency 的免费加速**，仅靠"时间到达后期"。

## 实战节奏对比

| 项目 | 无 O13 | 加 O13 |
|------|--------|--------|
| 玩家每天最优策略 | 同（无时间变化） | 季节变化时改变 build 顺序 |
| 玩家对资源的"耐心" | 高（资源可累积） | 低（春季 catnip 不可错过） |
| 决策频度 | 低（每 5-10 分钟） | 高（每季节切换 1 次） |
| 元游戏深度 | 浅 | 深（要算 cycle 节奏） |

## 反模式

| 反模式 | 后果 |
|--------|------|
| 单层时间（只有"白天/夜晚"） | 玩家 1 局就能内化，失去新鲜感 |
| 4 层都用同一种分类 | 玩家只关心一层，3 层浪费 |
| 组合数 > 200 | 玩家放弃预判，靠运气 |
| 不允许跳过 | 玩家被不利季节折磨 |
| 时代之间没有"分水岭" | 玩家无升级感 |
| 季节乘区写死为 ±5% | 玩家不关心时间变化 |

## 适用场景

- 资源型增量，需要"周期奖励 / 周期惩罚"双轨
- 玩家有"长线玩 100+ 小时"的预期
- 已有 O1（章节 Gate）和 O10（节奏规划），但缺少"主循环内的微节奏"
- 想给玩家"日历感"（真实日期 / 现实时间联动）

## 配套

- **基础**：[optional/o10-pacing-milestones.md](o10-pacing-milestones.md) — 7 阶段节奏
- **对照**：[optional/o11-multi-region.md](o11-multi-region.md) — 空间分区
- **跨轴**：[patterns/pattern-p2-dual-prestige.md](../patterns/pattern-p2-dual-prestige.md) — dark-future 加速 prestige
- **数据**：[cases/kittens-game/calendar.json](../cases/kittens-game/calendar.json)（4 季节 + 5 年色 + 3 周期）
- **案例**：[Kittens Game § 11 4 × 5 × 3 = 60 日历状态](../cases/kittens-game/README.md)
