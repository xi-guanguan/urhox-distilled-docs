# Optional 模块（O1-O13）

> 按需扩展的可选模块。**不是所有增量游戏都需要全部 O 模块**。

每个 O 模块都标注了**依赖关系**——只引入已满足依赖的模块。

---

## 模块索引

### 章节与终局

| 代号 | 文件 | 依赖 | 一句话 |
|------|------|------|--------|
| O1 | [o01-chapter-gates.md](o01-chapter-gates.md) | — | 阶段解锁（tier / 章节 / 区域）+ 资源门槛 Gate（**Kittens Game 实证**） |
| O2 | [o02-endgame-progress-bars.md](o02-endgame-progress-bars.md) | — | 副进度条 + 终局物 |

### 战斗与双轨 Reset

| 代号 | 文件 | 依赖 | 一句话 |
|------|------|------|--------|
| O3 | [o03-challenge-axis.md](o03-challenge-axis.md) | — | 战斗目标（boss / 波次 / HP） |
| O4 | [o04-cross-axis-feedback.md](o04-cross-axis-feedback.md) | O3 | 战斗强度 → 产出链 |
| O7 | [o07-dual-reset-track.md](o07-dual-reset-track.md) | O3（常见） | 产发轨 + 挑战轨（**单 currency 双源**；双 currency 见 [Pattern P2](../patterns/pattern-p2-dual-prestige.md)） |

### 辅助与节奏

| 代号 | 文件 | 依赖 | 一句话 |
|------|------|------|--------|
| O5 | [o05-bottleneck-balance.md](o05-bottleneck-balance.md) | O1 多资源 Gate | 瓶颈资源的额外加成（Focus + Broad 两档乘区，**Tower Wizard 实证** + 折扣上限规则，**Kittens Game 实证**） |
| O6 | [o06-area-focus.md](o06-area-focus.md) | —（参考形态，无实证） | 区域短时加速（参考形态，无实证） |
| O8 | [o08-support-systems.md](o08-support-systems.md) | — | 训练 / 派系 / 遗物 / 同伴 |
| O9 | [o09-interaction-qol.md](o09-interaction-qol.md) | — | 长按连发 / Tooltip / 跳跃提示 |
| O10 | [o10-pacing-milestones.md](o10-pacing-milestones.md) | — | 节奏规划 + Shelldiver 节奏案例 |

### 系统规模与多区域

| 代号 | 文件 | 依赖 | 一句话 |
|------|------|------|--------|
| O11 | [o11-multi-region.md](o11-multi-region.md) | O1（章节 Gate 是简化版） | 多区域子系统（产线 >10 时按区域分组，**Tower Wizard 12 区域实证**） |
| O13 | [o13-temporal-multicycle.md](o13-temporal-multicycle.md) | O10 | 时空多层循环（4 季节 × 5 年色 × 3 周期 = 60 日历状态，**Kittens Game 实证**） |

> **关于 O12 缺号**：Optional 编号从 O1 跳到 O13，**没有 O12**。这是有意为之：早期版本曾规划一个"全局事件系统"模块，后因框架内已有 O4（跨轴反馈）、O8（辅助系统）、O10（节奏里程碑）覆盖该需求而被废弃。编号保留空位以备将来重新引入。

---

## 推荐引入顺序

按题材类型：

### 纯点击增量（Cookie Clicker 类）

- O1（章节）→ O2（终局）→ O8（训练 / 收藏品）

### 战斗增量（Clicker Heroes 类）

- O1 → O3 → O4 → O7 → O10 → **Pattern E**（状态 Stack）+ O11（若产线 >10）

### 资源采集增量（Melvor 类）

- O6（区域焦点）→ O10（节奏）→ O11（多区域）

### 混合题材（如 Shelldiver）

- O1 + O3 + O5 + O7 + O10 + 实战 Pattern S/T/R/D

### 复杂战斗 + 多区域

- O1 + O3 + O4 + O5 + O7 + O8 + O10 + O11 + **Pattern E**（状态 Stack）+ Pattern S/T/R/D

---

## 实战 Pattern 集成

部分 O 模块会引用 [patterns/](../patterns/) 中的实战 Pattern：

| Optional | 集成 Pattern |
|---------|------------|
| [o01](o01-chapter-gates.md) | [Pattern B](../patterns/pattern-b-binary-unlock.md)（章节即二进解锁） |
| [o04](o04-cross-axis-feedback.md) | [Pattern R](../patterns/pattern-r-rarity.md)（稀有度作为跨轴信号） |
| [o05](o05-bottleneck-balance.md) | [Pattern C · Permanent Upgrades](../core/06-permanent-upgrades.md#pattern-c--条件专精)（Focus + Broad 永久项）+ [Pattern E 经济轴变体](../patterns/pattern-e-status-stack.md)（折扣上限规则）+ [Pattern AME](../patterns/pattern-ame-3tuple-attribute.md)（折扣用负数 `a` 表达） |
| [o07](o07-dual-reset-track.md) | [Pattern P2](../patterns/pattern-p2-dual-prestige.md)（双 prestige 货币，比 O7 更进一步） |
| [o09](o09-interaction-qol.md) | [Pattern T](../patterns/pattern-t-tier-jump.md)（跳跃 UX 提示） |
| [o10](o10-pacing-milestones.md) | 全部 Pattern（节奏案例参考） |
| [o11](o11-multi-region.md) | [Pattern E](../patterns/pattern-e-status-stack.md)（区域伤害链上挂状态 Stack）+ [Pattern N](../patterns/pattern-n-node-pipeline.md)（区域内的 node graph） |
| [o13](o13-temporal-multicycle.md) | [Pattern P2](../patterns/pattern-p2-dual-prestige.md)（dark-future 加速 prestige） |

### 自选 Debuff（O3 变体）

[Pattern C7](../patterns/pattern-c7-opt-in-debuff.md) 是 O3 的**反向变体**——把"完成目标换奖励"改为"接受惩罚换奖励"。配合 Pattern P2 提供 prestige currency 加速。

### 软重置变体（O7 变体）

[Pattern PR](../patterns/pattern-pr-service-soft-reset.md) 是 O7 的**反向变体**——O7 是"产发轨 + 挑战轨（双源）"，PR 是"代币 → 单 sub-tree 退款"。区别于 hard prestige（reboot 重置全部），PR 只重置 service 列表中的 upgrades + windows。

---

## 反模式

> 完整反模式目录（唯一权威源）见 [docs/anti-patterns.md](../docs/anti-patterns.md)。

| 反模式 | 后果 |
|--------|------|
| O3 与产出完全独立 | 后期一线废弃 |
| O7 无防刷 | 后期点数通胀 |
| O4 与 O3 指标不一致 | 跨轴失效 |
| 多资源 Gate 无 O5 | 资源全压单一方向 |
| O5 单层乘区（无 Broad） | 多资源时玩家只刷一个，其他资源停滞 |
| O5 focus × broad 用加法 | 高等级乘区爆炸 |
| O11 区域独自引用其他区域资源 | 失去 DAG 独立性 |
| O11 区域数 >10 活跃 | 玩家认知负担爆炸 |
| O11 区域无独立 UI 面板 | 玩家无法追踪区域进度 |
| 数值写死代码 | 无法调参与版本对比 |