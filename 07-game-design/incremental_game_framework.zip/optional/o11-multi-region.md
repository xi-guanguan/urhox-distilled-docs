﻿# O11 · 多区域子系统（Multi-region Subsystem）

> **代号**：O11
> **来源**：[cases/tower-wizard/README.md](../cases/tower-wizard/README.md) — 12 个区域（Orb / Study / Forest / Building / Prestige / Academy / Alchemy / Embassy / Sorcery / Temple / Observatory & Warden / Dragon Nest）实证
> **依赖**：—

当系统规模超过约 10 条产线时，按「区域 / 章节 / 塔层」分组是常见做法。每个区域拥有：

- 独立的解锁条件与 Gate
- 独立的自动化、专属资源、专属 sink
- 独立 UI 面板与子图腾

但**跨区域乘区**（训练 / 派系 / 符文 / 国家等）仍走**全局乘法链**，**不在区域内部硬绑**。区域数量本身是慢变量。

---

## 为什么需要 O11

**问题**：当增量游戏的产线超过 ~10 条时：

- 单页 UI 无法容纳
- 全局单一资源 DAG 失真（不同区域有不同的资源热点）
- 玩家决策疲劳（每条产线都要单独看）

**解法**：按区域分组。每个区域是**自包含子系统**，但跨区域乘区走全局链。

---

## 区域子系统模板

```text
region:
    id: "study"
    name: "Study"
    unlock_gate: { "tower_level": 2 }
    primary_resource: "knowledge"
    production_lines: [...]       # T1-T5 实例
    upgrades: [...]                # C1-C6 实例
    sink_curves: [...]             # 区域专属 sink
    ui_panel: "study_panel"
    totem_type: "knowledge"       # 区域专属图腾类型
```

---

## 设计原则

### 1. 独立性（区域内自包含）

- ✅ 区域有**专属主资源**（如 Study → Knowledge，Forest → Wood）
- ✅ 区域有**专属升级曲线**（如 `SkillDefScaling`）
- ✅ 区域有**专属自动化**（如 Study 的 Spirit Tome）
- ✅ 区域有**独立 UI 面板**
- ❌ 区域**不应**独自引用其他区域的资源作为输入

### 2. 全局性（跨区域乘区走全局）

- ✅ **训练**（Trainings）→ 全局乘入所有相关区域
- ✅ **派系**（Nations）→ 跨区域绑定（如 Verdania → 木）
- ✅ **遗物**（Relics）→ 全局加某类资源
- ✅ **祝福**（Blessings）→ 全局或条件性跨区域
- ✅ **跨轴反馈**（DestructionBlessing）→ 全局
- ❌ **不应**让区域内部的乘区硬绑到其他区域

### 3. 慢变量（区域数量本身是节奏）

- 区域数 = 节奏控制旋钮
- 新增 1 区域 ≈ 30-60 分钟新内容
- 终局区域数应 ≤ 玩家可同时关注的区域数（建议 5-8 个活跃区域）

---

## 区域解锁 Gate

| Gate 类型 | 机制 | 示例 |
|---------|------|------|
| **资源 Gate** | 持有 X 资源 | Tower Wizard 升塔 3→4：`{ magic: 350000, wood: 20000 }` |
| **成就 Gate** | 破某墙 / 解锁某成就 | Tower Wizard 升塔 7→8：需破云墙 |
| **零成本 Gate** | 仅需条件 | Tower Wizard 升塔 9→10：需 `broken_wall_level == 2` |
| **复合 Gate** | 多条件 AND | 资源 + 成就 + 前置区域 |

详见 [o01-chapter-gates.md](o01-chapter-gates.md) — O11 是 O1 的多区域版扩展。

---

## 跨区域乘区链

```text
final_output(region, resource):
    local_chain = compute_local(region, resource)        # 区域内部乘法链
    global_chain = compute_global_bonuses(resource)      # 跨区域乘区
    return local_chain × global_chain
```

**关键**：区域**不能**覆盖全局乘区。所有跨区域乘区走 `compute_global_bonuses`。

---

## 监督 / 区域焦点（Region Supervision）

部分游戏（如 Tower Wizard）支持"点击某区域后短时内该区域加速"：

```text
on_region_clicked(region):
    supervision[region] = 0.2s         # 持续时间
    supervision_multiplier[region] = 1 + p/100 × Supervision等级
```

详见 [o06-area-focus.md](o06-area-focus.md) — O11 让 O6 变成"区域维度"。

---

## 反模式

| 反模式 | 后果 |
|--------|------|
| 区域独自引用其他区域的资源 | 失去 DAG 独立性 |
| 区域内部乘区硬绑到全局乘区 | 调参困难、互相影响 |
| 区域数过多（>10 活跃） | 玩家只玩 1-2 个，其他荒废 |
| 区域解锁无成本 / 无门槛 | 失去节奏感 |
| 跨区域乘区没有分类（混在一起） | 玩家不知道哪个乘区来自哪 |
| 区域 UI 无独立面板 | 玩家认知负担爆炸 |

---

## 适用场景

- 战斗增量（多个 boss 战区 / 副本）
- 资源增量（多个矿脉 / 生态区）
- 模拟经营（多个城市 / 工厂）
- 塔防 / 卡片 / 棋盘（多个战场 / 牌组）

---

## 配套

- **依赖**：[o01-chapter-gates.md](o01-chapter-gates.md)（章节 Gate 是 O11 的简化版）
- **集成**：[o06-area-focus.md](o06-area-focus.md)（区域焦点是 O11 的细粒度加速）
- **数据**：[schemas/multi-region.schema.json](../schemas/multi-region.schema.json)
- **示例**：[examples/configs/example-multi-region.json](../examples/configs/example-multi-region.json)
- **伪代码**：[examples/pseudocode/region-manager.md](../examples/pseudocode/region-manager.md)
- **案例**：[Tower Wizard 12 区域](../cases/tower-wizard/README.md) — O11 完整版

---

## 与其他 O 的关系

| Optional | 关系 |
|---------|------|
| [o01-chapter-gates.md](o01-chapter-gates.md) | O11 是 O1 的多区域扩展 |
| [o06-area-focus.md](o06-area-focus.md) | O11 让 O6 区域化 |
| [o08-support-systems.md](o08-support-systems.md) | O11 的跨区域乘区常来自 O8（训练 / 派系 / 遗物） |
| [o10-pacing-milestones.md](o10-pacing-milestones.md) | O11 的"区域数 = 节奏旋钮"对应 O10 的 Phase 3 |

---

## 数据 Schema（速览）

```json
{
  "regions": [
    {
      "id": "study",
      "name": "Study",
      "unlock_gate": { "tower_level": 2 },
      "primary_resource": "knowledge",
      "production_lines": ["summon_spirit_tome"],
      "totem_type": "knowledge"
    },
    {
      "id": "forest",
      "name": "Forest",
      "unlock_gate": { "tower_level": 3 },
      "primary_resource": "wood",
      "production_lines": ["summon_druid"],
      "totem_type": "forest"
    }
  ]
}
```

完整定义见 [schemas/multi-region.schema.json](../schemas/multi-region.schema.json)。