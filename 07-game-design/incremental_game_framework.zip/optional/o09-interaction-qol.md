# O9 · 交互与 QoL

不改变 Core 数值；UX 与调试。

## 长按连发（T1）

```text
if hold_time > threshold:
    repeat every max(min_interval, f(hold_duration, user_setting))
```

`min_interval` 下限防刷；见 [../core/03-production-lines.md](../core/03-production-lines.md) T1。

## Flat 加速（可选）

```text
effective_speed = base + flat_bonus(current_stage)
```

高层级可递减 flat，避免主动碾压 T2。

## O6 焦点 UI

提示当前加成区域；数值见 [o06-area-focus.md](o06-area-focus.md)。

## Tooltip

```text
"*":  value × level
"^%": ((1+value/100)^level - 1) × 100
```

## 等级跳跃提示

为 [Pattern T 等级跳跃](../patterns/pattern-t-tier-jump.md) 提供 UX 提示：

### 显示规则

```text
# 例：等级表 [1..8 + 10]，第 9 级不存在
display_level(current, max):
    if current >= 9:
        return f"{current} / {max} ★"      # 顶级加星标
    if max == 10 and current == 8:
        return "8 → 10（跳级）"             # 提示跳级
    return f"{current} / {max}"
```

### UX 决策

- **跳级前提示**：升级到等级 9 时弹确认框（"即将跳到 10 级，单价 X 倍，确认？"）
- **进度条缺口**：可视化第 9 级为空白段（玩家清晰看到"还有这一步"）
- **跳级奖励高亮**：第 10 级单独动画 / 颜色 / 音效

### 反模式

- 跳级无视觉差异 → 玩家不知道自己已经到顶
- 跳级 UI 与普通升级混淆 → 玩家误以为是普通升级

### 适用场景

- 任何使用 [Pattern T](../patterns/pattern-t-tier-jump.md) 的核心成长轴
- 战斗中需要"立即判断是否要花大价钱"的决策点

**案例参考**（应用模式）：Shelldiver 中 16 个核心技能的跳 10 设计应配独立 UI 高亮。

---

## 其他

浮点 epsilon 判 cap · K/M/B 格式化 · 重链缓存 · O2/Reset ETA · 内测控制台
