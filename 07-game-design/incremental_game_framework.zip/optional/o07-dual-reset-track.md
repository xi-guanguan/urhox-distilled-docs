# O7 · 双轨 Reset

第二条 XP 轨；常配合 O3。产发轨见 [../core/05-reset-systems.md](../core/05-reset-systems.md) Core。

## 双轨

| 轨 | XP 来源 | 点数 |
|----|---------|------|
| 产发 | Core | → `run_points` |
| 挑战 | O3 伤害 / 击杀 | → 同一 `run_points` |

挑战轨使用相同 `gain_xp` / cap 模式（Cap-1/2/3），状态字段如 `challenge_meta_level` 独立存储。

## 防刷（可选 Pattern）

```text
total_points_earned = 累计已获得永久点（含未分配）

if total_points_earned <= meta_level + challenge_meta_level:
    stop challenge track XP
```

实现前在项目数值文档定义 `total_points_earned`。
