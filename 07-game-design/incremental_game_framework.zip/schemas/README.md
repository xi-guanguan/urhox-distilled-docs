# Schemas 索引

> 当前框架提供的 JSON Schema。每个项目按需在 data/*.json 顶部声明 `$schema`。

<!-- AUTO-GENERATED START -->

| Schema | 用途 | 对应框架 |
|--------|------|---------|
| [biome.schema.json](biome.schema.json) | 生物群落 — 每个群落有独立采集点、配方、环境事件、订单（O11 扩展形态；尚无独立落地 case）。 | [optional/o11](../optional/o11-multi-region.md) |
| [constants.schema.json](constants.schema.json) | 框架常量定义（cap 阶梯 / tier 表 / gate 成本等） | [core/05](../core/05-reset-systems.md) |
| [cross-building-inspiration.schema.json](cross-building-inspiration.schema.json) | 跨建筑 Inspiration 链 — 源建筑达成条件后,目标建筑的单位获得永久被动 / 事件增益。对应 patterns/pattern-c-cross-building-inspiration.md。顶层为包装对象，inspirations 数组内每项为单条 inspiration。 | [patterns/pattern-c-cross-building-inspiration](../patterns/pattern-c-cross-building-inspiration.md) |
| [multi-region.schema.json](multi-region.schema.json) | 多区域子系统配置 — 当产线数超过 ~10 条时按区域分组管理。 | [optional/o11](../optional/o11-multi-region.md) |
| [permanent-upgrade.schema.json](permanent-upgrade.schema.json) | 永久升级数据定义（覆盖线性/复合/Grant/Pattern C） | [core/06](../core/06-permanent-upgrades.md) |
| [rarity.schema.json](rarity.schema.json) | 稀有度数据定义（对应 Pattern R 概率叠加） | [patterns/pattern-r](../patterns/pattern-r-rarity.md) |
| [status-effect.schema.json](status-effect.schema.json) | 战斗 / 资源 / 终局的细粒度状态效果 stack 定义 — 取代按 buff 种类硬编码。顶层为包装对象，effects 数组内每项为单个状态效果。 | [patterns/pattern-e](../patterns/pattern-e-status-stack.md) |
| [upgrade.schema.json](upgrade.schema.json) | 升级数据定义（覆盖 C1-C6 成本曲线 + Pattern S/T/B） | [core/04](../core/04-upgrade-economy.md) + [patterns/](../patterns/) |

<!-- AUTO-GENERATED END -->

## 选择建议

- 单线产线 ≤ 5 条 → 用 [upgrade.schema.json](./upgrade.schema.json)
- 概率/稀有度分层 → 叠 [rarity.schema.json](./rarity.schema.json)
- 多产线分组（地理 / 派系） → 用 [multi-region.schema.json](./multi-region.schema.json)
- 群落有**环境事件 / 昼夜节律**等动态机制 → 用 [biome.schema.json](./biome.schema.json)（O11 的扩展）