﻿# 贡献指南

> 如何向本框架新增 Pattern / Case / Example。

> **跑完 case 后, 哪些内容值得反向沉淀到 framework?** 见 [docs/case-to-framework-contribute.md](docs/case-to-framework-contribute.md) — 6 阶段标准化流程 (完成度自检 → 差异分析 → 候选清单 → 决策矩阵 → 执行沉淀 → CI 接入). UI 完成标准见该文档 [附录 C](docs/case-to-framework-contribute.md#12-附录-c-游戏界面ui完成标准)（结构可复原：区域几何 + 组件清单）。

---

## 目录结构

```
core/        # 框架核心抽象（5 篇）
patterns/    # 实战模式（5 个 Pattern）
optional/    # Optional 模块（10 个）
cases/       # 应用案例
examples/    # 落地示例
schemas/     # JSON Schema
```

---

## 新增 Pattern

1. 在 `patterns/` 创建 `pattern-X-name.md`
2. 命名约定：`pattern-{letter}-{name}.md`，其中 `{letter}` 是模式含义首字母
3. 文件结构：

```markdown
# Pattern X · 模式名

> **代号**：X
> **来源**：[具体游戏案例](../cases/<your-case>.md)         <!-- 占位符：替换为真实案例文件，如 ../cases/shelldiver/README.md -->
> **首次出现**：[core/NN 章节](../core/<NN>-<topic>.md#章节)   <!-- 占位符：替换为真实 core 文档，如 ../core/04-upgrade-economy.md -->

实战沉淀：<一句话说明>

## 公式

<核心公式>

## 关键参数

| 参数 | 含义 | 典型范围 |
|------|------|---------|

## 反模式

- ...

## 适用场景

- ...

## 配套

- **依赖**：<哪些 Core / Optional / Pattern>
- **案例**：<哪个 games>
- **Schema**：<相关 schema.json>

## 数据 Schema

\`\`\`json
<示例 schema>
\`\`\`
```

4. 在 `patterns/README.md` 索引表追加
5. 在引用此 Pattern 的 Core / Optional 文档末尾追加"相关实战模式"段
6. 在 `CHANGELOG.md` 记录新增

---

## 新增 Case

> ⚠️ **本节是给 framework 维护者向本仓库贡献 case 用的，不是策划写新游戏用的**。
>
> 策划写新游戏请让 AI 按 [GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) 引导（先选一键托管 / 方案体检 / 逐步问答，再走 M0–M8）；策划案放到自己项目的 `my-game/docs/`，**不要**放进本仓库 `cases/`。中途修改走 `mid-game-balance-fix`。
>
> 下列流程要求**真实可查的数据源**（游戏的逆向数据 / 官方 API / 源代码）——策划的设计草案不满足这个前提。

1. 在 `cases/` 创建 `your-game.md`
2. 文件结构参考 [cases/shelldiver/README.md](cases/shelldiver/README.md)
3. 必含段：
   - 元数据（App ID、引擎、题材、规模）
   - 框架 → 游戏映射表
   - 游戏模块 → 框架映射表
   - 节奏表（若有）
   - 复用建议
   - 数据规模统计
   - 引用
4. 在 `cases/README.md` 索引表追加
5. 在 `CHANGELOG.md` 记录新增

---

## 新增 Example

### 伪代码

1. 在 `examples/pseudocode/` 创建 `function-name.md`
2. 提供 Python + TypeScript 双风格
3. 必含段：
   - 对应框架文档链接
   - 函数签名 + 完整实现
   - 反模式
4. 在 `examples/README.md` 索引表追加

### 配置示例

1. 在 `examples/configs/` 创建 `example-{name}.json`
2. 必须有 `$schema` 引用对应的 `schemas/*.schema.json`
3. 用 ajv / jsonschema 验证通过
4. 在 `examples/README.md` 索引表追加

---

## 新增 / 修改 Schema

1. 修改 `schemas/*.schema.json`
2. **破坏性变更**必须：
   - 升 `$id` 中的版本号
   - 在 `CHANGELOG.md` 标注 `BREAKING`
3. 用 ajv / jsonschema 验证所有 `examples/configs/*.json` 仍然有效

---

## 修改 Core / Optional 文档

### 应保持的约定

- 文件名 `YY-name.md`（Core）或 `oNN-name.md`（Optional）
- 必含"公式"、"反模式"、"相关实战模式"三段
- 引用使用相对路径（不写绝对 URL）
- 所有数据 / 数值用 JSON 配置引用，**不写死在 .md**

### 修改流程

1. 确认修改必要（不要"为改而改"）
2. 在 `CHANGELOG.md` 记录
3. 跨文档引用要更新所有指向此文档的链接

---

## 修改 / 新增 Pattern 时的冲突矩阵更新

[patterns/conflicts.md](patterns/conflicts.md) 是 18×18 Pattern/Optional 冲突矩阵（18 条冲突详档），任何 Pattern 改动必须同步检查：

### 新增 Pattern

1. 在 [patterns/README.md](patterns/README.md) 索引表追加（按代号字母序）
2. 在 [patterns/conflicts.md](patterns/conflicts.md) 矩阵添加新行/列
3. 对每个非 ✅ 的格子写冲突详档（现象 / 真实出处 / 解决策略 / 反模式）
4. 在 case 实证列写明"实证"或"理论冲突"
5. 在 `CHANGELOG.md` 记录新增 Pattern

### 修改 Pattern

1. 重新检查与之冲突的 Pattern 格子是否还准确
2. 同步修改对应冲突详档
3. 在 `CHANGELOG.md` 记录改动

### 新增 Optional

同上流程：冲突矩阵与详档统一维护在 [patterns/conflicts.md](patterns/conflicts.md)（含 Pattern × Optional 格子；不另建 `optional/conflicts.md`）。

---

## 反模式（贡献时）

| 反模式 | 后果 |
|--------|------|
| Pattern 写死具体题材数值 | 失去通用性 |
| Case 只列映射，不指明 Pattern | 模式沉淀不完整 |
| Schema 不用 `allOf` 业务约束 | 不验证联动 |
| 跨文档引用用绝对路径 | 项目搬迁失效 |
| 不更新 CHANGELOG | 无法追溯变更 |