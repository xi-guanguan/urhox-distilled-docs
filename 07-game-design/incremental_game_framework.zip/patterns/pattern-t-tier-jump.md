﻿# Pattern T · 等级跳跃（Tier Jump）

> **代号**：T  
> **来源**：[Shelldiver 16 个核心技能跳 8→10（tiers=[1..8,10]）](../cases/shelldiver/README.md)  
> **首次出现**：[06-permanent-upgrades.md](../core/06-permanent-upgrades.md) 的 Pattern C 之后

战斗/资源型增量的实战沉淀：**长成长轴** 在最高几级之间故意留一档空白（"跳级"），把最后一级单独做贵，让顶级成长成为 Prestige 级的努力目标。跳点视游戏节奏而定——Shelldiver 跳 8→10（跳过 9），Gnorp 跳 9→10。

---

## 应用场景

- 核心 DPS 轴（damage、fire_rate、reload）
- 核心经济轴（sell_speed、output_speed）
- 核心容量轴（tank、slot、max）
- 资源累计轴（frequency、value）

---

## 公式

```text
# 等级表：1..8 + 10（无 9）
levels = [1, 2, 3, 4, 5, 6, 7, 8, 10]

cost_for(level):
    if level == 10:
        return cost_for(9) × jump_multiplier     # 通常 5x ~ 20x
    return curve(level)                          # C2 / C4 标准曲线
```

---

## 关键参数

| 参数 | 含义 | 典型范围 |
|------|------|---------|
| `jump_multiplier` | 第 10 级相对第 8 级成本倍率 | 5x ~ 20x |
| `value_jump` | 第 10 级相对第 8 级数值倍率 | 2x ~ 5x（应高于成本倍率，否则玩家跳过） |
| 是否单局可获 | 是 = 鼓励反复单区刷；否 = 必须靠 Reset/Meta 解锁 | 项目自定 |

---

## 为什么这样设计

- 9 级与 10 级差距 = 数值质变点，让顶级玩家感知"我离顶还有一步"
- 第 10 级单独昂贵 → 自然形成"是否现在买"的决策点
- 多个核心轴同时跳 10 → 让"全 10"成为长线终极目标

---

## 反模式

- 跳 10 太便宜 → 玩家全满级无目标
- 跳 10 太贵 → 玩家看不到进度放弃
- 跳 10 但数值倍率与成本倍率倒挂 → 跳过 10 直接点 8

---

## UX 配套

见 [o09-interaction-qol.md § 等级跳跃提示](../optional/o09-interaction-qol.md#等级跳跃提示pattern-t-配套)：
- 跳级前确认框
- 进度条第 9 级空白段
- 跳 10 单独动画 / 颜色 / 音效

---

## 案例参考（应用模式，非项目默认值）

- Shelldiver 中 `bubble_damage` / `plasma_damage` / `store_speed` / `oxygen_tank` / `movement_speed` 等 ~16 个核心技能都使用 1..8 + 10 跳级（即跳 8→10，跳过 9）
- Gnorp 的核心轴（Runner Speed 3 px/s cap、Combo Chance 80% cap）跳 9→10
- 跳级技能同时承担 `biovalue_amount` 类 meta 永久项角色

---

## 配套

- **所属**：[Pattern S 成长轴分档](pattern-s-skill-tiers.md) 第 1 档（核心成长轴）
- **依赖**：[06-permanent-upgrades.md](../core/06-permanent-upgrades.md)（永久商店）
- **UX**：[o09-interaction-qol.md](../optional/o09-interaction-qol.md)（等级跳跃提示）

---

## 数据 Schema

```json
{
  "skill": "bubble_damage",
  "tiers": [1, 2, 3, 4, 5, 6, 7, 8, 10],
  "max_tier": 10,
  "jump_multiplier": 10.0,
  "value_jump": 3.0,
  "skill_type": "core"
}
```

完整定义见 [schemas/upgrade.schema.json](../schemas/upgrade.schema.json)。