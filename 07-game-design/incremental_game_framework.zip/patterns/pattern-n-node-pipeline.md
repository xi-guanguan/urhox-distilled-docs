﻿# Pattern N · 节点流水线图（Node Pipeline Graph）

> **代号**：N
> **来源**：[cases/upload-labs/README.md § 4](../cases/upload-labs/README.md) — 103 个 window 共享 1 个 6-type transfer engine（`scenes/resource_container.gd:84-161`）
> **首次出现**：原框架 Optional O11（多 region 子系统）处理"跨 region"，N 处理"region 内的 node graph"

实战沉淀：当玩家 build 是 *空间摆放*（X 放 Y 旁边）且表达是 *图拓扑*（A→B, A→C, B→D）时，把所有 node 抽象为"window + output port + input port"，让一个 6-type transfer engine 接管所有资源流转，引擎不需要知道 node 是什么。玩家摆放就是 build，连接就是配线。

---

## 与 Optional O11 + Pattern T 的差异

| 维度 | O11（多 region 子系统） | Pattern T（tier jump） | **Pattern N（node graph）** |
|------|------------------------|----------------------|---------------------------|
| 玩家表达 | 跨 region 切换 | 升级 tier 触发放大 | **摆节点 + 连线** |
| Build 单位 | region（一个完整面板） | tier 等级 | **单个 node（window）** |
| 资源流 | 每个 region 独立 | 同 region 内 flow | **node 间通过 connector 流转** |
| 引擎依赖 | 每个 region 自己的 system | tier transition 钩子 | **单一 transfer engine** |
| 视觉表达 | 多个 tab / 页面 | tier badge / 颜色 | **节点图 + 连接线** |

## 6-Type Transfer Engine

```gdscript
# scenes/resource_container.gd:84-161
func transfer():
    match self.type:
        0:  # MATERIAL
            for output in outputs:
                output.count += floor(count / N) + (rand() < frac ? 1 : 0)
        1:  # FLOW (bandwidth-style)
            for output in outputs:
                var sent = min(output.limit - output.count, count / N)
                output.count += sent
                count -= sent
        2:  # BOOST (pure divisor)
            for output in outputs:
                output.count += count / N
        3:  # MATERIAL_LIMITED
            for output in outputs:
                output.count += min(floor(count / N), output.limit - output.count)
        4:  # SETTING (broadcast)
            for output in outputs:
                output.count = count
        5:  # FLUID (bounded push)
            for output in outputs:
                output.count += min(count, output.limit - output.count)
```

| type | name | 行为 | 用途 |
|------|------|------|------|
| 0 | `MATERIAL` | 整数分裂，`floor(count)/N` per output，`pick_random()` 处理余数 | 文件资源、hack_points |
| 1 | `FLOW` | 带宽式：填到 `limit` 再分剩余 | download_speed、clock_speed、ai |
| 2 | `BOOST` | `count/N` 纯除数 | bandwidth_multiplier、overclock |
| 3 | `MATERIAL_LIMITED` | type 0 + 受 receiver `limit` 约束 | storage（per-file bucket） |
| 4 | `SETTING` | 纯广播 | overclock（setting 资源） |
| 5 | `FLUID` | 受限推送 | heat dissipation |

## 节点结构

```json
{ "name": "window_processor", "scene": "window_processor", "category": "cpu",
  "level": 0, "requirement": "upgrade.processor", "hidden": false,
  "attributes": { "limit": -1, "minimum_cores": 1, "maximum_cores": 99 },
  "data": {}, "guide": "window_processor" }
```

| 字段 | 含义 |
|------|------|
| `scene` | 引擎实例化的 Godot scene 路径 |
| `requirement` | 调色板显示门槛（`upgrade.X` / `research.X` / `perk.X`） |
| `attributes.limit` | `-1` 无限 / `1` 唯一（如 `data_lab`、`agi`）/ `0` 默认不可用 |
| `data` | 持久化状态（如 `breach_*` 存 `{level, max_level}`） |
| `group` | service 退款时的分组键 |

## Connector 信号

```gdscript
# scripts/signals.gd:7-13
signal connection_set()
signal create_connection(output: String, input: String)
signal delete_connection(output: String, input: String)
signal connection_created(output: String, input: String)
signal connection_deleted(output: String, input: String)
```

- 玩家点 `OUTPUT` 按钮 → `Globals.connecting = id`。
- 玩家拖到 `INPUT` 按钮释放 → `connection_droppped` → `create_connection` → 下游 `ResourceContainer.set_input()` 被调用。
- `scripts/connectors.gd:25-32` 监听 `connection_created` 并 spawn `Connector` scene 画线。

## 关键设计规则

### 1. Engine 不认识 node，只认识 type

错误做法：engine 知道"processor 输出 clock，verifier 接收 clock"。

正确做法：engine 只看 `ResourceContainer.type`，对所有 node 统一应用 6 种 transfer 规则。任何 type 匹配的 input slot 都可以接收 — 玩家自由组合 node。

### 2. Tick rate 是全局的

```gdscript
# scenes/windows/window_base.gd:83-86
func _on_tick() -> void :
    if !paused:
        process(0.05 * Attributes.get_attribute("time_multiplier") * Attributes.get_attribute("offline_time_multiplier"))
```

一个 `Signals.tick` 每 0.05s（20 Hz）触发所有 window。每个 window 独立读 input、推进状态、写 output。**engine 不需要 per-node 的 tick 调度**。

### 3. 视觉 shape 来自 type

`data/resources.json: connection: "circle" / "octagon" / "pentagon" / "triangle"` 是 connector 线的视觉形状。`color` 来自 `data/connectors.json` 的 11 个 key（white / black / lime / cyan / orange / red / yellow / violet / green / blue / pink）。

### 4. limit 三态

- `-1` = 无限（大多数 `cpu` / `network` / `gpu` window）
- `1` = 唯一（`data_lab`、`agi`、`coder`、`hacker`、`drain`）
- `0` = 默认不可用，需 perk 解锁（部分 `coding` window）

## 反模式

| 反模式 | 后果 |
|--------|------|
| Engine 知道 node 身份 | 每加一个 node 改 engine；不可扩展 |
| Per-node tick 调度 | tick 频率不均；调试难 |
| Custom transfer 规则 per node | engine 代码爆炸；6-type 体系崩溃 |
| type 字段硬编码到 engine | 不能用同一 input slot 接不同 type |
| Connector 不分 visual shape | 玩家看不到资源类型流动 |

## 适用场景

- 玩家 build 是空间摆放 + 配线（不是 tab 切换、不是参数调节）
- 资源在 node 间流动（不是单一 pool 累积）
- Node 数量 N ≥ 10（少于这个数 tab 化更简单）
- 玩家表达是图拓扑（多对多 wiring），不是线性（chain）

## 不适用场景

- 单一 pool 累积（Kittens Game 风格）— 复杂 node graph 过度设计
- 线性 chain（A→B→C）— tab 化更简单
- 参数调节（speed / capacity slider）— 弹窗更简单

## 配套

- **基础**：[optional/o11-multi-region.md](../optional/o11-multi-region.md) — 跨 region 切换
- **相关**：[patterns/pattern-t-tier-jump.md](pattern-t-tier-jump.md) — tier transition 触发放大
- **案例**：[Upload Labs § 4 节点流水线](../cases/upload-labs/README.md)
- **数据**：[cases/upload-labs/windows.json](../cases/upload-labs/windows.json)（103 个 window）+ [windows_by_category.json](../cases/upload-labs/derived/windows_by_category.json)
- **代码**：`scenes/resource_container.gd:84-161` 的 6-type transfer engine
