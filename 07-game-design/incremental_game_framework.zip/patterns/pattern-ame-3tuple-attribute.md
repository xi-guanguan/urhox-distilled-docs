﻿# Pattern AME · Additive-Multiplicative-Exponential 三元组属性

> **代号**：AME
> **来源**：[cases/upload-labs/README.md § 3](../cases/upload-labs/README.md) — `scripts/attribute.gd` 15 行实现 + `scripts/attributes.gd` 95 行 dispatcher
> **首次出现**：原框架 Pattern E 允许每个系统自定义 schema，AME 把"所有 system 共享一个 3-tuple schema"作为统一规范

实战沉淀：当游戏的 N 个 progression table（upgrades / research / perks / milestones / boosts / windows）需要共享同一个聚合引擎时，强制所有效果用 `[a, m, e]` 三元组表达，可以用一个 ~15 行的类统一所有加 buff / 减 debuff / 倍率 / 指数效果。负数 `a` 自然成为折扣，无需专门字段。

---

## 与 Pattern E 的差异

| 维度 | Pattern E（per-system schema） | **Pattern AME（统一 3-tuple）** |
|------|-------------------------------|--------------------------------|
| 效果 schema | 每个 system 自己的字段集 | **统一 `[a, m, e]` 三元组** |
| 引擎代码 | N 个 dispatcher | **1 个类 + 1 个 dispatcher** |
| 折扣表达 | 专门 `discount` 字段 | **负数 `a`**（`[-0.05, 0, 0]`） |
| 指数表达 | 专门 `exponent` 字段 | **`e > 0` 触发 `pow(e, e_count)`** |
| 引擎依赖 | 每个 system 各自的聚合代码 | **单一 `Attribute.add()` 方法** |
| 新增 system 成本 | 写 N 行新 dispatcher | **写 1 个 JSON 表 + 1 行 dispatcher** |

## 三元组语义

| 轴 | 符号 | 操作 | 例子 |
|----|------|------|------|
| additive | `a` | 加到 `raw` | `+0.2` bandwidth per level |
| multiplicative | `m` | 加到 `multiplier`（影响未来的 `a`） | `+0.1`（按当前 `multiplier` 缩放） |
| exponential | `e` | `pow(e, e_count)` 应用于 `raw` 和 `exponent` | `×1.2` per level（跨 level 复合） |

`e_count` 是该 tuple 被应用时的 **level**。所以 `add([0, 0, 1.2], level=3)` 等于 `pow(1.2, 3) = 1.728×` `raw`。这意味着同一段 JSON 可以在任何 level 应用，无需 JSON 知道 level 是几。

## 参考实现（Godot / GDScript，15 行）

```gdscript
class_name Attribute
extends RefCounted

var multiplier: float = 1
var exponent: float = 1
var raw: float = 0

func add(a: float, m: float, e: float = 0, e_count: float = 0) -> void :
    raw += a * (1.0 + (m / multiplier)) * multiplier * exponent
    multiplier += m
    if e > 0:
        var exp: float = pow(e, e_count)
        raw *= exp
        exponent *= exp
    changed.emit()
```

**关键不变量**：`add()` 是 **idempotent**（顺序无关），且 **sign-symmetric**（负 `a` 是折扣）。`add([0, 0, 2])` 与 `add([0, 0, 1.5])` 合成 `×3.0`，无论谁先调用。

## 统一 dispatcher（5 个 entry point）

```gdscript
# scripts/attributes.gd:42-91
func apply_attribute_dict(attrs: Dictionary, e_count: float = 1) -> void :
    for attr_name in attrs.keys():
        var tuple: Array = attrs[attr_name]   # [a, m, e]
        if tuple.size() >= 3:
            Attributes.get_attribute(attr_name).add(tuple[0], tuple[1], tuple[2], e_count)

func apply_windows_attribute_dict(attrs: Dictionary, e_count: float) -> void :
    # 用于 boost 的窗口属性（带自动移除监听）
    ...
```

5 个 entry point 对应 5 个 JSON 表：

| entry point | JSON 表 | `e_count` 含义 |
|-------------|---------|----------------|
| `apply_attribute_dict` | `Data.upgrades` | level（购买次数） |
| `apply_attribute_dict` | `Data.research` | 1（单次） |
| `apply_attribute_dict` | `Data.perks` | level |
| `apply_attribute_dict` | `Data.milestones` | level |
| `apply_windows_attribute_dict` | `Data.boosts` | 1（带 `Signals.boost_removed` 监听） |

## 关键设计规则

### 1. JSON 表达式必须统一

错误做法：upgrades 用 `{bandwidth: 0.2}`，perks 用 `{bandwidth_pct: 20}`，milestones 用 `{bandwidth_exp: 1.2}`。

正确做法：所有表都写 `{bandwidth_multiplier: [0.2, 0, 0]}` 或 `{bandwidth_multiplier: [0, 0, 1.2]}`。引擎读到 3-tuple 后只问"哪个轴非零"。

### 2. 折扣用负数 `a` 表达

```json
"breach_price_multiplier": [-0.05, 0, 0]   // 5% 折扣 per level
"cheapskate":              [-0.05, 0, 0]   // 5% 折扣 per level
```

不需要 `discount` 字段。`add([a, m, e], -level)` 即可撤掉该 level（service 退款用例）。

### 3. 单一 `e_count` 参数

`tower_wizard` 风格的 "level-by-level apply" 与 "一次性 apply" 都要统一到 `e_count` 参数。`e_count=0` 时 `pow(e, 0) = 1`，相当于无指数；`e_count=1` 是单次；`e_count=N` 是 N 次复合。

### 4. 指数只用于"乘性复合"场景

`pow(e, e_count)` 适合"每 level ×1.2"这种**几何级数**；线性加 buff 用 `a`；动态变化用 `m`。`e` 不应用于一次性的 `+0.2` buff（那用 `a`）。

## 反模式

| 反模式 | 后果 |
|--------|------|
| 多个 schema 混用 | dispatcher 代码爆炸；新 system 必须先适配 schema |
| 折扣用专门 `discount` 字段 | 必须写 `if discount: raw *= (1 - discount)`；负数 `a` 不允许 |
| 指数直接用 `*=` | 顺序敏感；`A *= 1.2; B *= 1.5` 与 `B *= 1.5; A *= 1.2` 结果不同 |
| `e_count` 写在 JSON 里 | JSON 不知道调用时 level 是几；level 必须由 dispatcher 注入 |
| `add()` 不幂等 | 玩家读档后 effect 双倍叠加 |

## 适用场景

- 游戏的 progression table 数量 ≥ 3，且希望共享一个聚合引擎
- 折扣、加 buff、乘 buff、指数 buff 都需要支持
- 引擎代码行数预算紧（如 7DRL、增量游戏模组）
- 读档后 effect 必须幂等（顺序无关）

## 配套

- **基础**：[patterns/pattern-e-status-stack.md](pattern-e-status-stack.md) — per-system schema 版本
- **同源**：[optional/o05-bottleneck-balance.md](../optional/o05-bottleneck-balance.md) — 折扣用负数 `a` 的具体应用
- **案例**：[Upload Labs § 3 三元组属性](../cases/upload-labs/README.md)
- **数据**：[cases/upload-labs/attributes.json](../cases/upload-labs/attributes.json)（57 个 attribute）
- **代码**：[cases/upload-labs/source_code.json](../cases/upload-labs/source_code.json) 中的 `attribute_add` 公式
