﻿# Pattern P2 · 双 Prestige 货币（Dual Prestige Currency）

> **代号**：P2
> **来源**：[cases/kittens-game/README.md § 8](../cases/kittens-game/README.md) — `paragon`（单局）+ `burnedParagon`（跨局）双轨
> **首次出现**：原框架 Pattern P + O7 只有**单 currency 双源**，KG 证明**双 currency 双 cap** 也可行

实战沉淀：当 prestige 的"短期购买"和"长期购买"需要的**决策节奏不同时**，单一 prestige 货币会让玩家在"立即消费"和"长期投资"之间反复权衡。拆成两个独立 currency、两个独立 cap、两个独立公式，让两条轨各自演进。

---

## 与 Pattern P + O7 的差异

| 维度 | Pattern P（单 currency） | O7（单 currency 双源） | **Pattern P2（双 currency）** |
|------|--------------------------|----------------------|-------------------------------|
| 货币数 | 1 | 1 | **2** |
| XP/资源来源 | 单 run 累积 | 双轨（产发 / 挑战） | 每种 currency **各自**有来源 |
| 持久性 | 跨 run（永久） | 跨 run | currency 1 = 单局 / currency 2 = 跨局 |
| 公式 | 单一 cap | 单一 cap | **两个独立 cap + 两个独立公式** |
| 转换 | 无 | 无 | 关键：currency 1 → currency 2 转换（可选） |

## 设计形态（KG 实证）

```text
# 两种 currency
paragon             # 单局（run-level）—— 重置时部分清零
burnedParagon       # 跨局（account-level）—— 持久保留

# 各自的公式
getParagonProductionRatio():
    productionRatioParagon = min(paragon.value * 0.01 * paragonRatio,
                                 2 * paragonRatio)
    productionRatioBurnedParagon = min(burnedParagon.value * 0.01 * paragonRatio,
                                       dark_future ? 4 : 1 * paragonRatio)
    return productionRatioParagon + productionRatioBurnedParagon

getParagonStorageRatio():
    return paragon.value / 1000 * paragonRatio
         + (dark_future ? burnedParagon.value / 500
                        : burnedParagon.value / 2000) * paragonRatio
```

两条公式**完全独立**：paragon 的 cap 是 2×、burnedParagon 的 cap 是 4×（dark future）；paragon 的 storage 是 /1000、burnedParagon 的 storage 是 /500 或 /2000。玩家必须分别优化两条线。

## 关键设计规则

### 1. 转换规则显式化

单 currency 系统中"重置时部分转化为永久"是隐式的；P2 系统中**两 currency 间的转换是显式可调的**：

```text
on_reset():
    paragon_to_burn = min(paragon.value, conversion_cap)
    burnedParagon.value += paragon_to_burn
    paragon.value = paragon.value - paragon_to_burn  # 或清零
```

`conversion_cap` 通常是**公式**而非常数（KG：`paragon * 0.05 + burnedParagon * 0.1 + cycleYear * 0.1`），给玩家**一个早期投资更划算、晚期投资贬值**的曲线。

### 2. 各自的 cap 必须独立

错误做法：让 `burnedParagon` 共享 `paragon` 的 cap → 玩家用 paragon 直接刷 burnedParagon 失去两条线意义。

正确做法：每种 currency **有自己的 cap 公式**（如 KG 的 `getLimitedDR(paragon.value * 0.01, 2)` vs `min(burnedParagon.value * 0.01, 4 * paragonRatio)`）。

### 3. 永久项分两组

每种 currency 永久项**不要混在同一个商店**，否则玩家会用"短期 currency 买长期 currency 才能买的项"导致系统退化：

```text
paragon_shop:           # 短期、立即生效
    - "engeneering"  (1% price cut per level)
    - "goldenRatio"  (0.5% ratio boost per level)

burned_paragon_shop:    # 长期、永久
    - "transcendence" (5% all per-tick)
    - "nirvana"      (10% all effects)
```

### 4. dark-future 加速器（可选）

KG 的 burnedParagon 在 `darkFutureYears() >= 0` 时 production ratio ×4、storage ratio /500（vs /2000）—— 这是**临时加速器**让后期 game state 显著缩短暂 prestige 循环。

## 反模式

| 反模式 | 后果 |
|--------|------|
| 单一 currency + 单一 cap 假装双 currency | 玩家总是"立即花光"，长期投资不存在 |
| 转换 cap 写死为常数 | 没有节奏，玩游戏 N 局和 N+1 局体验完全一样 |
| 两种 currency 共用 cap | 短期 currency 刷爆 → 长期 currency 实际无法积累 |
| 永久项混在同商店 | 货币选择无意义，两条线合并退化为一条 |
| 不区分"短 / 长"决策节奏 | 玩家用短期 currency 买长期项 = 系统错配 |

## 适用场景

- prestige 决策节奏分裂为 "立即生效的微调" + "长线累加的解锁" 时
- 单 currency cap 不能同时满足"游戏内短规划"和"存档级长规划"时
- 需要 dark-future / late-game 状态做"软重置"或"加速 prestige 循环"时
- pattern 文档已经在 Pattern P 中提到 [core/05-reset-systems.md § Cap 模式](../core/05-reset-systems.md) 但未细化为双 currency

## 配套

- **基础**：[core/05-reset-systems.md](../core/05-reset-systems.md) — 单 currency Reset
- **相关**：[optional/o07-dual-reset-track.md](../optional/o07-dual-reset-track.md) — 单 currency 双源
- **跨轴**：[optional/o04-cross-axis-feedback.md](../optional/o04-cross-axis-feedback.md) — prestige 资源如何反哺产线
- **案例**：[Kittens Game § 8 paragon + burnedParagon](../cases/kittens-game/README.md)
- **数据**：[cases/kittens-game/prestige.json](../cases/kittens-game/prestige.json)（37 个 perk）
