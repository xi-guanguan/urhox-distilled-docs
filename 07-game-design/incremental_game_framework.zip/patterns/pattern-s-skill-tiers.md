﻿# Pattern S · 成长轴分档（Skill Tier Ladder）

> **代号**：S  
> **来源**：[Shelldiver 68 个技能的 3 档分级](../cases/shelldiver/README.md)  
> **首次出现**：[04-upgrade-economy.md](../core/04-upgrade-economy.md) 的 Sink 配对表

战斗/资源型增量实战沉淀：把升级按"成长负担"分成 3 档，避免所有技能都是 8 级，让玩家感受到"主线 vs 支线"。

---

## 3 档定义

| 档 | 等级数 | 典型曲线 | 用途 | 案例参考 |
|---|------|---------|------|---------|
| **核心成长轴** | 8 + 跳 10 | C2 指数 / C4 多项式 + [Pattern T](pattern-t-tier-jump.md) 跳跃 | DPS / 经济 / 容量等长线投入 | `bubble_damage`, `store_speed` |
| **次要技能** | 3 ~ 5 | C2 指数 | 强化、攻速、容量等支撑维度 | `bubble_reload`, `bubble_capacity` |
| **单点开关** | 1 ~ 2 | C3 一次性（[Pattern B](pattern-b-binary-unlock.md)） | 解锁即生效、机制类技能 | `bubble_smite`(2), `entity_arrival`(1) |

---

## 选取规则

```text
classify_upgrade(id):
    effect_per_level = average_value_gain / cost_at_level_1
    if effect_per_level > threshold_high:
        return "core"      # 8 级 + Pattern T 跳 10（如 Shelldiver tiers=[1..8,10]）
    if effect_per_level > threshold_low:
        return "secondary" # 3-5 级
    return "toggle"        # 1-2 级
```

---

## 设计原则

- **核心 ≤ 3 条**：玩家最多同时追 3 个核心轴（DPS / 经济 / 容量）
- **次要 5-10 条**：围绕每条核心轴配 2-3 条次要
- **开关无上限**：作为机制解锁，不占成长预算

---

## 反模式

- 所有技能 8 级 → 玩家决策疲劳
- 所有技能 1-2 级 → 玩家无长期目标
- 核心轴过多（>5）→ 货币分散，每条都点不满

---

## 案例参考（应用模式）

Shelldiver 的 68 个技能中约 16 个核心、约 35 个次要、约 17 个开关。

---

## 配套

- **依赖**：[04-upgrade-economy.md](../core/04-upgrade-economy.md)（C1–C6 成本曲线）
- **核心档必备**：[Pattern T 等级跳跃](pattern-t-tier-jump.md)（核心轴用 8+跳 10）
- **开关档独立**：[Pattern B 二进制开关](pattern-b-binary-unlock.md)