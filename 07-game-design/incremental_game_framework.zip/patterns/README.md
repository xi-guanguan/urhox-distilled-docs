﻿# 实战模式 Patterns

> 来自具体游戏沉淀的设计模式。沉淀后即视为通用，不依赖具体题材。

实战模式最初源自 [Shelldiver 案例](../cases/shelldiver/README.md) 的逆向分析。Pattern E（状态 Stack）从 [Tower Wizard 案例](../cases/tower-wizard/README.md) 的 5 种状态效果实证沉淀。Pattern P2（双 prestige 货币）、Pattern C7（自选永久 debuff）从 [Kittens Game 案例](../cases/kittens-game/README.md) 沉淀。Pattern AME（3-tuple 属性）、Pattern N（节点流水线图）、Pattern PR（Service 软重置）从 [Upload Labs 案例](../cases/upload-labs/README.md) 沉淀。Pattern C·跨建筑 Inspiration 链从 [Gnorp 案例](../cases/gnorp/README.md) 的 11 个 inspirations 沉淀，Pattern E 的"5 段式衰减时序"补充亦由 Gnorp 5 种 status effect 实证。Pattern E 同时覆盖战斗轴（DOT / 易伤）和经济轴（永久 effect-key 命名约定 + 单一聚合器）。任何增量游戏在设计战斗、资源、收集循环时都可参考。

---

## 命名约定

- **P 前缀** = Pattern（来自具体项目沉淀的模式），区别于成本曲线的 **C 前缀**（Cost Curve）
- **代号字母** = 模式含义首字母（R / D / S / B / T / E / P / C）
- 所有 Pattern 都给出"反模式"段，提示常见错误
- 所有 Pattern 都标注"案例参考（应用模式，非默认）"——避免被误读为项目默认值

---

## 模式索引

| 代号 | 名称 | 一句话定义 | 依赖 |
|------|------|----------|------|
| [R](pattern-r-rarity.md) | 概率叠加资源 | 多档稀有度 + 跨种类 meta 倍率（含非掉落型分档变体） | [02-resources](../core/02-resources.md) |
| [D](pattern-d-dual-pool.md) | 双资源池共享 | 1 个限制资源同时挂多链路放大器 | [03-production-lines](../core/03-production-lines.md) |
| [S](pattern-s-skill-tiers.md) | 成长轴分档 | 核心 8+跳 10 / 次要 3-5 / 开关 1-2 | [04-upgrade-economy](../core/04-upgrade-economy.md) |
| [B](pattern-b-binary-unlock.md) | 二进制开关 | 1-2 级机制解锁，无成长曲线 | [Pattern S](pattern-s-skill-tiers.md) |
| [T](pattern-t-tier-jump.md) | 等级跳跃 | 核心轴顶级质变点（跳点视节奏，如 8→10 / 9→10） | [06-permanent-upgrades](../core/06-permanent-upgrades.md) |
| [E](pattern-e-status-stack.md) | 状态效果 Stack | 战斗轴状态叠加（DOT / 易伤 / 缓速）+ 经济轴 6 键 effect-key 命名约定 | [o03-challenge-axis](../optional/o03-challenge-axis.md) |
| [P2](pattern-p2-dual-prestige.md) | 双 Prestige 货币 | 短期 + 长期两种 prestige currency，各自 cap / 公式 / 永久项（**Kittens Game 实证**） | [Pattern P](../core/05-reset-systems.md), [o07](../optional/o07-dual-reset-track.md) |
| [C7](pattern-c7-opt-in-debuff.md) | 自选永久 Debuff | 玩家主动 toggle 永久减益换 prestige 加速度（**Kittens Game 实证**） | [Pattern C](../core/06-permanent-upgrades.md), [o03](../optional/o03-challenge-axis.md) |
| [C·跨建筑](pattern-c-cross-building-inspiration.md) | 跨建筑 Inspiration 链 | 源建筑达成条件 → 目标建筑单位获永久被动/事件增益，互斥槽 + 可叠加链（**Gnorp 实证**） | [Pattern C](../core/06-permanent-upgrades.md), [o04](../optional/o04-cross-axis-feedback.md), [o08](../optional/o08-support-systems.md) |
| [AME](pattern-ame-3tuple-attribute.md) | 3-tuple 属性统一 | 全部 effect 用 `[a, m, e]` 三元组表达，单一 `Attribute.add()` 引擎（**Upload Labs 实证**） | [Pattern E](pattern-e-status-stack.md), [o05](../optional/o05-bottleneck-balance.md) |
| [N](pattern-n-node-pipeline.md) | 节点流水线图 | 玩家摆放 node + 配线，1 个 6-type transfer engine 接管资源流转（**Upload Labs 实证**） | [o11](../optional/o11-multi-region.md), [Pattern T](pattern-t-tier-jump.md) |
| [PR](pattern-pr-service-soft-reset.md) | Service 软重置 | 代币消费触发单 sub-tree refund + 可选 window 销毁，区别于 hard prestige（**Upload Labs 实证**） | [AME](pattern-ame-3tuple-attribute.md), [Pattern P2](pattern-p2-dual-prestige.md) |

> **冲突矩阵**：见 [conflicts.md](conflicts.md) — 18×18 Pattern/Optional 冲突矩阵 + 18 条冲突详档（解决策略 + 反模式）。同时启用多个 Pattern 前先查此表。

---

## 模式依赖图

```text
[02-resources] ──→ Pattern R 概率叠加（含非掉落型分档变体）
                    │
                    ▼
                 Pattern D 双资源池
                    │
                    ▼
[03-production-lines] ──→ [04-upgrade-economy]
                                │
                                ▼
                          Pattern S 成长轴分档
                                │
                          ┌─────┴─────┐
                          ▼           ▼
                    Pattern B     Pattern T 等级跳跃
                    二进制开关         │
                          │           ▼
                          └────→ [06-permanent-upgrades]
                                     │
                                     ▼
                              [o09-interaction-qol]
                              等级跳跃 UX 提示
                                     │
                                     ▼
                              [o03-challenge-axis]
                              战斗轴 / 终局挑战
                                     │
                          ┌──────────┴──────────┐
                          ▼                     ▼
                    Pattern E 状态 Stack    Pattern C7 自选 debuff
                    (战斗轴 + 经济轴)              │
                    + 5 段式衰减时序              ▼
                    (tick/time/charge/     Pattern P2 双 prestige
                     event/element-gated)  (双 currency 加速)
                          │
                          │              [06-permanent-upgrades]
                          │                     │
                          │                     ▼
                          │              Pattern C·跨建筑 Inspiration 链
                          │              (源建筑→目标单位, 互斥+可叠加)
                          │              挂 [o04] / [o08], 前提 [o11]
                          ▼
                    [o11-multi-region] 战斗伤害链
                    [o13-temporal-multicycle] 经济轴节奏
                    [schemas/status-effect] 数据
                    │
                    ▼
              Pattern AME 3-tuple 属性
              （统一所有 progression table 的 add() 引擎）
                    │
              ┌─────┴─────┐
              ▼           ▼
          Pattern N    Pattern PR
        节点流水线图   Service 软重置
       （玩家摆放 + 配线）（单 sub-tree 退款）
```

---

## 启用建议

### MVP（战斗/资源/收集型题材）

- Pattern S：分出 3 条核心轴 + 5-10 条次要 + 若干开关
- Pattern T：至少 1 条核心轴使用跳 9→10
- Pattern R：2-4 档稀有度 + 跨种类 meta 倍率

### 进阶

- Pattern D：当 1 个资源池跨多个武器/技能时引入
- Pattern B：当需要解锁式机制（如跨模块联动）时引入
- Pattern E：当引入战斗乘区 / DOT / 易伤 / 缓速 / 增伤时引入（**强烈推荐**——比硬编码 buff 优雅得多）

### 终局

- Pattern E + [o03-challenge-axis](../optional/o03-challenge-axis.md) + [o11-multi-region](../optional/o11-multi-region.md) = 完整的战斗增量终局

---

## 反模式（跨模式共性）

> 完整反模式目录（唯一权威源）见 [docs/anti-patterns.md](../docs/anti-patterns.md)。

| 反模式 | 后果 |
|--------|------|
| Pattern T 跳跃太便宜 | 全满级无目标 |
| Pattern T 跳跃太贵 | 玩家看不到进度放弃 |
| Pattern R 概率只有 1 条技能 | 玩家不知道优先升级哪条 |
| Pattern D 1 个池挂 5+ 链 | 万能钥匙、失去选择性 |
| Pattern S 所有技能同档 | 决策疲劳或无目标 |
| Pattern E 易伤 / 增伤用加法 | 单一 boss 叠满打崩平衡 |
| Pattern E DOT 走独立伤害链 | 玩家需分别堆 DOT 与瞬伤 |
| Pattern E 用错衰减时序（charge 型用 tick 衰减） | charge buff 永不耗尽 / DOT 立即消失 |
| Pattern C·跨建筑 source 与 target 同一建筑 | 退化成普通升级，失去跨建筑策略 |
| Pattern C·跨建筑 全可叠加且无 cap | 后期数值爆炸 |

详见各 Pattern 文档的"反模式"段。