﻿# Pattern D · 双资源池共享（Dual-Pool Coupling）

> **代号**：D  
> **来源**：[Shelldiver 氧气池同时控制时长 + 武器伤害](../cases/shelldiver/README.md)  
> **首次出现**：[03-production-lines.md](../core/03-production-lines.md) 的产线对照表

实战沉淀：**一个限制资源** 同时承担多个产出链的"输入"或"放大器"角色，让单点投资跨域生效。

---

## 形态：限制资源 → 多链路放大

```text
# 例：氧气池同时控制时长 + 伤害
final_damage(weapon):
    base = weapon.base_damage
    pool_bonus = current_oxygen_max × weapon.oxygen_to_damage_ratio
    return base × pool_bonus × other_multipliers
```

---

## 三种耦合方向

| 方向 | 示例 | 设计意图 |
|------|------|---------|
| **限制→放大** | `oxygen_max` 同时给"潜水时长"和"武器伤害" | 升级池同时解锁两域 |
| **限制→解锁** | `inventory_slots` 同时给"采集量"和"单槽容量" | 容量瓶颈两维度同步 |
| **资源→资源** | `jellyfish_count` 同时给"采集量"和"卖出价值" | 资源热点跨系统 |

---

## 关键参数

```text
dual_pool_coupling(pool_resource, sink_chains):
    for chain in sink_chains:
        chain.input_or_multiplier ← pool_resource.value
        # 耦合强度 = ratio_k（每个链独立）
```

| 参数 | 含义 | 典型范围 |
|------|------|---------|
| `ratio_k` | 每单位池资源换多少放大 | 0.001 ~ 0.1 |
| `is_accumulating` | 池资源是否永久增长 | 项目自定 |
| 跨链叠加 | 多链 × ratio_k 总和 | 必须 < 1.0 避免后期数值爆炸 |

---

## 设计规则

- **1 个池资源 ≤ 3 个 sink 链**：避免"全都要"瓶颈
- **`ratio_k` 应与池资源的成长曲线同步**：避免后期失衡
- **失效模式**：当 sink 链被解锁但池资源 = 0 时，必须有 fallback（否则新玩家卡关）

---

## 反模式

- 1 个池资源挂 5+ 链 → 升级池成"万能钥匙"，失去选择性
- ratio_k 跨链不一致 → 玩家专攻最高 ratio 链，其他链荒废
- 池资源失效后链锁死 → 新玩家无法推进

---

## 适用场景

- 动作型增量：体力池同时控制时长 + 伤害 + 速度
- 生存型增量：氧气 / 生命 / 法力池共享多武器
- 资源型增量：采集槽同时给"量"和"质"

---

## 配套

- **依赖**：[02-resources.md](../core/02-resources.md)（资源分层）、[03-production-lines.md](../core/03-production-lines.md)（产线）
- **案例**：[Shelldiver 氧气系统](../cases/shelldiver/README.md#模块-3氧气系统核心限制器)

---

## 数据 Schema

```json
{
  "dual_pool": {
    "pool_resource": "oxygen_max",
    "sink_chains": [
      { "chain": "dive_duration", "ratio_k": 0.01, "fallback": 60 },
      { "chain": "bubble_damage", "ratio_k": 0.005, "fallback": 1 },
      { "chain": "plasma_damage", "ratio_k": 0.005, "fallback": 1 }
    ]
  }
}
```