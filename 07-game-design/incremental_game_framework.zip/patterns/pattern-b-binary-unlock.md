﻿# Pattern B · 二进制开关（Binary Unlock）

> **代号**：B  
> **来源**：[Shelldiver 17 个 1-2 级开关技能](../cases/shelldiver/README.md)  
> **首次出现**：[04-upgrade-economy.md](../core/04-upgrade-economy.md) 的 Sink 配对表

实战沉淀：1-2 等级技能作为"机制解锁"，没有成长曲线，只决定解锁与否。

---

## 适用场景

- **跨模块联动**：`homing_bubbles`（自瞄）、`robot_lightning`（友军触发闪电）
- **状态机切换**：`transmutator_golden`/`_emerald`（转化稀有度变种）
- **机制开关**：`bubble_smite`、`bubble_duration`、`mult_reload`

---

## 设计规则

```text
binary_unlock(id):
    cost = fixed_cost_per_level                # 每级固定成本
    effect = if level > 0: activate else null   # 解锁即生效
    max_level = 1 or 2                          # 通常不超过 2
```

---

## 反模式

- 用指数曲线给开关 → 浪费玩家对"是否要点"的认知预算
- 开关 > 3 级 → 失去"二进制"语义，玩家以为是成长轴

---

## 与 Pattern S 的关系

属于 [Pattern S 成长轴分档](pattern-s-skill-tiers.md) 的第 3 档"单点开关"。在 Pattern S 中归类，开关档的具体规则详见本档。

---

## 配套

- **所属**：[Pattern S 成长轴分档](pattern-s-skill-tiers.md) 第 3 档
- **依赖**：[04-upgrade-economy.md](../core/04-upgrade-economy.md) C3 一次性 Unlock