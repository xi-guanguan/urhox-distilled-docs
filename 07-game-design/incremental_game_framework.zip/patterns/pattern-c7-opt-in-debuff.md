﻿# Pattern C7 · 自选永久 Debuff（Opt-in Permanent Debuff）

> **代号**：C7
> **来源**：[cases/kittens-game/README.md § 9](../cases/kittens-game/README.md) — 8 个 challenge（ironWill, blackSky, pacifism, postApocalypse, energy, atheism, crowded, lethargic, ninetyNine）作为自选永久 debuff 换 paragon
> **首次出现**：原框架 Pattern C 是"永久 buff"，KG 证明"永久 **debuff**" 也是有效的 Pattern，且可以叠加

实战沉淀：当玩家已"通关"主游戏但 prestige currency 增长变慢时，给玩家一组**自选永久减益**换 prestige 加速度，是延寿游戏的常用设计。每个 debuff 都是独立 toggle、永久开启、可叠加、奖励可叠加。

---

## 与 Pattern C 的镜像关系

| 维度 | Pattern C（永久 buff） | **Pattern C7（永久 debuff）** |
|------|----------------------|-------------------------------|
| 方向 | 资源 + / 效果 + | 资源 - / 效果 - |
| 来源 | 货币购买 | 玩家主动 toggle |
| 玩家意图 | 强化 | 自我挑战 |
| 奖励 | 解锁更强能力 | 加速 prestige currency 获取 |
| 持久性 | 跨 run 永久 | **跨 run 永久**（重置时仍生效） |
| 数量 | 通常 5-15 个 | 通常 5-10 个（过多则失去选择性） |

## 设计形态（KG 实证）

```text
# 9 个 challenge 之一
{
    id: "ironWill",
    description: "Smelters turn off at 95% max Iron.",
    debuff_effects: { "smelter_max_modifier": 0.95 },
    prestige_bonus: { "paragon_ratio": 0.25 },
    default_on: true,    # 老玩家默认开
    stackable: true       # 可与其它 challenge 叠加
}

# 引擎逻辑
on_challenge_active(challenge_id):
    apply_effects(challenge_id, debuff_effects)   # 写黑名单
    modify_prestige_gain(prestige_bonus)         # 加快 currency 累计

# 玩家开关
toggle_challenge(challenge_id, on):
    if on and not active(challenge_id):
        apply_debuff(...)
        prestige_bonus += challenge.prestige_bonus
    elif not on and active(challenge_id):
        remove_debuff(...)
        prestige_bonus -= challenge.prestige_bonus
```

## 关键设计规则

### 1. 奖励必须 > 代价（否则无人开）

```text
# KG：ironWill 1 个 debuff → +25% paragon（每 run）
#     blackSky 1 个 calciner ×11 cost → +20% calciner efficiency
#
# 一般规则：每开 1 个 debuff → +20% ~ +50% prestige
# 极端 debuff（如全资源 ×0.5） → +100% prestige
```

### 2. 关键 debuff 应默认开启

`ironWill` 在 KG 中 `default_on: true` —— 老玩家跑完主线后这是**默认**。新玩家可以关闭熟悉机制，再逐步开启。**不要强制**：让玩家**主动 toggle**是 debuff 的核心乐趣。

### 3. 必须可叠加且奖励可叠加

错误：8 个 debuff 二选一 → 玩家永远只开最容易的。  
正确：8 个 debuff 任意组合 → 开 N 个 × 各自 bonus 累加 → 高难度玩家 prestige 收益指数级。

### 4. 不要让 debuff 改变游戏规则（仅修改数值）

```text
# ✅ 允许：smelter cap ×0.95、paragon +25%、blueprint 不能买
# ❌ 禁止：移除整个科技树、改变资源类型、锁定 UI 面板
#
# 原因：debuff 的乐趣是"用同一套机制打更高分"，不是"玩另一个游戏"
```

### 5. 提供可视化的"debuff running cost"面板

让玩家看到"我现在 5 个 debuff，下次 prestige 收益是 ×3.2"。否则玩家无法规划。

## 反模式

| 反模式 | 后果 |
|--------|------|
| debuff 奖励 < 代价 | 玩家全部关闭，机制失效 |
| 强制开启、不可关闭 | 玩家感到被惩罚，不是自我挑战 |
| debuff 改变游戏机制（而非数值） | 玩家觉得在玩"另一个游戏" |
| debuff 数量太多（>15） | 玩家难以理解、组合爆炸、决策疲劳 |
| debuff 奖励写死为常数 | 老玩家 prestige 增长线性、无进步感 |
| 把 debuff 称为"成就" | 心理预期错误——debuff 是"代价"不是"奖励" |

## 适用场景

- 玩家已通关主线，需要"再玩一遍"动力时
- prestige currency 增长边际递减，需要给玩家加速选项时
- 想要"难度档位"但不想拆分多个 save 时
- 想要让玩家之间 prestige 速率产生差异（硬核玩家通过 debuff 拉开差距）

## 配套

- **基础**：[core/06-permanent-upgrades.md § Pattern C](../core/06-permanent-upgrades.md) — 永久 buff 模式
- **关联**：[optional/o03-challenge-axis.md](../optional/o03-challenge-axis.md) — 正向挑战目标（boss / wall / wave）
- **奖励源**：[patterns/pattern-p2-dual-prestige.md](pattern-p2-dual-prestige.md) — 奖励的 prestige currency
- **数据**：[cases/kittens-game/challenges.json](../cases/kittens-game/challenges.json)（9 个 challenge）
- **案例**：[Kittens Game § 9 ironWill + 8 opt-in](../cases/kittens-game/README.md)
