﻿# Pattern R · 概率叠加资源（Rarity Tier）

> **代号**：R  
> **来源**：[Shelldiver 3 档稀有度（Silver/Gold/Rainbow）+ biovalue 元倍率](../cases/shelldiver/README.md)  
> **首次出现**：[02-resources.md](../core/02-resources.md) 的资源分层章节

实战沉淀：实体（怪物 / 物品 / 资源）按**概率分档**产出多档价值，跨档"概率叠加"成为长线 meta 维度。

---

## 资源形态

```text
on_entity_drop(entity):
    rarity = roll_rarity(probabilities)        # 普通/Silver/Golden/Rainbow
    value = base_value(rarity) × value_multipliers
    add_resource(type, value)
```

---

## 概率分布模板

| 档 | 默认概率 | 价值倍率 | 提升技能 |
|----|---------|---------|---------|
| 普通 | 100% | 1.0× | — |
| Silver | 1-5% | 3-5× | `o_skill_biovalue_silver` |
| Golden | 0.1-1% | 10-20× | `o_skill_biovalue_gold` |
| Rainbow | 0.01-0.1% | 50-100× | `o_skill_biovalue_rainbow` |

---

## 概率乘区设计

```text
final_probability(tier):
    return base_probability(tier) × Π upgrade_chance(tier)
```

- 每档**独立**概率技能（避免 1 个全包）
- 顶部档概率增长需要 [Pattern T 等级跳跃](pattern-t-tier-jump.md)
- 跨种类共用时 → 用 `biovalue_amount` 等 meta 倍率一次性叠加

---

## 价值链

```text
final_value = base_value × rarity_multiplier × jellyfish_value_skill × biovalue_amount
```

- `rarity_multiplier`：由概率档决定（普通 1×, Silver 3-5×, …）
- `jellyfish_value_skill`：跨档普适的成长技能
- `biovalue_amount`：跨种类叠加的 meta 乘区（Pattern T 跳 10）

---

## 反模式

- 概率乘区只有 1 条技能 → 玩家不知道优先升级哪条
- 顶部档概率成长过慢 → 玩家永远抽不到，失去追求
- 价值倍率与概率倍率倒挂 → 玩家专攻低档（无风险套利）

---

## 适用场景

- 刷宝型增量（怪物掉落、卡牌稀有度、矿脉品质）
- 收藏型增量（水母 / 精灵 / 卡牌）
- 长线经济扩张（多档货币叠加）

---

## 变体：非掉落型分档（KG 实证）

> **来源**：[cases/kittens-game/README.md § 1](../cases/kittens-game/README.md) — 58 资源按 4 个 `type` 字段（common / uncommon / rare / exotic）分档

Pattern R 默认是**掉落型**——按概率 roll 出稀有度。但 KG 证明 Pattern R 也适用于**资源本身的稀有度分层**：每个资源自带一个 `type` 字段（4 档），影响 UI 分组、AI 行为、解锁顺序。

```text
# 资源分档（不依赖概率）
{ name: "catnip",    type: "common",   … }
{ name: "furs",      type: "uncommon", … }
{ name: "unicorns",  type: "rare",     … }
{ name: "relic",     type: "exotic",   … }
```

### 掉落型 vs 资源分档型

| 维度 | 掉落型 Pattern R | 资源分档型（KG） |
|------|------------------|------------------|
| 分档对象 | 同一实体的多个 drop | 不同种类的资源 |
| 分档依据 | 概率 roll | 解锁阶段 / 来源稀有度 |
| 价值倍率 | 3× / 10× / 50× 数值 | 不影响数值，只影响 UI / AI |
| 解锁逻辑 | 概率提升技能 | 科技 / Prestige 解锁 |
| 玩家行为 | "刷更稀有的" | "解锁更稀有的" |

### 4 档语义（KG 实证）

| 档 | 数量 | 含义 | 例子 |
|----|------|------|------|
| `common` | 43 | 主游戏中一直可见、一直可产出 | catnip / wood / iron / science |
| `uncommon` | 3 | 贸易 / 随机掉落才出现 | furs / ivory / spice |
| `rare` | 5 | 中后期科技 / Prestige 解锁 | unicorns / alicorn / tears |
| `exotic` | 7 | 纯 Prestige / Transcendence 产出 | relic / void / T-Mythril |

### 与 Pattern R 默认（掉落型）的关键差异

- **不修改数值**：type 字段不影响乘区、不影响价格，仅影响 UI / AI
- **不能升级**：玩家无法"提升资源的 rarity"，只能"解锁更多资源"
- **可作为"是否对 AI 暴露"的过滤**（KG 的 `aiCanDestroy` flag）

### 设计规则

- 档位数量 **3-4 档为主流**：KG 4 档（common/uncommon/rare/exotic），Shelldiver 3 档（Silver/Gold/Rainbow，无"普通"档）
- 每档资源数量：common 远多于其它（KG: 43/58 = 74% 是 common）
- 资源稀有度**不能与数值混用**（不能让 exotic 比 common 强 10×）
- 资源稀有度**应驱动 UI 顺序**（exotic 在最后，common 在最前）

### 反模式

- 资源分档后把 type 当数值倍乘（破坏了"稀有度 = 出现频率"的语义）
- 5 档以上（玩家难以区分；3-4 档即可，少于 3 档则失去"分层"意义）
- 资源分档**不可逆**（不能把 common 转 exotic）
- 用资源分档代替"解锁科技"机制（应先用 O1 解锁，再用 type 标记）

## 配套

- **依赖**：[02-resources.md](../core/02-resources.md)（资源分层与入库）
- **进阶**：用 [Pattern T 等级跳跃](pattern-t-tier-jump.md) 设计 `biovalue_amount` 跳 10 的 meta 永久项
- **案例**：[Shelldiver 3 档稀有度](../cases/shelldiver/README.md#模块-8资源与稀有度经济扩展)

---

## 数据 Schema

```json
{
  "rarity_tiers": [
    { "id": "common", "base_probability": 1.0, "value_multiplier": 1.0, "skill_id": null },
    { "id": "silver", "base_probability": 0.05, "value_multiplier": 4.0, "skill_id": "biovalue_silver" },
    { "id": "golden", "base_probability": 0.005, "value_multiplier": 15.0, "skill_id": "biovalue_gold" },
    { "id": "rainbow", "base_probability": 0.0005, "value_multiplier": 75.0, "skill_id": "biovalue_rainbow" }
  ]
}
```

完整定义见 [schemas/rarity.schema.json](../schemas/rarity.schema.json)。