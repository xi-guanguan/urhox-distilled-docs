﻿# Pattern PR · Prestige-Reset Service（代币驱动的软重置）

> **代号**：PR
> **来源**：[cases/upload-labs/README.md § 9](../cases/upload-labs/README.md) — `data/services.json` 3 个 service + `scripts/services/service_*.gd` 各 30 行退款实现
> **首次出现**：原框架 Pattern P（单 prestige currency）只设计"currency 跨 reset 保留"，PR 设计"currency 消费触发**单 sub-tree** refund"

实战沉淀：当游戏有 ≥3 个 progression sub-tree（hack / code / breach / …），玩家需要 *re-specialise*（重洗）其中一个 sub-tree 而**不重置整个游戏**时，引入"service"：用 token 货币触发 *单 category* 的 upgrade 退款 + 可选的 window 销毁。区别于 hard prestige（重置全部）和 milestone（加 buff），service 是 *反向 buff*。

---

## 与 Pattern P + Pattern C7 的差异

| 维度 | Pattern P（prestige currency） | Pattern C7（opt-in permanent debuff） | **Pattern PR（service soft-reset）** |
|------|--------------------------------|--------------------------------------|--------------------------------------|
| 操作方向 | 跨 reset 保留 | 玩家自愿永久 debuff | **消费 token → 退款** |
| 触发条件 | 任何 reset | 主动选择 challenge | **主动花 token 触发 service** |
| 状态变化 | +buff（perk/milestone） | -debuff（自残） | **-upgrade（refund）+ 货币回流** |
| 引擎依赖 | reset signal | challenge toggle | **service list + reverse-add 钩子** |
| 与 reboot 关系 | 跨 reboot 持久 | 跨 reboot 持久 | **独立于 reboot，可随时触发** |

## Service 结构

```json
{ "name": "application_reset", "currency": "token", "cost": <varies>, "cost_e": <varies>,
  "upgrades": ["application_X", "application_Y", ...],   // 10 项
  "windows":  ["application_window_a", "application_window_b", ...],  // 10 项（可选）
  "window_groups": []   // 可选：按 group 销毁
}
```

## 退款实现（30 行 / service）

```gdscript
# scripts/services/service_application_refund.gd
func refund(player: Globals) -> void :
    # 1. 检查 token 足够
    if player.currencies["token"] < Data.services["application_reset"].cost:
        return

    # 2. 扣 token
    player.currencies["token"] -= Data.services["application_reset"].cost

    # 3. 退款：遍历 upgrades，对每个 level 调用 Attribute.add(-level)
    for upgrade_name in Data.services["application_reset"].upgrades:
        var upgrade = Data.upgrades[upgrade_name]
        var current_level = player.upgrade_levels[upgrade_name]
        Attributes.apply_attribute_dict(upgrade.attributes, -current_level)  # 负数 level

        # 4. 退款 currency：返还 cost × 10^cost_e × cost_inc^level 给对应 currency pool
        var refund = upgrade.cost * pow(10, upgrade.cost_e) * pow(upgrade.cost_inc, current_level)
        player.currencies[upgrade.currency] += refund

        # 5. 清零 level
        player.upgrade_levels[upgrade_name] = 0

    # 6. 销毁 window（如果 service 有 windows 列表或 window_groups 列表）
    for window in player.active_windows:
        if Data.services["application_reset"].windows.has(window.name) or
           Data.services["application_reset"].window_groups.has(window.group):
            window.close()
```

**核心技巧：`Attribute.add(attrs, -level)`** — 用 AME 引擎的负数 level 实现反向 buff。这要求 AME 的 `add()` 是 sign-symmetric（`add([a, m, e], -n)` 真的能撤掉 `add([a, m, e], +n)`）。Upload Labs 用这个机制同时支持 service 退款、boost 自动移除、perk 撤销。

## 关键设计规则

### 1. Service 与 Hard Prestige 互不替代

- **Hard prestige（reboot）** 保留 perks/milestones/achievements，重置 money/research/upgrade levels/window placements。
- **Service** 只重置 service 列表里的 upgrades + windows，**不重置**任何其他状态。

错误做法：让 service 触发 reboot → 等同 hard prestige，PR pattern 失去意义。

### 2. Cost 必须有上限

错误做法：service cost 随 refund 量线性增长 → 玩家无限循环刷退款。

正确做法：service cost 固定或按 schedule 增长（`cost × 10^cost_e × cost_inc^n`，n = 已使用次数）。Upload Labs 的 service cost 是固定的 — 第一次用 100 token，第二次 200，第三次 400（cost_inc=2）。

### 3. 退款金额必须等于原始 cost

错误做法：refund 给 50% 货币 → 玩家"赔钱"re-spec，PR 没人用。

正确做法：refund 100% 货币，玩家净损失是 service cost（不是 refund 量）。Upload Labs 的 refund 公式 = `cost × 10^cost_e × cost_inc^level` 完整还原。

### 4. Service 列表必须可扩展

错误做法：service hardcode 到 engine。

正确做法：service 是 JSON 表 + 30 行 script 的组合。新增 service = 新增 JSON entry + 新增 1 个 script。Upload Labs 的 3 个 service 是 `service_hack_refund.gd` / `service_optimization_refund.gd` / `service_application_refund.gd`，各 30 行。

### 5. Window 销毁的两种方式

- `windows: [...]` — 精确列出要销毁的 window 名。
- `window_groups: [...]` — 按 `data/windows.json: group` 字段批量销毁。

Upload Labs 的 `application_reset` 用了 `windows` 方式（10 个 application window 精确列出）。如果用 `window_groups`，新增 window 只要在 JSON 里标 `group: "application"` 就自动被 service 覆盖。

## 反模式

| 反模式 | 后果 |
|--------|------|
| Service 触发 reboot | 退化为 hard prestige，PR 失去意义 |
| Refund 给 50% 货币 | 玩家赔钱 re-spec，PR 没人用 |
| Service cost 随 refund 线性增长 | 玩家循环刷退款套利 |
| Service hardcode 到 engine | 加新 service 必须改代码 |
| 不支持 window 销毁 | 玩家 refund upgrade 但 window 仍然存在 = 半重置 |
| 退款与原 cost 不一致 | 玩家发现漏洞刷退款 |

## 适用场景

- 游戏有 ≥3 个 progression sub-tree，玩家需要 re-specialise
- Hard prestige 体验太重（玩家不想重置整个 game）
- sub-tree 内部的 build order 错误时需要"重洗"
- 中后期有"second wind"需求（玩家 re-spec 以应对新内容）

## 不适用场景

- 单一 progression tree（无 sub-tree）— service 没东西 refund
- 玩家想保留 progression 时（PR 强制 refund）— 让他们用 hard prestige
- 游戏的 progression 是一次性的（无 re-spec 需求）

## 配套

- **基础**：[core/05-reset-systems.md](../core/05-reset-systems.md) — Pattern P（prestige currency）跨 reset 设计
- **同源**：[patterns/pattern-c7-opt-in-debuff.md](pattern-c7-opt-in-debuff.md) — 自愿 debuff
- **依赖**：[patterns/pattern-ame-3tuple-attribute.md](pattern-ame-3tuple-attribute.md) — `add(attrs, -level)` 退款
- **案例**：[Upload Labs § 9 Service-Driven Partial Reset](../cases/upload-labs/README.md)
- **数据**：[cases/upload-labs/services.json](../cases/upload-labs/services.json)（3 个 service）
- **代码**：`scripts/services/service_*.gd`（3 个 service 的退款实现）
