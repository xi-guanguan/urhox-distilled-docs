# Pattern × Pattern 冲突矩阵（Conflicts）

> **本文件目标**：列出已知 Pattern / Optional 同时启用时会**实际产生副作用**的组合，给出可操作的解决策略。
>
> **不是** 依赖关系（"X 必须先于 Y"）—— 依赖关系见 [README.md § 模式依赖图](README.md#模式依赖图)。
> **不是** 通用反模式（"X 会导致 Y 后果"）—— 通用反模式见 [docs/anti-patterns.md](../docs/anti-patterns.md)。
>
> **冲突矩阵位置** 标注每个冲突在哪两个 Pattern 的实际组合中被观察到（case 实证）。

---

## 冲突矩阵速览

> ✅ = 同时启用无冲突 | ⚠️ = 需注意（有限制 / 优先级 / 字段约定） | ❌ = 必须二选一或做特殊设计

| | P-R | P-D | P-S | P-B | P-T | P-E | P-P2 | P-C7 | P-C·跨建筑 | P-AME | P-N | P-PR | O1 | O3 | O5 | O7 | O11 | O13 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **P-R** | — | ✅ | ✅ | ✅ | ⚠️ R2 | ⚠️ R3 | ✅ | ⚠️ R1 | ✅ | ✅ | ✅ | ✅ | ✅ | ⚠️ R4 | ✅ | ✅ | ✅ | ✅ |
| **P-D** |  | — | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ⚠️ D1 | ✅ | ⚠️ D2 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-S** |  |  | — | ⚠️ S1 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-B** |  |  |  | — | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-T** |  |  |  |  | — | ✅ | ✅ | ✅ | ✅ | ⚠️ T1 | ✅ | ✅ | ⚠️ T2 | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-E** |  |  |  |  |  | — | ✅ | ✅ | ✅ | ⚠️ E1 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-P2** |  |  |  |  |  |  | — | ✅ | ✅ | ✅ | ✅ | ⚠️ P2-1 | ✅ | ✅ | ✅ | ⚠️ P2-2 | ✅ | ✅ |
| **P-C7** |  |  |  |  |  |  |  | — | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-C·跨建筑** |  |  |  |  |  |  |  |  | — | ✅ | ❌ CN-1 | ✅ | ✅ | ✅ | ✅ | ✅ | ⚠️ CN-2 | ✅ |
| **P-AME** |  |  |  |  |  |  |  |  |  | — | ⚠️ AN-1 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **P-N** |  |  |  |  |  |  |  |  |  |  | — | ✅ | ✅ | ✅ | ✅ | ✅ | ⚠️ N-1 | ✅ |
| **P-PR** |  |  |  |  |  |  |  |  |  |  |  | — | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **O1** |  |  |  |  |  |  |  |  |  |  |  |  | — | ✅ | ⚠️ O1-1 | ✅ | ✅ | ✅ |
| **O3** |  |  |  |  |  |  |  |  |  |  |  |  |  | — | ⚠️ O3-1 | ✅ | ✅ | ✅ |
| **O5** |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — | ✅ | ⚠️ O5-1 | ✅ |
| **O7** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — | ✅ | ✅ |
| **O11** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — | ✅ |
| **O13** |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |

> 阅读方式：行是"Pattern A"，列是"Pattern B"，格子是 A × B 同时启用时的状态。冲突 ID（R2 / D1 / …）在下文逐条展开。

---

## 冲突详档

### ⚠️ R1 · P-R 概率叠加 × P-C7 自选永久 debuff

**现象**：debuff 提高某些稀有度概率时（如 `ironWill` 改 `challengeRarityModifier`），与 P-R 的"目标稀有度判定公式"互相干扰；debuff 的乘区是否计入 `final_probability()` 取决于调用顺序。

**真实出处**：[cases/kittens-game/README.md § 8-9](../cases/kittens-game/README.md) — KG 的 9 challenges 中 `ironWill`（默认开启）实质修改 prestige 货币生成，但 KG 自身**没有显式 rarity tier**，所以未观察到直接冲突。**冲突风险点**：当 P-R（掉落型分档）改造 KG 风格游戏时会出现。

**解决策略**：

```text
# 显式优先级：debuff modifier 在 rarity roll 之前 apply
final_probability(tier):
    base = base_probability(tier)
    debuff_mod = get_active_debuff_modifier("rarity")   # C7 显式贡献
    return base × upgrade_chance(tier) × debuff_mod     # debuff 在最后
```

**反模式**：
- 把 debuff modifier 塞到 `upgrade_chance()` 里混在一起 → 玩家无法追溯"哪个 debuff 影响了哪条概率"
- debuff 影响概率但**不**影响 `value_multiplier` → 高 debuff 玩家拿到更高稀有度但价值不变，体验割裂

---

### ⚠️ R2 · P-R 概率叠加 × P-T 等级跳跃

**现象**：P-R 的顶部档（Rainbow / exotic）需要 `biovalue_amount` 类的 meta 永久项跳 10 → 与 P-T 的"跳 8→10 / 9→10"在**字段命名空间**上撞车。两者都想占用"最终稀有度乘区"位置。

**真实出处**：[cases/shelldiver/README.md § 5](../cases/shelldiver/README.md) — Shelldiver 的 `o_skill_biovalue_amount`（跳 1→10）是 P-R + P-T 的真实组合，工作良好。

**解决策略**：

- P-R 的"稀有度概率技能"走普通 tier（无跳级）
- P-T 的"meta 倍率永久项"（如 biovalue_amount）独占跳 10 槽位
- 字段命名强制区分：`o_skill_biovalue_<tier>` 是概率技能，`o_skill_biovalue_amount` 是 meta 永久项

**反模式**：
- 把"提升 Rainbow 概率"也做成跳 10 → 玩家两个目标混淆，决策瘫痪
- meta 永久项走普通 tier → 长线没追求感

---

### ⚠️ R3 · P-R 概率叠加 × P-E 状态 Stack（战斗轴）

**现象**：P-E 的 5 种衰减时序里 `decay_strategy` 字段与 P-R 的"稀有度判定时机"耦合——易伤状态下打怪的稀有度 roll 是否享受易伤加成？

**真实出处**：[cases/tower-wizard/README.md § 4-5](../cases/tower-wizard/README.md) — Tower Wizard 用 P-E 但**没有 P-R**（无稀有度系统），所以无冲突案例。**冲突风险点**：在战斗 + 收集双轴游戏中会出现。

**解决策略**：

```text
# rarity roll 在 damage 计算之前；debuff 不影响 rarity
on_kill(entity):
    rarity = roll_rarity(probabilities)          # P-R
    value = base_value(rarity) × active_debuff_mod   # P-E 影响 value
    drop_resource(entity, value)
```

**反模式**：
- debuff 直接乘到 rarity roll 上 → 易伤状态刷稀有度变成"必出 Rainbow"，稀有度丧失意义
- rarity roll 在战斗结算之后 → 高 DPS build 反而降低稀有度收益，体验反向

---

### ⚠️ R4 · P-R × O3 挑战轴

**现象**：O3 的挑战目标（boss HP / 波次）有自己的"完成奖励"乘区；P-R 的稀有度判定有时被嵌入 O3 的伤害流（"打到 boss 最后 1% 时掉落稀有度翻倍"）。两者的稀有度逻辑需要统一来源。

**真实出处**：[cases/gnorp/README.md § 9](../cases/gnorp/README.md) — Gnorp 用 P-R 的"资源分档型"（KG 变体）+ O3 的 elite enemy 战，**rarity 字段只标 type 不改数值**，避开了冲突。

**解决策略**：
- 用 P-R 的"资源分档型"（KG 变体）而非"掉落型" → rarity 不参与数值
- 若必须用掉落型，把 O3 的奖励显式抽到独立 currency，不与 P-R 共享字段

**反模式**：
- O3 战利品表与 P-R 稀有度表共用字段名 → 改了 O3 伤害公式意外影响稀有度 drop

---

### ⚠️ D1 · P-D 双资源池 × P-C·跨建筑 Inspiration

**现象**：P-D 的"1 个限制资源跨多条产线"通常意味着该资源是全局共享；P-C·跨建筑的 `source_building` 触发条件如果检查"限制资源持有量"会与 P-D 的产线消费冲突——某个建筑既要用该资源做生产，又要满足 source 的 trigger。

**真实出处**：[cases/gnorp/README.md § 9](../cases/gnorp/README.md) — Gnorp 用 P-C·跨建筑但**没有显式 P-D**（多数资源是区域内自治），所以未观察到直接冲突。

**解决策略**：
- inspiration 的 trigger 用"单位数 / 状态激活"，**不用**资源持有量（避开 P-D 的核心字段）
- 若必须用资源 trigger，用 `state.max_ever_held` 而非 `state.current_held`（不与 P-D 产线抢消费）

**反模式**：
- trigger 用 `state.current_held` → 玩家刷 P-D 产线消耗资源时 inspiration 反复失去激活，UI 闪烁

---

### ⚠️ D2 · P-D 双资源池 × P-N 节点流水线

**现象**：P-N 的 6-type transfer engine 假设每个 node 有自己的 input slot 和 limit；P-D 的"限制资源"在多 node 间共享时，需要显式定义"限制资源是 node 内部状态还是全局状态"。

**真实出处**：[cases/upload-labs/README.md § 4](../cases/upload-labs/README.md) — Upload Labs 用 P-N 但**未显式 P-D**（资源主要按 node 流，不共享）。

**解决策略**：
- 限制资源做成"全局共享 + node limit 引用" → 每个 node 自己设 `attributes.limit`，transfer engine 读全局值做对比
- 不用 P-D 的传统"1 个 resource 跨多产线"语义，改用 P-N 的"1 个全局 pool + 多 node 引用"

**反模式**：
- 把限制资源做成 node 内部状态 → 跨 node 共享失效
- 全局共享但 node 不设 limit → 1 个 node 消耗所有限制资源，其他 node 饿死

---

### ⚠️ S1 · P-S 成长轴分档 × P-B 二进制开关

**现象**：P-S 的次要轴（3-5 tier）有时被误用为 P-B（1-2 tier 机制解锁），或反之——开关型技能做成 3 tier 后失去"解锁即生效"的语义。

**真实出处**：[cases/shelldiver/README.md § 6](../cases/shelldiver/README.md) — Shelldiver 把 P-S 和 P-B **严格按 tier 数分开**（core 8+跳 10 / secondary 3-5 / toggle 1-2），无冲突。

**解决策略**：
- 强制规则：开关型技能 `max_tier ≤ 2`
- tier = 1 的技能不允许 `cost_inc`（只能是 C3 一次性）
- 数据 schema 校验：`{ max_tier: 1 }` 必须同时 `{ stacking_policy: "binary" }`

**反模式**：
- 开关型做成 3 tier → 玩家不知道"3 tier 后还会不会有 4"
- tier = 1 但允许重复购买 → 等于 tier = ∞ 的退化

---

### ⚠️ T1 · P-T 等级跳跃 × P-AME 3-tuple 属性

**现象**：P-T 跳 10 时 `e_count = 10` 调用 `add([a, m, e])`；P-AME 的指数语义 `pow(e, e_count)` 在 `e_count = 10` 时会爆发式增长。**两个 Pattern 都喜欢 e_count 大**，但组合后可能失控。

**真实出处**：[cases/upload-labs/README.md § 3](../cases/upload-labs/README.md) — Upload Labs 用 P-AME 但**未大量使用 P-T**（多数 progression 是 level-based，不是跳级）。

**解决策略**：
- P-T 跳级技能在 P-AME 中**不用指数轴**（`e = 0`），只用加法轴（`a`）—— 跳级效果体现在 `a` 的 level 增量
- 显式约束：`if skill.jump_tier: tuple.e = 0`（代码 / schema 双侧）

**反模式**：
- 跳级技能用指数轴 `e = 1.2, e_count = 10` → `pow(1.2, 10) = 6.19×`，单技能 6 倍增长，破坏乘区链
- 跳级 + 指数 + 加法三者叠满 → 单技能超 100 倍增长

---

### ⚠️ T2 · P-T 等级跳跃 × O1 章节 Gate

**现象**：跳级让章节 Gate 在视觉上失效（"明明没过 Gate 但已经满级"）。Shelldiver 跳 8→10 + 4 生态区 Gate（通过成就解锁）共存，需要额外 UI 处理跳级技能在 Gate 未通过时的状态显示。

**真实出处**：[cases/shelldiver/README.md § 3, 6](../cases/shelldiver/README.md) — Shelldiver 的 4 生态区解锁通过 `ACH_DEPTH_01-04` 成就，跳级技能 `o_skill_oxygen_tank` 在未达成深度前已经显示完整进度。

**解决策略**：
- 跳级技能在未达章节 Gate 时**隐藏而非灰显**
- 章节 Gate 通过后跳级技能的 tier 数才显示完整（如 `tiers: [1..8, 10]` 在 unlock 前显示 `tiers: [1..8]`）

**反模式**：
- 跳级技能跨 Gate 可见 → 玩家盯着买不起的东西挫败（违反 O1 反模式"用灰显而非隐藏"）
- Gate 通过后才解锁跳级技能 → 失去"提前知道有目标"的期待感

---

### ⚠️ E1 · P-E 状态 Stack × P-AME 3-tuple 属性

**现象**：P-E 的战斗轴有 `stacking_policy`（refresh / extend / stack）+ `decay_strategy`（5 种时序）；P-AME 把所有效果压平成 `[a, m, e]`。两者共用 `Attribute.add()` 时需要决定：状态 stack 累加的"层数"应该用哪个轴表达？

**真实出处**：[cases/upload-labs/README.md § 3](../cases/upload-labs/README.md) — Upload Labs 把 P-E 的经济轴变体（KG 风格）实现为 P-AME 3-tuple，但**战斗轴 P-E 没用 P-AME**（仍在用 per-system schema）。两个 Pattern 共存于同一游戏时需要明确优先级。

**解决策略**：
- **经济轴** effect 走 P-AME 3-tuple（统一加 / 乘 / 指数）
- **战斗轴** status effect 走 P-E 原始 schema（保留 `stacking_policy` / `decay_strategy` 字段）
- 战斗效果最终"投影"到 3-tuple 时只用加法轴 `a`（`a = stacks × percent_increase / 100`），不用指数

**反模式**：
- 战斗效果也压成 3-tuple → 失去 5 种衰减时序语义（[P-E 反模式](../patterns/pattern-e-status-stack.md)）
- 经济效果保留 per-system schema → 与 P-AME 的统一引擎冲突，无法共享 `Attribute.add()`

---

### ⚠️ P2-1 · P-P2 双 prestige × P-PR Service 软重置

**现象**：P-P2 把 prestige 拆成"短期 + 长期"两条 currency；P-PR 的 Service 软重置是"代币消费触发单 sub-tree refund"——当 refund currency 是 P-P2 的双 currency 之一时，需要决定 refund 走哪条轨。

**真实出处**：[cases/upload-labs/README.md § PR](../cases/upload-labs/README.md) — Upload Labs 同时用 P-P2 和 P-PR，但 P-PR 的 refund 用**短期 currency**（`paragon`），不用 `burnedParagon`。

**解决策略**：
- P-PR 的 refund **永远走短期 currency**（单局 currency，refund 不影响跨局进度）
- 显式约束：`service.refund_cost.currency ∈ short_term_currencies`
- 文档化：`burnedParagon` 类长期 currency 不接受 P-PR refund

**反模式**：
- refund 走长期 currency → 玩家 refund 一次损失跨局进度，不敢用 PR
- refund 同时消耗两种 currency → 长期 currency 实际被绑定到 refund，丧失独立性

---

### ⚠️ P2-2 · P-P2 双 prestige × O7 双 reset 轨

**现象**：两者都是"双 currency / 双轨"——P-P2 是 prestige 层（短期 + 长期 currency），O7 是 reset 轨（产发 + 挑战）。两个 Pattern 同时启用会出现 4 currency 交互（短期 prestige + 长期 prestige + 产发 XP + 挑战 XP）。

**真实出处**：当前 7 个 case **没有**同时引入 P-P2 和 O7（KG 有 P-P2 但无显式 O7，Upload Labs 有 O7 但 P-P2 是变体）。

**解决策略**：
- **不要同时启用**。若必须：P-P2 替代 O7（prestige 层本身就承载"短期/长期"语义）
- 若坚持组合：把 O7 的"挑战轨 XP"折算进 P-P2 的 `burnedParagon` 公式（`burnedParagon += challenge_xp × 0.1`）

**反模式**：
- P-P2 + O7 都做完整 4 currency → 玩家不知道先刷哪个，决策瘫痪
- 让两种 currency 互相兑换 → 套利空间出现，玩家用短期 currency 刷长期 currency 跑赢系统

---

### ❌ CN-1 · P-C·跨建筑 × P-N 节点流水线

**现象**：两个 Pattern 都是"复杂图结构"——P-C·跨建筑是 inspiration source-target 有向图，P-N 是 node connector 拓扑图。两者都用 `signal connect` 类的引擎抽象，UI 上都是"圆圈 + 连线"，玩家分不清"我摆的是 node 还是 inspiration"。

**真实出处**：当前 7 个 case **没有**同时引入两者。**理论冲突**，无实证。

**解决策略（二选一）**：
- **选 P-N**：当玩家 build 是"摆 + 连线"为主 → 用 P-N 统一所有空间操作；inspiration 退化为"node 属性"（每个 node 自带 inspiration 字段）
- **选 P-C·跨建筑**：当玩家 build 是"区域面板 + 升级"为主 → 用 P-C·跨建筑；空间摆放需求弱化

**反模式**：
- 两者全开 + UI 风格不区分 → 玩家摆 node 时误以为是 inspiration，误触发 source 触发器
- 两者全开 + 数据结构独立 → 双套图维护，bug 风险

---

### ⚠️ CN-2 · P-C·跨建筑 × O11 多区域

**现象**：P-C·跨建筑的 source-target 必须跨建筑；当引入 O11 后，"建筑"与"区域"的语义边界变模糊。Gnorp 的 inspiration 都在**单一区域**内（11 个 inspiration 全在主区），但 Tower Wizard 12 区域 + 跨区域乘区（训练、派系）若引入 inspiration 会冲突。

**真实出处**：[cases/gnorp/README.md § 9](../cases/gnorp/README.md) — Gnorp 单区域。**理论冲突**，无跨区域 inspiration 实证。

**解决策略**：
- inspiration 的 `source_building` 和 `target_unit` 必须明确标 `region` 字段
- 跨区域 inspiration 需要 O11 的"跨区域乘区链"显式支持（与训练 / 派系走同一路径）
- 禁止跨区域 inspiration 触发本区域未解锁的 source（用 O1 的章节 Gate 校验）

**反模式**：
- inspiration 默认全局生效 → 玩家提前解了某区域的 source，触发其他区域还没解锁的 target，破坏 O11 的"区域解锁节奏"
- 跨区域 inspiration 无 region 字段 → 数据可视化时丢失"这条灵感从哪个区域发出"

---

### ⚠️ AN-1 · P-AME × P-N

**现象**：P-AME 的 `Attribute.add()` 是全局聚合器（任何 system 都 push effect）；P-N 的 6-type transfer engine 是**局部节点间流转**。两者职责看似不重叠，但当 effect 在 node 间 transfer 时，何时"过 transfer engine vs 直接进 Attribute"需要明确。

**真实出处**：[cases/upload-labs/README.md § 3-4](../cases/upload-labs/README.md) — Upload Labs **同时用 P-AME 和 P-N**，但通过显式分层解决：P-N 处理"资源在 node 间流转"，P-AME 处理"全局 attribute 累加"。两者不互相调用。

**解决策略**：
- 显式分层：P-N 的 transfer engine 不调用 P-AME 的 `Attribute.add()`
- P-AME 的 effect 来源是 5 个 JSON 表（upgrades / research / perks / milestones / boosts），不包含 P-N 的 node
- 若需要"node 产出也影响 attribute"，用 P-N 的"type 4 SETTING"作为桥接（broadcast 到全局）

**反模式**：
- P-N 的 transfer engine 直接调用 P-AME → transfer 一次 attribute 累加一次，单次 tick 内 attribute 多次重复加
- P-AME 的 effect 来源包括 node → 数据来源混乱，无法判断"attribute 来自升级还是 node"

---

### ⚠️ O1-1 · O1 章节 Gate × O5 瓶颈平衡

**现象**：O1 的多资源 Gate 需要每个资源持有 ≥ 阈值；O5 的 bottleneck 判定"完成度最低的资源"在章节 Gate 边界处意义模糊——"已经 Gate 但还没产出的资源"算瓶颈吗？

**真实出处**：[cases/tower-wizard/README.md § 4-5](../cases/tower-wizard/README.md) — Tower Wizard 用 O1 + O5，bottleneck 判定明确：只看**Gate 要求的资源**，不看章节外资源。

**解决策略**：
- bottleneck 只在当前章节 Gate 的 `required_resources` 内判定
- 章节外的资源即使进度低也不计为瓶颈（避免 O5 的 focus 加成浪费在已通过 Gate 的资源上）

**反模式**：
- 全局所有资源都参与 bottleneck → 玩家 O5 focus 在不相关资源上
- 已通过 Gate 的资源仍参与判定 → 后续章节资源无瓶颈信号，玩家不知道刷哪个

---

### ⚠️ O3-1 · O3 挑战轴 × O5 瓶颈平衡

**现象**：O3 的"完成挑战 → cross_axis 反哺产线"通常修改主货币乘区；O5 的 bottleneck 加成也修改主货币乘区。两者的乘区需要明确"叠加顺序 vs 相乘顺序"。

**真实出处**：[cases/tower-wizard/README.md § 4](../cases/tower-wizard/README.md) — Tower Wizard 的 Destruction Blessing（O3 → O4 跨轴）和 Balance Blessing（O5）是分开的 UI 面板，但**乘区都进同一链**，需要在引擎层定义顺序。

**解决策略**：
- O3 的 cross_axis 反哺走"基础乘区"（最早 apply）
- O5 的 focus 加成走"条件乘区"（之后 apply）
- 显式乘区链：`final = base × O3_cross × O5_focus × O5_broad × ...`

**反模式**：
- O3 和 O5 的乘区相乘 → 玩家完成挑战 + 命中瓶颈时单次乘区超过 10×
- 顺序未定 → 调一个值影响另一个的等效数值，平衡不可控

---

### ⚠️ O5-1 · O5 瓶颈平衡 × O11 多区域

**现象**：O11 的多区域子系统意味着每个区域有自己的资源 DAG；O5 的"全局瓶颈"判定在多区域时**失效**——不同区域的瓶颈是不同的资源，全局单焦点无意义。

**真实出处**：[cases/tower-wizard/README.md § 5](../cases/tower-wizard/README.md) — Tower Wizard 的 Balance 祝福是**per-region 焦点**（每个区域选自己最缺的资源），不是全局。

**解决策略**：
- O5 的 focus 改为 per-region 焦点（每个 region 独立判定 bottleneck）
- O5 的 broad 仍然全局（避免 broad 也按 per-region 后失去跨区域意义）
- 每个 region 的 focus 等级独立升级（避免一个 region focus 等级影响另一个 region）

**反模式**：
- 全局 focus + 多区域 → 玩家只刷 1 个 region，其他 region 资源停滞
- per-region focus + per-region broad → 失去 broad 的"温和跨区域"作用

---

### ⚠️ N-1 · P-N 节点流水线 × O11 多区域

**现象**：P-N 的 node 通常属于某个区域；O11 的多区域意味着"跨区域 node"概念。如果 node 只能在自己区域内 transfer，那么区域间资源流靠什么？P-N 自身不解决跨区域。

**真实出处**：[cases/upload-labs/README.md § 4](../cases/upload-labs/README.md) — Upload Labs 的 node 都是单区域概念，没有显式跨区域 node。

**解决策略**：
- 跨区域资源流用 P-N 的"type 4 SETTING"广播机制——设一个全局"区域间 transfer node"
- 不用 P-N 的 node graph 表达区域间关系，改用 O11 自己的"跨区域乘区"机制（与训练 / 派系走同一路径）
- 文档化：P-N 处理"区域内部 node 流"，O11 处理"区域间资源流"

**反模式**：
- 在 O11 框架上硬塞 P-N 跨区域 node → 双套图维护，区域解锁节奏被打破
- 跨区域资源流靠全局 multiplier 隐式传递 → 玩家看不到资源从哪里来到哪里去，调试困难

---

## 冲突解决的通用规则

| 规则 | 说明 |
|---|---|
| **优先级显式化** | 冲突的乘区 / 公式必须有显式的调用顺序（"X 在 Y 之前 apply"），不能依赖隐式实现顺序 |
| **字段命名空间隔离** | 冲突的字段必须有不同前缀（如 P-AME 的 3-tuple vs P-E 的 stacking_policy） |
| **per-region / per-system 分层** | 全局 vs 局部分层：focus × broad 的 O5 处理、attribute vs transfer engine 的 P-AME × P-N 处理 |
| **数据 schema 校验** | 冲突字段必须在 schema 层校验（如 `if jump_tier: tuple.e = 0`） |
| **案例优先** | 没有 case 实证的冲突标"理论冲突"——实施前必须小范围 alpha 测 |

---

## 关联文档

- **依赖关系**：[patterns/README.md § 模式依赖图](README.md#模式依赖图)
- **通用反模式**：[docs/anti-patterns.md](../docs/anti-patterns.md)
- **决策树**：[GAME_DESIGN_GUIDE.md 附录 C 何时引入](../GAME_DESIGN_GUIDE.md#决策树何时引入)
- **Case 实证**：
  - P-R + P-T：[cases/shelldiver/README.md § 5](../cases/shelldiver/README.md)
  - P-P2：[cases/kittens-game/README.md § 8](../cases/kittens-game/README.md)
  - P-AME + P-N：[cases/upload-labs/README.md § 3-4](../cases/upload-labs/README.md)
  - P-C·跨建筑：[cases/gnorp/README.md § 9](../cases/gnorp/README.md)
  - P-E + 5 衰减时序：[cases/gnorp/README.md § 5](../cases/gnorp/README.md)
  - O1 + O5：[cases/tower-wizard/README.md § 4-5](../cases/tower-wizard/README.md)

---

## 维护规则

新增 Pattern 时必须：

1. 检查本表新增的 (Pattern × 已有 Pattern) 格子
2. 对每个非 ✅ 的格子写冲突详档
3. 在 case 实证列写明"实证"或"理论冲突"

修改 Pattern 时必须：

1. 重新检查与之冲突的 Pattern 的格子是否还准确
2. 同步修改对应冲突详档