﻿# Pattern E · 状态效果 Stack 系统（Status Effect Stack）

> **代号**：E
> **来源**：通用战斗增量设计规律沉淀（多款战斗型增量的细粒度状态系统共性）
> **首次出现**：本框架先前**未显式覆盖**——战斗增量中后期必备
> **案例参考**：[Gnorp](../cases/gnorp/README.md)（5 状态 5 衰减策略）、[Tower Wizard](../cases/tower-wizard/README.md)（Cursed / Molten / Frost / Weakened / Resonance）

战斗/资源型增量实战沉淀：**细粒度状态效果**（DOT / 易伤 / 缓速 / 增伤）是战斗轴的细粒度叠加器。用统一的 stack 结构管理，比按"buff 种类"硬编码更具扩展性。

---

## 完整结构

```text
effect_id
max_stacks               # 上限，1 = 不可叠层
duration                 # 秒；-1 = 永久直到被刷新 / 驱散
stacking_policy          # "refresh" / "extend" / "stack"
on_apply / on_tick / on_expire   # 三个回调钩子
percent_increase          # 每层加成（伤害 / 易伤）
tick_interval             # DOT 触发间隔
damage_per_tick           # DOT 单次
tag                       # 用于 buff 互斥 / 驱散分类
```

---

## 变体：经济轴 Permanent Effect（KG 实证）

> **来源**：[cases/kittens-game/README.md § 14](../cases/kittens-game/README.md) — `game.getEffect(name)` 单一聚合器 + 6 键扁平命名约定

战斗轴的 status stack（DOT / 易伤 / 衰减）有一个**非战斗对应物**：每个建筑、升级、科技、宗教祝福等都在引擎里 push 一个**永久 effect 键**到全局字典，引擎只通过 `getEffect(name)` 一次聚合。两条轴共享"stack 累加 + 命名约定 + 单一聚合器"的设计骨架，但：

| 维度 | 战斗型 Pattern E | 经济型（KG 变体） |
|------|------------------|-------------------|
| 持续时间 | `duration` / `-1=永久` | **全部为永久**，无 duration / tick / on_expire |
| 衰减 | 有（`decay_start` 公式） | 无 |
| 叠加策略 | `refresh` / `extend` / `stack` | **总是 stack**（加法或乘法由调用方决定） |
| 适用对象 | 单一战斗目标 / 玩家自身 | 全局所有产线（任何 `getEffect` 都会读到） |
| 典型 tag | `physical` / `magical` / `curse` | 资源名 + 维度（`catnipRatio` / `barn-catnipMax`） |

### 6 键命名约定（KG 实证）

所有 effect 键遵循**严格前缀**，引擎不 type-check，只用前缀做人类可读的语义分组：

| 前缀 | 含义 | 引擎语义 | 例子 |
|------|------|---------|------|
| `XxxPerTickBase` | 资源基础 per-tick 产量 | 加法累加 | `catnipPerTickBase: 0.125`（field） |
| `XxxPerTick` | 资源 per-tick 产量（与 base 区分） | 加法累加 | `unobtainiumPerTick: 0.5`（moonOutpost） |
| `XxxRatio` | 资源乘区 | 与 base 相乘 | `catnipRatio: 0.5`（hydroponics） |
| `XxxMax` | 资源存储上限乘区 | 与 maxValue 相乘 | `barn-catnipMax: 1.5`（barn） |
| `XxxCostReduction` | 建筑/资源成本折扣 | `(1 - reduction)` 截断到 1.0 | `fieldCostReduction: 0.1`（tier-3 kit） |
| `XxxJobRatio` | 单位工作产出加成 | 与 per-cat 产量相乘 | `farmerJobRatio: 0.5`（mineralHoes） |

> 关键：键名是**字符串**，引擎 `getEffect(name)` 只是在全局字典里 sum，**没有 enum / 没有 type check**。平衡改动永远是 `+0.05` 到一个键，不是 refactor。

### 单一聚合器（KG 实证）

```text
# core.js 核心逻辑
getEffect(name):
    total = 0
    for source in (resources, buildings, techs, upgrades, religion,
                   space, time, prestige, challenges, calendar, village, voidspace):
        total += source.get(name, 0)
    return total
```

每个 system（10+ 个 manager）独立 push 自己的 effect 键；调用方**只关心键名、不关心来源**。这是把 Pattern E 的"tag + 多效果"思想推到极致：**没有任何分类 schema，仅靠键名约定 + 单点聚合**。

### 与战斗 Pattern E 共享的反模式

- **不要给"per-tick"键加 duration**（KG 经验：duration 在经济轴上没有意义——要么是永久加成、要么是临时任务）
- **不要混用加法键和乘法键**（`PerTickBase` 是加到 base，`Ratio` 是乘到 base，二者必须分开命名）
- **不要把多个独立维度塞进同一个键**（`catnipPerTickBase` 不能既包含 jobs 也包含 buildings）
- **discount 必须截断**（`getLimitedDR(discount, 1.0)`，否则多个 50% 折扣相乘会变成负成本）

### 适用场景

- 资源型增量（10+ 资源、5+ 产线、3+ 永久项系统）
- 多 manager（建筑/科技/宗教/太空各自 push 自己的 effect）
- 不需要类型安全的项目（用命名约定 + schema 校验替代 enum）

---

## 衰减公式（典型实践）

```text
decay_start = blessing_of_effects.decay × 等级
若 effect != Frost:
    decay_start += Frost层数           # Frost 不被 Frost 衰减

decay = ((max(0, stacks - decay_start)) / 100) ^ 1.15
stacks = max(0, stacks - decay)
```

**每 0.1s tick** 跑一次衰减。

---

## 三种叠加策略

| 策略 | 公式 | 适用 |
|------|------|------|
| `refresh` | 重置 duration，stacks 不变 | 易伤、增伤类（**最常用**） |
| `extend` | duration 累加 | DOT、中毒 |
| `stack` | stacks += applied，duration 取新值 | 叠加型减益（Weakened、Resonance） |

---

## 与战斗乘区集成

```text
damage_multiplier =
    (1 + 永久挑战加成)
  × Π (1 + effect.stacks × effect.percent_increase / 100)  # 每效果相乘
  × (1 + 易伤层数 × debuff_percent / 100)
  × 战斗技能 × 派系 / 科技
```

**关键规则**：

- 易伤 / 增伤类**相乘**而非相加 → 避免单一 boss 叠满打崩平衡
- DOT 与玩家技能伤害走**同一条**伤害乘区链 → 避免"DOT 一套、瞬伤一套"
- tag 字段用于 buff 互斥（如 `physical / magical / curse`）

---

## 字段参考

| 字段 | 含义 | 示例 |
|------|------|------|
| `effect_id` | 唯一标识符 | `weakened`、`frost` |
| `max_stacks` | 上限 | weakened=10、frost=5 |
| `duration` | 秒；-1 = 永久 | weakened=5.0、frost=-1 |
| `stacking_policy` | 叠加方式 | `refresh` / `stack` |
| `percent_increase` | 每层加成 | weakened=20% / 层 |
| `tick_interval` | DOT 间隔 | 燃烧 1s / tick |
| `damage_per_tick` | DOT 单次 | 基础伤害 × 5% / tick |
| `tag` | 分类 | physical / magical / curse |
| `decay_start` | 衰减起始 | 默认 0；被 Frost 等加速 |
| `decay_strategy` | 衰减时序类型 | `tick` / `time` / `charge` / `event` / `element-gated` |

---

## 5 段式衰减时序（Gnorp 实证）

> **来源**：[cases/gnorp/README.md § 5](../cases/gnorp/README.md) — (the) Gnorp Apologue 5 种 status effect 各用不同衰减时序

上文 [三种叠加策略](#三种叠加策略)(`refresh`/`extend`/`stack`)回答的是"**再次施加时怎么累加**";本节回答的是另一个正交问题:"**已存在的 stack 何时减少 / 消失**"。把它显式建模为 `decay_strategy` 字段,避免"所有状态都用同一套 tick 衰减"导致的语义错配。

### 5 种衰减时序

| `decay_strategy` | 何时减少 | 典型用途 | gnorp 例 |
|------------------|----------|----------|----------|
| **`tick`** | 每 tick 按公式衰减剩余量 | DOT 烧伤、自然消退 | Fire(每 tick 烧 10% 剩余) |
| **`time`** | 固定时长后整体消失 | 限时增益/易伤 | Vulnerability(15s 后失效) |
| **`charge`** | 每次生效消耗 1 充能,耗尽即除 | 次数型 buff | Zybe(3x 增伤 5 次用尽) |
| **`event`** | 由外部事件触发清除/转化 | 蓄爆、周期重置 | Ice(蓄积 4s→shatter 清空)/ Acid(CE 时清) |
| **`element-gated`** | 仅当另一元素条件满足才衰减/共存 | 元素互斥/联动 | Frost 不被 Frost 衰减(本案 §衰减公式);Frostfire 让冰火共存 |

### 5 种时序伪代码

```text
decay_step(active, dt, now, events):
    s = active.effect.decay_strategy

    if s == "tick":            # 按剩余比例衰减
        active.stacks -= active.stacks * tick_decay_pct

    elif s == "time":          # 到期整体清除
        if now >= active.expires_at: remove(active)

    elif s == "charge":        # 不随时间变,生效时 consume_charge() 扣减
        pass                    # 见 consume_charge()

    elif s == "event":         # 等外部事件(shatter / CE / wave)
        if active.effect.trigger_event in events:
            on_event_resolve(active)   # 如 ice→shatter 释放 2x 蓄积伤害后清空

    elif s == "element-gated":  # 受其它元素 stack 调制
        if not gated_by(active, other_stacks):
            active.stacks -= active.stacks * tick_decay_pct

consume_charge(active):         # charge 型专用:每次生效调用
    active.stacks -= 1
    if active.stacks <= 0: remove(active)
```

### gnorp 5 status 完整映射

| status | `decay_strategy` | `stacking_policy` | 备注 |
|--------|------------------|-------------------|------|
| Fire | `tick` | `extend` | 每 tick 烧 10% 剩余;Superhot 2.5x dmg 6x tick |
| Ice | `event` | `stack` | 6 hit 触发 freeze,蓄积 4s 后 shatter(2x);Supershatter 25s |
| Vulnerability | `time` | `refresh` | 240 rockets 触发,15s,后续不延时 |
| Zybe | `charge` | `stack` | 3x 增伤 5 charges,自身 0 dmg |
| Acid | `event` | `extend` | DOT,CE 时随 pile 清;Enriched Puke 2x |

> 关键洞察:Pattern E 的两个正交维度 = `stacking_policy`(施加累加)× `decay_strategy`(消退时序)。gnorp 5 status 几乎覆盖二者的全部组合,是该正交结构的最完整实证。

---

## 反模式

| 反模式 | 后果 |
|--------|------|
| 按 buff 种类硬编码（"每种状态一套 switch"） | 失衡、扩展性差 |
| 易伤类用加法（`+ stacks × p`） | 单一 boss 叠满打崩 |
| DOT 走独立伤害链 | 玩家需分别堆 DOT 与瞬伤 |
| 多效果同源用相加 | 重复刷同一效果数值翻倍 |
| duration=0 立即过期 | 与"短暂增益"语义混淆 |
| 用错衰减时序（如 charge 型用 tick 衰减） | charge buff 永不耗尽 / DOT 立即消失 |
| 混用衰减时序于同一 effect | 难以推理何时消退,平衡不可控 |

---

## 适用场景

- 战斗增量（DOT / 易伤 / 缓速 / 增伤）
- 资源型（生产加速 / 幸运加成 / 采集翻倍）
- 终局段（boss 战的 debuff 链）

---

## 配套

- **依赖**：[o03-challenge-axis.md](../optional/o03-challenge-axis.md)（战斗目标）
- **跨轴**：[o04-cross-axis-feedback.md](../optional/o04-cross-axis-feedback.md)（状态伤害 → 产出链）
- **数据**：[schemas/status-effect.schema.json](../schemas/status-effect.schema.json)
- **示例**：[examples/configs/example-status-effect.json](../examples/configs/example-status-effect.json)
- **伪代码**：[examples/pseudocode/apply-status-effect.md](../examples/pseudocode/apply-status-effect.md)
- **案例**：[Tower Wizard 5 种状态](../cases/tower-wizard/README.md) — Cursed / Molten / Frost / Weakened / Resonance

---

## 数据 Schema（速览）

```json
{
  "effect_id": "weakened",
  "max_stacks": 10,
  "duration": 5.0,
  "stacking_policy": "stack",
  "percent_increase": 20,
  "tick_interval": null,
  "damage_per_tick": null,
  "tag": "physical",
  "decay_exempt": false
}
```

完整定义见 [schemas/status-effect.schema.json](../schemas/status-effect.schema.json)。