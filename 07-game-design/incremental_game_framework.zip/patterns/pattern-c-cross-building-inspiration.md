﻿# Pattern C·跨建筑 Inspiration 链（Cross-building Inspiration Chain）

> **代号**：C（跨建筑变体）
> **来源**：[cases/gnorp/README.md § 9](../cases/gnorp/README.md) — (the) Gnorp Apologue 11 个 inspirations + 6 个 source building 实证
> **首次出现**：原框架 [core/06 § Pattern C](../core/06-permanent-upgrades.md) 是"条件专精"广义；[O4 跨轴反馈](../optional/o04-cross-axis-feedback.md) 是纯数值型;[O8 辅助系统](../optional/o08-support-systems.md) 列了 5 类辅助。三者都**没有**"建筑 A 启发出建筑 B 的单位 + 触发条件 + 互斥/可叠加"的标准模板。本 Pattern 把它显式化。

实战沉淀：当多产线增量(O11 多区域)需要让**区域之间互相增益**,而不是各自独立时,"跨建筑 Inspiration 链"是一种比"全局乘区"更有策略深度的设计：**源建筑达成某条件 → 目标建筑的单位获得永久被动**。玩家通过"安排哪个建筑启发哪个单位"做策略选择,而不是无脑堆数值。

---

## 与 Pattern C / O4 / O8 的关系

| 维度 | core/06 Pattern C（广义条件专精） | O4 跨轴反馈 | O8 辅助系统 | **本 Pattern C·跨建筑变体** |
|------|----------------------------------|-------------|-------------|------------------------------|
| 增益来源 | 永久点购买的条件项 | 挑战强度 `cross_axis` 映射 | 训练/派系/遗物/放置物/同伴 | **另一个建筑达成条件** |
| 触发方式 | 满足 if 条件 | `tier = floor(log10(power))` | 子项各自公式 | **source 建筑的单位数/状态/资源** |
| 作用对象 | 当前产线 | 主货币/副产物/O2 经验 | 全局乘法链 | **target 建筑的特定单位** |
| 玩家决策 | 选哪个专精 | 无(自动公式) | 选练哪个训练 | **选哪个 source 启发哪个 target** |
| 数值 vs 事件 | 数值 | 数值 | 数值 | **数值 + 事件(单位行动触发)** |

> 关键：本 Pattern 是 core/06 Pattern C(条件专精)的**跨建筑具体化**,与 [Pattern C7 自选永久 Debuff](pattern-c7-opt-in-debuff.md) 是同一 C 家族的两个不同变体(C7=自我减益换 prestige;本 Pattern=建筑互相增益)。

---

## 4-tuple 模板

每个 inspiration 是一个 **4 元组**:

```text
inspiration:
    id: "express_attunement_mountaineer"
    source_building: "the_express"      # 谁发出启发
    target_unit: "runner"               # 谁被启发(target 建筑的单位)
    trigger_condition: { type, value }  # 触发条件(见下文 3 类)
    effect: { stat, op, value }         # 效果(乘/加到 target 单位的某属性)
    type: "passive" | "active"          # 永久被动 / 主动开关
    stackable: bool                     # 是否可与同 target 的其它 inspiration 叠加
```

**gnorp 实证**:`Mountaineer Inspiration` = `the_express` 在有 `5 mountaineers` 时,让 `runner` 获得 `capacity +10%/mountaineer`。

---

## 触发条件 3 类

| 类 | `trigger_condition.type` | 含义 | gnorp 例 |
|----|--------------------------|------|----------|
| **单位数** | `unit_count` | source 区域单位 ≥ N | `5 Mountaineers` → Runner capacity |
| **状态** | `state_active` | 某状态/升级已激活 | `Garden Director spawned` → Runner G.E.E.T. |
| **资源** | `resource_owned` | 持有某资源 ≥ N | `1 Zybe collected` → Zybellium Collection 解锁 |

```text
check_trigger(inspiration, state):
    cond = inspiration.trigger_condition
    if cond.type == "unit_count":
        return state.unit_count(cond.source_unit) >= cond.value
    if cond.type == "state_active":
        return state.is_active(cond.flag)
    if cond.type == "resource_owned":
        return state.resource(cond.resource) >= cond.value
```

---

## 互斥 vs 可叠加 2 种类型

gnorp 同一 target 建筑内的多个 inspiration **互斥**(玩家点圆圈选一个),但**不同 source 发出的可叠加**:

| 类型 | 规则 | gnorp 例 |
|------|------|----------|
| **互斥(同建筑内)** | 同一 target 建筑的 inspiration slot 只能选 1 个 | Academy 的 Runner/Drone/Mountaineer Attunement 三选一 |
| **可叠加(跨建筑)** | 不同 source 发出的、作用于不同 stat 的可同时生效 | Runner 同时吃 Mountaineer(capacity) + Director(G.E.E.T.) |

```text
resolve_target(target_unit, state):
    mult = 1.0
    selected = state.selected_inspiration(target_unit)   # 互斥槽:玩家选的那个
    if selected and check_trigger(selected, state):
        mult *= apply_effect(selected.effect, state)
    for insp in state.stackable_inspirations(target_unit): # 可叠加:不同 source
        if check_trigger(insp, state):
            mult *= apply_effect(insp.effect, state)
    return mult
```

---

## gnorp 11 个 inspiration 完整映射

| # | source building | target | trigger | effect | 类型 |
|---|-----------------|--------|---------|--------|------|
| 1 | The Express | Runner | 5 Mountaineers | capacity +10%/mtn | 可叠加 |
| 2 | The Express | Runner | 1 Zygnorp | G.E.E.T. +boost | 可叠加 |
| 3 | Express + Garden | Runner | Director spawned | G.E.E.T. +5% | 可叠加 |
| 4 | The Express → Cocoa | Zygnorp | 20 Runners | 收集 40%→80% | 互斥 |
| 5 | Garden(red) | Mountaineer | red flower | Hulk shockwave 16x | 可叠加 |
| 6 | Runner → Slammer | Slammer | 10 Runners | Motivation(2x dmg) | 可叠加 |
| 7 | Garden(green) | Bomber | weakspot + Garden | weakspot proc +5% | 互斥 |
| 8 | Academy → Bomber | Bomber | 3 Zygnorps | timeshift +1/级 | 互斥 |
| 9 | Cocoa → Bomber | Bomber | 8 Mountaineers | pocket rocket 5%派送 | 互斥 |
| 10 | Academy(3 attunements) | Zygnorp | 20 run/10 drone/15 mtn | 收集 ×2(各源) | 互斥 |
| 11 | Rock Analysis Lab Balloon | Rock | Balloon + 闲时 | 射 riflegnorp bullet | 可叠加 |

> 6 个 source building:The Express / Cocoa Cafe / Gnorp Propulsion Lab / Academy / The Garden / Rock Analysis Lab。

---

## 实现伪代码骨架

完整伪代码见 [examples/pseudocode/inspiration-resolver.md](../examples/pseudocode/inspiration-resolver.md);配置示例见 [examples/configs/example-cross-building-inspiration.json](../examples/configs/example-cross-building-inspiration.json)。

```text
# 挂在 O8 辅助系统(乘入 typed_bonuses)或 O4 跨轴反馈(乘入 cross_axis)
get_unit_multiplier(target_unit, state):
    base = 1.0
    return base × resolve_target(target_unit, state)  # 见上文
```

---

## 关键设计规则

### 1. source ≠ target 建筑

inspiration 的本质是"**跨建筑**",source 与 target 必须是不同建筑/区域。同建筑内的增益应走普通升级(core/04),不是 inspiration。

### 2. 互斥槽提供策略,可叠加提供深度

- **互斥槽**(同 target 建筑选 1 个):制造"机会成本",玩家必须取舍。
- **可叠加**(不同 source):奖励玩家发展多个 source 建筑。
- 二者搭配才有策略深度——全互斥太死,全可叠加退化成无脑堆。

### 3. trigger 用条件,不用单位类型本身

错误:"Runner 存在就启发 Slammer"(等于无条件)。正确:"≥10 Runner 才启发 Slammer"(有门槛,值得规划)。

### 4. 多个 inspiration 累加要设计上限或递减

gnorp `capacity +10%/mountaineer` 若无上限,后期 100 mountaineer = +1000%。要么设 cap,要么用 `(1+p)^group` 分组递减(参考 [O8 放置物分组复合](../optional/o08-support-systems.md))。

---

## 反模式

| 反模式 | 后果 |
|--------|------|
| source 与 target 同一建筑 | 退化成普通升级,失去"跨建筑"策略 |
| 用单位类型本身当 trigger(无门槛) | 等于无条件永久 buff,无规划价值 |
| 全部互斥 | 玩家永远只选最强的一个,其它是死配置 |
| 全部可叠加且无 cap | 后期数值爆炸,平衡崩溃 |
| trigger 条件不可视化 | 玩家不知道"还差几个单位解锁" |
| inspiration 改变规则而非数值/事件 | 与"另一个游戏"无异,难平衡 |

---

## 适用场景

- 多产线 / 多区域(O11)增量,需要区域之间产生策略性互动时
- 想要"安排谁帮谁"的 build 深度,而不是无脑全局乘区时
- 已有 O4(跨轴)/ O8(辅助)但觉得"增益来源太单一"时

## 配套

- **基础**:[core/06-permanent-upgrades.md § Pattern C](../core/06-permanent-upgrades.md) — 广义条件专精
- **挂载点**:[optional/o04-cross-axis-feedback.md](../optional/o04-cross-axis-feedback.md) / [optional/o08-support-systems.md](../optional/o08-support-systems.md)
- **多区域前提**:[optional/o11-multi-region.md](../optional/o11-multi-region.md)
- **同 C 家族变体**:[patterns/pattern-c7-opt-in-debuff.md](pattern-c7-opt-in-debuff.md)
- **伪代码**:[examples/pseudocode/inspiration-resolver.md](../examples/pseudocode/inspiration-resolver.md)
- **配置**:[examples/configs/example-cross-building-inspiration.json](../examples/configs/example-cross-building-inspiration.json)
- **数据**:[cases/gnorp/inspirations.json](../cases/gnorp/inspirations.json)(11 个 inspiration)
- **案例**:[cases/gnorp/README.md § 9](../cases/gnorp/README.md)
