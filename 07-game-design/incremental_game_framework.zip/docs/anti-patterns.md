﻿# 反模式总目录（唯一权威源）

> 本文件是框架**全部反模式的唯一权威目录**。各 core / pattern / optional / schema 文档保留各自的详细反模式描述（含上下文），本目录负责**汇总 + 去重 + 索引**。
>
> 维护规则：新增反模式时，先在对应专题文档写详细描述，再在此处登记一行（带链接）。根 [README.md](../README.md#反模式) 的反模式表是面向初学者的"跨模块速查"，应指向本目录，不再各自维护独立全量副本。

---

## 1. Core（核心循环）

> 详见 [core/README.md § 反模式](../core/README.md)

| 反模式 | 后果 |
|--------|------|
| 只有指数 sink、无 Reset / 永久 | 硬顶流失 |
| 永久仅加法、成本纯指数 | 追不上曲线 |
| 全局单一 bonus | 无法专精与平衡 |
| 无终点且无软顶 | 动机衰竭 |
| 抄固定 tier / Reset 点数当标准 | 误套其他题材 |
| 数值写死代码不抽配置 | 无法调参与版本对比 |

伪代码层（[examples/pseudocode/](../examples/pseudocode/)）：

| 反模式 | 后果 | 来源 |
|--------|------|------|
| XP 来源未经过 `gain_xp` | 失去 cap 校验 | [gain-xp.md](../examples/pseudocode/gain-xp.md) |
| 资源未经过 `on_resource_added` | Reset XP / 任务 / 统计丢失 | [add-resource.md](../examples/pseudocode/add-resource.md) |
| 跳过 `can_afford` 检查 | 资源为负 | [purchase.md](../examples/pseudocode/purchase.md) |
| `grants_resource` 不传 `apply_global=False` | 全局加成重复 | [purchase.md](../examples/pseudocode/purchase.md) |

---

## 2. Patterns（落地模式）

> 跨模式共性见 [patterns/README.md § 反模式](../patterns/README.md)

| 反模式 | 后果 | 来源 |
|--------|------|------|
| Pattern T 跳跃太便宜 | 全满级无目标 | [pattern-t](../patterns/pattern-t-tier-jump.md) |
| Pattern T 跳跃太贵 | 玩家看不到进度放弃 | [pattern-t](../patterns/pattern-t-tier-jump.md) |
| Pattern T 数值倍率与成本倍率倒挂 | 跳过最高级直接点次高级 | [pattern-t](../patterns/pattern-t-tier-jump.md) |
| Pattern R 概率只有 1 条技能 | 玩家不知道优先升级哪条 | [pattern-r](../patterns/pattern-r-rarity.md) |
| Pattern R 顶部档概率成长过慢 | 玩家永远抽不到，失去追求 | [pattern-r](../patterns/pattern-r-rarity.md) |
| Pattern R 价值 / 概率倒挂 | 玩家专攻低档无风险套利 | [pattern-r](../patterns/pattern-r-rarity.md) |
| Pattern R 档位 5 档以上 / 少于 3 档 | 玩家难区分 / 失去分层意义 | [pattern-r](../patterns/pattern-r-rarity.md) |
| Pattern D 1 个池挂 5+ 链 | 万能钥匙、失去选择性 | [pattern-d](../patterns/pattern-d-dual-pool.md) |
| Pattern D ratio_k 跨链不一致 | 玩家专攻最高 ratio 链，其它荒废 | [pattern-d](../patterns/pattern-d-dual-pool.md) |
| Pattern S 所有技能同档 | 决策疲劳或无目标 | [pattern-s](../patterns/pattern-s-skill-tiers.md) |
| Pattern S 核心轴过多（>5） | 货币分散，每条都点不满 | [pattern-s](../patterns/pattern-s-skill-tiers.md) |
| Pattern B 用指数曲线给开关 | 浪费玩家"是否要点"的认知预算 | [pattern-b](../patterns/pattern-b-binary-unlock.md) |
| Pattern B 开关 > 3 级 | 失去"二进制"语义 | [pattern-b](../patterns/pattern-b-binary-unlock.md) |
| Pattern E 按 buff 种类硬编码 | 失衡、扩展性差 | [pattern-e](../patterns/pattern-e-status-stack.md) |
| Pattern E 易伤 / 增伤用加法 | 单一 boss 叠满打崩平衡 | [pattern-e](../patterns/pattern-e-status-stack.md) |
| Pattern E DOT 走独立伤害链 | 玩家需分别堆 DOT 与瞬伤 | [pattern-e](../patterns/pattern-e-status-stack.md) |
| Pattern E 用错衰减时序 | charge buff 永不耗尽 / DOT 立即消失 | [pattern-e](../patterns/pattern-e-status-stack.md) |
| Pattern C·跨建筑 source / target 同一建筑 | 退化成普通升级，失去跨建筑策略 | [pattern-c-cross-building](../patterns/pattern-c-cross-building-inspiration.md) |
| Pattern C·跨建筑 全部互斥 / 全部无 cap 叠加 | 死配置 / 数值爆炸 | [pattern-c-cross-building](../patterns/pattern-c-cross-building-inspiration.md) |
| Pattern P2 单一 currency 假装双 currency | 长期投资不存在 | [pattern-p2](../patterns/pattern-p2-dual-prestige.md) |
| Pattern P2 两种 currency 共用 cap | 长期 currency 无法积累 | [pattern-p2](../patterns/pattern-p2-dual-prestige.md) |
| Pattern C7 debuff 奖励 < 代价 | 玩家全部关闭，机制失效 | [pattern-c7](../patterns/pattern-c7-opt-in-debuff.md) |
| Pattern C7 强制开启不可关闭 | 玩家感到被惩罚 | [pattern-c7](../patterns/pattern-c7-opt-in-debuff.md) |
| Pattern N Engine 知道 node 身份 | 每加一个 node 改 engine | [pattern-n](../patterns/pattern-n-node-pipeline.md) |
| Pattern N type 字段硬编码到 engine | 不能复用 input slot | [pattern-n](../patterns/pattern-n-node-pipeline.md) |
| Pattern PR Service 触发 reboot | 退化为 hard prestige | [pattern-pr](../patterns/pattern-pr-service-soft-reset.md) |
| Pattern PR Service cost 随 refund 线性增长 | 玩家循环刷退款套利 | [pattern-pr](../patterns/pattern-pr-service-soft-reset.md) |
| Pattern AME 多个 schema 混用 | dispatcher 代码爆炸 | [pattern-ame](../patterns/pattern-ame-3tuple-attribute.md) |
| Pattern AME `add()` 不幂等 | 读档后 effect 双倍叠加 | [pattern-ame](../patterns/pattern-ame-3tuple-attribute.md) |

---

## 3. Optionals（可选模块）

> 总表见 [optional/README.md § 反模式](../optional/README.md)

| 反模式 | 后果 | 来源 |
|--------|------|------|
| O1 门槛值 < 前置建筑容量 | 玩家绕过前置直接解锁 | [o01](../optional/o01-chapter-gates.md) |
| O1 用灰显而非隐藏 | 玩家盯着买不起的东西挫败 | [o01](../optional/o01-chapter-gates.md) |
| O3 与产出完全独立 | 后期一线废弃 | [o03](../optional/o03-challenge-axis.md) |
| O4 与 O3 指标不一致 | 跨轴失效 | [optional/README](../optional/README.md) |
| O5 单层乘区（无 Broad） | 多资源时玩家只刷一个，其它停滞 | [o05](../optional/o05-bottleneck-balance.md) |
| O5 focus × broad = 加法 | 高等级时乘区爆炸 | [o05](../optional/o05-bottleneck-balance.md) |
| O5 折扣直接相乘 / 缺 cap | 折扣叠加失控、0 成本崩溃 | [o05](../optional/o05-bottleneck-balance.md) |
| O7 无防刷 | 后期点数通胀 | [optional/README](../optional/README.md) |
| O9 跳级无视觉差异 / 与普通升级混淆 | 玩家不知已到顶 / 误判 | [o09](../optional/o09-interaction-qol.md) |
| O11 区域独自引用其它区域资源 | 失去 DAG 独立性 | [o11](../optional/o11-multi-region.md) |
| O11 区域数 >10 活跃 | 玩家认知负担爆炸 | [o11](../optional/o11-multi-region.md) |
| O13 单层时间 / 4 层同类 | 玩家 1 局内化，失去新鲜感 | [o13](../optional/o13-temporal-multicycle.md) |
| O13 组合数 > 200 | 玩家放弃预判，靠运气 | [o13](../optional/o13-temporal-multicycle.md) |

---

## 4. Schema / 示例 / 案例数据 / 贡献（工程层）

写 Schema 时（[schemas/README.md](../schemas/README.md)）：

| 反模式 | 后果 |
|--------|------|
| 用 `patternProperties` 放业务规则 | 失去类型提示 |
| 缺少 `allOf` 业务约束 | 不验证 Pattern T/S 联动 |
| `if` 只写 `properties` 不写 `required` | 字段缺失时 `if` 真空为真，误触发 `then`（历史 bug 根因） |
| `enum` 写中文 | 不利于国际化 |
| `$id` 用相对路径 | 跨项目无法复用 |

案例数据（[cases/README.md](../cases/README.md)）：

| 反模式 | 后果 |
|--------|------|
| 顶层直接是 list | id 无法稳定引用、无处放 `_source` |
| 在 case data 写 `$schema` 强校验原生字段 | 原生字段名 ≠ 框架概念名，校验必失败 |
| `metadata.json` 缺 `_source` | 数值无法追溯 |
| 跨 case 引用数据 | 案例互相耦合 |

贡献时（[CONTRIBUTING.md](../CONTRIBUTING.md)）：见该文件 § 反模式。

---

## 5. 流程反模式（设计 / 实现 / 调优）

> 详见 [GAME_DESIGN_GUIDE.md 附录 C 反模式](../GAME_DESIGN_GUIDE.md#附录-c反模式与决策树)

- **设计**：没参考 case 从零发明；DAG 节点 > 12；没限制资源；节奏曲线没有 M0；M3 reset < 5min；M5 endgame 没内容
- **实现**：M6 阶段做 UI；数值写死代码；顶层用 list；cost 不带 `cost_inc`；没用 schema 验证；save/load 不测试；UI 层内嵌业务逻辑
- **调优**：用人工试玩代替批量模拟；一次改 5 个变量；改完不写 changelog；不看 5 类指标就调；"数据不好就重做"

---

## 6. 真实反例（案例实证）

| 反例 | 说明 | 来源 |
|------|------|------|
| Gnorp X-rockets `C2 5.0^n` | 单升级 3.04M → 15.2M → 76M，玩家资源完全跟不上，只能买 1-2 次 | [cases/gnorp/README.md](../cases/gnorp/README.md) |
