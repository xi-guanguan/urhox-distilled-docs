# 增量游戏数值设计手册（按游戏模式分章）

> **独立文档**：可单独拷贝使用，不依赖任何外部资料。
> **读者**：策划填表、程序员实现引擎、调优时对照。
> **原则**：数值写配置（JSON），逻辑写代码；先选「游戏模式档案」（§2），再按「通用公式」（§3），最后按 §6 调优手册微调。

---

## 目录

1. [游戏模式档案的必要性](#1-游戏模式档案的必要性)
2. [8 种游戏模式档案（按 case 实证）](#2-8-种游戏模式档案按-case-实证)
3. [通用基础：成本 / 产出 / Reset 公式与字段约定](#3-通用基础成本--产出--reset-公式与字段约定)
4. [起步 JSON 模板（中型 MVP）](#4-起步-json-模板中型-mvp)
5. [引擎伪代码（最小实现）](#5-引擎伪代码最小实现)
6. [调优手册（症状 → 旋钮）](#6-调优手册症状--旋钮)
7. [交付检查清单](#7-交付检查清单)
8. [公式速查卡](#8-公式速查卡)
9. [反模式速查](#9-反模式速查)

---

## 1. 游戏模式档案的必要性

增量游戏的"数值"长得很像，但**主角动词**不同：

| 主导动词 | 代表 | 核心 sink | 数值特征 |
|---------|------|----------|----------|
| **点击 / 点击杀怪** | 经典 Clicker 形态 | 升级 + 杀怪 | 主货币爆炸增长，配角最低 |
| **资源采集 / 建造** | Kittens Game / Farm 形态 | 时代门槛 + 资源链 | 货币多、DAG 长、节奏跨时代 |
| **塔层 / 区域破关** | Tower Wizard 形态 | 墙 HP + 区域门槛 | 多区域分段，强 Gate |
| **节点流水线** | Upload Labs 形态 | 节点 + 配线 | 单引擎 + 多 currency transfer |
| **物理 / 合成** | Gnorp 形态 | 收集速率 + 压缩事件 | 单 prestige + 跨建筑 inspiration |
| **战场 + 召唤 + 战斗** | 经典战斗增量 | 怪 HP + 角色升级 | 战斗 + 经济双轨 |
| **跨 run 主题循环** | Agrivore 形态 | 主题 currency + 跨 run skill tree | 多 currency + Treasury pool |
| **塔防 + 灾变** | DEM 形态 | boss 山 + 灾变 + 多阶段神器 | 长程 prestige + artifact 多类型 |

> **关键区别**：在"点击 + 升级"数值模板里默认的"主轴 3 条、成本增长 ×10、首次 Reset +20%"，
> 直接套用到"塔层 + 区域破关"游戏会**完全失效**——破墙游戏主角是 HP，玩家买的是"伤害 buff"，不是"主货币 ×10"。
>
> 因此本手册**不再**把所有游戏的数值规则混写在"五规则"里，而是给**8 种真实存在的游戏模式**各开一节独立数值档案，所有数值都标出来源 case。

**怎么用本手册**：

1. §2 挑出最像的 1 个模式档案
2. §3 取通用公式（C1-C6 / add_resource / Reset XP）作为基础引擎
3. §4 拷一份中型起步 JSON，按 §2 模式的"特征档"参数替换
4. §5 拷引擎伪代码实现最小可玩
5. §6 按 M7 实测指标微调（用对应模式档案的"症状 → 旋钮"段）

**不要做的事**：

- ❌ 把 §2 当"风格推荐"——每个档案的数值来自真实 case，**挪到不当的题材会失效**
- ❌ 跨模式"挑喜欢的字段"——不同模式的字段集合是耦合的（见 §9 反模式）
- ❌ 没有 case 支撑就自己组合——若新游戏是 §2 之外的形态，请先按 §3 通用基础搭最小，再补"自创档案"段并写 changelog

---

## 2. 8 种游戏模式档案（按 case 实证）

每节字段统一：题材与时长大档、案例引用、metric 档、特征表（核心 sink / 主货币增长速率 / Reset 类型 / 必含 Pattern）、数值锚点（货币 / 主轴 / 跳级 / Reset 收益）、常见配方、常见变体、起始最小集、调优旋钮。

---

### 2.1 模式 A：Cozy 探险 + 收集 + 多区域（Shelldiver 档案）

**题材 & 时长**：cozy 探险 / 短游戏 / 约 4 小时一次通关 / **无 Reset**。

**案例**：[Shelldiver](../cases/shelldiver/README.md)（App ID 3862670，GameMaker 2024.x，4 个生态区 + 88 个技能 + 11 个模块）。

**判断为该模式的特征**：玩家玩一下午就能玩到 100%；游戏**没有** reset / 不靠"再来一局"留住玩家；解锁是关卡/区域级而非时代级；副货币是"区域采集"而非"prestige"。

| 项 | 锚点 |
|----|------|
| **核心 sink** | 88 个技能的核心 4 条（Oxygen Tank / Bubble Damage / Plasma Damage / Store Speed） |
| **主货币增长** | T1/T2 自动 + T3 进度满结算；不靠指数爆炸，靠**深度探索** |
| **Reset 类型** | **无 reset**—— 改为"探索深度 = 进度条 + 多生物群落分段" |
| **必含 Pattern** | Pattern R（多档稀有度）+ Pattern S（核心 4 + 次要 50 + 开关 33）+ Pattern T（跳 8→10）+ Pattern B（解锁式 26 个）+ Pattern D（限制资源跨多链路） |
| **货币数量** | 6 个（主 + 4 资源货币 + 1 终局炼金） |
| **生态区** | 4 个，按"潜水深度"渐进解锁 |
| **技能数** | 88（核心 4 + 次要 50 + 开关 33 + 解锁式 26 — 部分数交叉） |

**核心数值档**（Shelldiver 实证）：

| 字段 | 值 |
|------|----|
| 核心轴 `cost_inc` | 10 |
| 跳级 | `[1,2,3,4,5,6,7,8,10]`（跳 8→10，不是 9→10） |
| 主轴核心技能数 | ≤ 4 条 |
| 次要轴 tier 数 | 3–5（部分 `[1,2,10]` 跳级） |
| 开关 tier 数 | 1–2 |
| 解锁式 | 26 个（无 tier，机制解锁） |
| 武器双轨 | 2 把 DPS × 各自 17 + 14 字段 |
| 战斗乘区 | 战斗链 31 字段 + 资源/稀有度/辅助/同盟 56 字段 |
| 稀有度档数 | 3 档（Silver / Gold / Rainbow，**无"普通"档**） |
| 单 run 时长 | ~4h |
| 100% 解锁需通关数 | 1（无 missable 成就） |
| 单次 Reset 收益 | **不适用**——游戏无 Reset |

**常见配方**：

```text
# 资源入库——T1/T2 自动 + T3 进度条
every interval (1s):
    local = auto_base × chain
    add_resource(primary, local, apply_global=true)

# 区域深度解锁——按成就（探索深度）解锁，不靠资源成本
ACH_DEPTH_01 → shallows 解锁
ACH_DEPTH_02 → glacial 解锁
ACH_DEPTH_03 → swamp 解锁
ACH_DEPTH_04 → magma 解锁

# 资源 → 货币 → 升级 → 解锁 → 探索 → 资源（环形）
```

**常见变体**：

- 仅加"成就面板 + 统计"取代 Reset，附 Steam 成就同步
- 末段加 O2 终局 bar（隐藏 100% 触发彩蛋），如 Gnorp 的 Finale
- 加装备/物品系统（多武器 × 多 tier），但 sink 仍是不带 reset 的技能树

**起始最小集**：

```text
- 1 主货币（点击产出）
- 1 自动产线（T2）
- 1 个 4–6 字段的核心轴（核心 4 条之一）
- 2 个开关技能（深度上限、攻击速度）
- 1 个资源 currency（区域 1 资源）
- 1 个生态区 + 1 个稀有度档
```

**调优旋钮**（这模式 reset 不适用，其它单独列）：

| 症状 | 改 | 步长 |
|------|----|------|
| M0 → M1 太空 | 加中间里程碑（`o_skill_bubble_smite` 这类 1–2 级开关） | 不先狂改 cost |
| 整体太快 | 主轴 `cost_e` **+0.5** | 半数量级 |
| 整体太慢 | 主轴 `cost_e` **−0.5** | 半数量级 |
| 跳 8→10 没人买 | `jump_multiplier` ↓ 或跳级数值 ↑ | 保持价值/成本合理 |
| 区域没意义 | 加解锁式 biodiversity 技能（每区 1 个） | Pattern B |

**反模式**：

- ❌ 引入 Reset / prestige currency / 永久加成——这是对 cozy 概念的破坏
- ❌ 5 个稀有度档（Shelldiver 只有 3 档且**无"普通"档**）
- ❌ 核心轴 > 5 条——决策疲劳
- ❌ 终极武器必须破 100% 才用——endgame 应该是奖励而非门槛

---

### 2.2 模式 B：塔层 + 多区域 + 破墙终局（Tower Wizard 档案）

**题材 & 时长**：塔层升级 / 中型 / 单 run 2–4 hr / 多次 reset（双轨）。

**案例**：[Tower Wizard](../cases/tower-wizard/README.md)（Godot 4.2.3，10 塔层 + 12 区域 + 80 技能 + 40 祝福 + 22 国家 + 4 堵墙）。

**判断为该模式的特征**：玩家**分段**推进——升 1 层塔、解锁 1 个新区域；**有 HP 墙**作为破关门槛；祝福 / 区域升级是核心成长轴；reset 类型是双轨（per-run + 永久）。

| 项 | 锚点 |
|----|------|
| **核心 sink** | 4 堵墙的 HP（云墙 20M → 太阳墙 5B → 宇宙墙 ×2 INF）+ 升塔成本 |
| **主货币增长** | T2 调率自动化 + 跨祝福乘区（O4 跨轴反馈） |
| **Reset 类型** | **双轨**——本 run prestige point（per-run）+ Damage Prestige（跨 run） |
| **必含 Pattern** | Pattern S（核心 3 档）+ Pattern T（跳级 ×2 buy + Doubling 祝福）+ Pattern E（5 状态 Stack）+ 全部 O 模块（O1-O11） |
| **货币数量** | 11 个（Magic 主 + 3 中间 + 4 advanced + 2 tactical） |
| **区域数** | 12 个活跃（**O11 完整版**——通常产线 >10 按区域分组） |
| **墙数** | 3 堵逐塔层解锁 + 1 个 Final Ascension |

**核心数值档**（Tower Wizard 实证）：

| 字段 | 值 |
|------|----|
| 升塔成本起点 | 30 magic |
| 升塔成本终点 | 1e12 magic + 500 magic_gold（6→7） |
| 7→8 / 8→9 升塔成本 | 0 magic（需破墙——**复合 Gate**） |
| 9→10（Final Ascension） | 42 / 50 cosmic_dust |
| 升塔奖励 | 4 building_points / Final = ×3 |
| 核心技能曲线 | `base × multiplier^level` |
| SkillDefSpirit 公式 | `level=1: 201 magic; level≥2: 200 + 0.7 × L^(2.1+0.23×L^0.4) × 0.9` |
| SkillDefGold 公式 | `round(1M × (1 + level²))`, max_level=100000 |
| Doubling 祝福 | 每次 purchase 等级 +2 而非 +1（**Pattern T 跳级变体**） |
| 单灵体等级 | ≈100 触顶，需转生抬天花板 |
| 区域解锁条件 | 塔层 0/1/2/...10 渐进 → 区域 0/2/3/...9 渐进 |
| 跨区域乘区 | 22 国家绑定区域 × 4 训练 × 多祝福 |
| 跨轴反馈 | Destruction 祝福：DPS 量级 → magic/wood/knowledge/alchemy XP/rune XP 链 |
| 双 Prestige | magic prestige（16 上限）+ damage prestige（per-run） |
| 副进度条 | 3（Alchemy / Temple / Rune Tree） |

**常见配方**：

```text
# 升塔——单资源或复合 Gate
if tower_level < 7:
    cost = magic (single)      # 30 → 1e12
elif 7 <= tower_level < 10:
    cost = 0 + (broken_wall_level >= tower_level - 6)  # 复合 Gate
else:  # 9→10
    cost = 42 cosmic_dust + (broken_wall_level == 2)

# 跨轴反馈——Destruction 祝福示例
damage_level = floor(log10(DPS))
percent_bonus = damage_level × blessing_of_destruction.percent_increase
if blessing_of_compounding > 0:
    percent_bonus *= (1 + blessing_of_compounding.percent_increase/100) ^ damage_level
# 乘入 magic/wood/knowledge/alchemy_xp/rune_xp 5 条产出链
```

**常见变体**：

- 塔层数 5–10（5 偏短、10 偏长）
- 区域数 8–12（≥10 按 O11 分区域分组，<10 走单页）
- 墙数 1–4（1 偏简单，3 是实测，4 是含 Final Ascension）
- "塔" 可替换为 "层 / 章 / 章节 / 楼 / 工厂"——任何"层叠 + 段位 + 顶层 boss"的形态

**起始最小集**：

```text
- 1 个塔层枚举 + 升塔 cost 查表（C6 查表 Gate）
- 1 个主货币 magic（点击 + 自动）
- 3–5 个区域（不要 <3，否则没有区域分组意义）
- 1 堵墙 + 1 个破墙 buff 链
- 1 个 prestige 轨（per-run）+ 1 个永久 upgrade shop
- 1 个跨轴祝福（参考 Destruction）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| 升塔太快 | 升塔成本 ×1.5 | 半数量级 |
| 升塔太慢 | 升塔成本 / 2 + 加中间 sink | 谨慎 |
| 墙破得太快 | 墙 HP ×2 + 玩家 DPS 上限降低 | 联调 |
| 跨轴反馈失效 | 改成 `DPS^0.5` 或 `DPS` 一次项 | 防后期爆炸 |
| 终局内容太快 | 加 11→12 区 / 0.5x 资源 | 拉长 |

**反模式**：

- ❌ 塔层 + cost 用纯指数公式；应该用 C6 查表（每层单独成本）
- ❌ 区域独立 UI 不分组——12 区必须独立面板
- ❌ 跨轴 feedback（O4）与 O3 指标不对齐
- ❌ 没有 HP 墙但用 boost 类暗算"通关"
- ❌ 区域数 >12 活跃

---

### 2.3 模式 C：多时代超长 / 9 era 跨周期（Kittens Game 档案）

**题材 & 时长**：跨时代 / **超长** / 50+ hr / 多次 reset / 跨周期 + dark future。

**案例**：[Kittens Game](../cases/kittens-game/README.md)（JavaScript + Dojo 1.7 / IE6 兼容，58 资源 + 39 建筑 + 62 techs + 137 upgrade + 37 prestige perk + 9 时代 + 12 个 prestige 货币 / dual cap）。

**判断为该模式的特征**：玩家玩**多天 / 多 session**；存在**多个时代**（资源 / 科技大跨档）；currency 多（≥10）；单 run 内有季节 / 年 / 周期的多重时间循环；Permanent 与 Permanent-permanent 双层 reset；终局要走 dark future 加速。

| 项 | 锚点 |
|----|------|
| **核心 sink** | 39 建筑升级 + 62 techs + 137 workshop upgrade + 9 个时代推动 |
| **主货币增长** | 58 资源 DAG（含 7 exotic 软通币），4 季节 × N 年色 × N 周期叠加 |
| **Reset 类型** | **双 prestige 货币（P2）**——paragon（短期）+ burnedParagon（长期）+ dark future 加速 |
| **必含 Pattern** | Pattern B / C / D / E / P（KG 子变体）/ R / S / T + O1 / O3 / O5 / O11 / O13 |
| **资源 DAG 节点数** | 58（11.7 KB），含 7 exotic rarity band |
| **科技树** | 62 techs，1 个 tech 解锁多 system（buildings/tabs/jobs/policies/crafts） |
| **workshop upgrade** | 137 + 6-key effect 命名空间（`XxxPerTickBase / XxxPerTick / XxxRatio / XxxMax / XxxCostReduction / XxxJobRatio`） |
| **planets** | 8 个（重排行相同的 effect 数组为不同强度的"multiplier tab"） |
| **宗教 4 季** | 10 升级由 `calendar.cycleEffectsReligion` 按 slot 限制可买 |
| **time/void（chronoforge）** | 7 升级（rewind 日历）+ 6 voidspace 升级（终极存档类） |
| **dual prestige 公式** | `paragon = min(value × 0.01 × ratio, 2 × ratio)`；`burnedParagon = min(value × 0.01 × ratio, 4 × ratio)`（dark-future ×2） |
| **perk 总数** | 37（含 engineering、learning 等同时影响多个 cost） |
| **race 选择** | 8 个（强化不同方向，相当于 Pattern C7 的 buff 侧镜像） |
| **transcendence** | 跨 run，消耗 karma（passive 产出） |

**核心数值档**：

| 字段 | 值 |
|------|----|
| 时代数 | 9（农业 → 工业 → 太空 → 反物质 → 深空 → 虚空 → 升天 → 暗未来 → 终末） |
| 单 run 时长 | 2–4 hr（M3 首次 reset） |
| 总时长 | 50+ hr（含多次 reset） |
| 资源 DAG 节点 | 58（43 common + 3 uncommon + 5 rare + 7 exotic） |
| 价格曲线 | `cost = base × ratio^(current_val + fakeBought) × priceModifier × resPriceModifier`（KG line 2268） |
| 建筑 priceRatio | 1.10–2.50（39 建筑） |
| 科技价格 | 固定（无曲线），受 `techPriceRatio` 全局乘区影响 |
| storage cap | 静态默认 + 动态 `XxxMax`（双层 cap） |
| `unlockScheme` | 独立 gate + 价格（"能买 vs 解锁"是两件事） |
| week/season/year | 4 季节 × N 年色 × N 周期 → 60 日历状态 |
| dark future | prestige 公式 ×4（短期 + 长期双倍 cap） |

**常见配方**：

```js
// KG 价格引擎（js/buildings.js:2268）
prices.push({
  val: bldPrices[i].val 
       * Math.pow(ratio, bld.get("val") + fakeBought) 
       * priceModifier 
       * resPriceModifier,
  name: bldPrices[i].name
});
// fakeBought = Σ XxxFakeBought effect + additionalBought (UI buy-N)

// unlockScheme — 与价格独立
unlockScheme: { name: "catnip", threshold: 56 }   // 必须先达到 catnip 累计 56

// 双 prestige 公式（KG getParagonProductionRatio:501）
paragon = min(value × 0.01 × ratio, 2 × ratio)
burnedParagon = min(value × 0.01 × ratio, 4 × ratio)  // dark-future ×2

// 季节叠加
for key in effect_keys:
  effect[key] *= season_modifier[key]
```

**常见变体**：

- 时代数 6–12（9 是经典、12 是 C2S 上限）
- currency 数 30–60
- 双 prestige vs 单 prestige（早期只有 paragon，后加 burnedParagon 是 KG 的演化）
- 季节 × 年色 × 周期数（14×4×N）

**起始最小集**：

```text
- 1 个 resource DAG（≥30 节点，含至少 5 个稀有档 currency）
- 1 个科技树 + 1 个解锁多系统的 tech 机制
- 1 个效果扁平化引擎（6-key 命名：`XxxPerTickBase/Ratio/Max/CostReduction/JobRatio`）
- 1 套 buildings + 1 套 workshop upgrades + 1 套 prestige perks
- 1 个 calendar（至少季节循环）
- 1 个 prestige 货币 + 1 个跨 run 货币（**双 prestige**，P2）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| 时代转换太快 | `ratio` ×1.1 或加 `unlockScheme` 阈值 | 加 10–20% |
| 时代太慢 | 加新 currency 或副进度条（O2） | 不先狂改 cost |
| 双 prestige 短期刷爆 | `paragon` cap 公式系数 ↓ | 使长期能积累 |
| 季节叠加过强 | 季节 modifier 上限 cap | 防爆炸 |
| 跨 run currency 失效 | 与短期 currency 不共用 cap | 必备规则 |
| effect 6-key 命名违背 | 重写 effect key 而非硬补丁 stat | 防 schema 碎片 |

**反模式**：

- ❌ **单一 prestige currency 假装双 prestige**——`burnedParagon` 必须有显式 cap 和不同公式
- ❌ 双 prestige 共用 cap
- ❌ 科技树用纯指数曲线——应"固定价 + 全局乘区"
- ❌ tech 解锁不跨多 system（即只能 unlock buildings，不能同时 unlock jobs/policies/crafts）
- ❌ 时代转换只有数字变大，没有质变点
- ❌ currency 隐式兑换（必须显式）
- ❌ 没有 calendar / 季节 / 时间循环——失去 KG 标志性的"多重时间叠加"

---

### 2.4 模式 D：节点流水线 + 自动化（Upload Labs 档案）

**题材 & 时长**：节点摆放 + 配线 / 中型 / 单 run 2–4 hr + 软重置循环。

**案例**：[Upload Labs](../cases/upload-labs/README.md)（Godot 4.x，103 个 window/node × 6-type resource transfer engine + 3-tuple attribute 单一引擎 + 8 currency + service 软重置）。

**判断为该模式的特征**：玩家的**核心动作**是"摆节点"+"配线"，而不是"点按钮 / 选升级"；**单一 attribute engine**（3-tuple `[a, m, e]`）处理游戏所有 effect（含 buff / debuff / 折扣 / 指数）；service 类软重置是常规 reset 之外的第三种 prestige 形态。

| 项 | 锚点 |
|----|------|
| **核心 sink** | in-window add/upgrade buttons（×1000 / ×4 硬编码）+ 节点摆放上限 + storage cap |
| **主货币增长** | 6-type resource transfer（download → process → verify → storage → upload → sell）+ 8 currency 分域 |
| **Reset 类型** | **3 种**：①hard prestige（reboot）②service 软重置（PR 模式）③perk（永久 token） |
| **必含 Pattern** | Pattern AME（3-tuple + 单 `Attribute.add()` 引擎）+ Pattern N（节点流水线 + 6-type 单一转移引擎）+ Pattern PR（service 软重置）+ Pattern P2（双 currency） + 完整 B/C/D/E/P/R/S/T |
| **货币数** | 8（5 是非产出型 per-subsystem） |
| **node / window 数** | 103 节点（6 类资源容器） |
| **核心公式** | `price(level) = base × 10^cost_e × cost_inc^level × price_multiplier` |
| **3-tuple 引擎** | `add(a, m, e, e_count)` — 15 行 class，单源真值 |
| **in-window add cost** | `1 × 10^6 × 1000^count × price_multiplier`（**C-tier ×1000 硬编码**） |
| **in-window upgrade cost** | `4 × 10^3 × 4^(level+1) × price_multiplier`（C-tier ×4 硬编码） |
| **achievement requirement** | `requirement × 10^requirement_e`（**同样 3 字段**） |
| **soft-reset service** | refund hack_reset / optimization_reset / application_reset，**只清 service 列表 + 不清 token** |
| **非产出 currency 用途** | 5 个 currency（`hack_point` / `corporation_data` / `government_data` / `optimization_point` / `application_point`）只来自对应 sub-gameplay |
| **3 类时间 track** | real time + time-played + elapsed-time × offline-multiplier（rest toggle ×5） |
| **折扣表达** | `[a=-0.05, m=0, e=0]` 即 -5% cost，无需特判字段 |

**核心数值档**：

| 字段 | 值 |
|------|-----|
| `cost` 字段档 | upgrades=86 + research=47 + perks=18 + milestones=3 |
| `cost_inc` 档 | 1（perks linear）+ 10（upgrades main）+ 100（milestones 1 数量级陡）+ 2000（breach 终点） |
| `cost_e` 主轴 | -3 ~ 8 |
| currency 类型 | 8（1 主 buy + 1 通用 prestige token + 1 research + 5 sub-gated） |
| 8 currency gate | level 0/9 + research 节点 |
| `attributes.json:storage_size` 默认 | `1e24`（storage 总 cap） |
| `attributes.json:max_rest_time` 默认 | `600s`（+30s/level perk） |
| node port limit | 每端口 `storage_size: 100`（per file-type bucket） |
| 3-tuple 引擎行数 | 15 行 `Attribute.add()` |
| tick 引擎 | 3 类时间 track（real + played + played × offline-multiplier） |
| 离线倍率 | 5× toggle 切"resting" |
| service 类数 | 3（hack / optimization / application），每类独立 refund |

**常见配方**：

```gdscript
# 统一价格（1 行 4 个表全部用）
var price = Data.upgrades[name].cost * pow(10, Data.upgrades[name].cost_e) 
            * pow(Data.upgrades[name].cost_inc, level) 
            * Attributes.get_attribute("price_multiplier")

# 3-tuple attribute 引擎（核心 15 行）
class_name Attribute extends RefCounted
var multiplier: float = 1
var exponent: float = 1
var raw: float = 0
func add(a, m, e=0, e_count=0):
    raw += a * (1.0 + (m / multiplier)) * multiplier * exponent
    multiplier += m
    if e > 0:
        var exp = pow(e, e_count)
        raw *= exp
        exponent *= exp
    changed.emit()

# in-window add cost（独立硬编码）
add_cost = 1 * pow(10, 6) * pow(1000, count) * Attributes.get_attribute("price_multiplier")

# service 软重置（区别于 hard prestige）
signal reboot   # 全清
func hack_reset():
    emit_signal("refund_subtree", "hacking")   # 只清 hacking 子树
# 不 emit reboot → perk + token 保留
```

**常见变体**：

- 节点连 6 类资源 transfer 可缩到 4 类（最少 download → process → sell）
- service 软重置可删——若题材不需要"重选 subtree"
- 3 类时间 track 可并为 1 类

**起始最小集**：

```text
- 1 个 Node 基类 + 4–6 类 window（download / process / verify / storage / sell / 终极）
- 1 个单 connector 类（in/out/limit）
- 1 个 3-tuple Attribute class（15 行）
- 1 个 transfer engine（`transfer_in / out` 6-type 桶）
- 1 个 upgrade 表 + 1 个 research 树 + 1 个 perks + 1 个 milestones
- 1 个 service 列表（≥1 类）+ 1 个 token currency
- 1 个 storage cap（默认 1e24 量级）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| 节点增长太慢 | in-window `1000^count` 改 `500^count` | 半数量级 |
| service 软重置被滥用 | service cost 不再随 refund 线性增长 | 改 `cost_inc × 1.5` |
| 3-tuple 引擎幂等问题 | 存档时重建 attribute（不能累加） | 见 §5.3 重建算法 |
| currency 太多迷失 | 把 5 个 sub-gated 合到 1 个通用 currency | 慎用 |
| main upgrade 爆破 | `cost_inc` 100 → 200 | 数倍 |

**反模式**：

- ❌ dispatcher 知道每个 node 类型 → Pattern N 反模式（type 硬编码到 engine）
- ❌ 多个 schema 混用 3-tuple → Pattern AME 反模式（dispatcher 爆炸）
- ❌ `Attribute.add()` 不幂等 → 读档后 effect 双倍
- ❌ service cost 随 refund 线性增长 → 玩家循环刷退款套利
- ❌ service 触发 reboot 信号 → 退化为 hard prestige（PR 反模式）
- ❌ discount 字段单独存在 → 用 3-tuple 负数 `a` 表达（`[-0.05, 0, 0]`）

---

### 2.5 模式 E：物理合成 + 单 prestige（Gnorp 档案）

**题材 & 时长**：物理合成 + 战略 / 中型 / 单 run 2–3 hr / 单 prestige。

**案例**：[Gnorp](../cases/gnorp/README.md)（Go+LLVM 单 exe，3 currency + 14 建筑 + 35 talents + 11 inspirations + 5 status + 10+1 compression）。

**判断为该模式的特征**：玩家**主动点击 / 拖拽**触发物理事件；compression 是周期性"全部回收再分配"事件；prestige 是**单轨**（Talent Point 1 种 currency）；跨建筑 inspiration 链是核心成长轴。

| 项 | 锚点 |
|----|------|
| **核心 sink** | Compression Event（CE，11 级 + Finale）+ 跨建筑 inspiration 链 |
| **主货币增长** | Rock 产出 → Pile 累积 → Runner/Mountaineer 收回 → Stash → shard 余额 |
| **Reset 类型** | **单轨 prestige**（Talent Point 永久 + Hat 软）+ Finale 终极 sink |
| **必含 Pattern** | Pattern B / C / D / E / P / R / S / T + O1-O5 / O7-O11 / O13 |
| **货币数** | 3 + Zybellium 双档 |
| **建筑数** | 14 |
| **Gnorp 类型** | 8（Slammer / Runner / Mountaineer / Bomber / Riflegnorp / Gatlegnorp / Zygnorp / Drone） |
| **talents** | 35（5 default + 6 tier × 5 active） |
| **inspirations** | 11（attunement 互斥/可叠加） |
| **compression 等级** | 11 + CE 10 触发 Finale（endgame bar） |
| **永久项** | 1 类（Talent Points） |
| **endgame** | Railgun + (the) Finale + Speedrun Mode + Epilogue 扩展 |

**核心数值档**：

| 字段 | 值 |
|------|-----|
| 单 prestige currency | Talent Points（`/collection` 阈值获得） |
| 压缩事件公式 | `shard_value *= 4^CE` |
| Zybellium cap | 1–2 个/run（Agitator +3） |
| 双档乘区 | `loose_zybellium` + `stored_zybellium`（Pattern D 实证） |
| 跨建筑 chain | 11 inspirations，attunement 互斥 + 可叠加 |
| combo 公式 | cap 98%（80 base + 5 Motivation + 3 Drone Inspiration + 10 Combo Power） |
| Reclamation | Pile 顶端吸取（**反向 sink**，Nullification 缓解） |
| Compression Event CE10 | 触发 Finale → Railgun 终极目标 |
| 单一永久 currency | 1 类（不像 C2S/KG 的多层） |
| 物理 effects | 5 种（Fire / Ice / Vulnerability / Zybe / Acid） |
| 物理 tier jump | Runner Speed 1→3 px/s；Combo Chance 20→80% |
| Zybe allocation | 1–2 永久项目（开局 -201 spirits debt 类似） |

**常见配方**：

```text
# 核心循环
玩家点击 / Gnorp 砸击
  → Rock 输出 Physical Shards
  → 落入 Pile
  → Runner / Mountaineer / Drone / Zygnorp 收回 Shards
  → 计入 stash

# 压缩事件（CE）
Pile 达到固定高度 → 触发 CE
  → shard_value *= 4^CE
  → 生成 Loose Zybellium
  → Drone 死亡生成 Baby Drone
  → Rock 开始 Reclamation
  → 进度条重置

# 双 prestige 单 currency
每次 CE → 收集速率达标阈值 → +1 Talent Point
  → Prestige 触发时 reset run，TP 保留
  → Talent Stone 永久 modifier

# 跨建筑 Inspiration
当源建筑达成条件 → 目标建筑单位获永久被动
  互斥槽 + 可叠加链（attunement）
```

**常见变体**：

- CE 等级 5–15（>11 进入 Finale）
- 建筑数 8–20
- inspirations 4–15
- 跨 run 可加 1 个 Hat 类软货币（Gnorp Hats 实证）

**起始最小集**：

```text
- 1 个核心周期事件（CE 或类周期）
- 3 currency（主 + 1 中间 + 1 prestige）
- 5–8 建筑（4 个核心 + 1–2 个 inspiration 源 + 1 个 endgame）
- 1 个跨建筑 inspiration 链（4–8 inspirations）
- 1 个单 prestige 升级树（5 default + 2–3 tier groups × 5 talents）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| CE 太快 | CE 阈值 ×1.5 | 减频 |
| CE 太慢 | CE 阈值 / 1.5 或 `shard_value *= 5^CE` | 加频 |
| Zybellium 过强 | cap 减少 | 1–2 起步 |
| Inspiration 互斥太强 | 加可叠加链 | 平衡 |
| Reclamation 反向 sink 失控 | Nullification 升级前置 | 必加 |

**反模式**：

- ❌ 升级用 `C2 5.0^n`（Gnorp X-rockets 实证单升级 3.04M → 15.2M → 76M，玩家跟不）
- ❌ prestige 多 currency 共用 cap（KG 反模式提醒）
- ❌ 跨建筑 source 与 target 同一建筑（退化成普通升级）
- ❌ 物理 cycle 按钮硬编码 + 无 tier
- ❌ Compression Event 走纯指数 1.1^CE（用 4^CE 阶梯型才是对的）

---

### 2.6 模式 F：农场 + 战斗 + 跨 run skill tree（Agrivore 档案）

**题材 & 时长**：农场 + 战斗 + 7 主题 run / 单 run 4–6 hr / 多次 reset。

**案例**：[Agrivore](../cases/agrivore/README.md)（Unity 6 + Addressables 2.7.3 + LocalizedString，9 系统 + 6 货币 + 26 crops + 13 item types + 7 sins + 35 evolutions + 4 sigils + 1 set bonus + 5 lifetime stats）。

**判断为该模式的特征**：每局 gameplay 在**主题上**做切（7 罪孽主题 run）；存在装备系统（多 item type × 多 tier）；跨 run 通过 Treasury skill tree 持续投资；战斗系统（双武器 + 4 sigils + 35 evolutions）。

| 项 | 锚点 |
|----|------|
| **核心 sink** | 战斗 DPS + 装备 tier + 主题 sin currency |
| **主货币增长** | 主 coin 来自作物收获 + 4 seed 来自种植系统 + gem/crown 来自跨 run |
| **Reset 类型** | **跨 run**（Treasury skill tree 31 节点）+ 7 主题 sin run（亚 reset） |
| **必含 Pattern** | Pattern B / C / E / R / S + O1 / O2 |
| **货币数** | 6（coins + 4 seed + gems + crowns） |
| **ItemType** | 13 × EquipmentType 7 = 91 装备类 |
| **Rarity** | 5 档 |
| **CropTier** | 26 CropType × 4 Tier + 8 Golden = 4 + 8 = 12 变体 |
| **Sins** | 7 types + None + 11 RunEffect kind |
| **Evolutions** | 35 EvolutionId + 4 Modifier type + 17 UnlockNode 子类 |
| **Sigils** | 4 SigilType + 4 BaseSigil 子类 |
| **Unique Skills** | 6 type |
| **Achievement** | 5 Lifetime + 3 Run stat + 7 Prestige + Treasury(41 fields) |
| **Run 单时长** | 4–6 hr |
| **跨 run 池** | Treasury Skill Tree 31 节点 |

**核心数值档**：

| 字段 | 值 |
|------|-----|
| Item rarity | 5 档（普/优/稀/史/传） |
| Item tier | ItemData 59 字段 + tierEntries[] + statModifiers[] |
| EquipmentStat | 6 类 damage stat（per ItemType） |
| Crop tier | 4 + 4 golden 变体 |
| Crop yield | `coinValue + cropValueBonus + goldenYield` |
| Sin effect | `AttackSpeedPercent / CritChanceAdd / ...`（11 kind） |
| Sin unlock | `SinEvolutionUnlockNode`（与 EvolutionId 29–35 一一对应） |
| Evolution Modifier | Add / Multiply / Replace / SetFlag（4 type） |
| Sigil on item | List<Sigil {sigilType, level}> |
| Achievement rarity | 4–5 档（common/rare/epic/legendary via BadgeTier） |
| Crop Respawn | 12 触发源（Default / SunBurn / Bow / Sword / Gun / Tractor / ...） |
| Treasury SkillTree | 31 节点跨 run 永久池 |
| Lifetime stat | 5 类型 |

**常见配方**：

```text
# 主货币生成 → 收 → 卖 → 投资
作物 (26) → 收获 → coins → 升级种植技能
装备 (13 type × 7 slot) → 战斗掉落 → tier upgrade → sigil + evolution
战斗 → gem + crown → Treasury Skill Tree (跨 run)

# 7 罪孽主题 run
每 run 选定 1 个 sin 主题 → SinRunEffect 驱动该 sin 的全局修饰
sin_currency 累计 → SinEvolutionUnlockNode 解锁 progression node

# 装备 stat 累积
ItemData[tier] + statModifiers[] → 总 stat → 与武器加法 → DPS
```

**常见变体**：

- sins 主题数 3–10（3 偏少、>10 决策疲劳）
- 装备系统可并入"卡片收集 + 升级"简化
- 跨 run 池可改为"成就墙 + 永久 store"

**起始最小集**：

```text
- 1 个主货币 + 1 个 theme currency (sin 或类似)
- 1 个作物 / 收集系统 (≥10 个 item)
- 1 个装备/卡片系统 (≥5 type × 3 tier)
- 1 个跨 run 池 (5–20 节点 skill tree)
- 1 个战斗轴（HP + DPS 衰减链）
- 1 个主题切换机制（run start 时可选）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| 主题切换不够明显 | SinRunEffect 11 kind 全覆盖 | 必填 |
| 装备 tier 阶梯不清晰 | `tierEntries[]` 加 layer | 用现有 |
| 跨 run 池过强 | Treasury node 等级 ×level 上限 cap | 标准 |
| 战斗过于复杂 | 装备 stat → 单一 DPS 引擎 | 简化为数值 |

**反模式**：

- ❌ 7 罪孽 currency 共用 cap 但又分 7 个升阶轨道（互斥选择 vs 共享 cap 冲突）
- ❌ 装备 tier 用纯指数曲线（应 tierEntries 离散 + Mod 增幅）
- ❌ 跨 run 池与 run 内 currency 混用 store
- ❌ Evolution Modifier 类型 > 4 个（决策疲劳）

---

### 2.7 模式 G：塔防 + 多阶段神器 + 多 tier prestige（Dwarf Eat Mountain 档案）

**题材 & 时长**：挖山 + 塔防 + 灾变 + boss 山 / 长 / 单 run 4–8 hr + 多 tier prestige。

**案例**：[Dwarf Eat Mountain](../cases/dwarf-eat-mountain/README.md)（GMS 2.3+ GEN8，14 建筑 + 199 升级 + 124 artifact + 102 prestige + 27 ore + 5 den + 30 calamity + 6 特殊山 + 10 dwarf type）。

**判断为该模式的特征**：玩家既是"挖方"又是"守方"——资源进度与敌人进度**并行增长**；存在**多阶段 item**（artifact 三种 effect：collect / passive / access）；多 tier prestige 嵌套（PP + Ascension rank 加速）；终局是"打到特定 boss 山"。

| 项 | 锚点 |
|----|------|
| **核心 sink** | 建筑 8–21 tier 升级 + 灾变 HP + 6 boss 山 HP + 124 artifact 收集 |
| **主货币增长** | 6 currency（含跨 run mithril + PP + faith + soul + 27 ore 全分类） |
| **Reset 类型** | **多 tier prestige**——PP + Ascension rank（rank 越高 prestige 节点加成越强） |
| **必含 Pattern** | Pattern B / S / T + O5 (cross-run) + 候选 O14 (multi-phase artifact) |
| **建筑数** | 14 + 200 升级节点 |
| **神器数** | 124（24 collect + 83 passive + 14 混合 + 3 required-to-access） |
| **prestige 节点** | 102（PP-spend） |
| **ore 类** | 27（分 5 类：普通 gold / pure gold / 特殊矿 / gem family / mithril） |
| **den 类** | 5（产出敌人） |
| **灾变事件** | 30 |
| **特殊山** | 6（终局 boss 山，部分需特定 artifact 才能进） |
| **dwarf 类型** | 10 |
| **数据结构** | GMS `data.win` inline struct literal（无 SO 类，靠 JSON localization 提供文本） |

**核心数值档**：

| 字段 | 值 |
|------|-----|
| 货币 | 6（gold + 27 ore + mithril + PP + faith + soul） |
| 建筑升级数 | 199（线性 1-time purchase，每建筑 8–21） |
| 神器 effect 类 | 3（collect / passive / access） + 1 flavor |
| Artifact effect | `Collect: … + Passive: …` 文本内嵌数值（regex 提取） |
| Prestige 节点 | 102（PP-spend，节点类型：stat_multiplier / new_building_unlock / new_upgrade_unlock / new_dwarf_unlock） |
| Ascension 等级 | 0/2/4/6/8（rank 提升时某些节点加成增强） |
| Ore 分类 | 27 → 5 类：普通 gold 3 size + pure gold 5 size + 特殊矿 5 + gem 10 + mithril 1 |
| Den 产出 | 5 类，含 artifact/mithril/calamity reward |
| Calamity | 30 个（含 rockfall 类 5 + troll 类 1 + goblin 类 1 + gem 类等） |
| Special Mountain | 6（triple_seal_gate / goblin_king_spire / dragons_peak / architects_summit / balrogs_pit / great_world_spire） |
| Dwarf 类型 | 10（runner / miner / priest / brewmaster / scientist / runesmith / stonecaller / demodwarf / cybordwarf / bulldozer） |
| Buldozer | 推土机，manufactorum 制造 |

**常见配方**：

```gms
# 挖 → 卖 gold + 解锁神器 + 升级建筑
ore 挖出 → sell for gold
artifact pick up → trigger Collect + Passive
  ↑ Required-to-access artifact 解锁特殊山

# Prestige 树（102 节点）
prestige node (PP-spend)
  ├─ stat_multiplier (+X% by Ascension rank)
  ├─ new_building_unlock  (e.g. Manufactorum needs At6_keep_artifacts_choice)
  ├─ new_upgrade_unlock
  └─ new_dwarf_unlock (e.g. Cybordwarf)

# 防御循环
calamity 触发 → 玩家可主动 trigger 应对
  ├─ cannon / turret 攻击
  ├─ harpoon
  ├─ flamer
  └─ laser cannon (scientist)
Dens spawn enemy → dwarves 击败 → reward

# 加速公式
Bonus per rank is increased by +X% per Ascension rank
(节点 At6_keep_artifacts_choice 可在 prestige 时保持 1/2/3/4/5 个 chosen artifact)
```

**常见变体**：

- 建筑 8–20
- 神器数 30–150（30 起步，150 是 DEM 上限）
- 灾变 10–40
- 特殊山 3–8

**起始最小集**：

```text
- 1 个主货币 + 1 个跨 run currency (prestige point)
- 1 个挖方子系统（矿→金币）+ 1 个守方子系统（防御单位）
- 1 个 multi-phase 物品系统（≥3 类 effect：collect / passive / access）
- 1 个 tier-nested prestige 树（≥3 tier）
- 1 个跨 run 升级池（5–20 节点）
- 1 套敌人 / 灾变系统（≥10 个）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| 防守压力太小 | 灾变数量 + 5 或 boss HP ×1.5 | 拉长 |
| 防守压力过大 | dwarves 数量 + 1 / 武器 DPS ×1.5 | 缓冲 |
| 神器没人拾 | 加主动触发效果 `Collect: ...` | 加 10–20% |
| Prestige 节点太多 | 折叠 stat_multiplier 类 | 减半 |
| Ascension rank 加速过强 | rank bonus per tier ×0.8 | 调整 |

**反模式**：

- ❌ 神器用单 effect（multi-phase 是核心！必须 collect + passive 至少 2 阶段）
- ❌ multi-tier prestige 共用 cap
- ❌ 塔防 spawn 与经济 spawn 互不影响（应同时驱动）
- ❌ 同一 boss 山需要 30 玩家攻击 = 1 个大招玩家（未区分）
- ❌ 防御阵营与挖方阵营的玩家策略互斥（应协同）

---

### 2.8 模式 H：长程运营 12 era + 3 层 prestige（Cell to Singularity 档案）

**题材 & 时长**：长程运营 / **超长** / 100+ hr / 多次 reset / **3 层 prestige 嵌套** + 12 era 渐进。

**案例**：[Cell to Singularity](../cases/cell-to-singularity/README.md)（Unity 2021+ built-in + I2 Loc + PlayFab + Firebase，单人开发 9+ 年 / live service 长期演进）。

**判断为该模式的特征**：游戏**长期上线维护**，新 era 渐进加（已加到 12 era + 7 Kardashev tier）；prestige 是**真正的多层嵌套**（短 → 中 → 长→ 终）；同一游戏运行 100+ hr；公开成就跨平台同步；多个合作 SDK（PlayFab/Firebase/IAP）= "live service 增量"。

| 项 | 锚点 |
|----|------|
| **核心 sink** | 30+ producer 1-time purchase + 12 era 推动 + 7 Kardashev 升阶 + creature 4 tier |
| **主货币增长** | 6 currency（entropy / cubits / megastars / dna / replicanti / sagan） |
| **Reset 类型** | **3 层嵌套 prestige**——Big Bang（era 内）→ Madness（跨 era）→ Kardashev Ascension（终局 7 tier） |
| **必含 Pattern** | Pattern B / S / T / R / P2 / E + O1-O11 / O13 |
| **Era 数** | 12（Origin → Microbe → Ocean → Mesozoic → Mammal → Primate → Human → Civilization → Spacefaring → Galactic → Intergalactic → The Singularity） |
| **Prestige 层** | 3（Big Bang → Madness → Kardashev） |
| **Kardashev Tier** | 7（I–VII） |
| **货币** | 6（entropy 主 + cubits 软 + megastars 硬 + dna 中后期 + replicanti advanced + sagan 终局） |
| **producer 数** | 30+（Cell → Ascension） |
| **升级数** | 12+（Tap Power 1-3 / Double Production 1-2 / Triple / Auto Buyer 1-2 / Creature Boost 1-2 / Megastar Boost / Sagan Boost） |
| **Creature 卡** | 12+（每张 4 tier + Golden） |
| **公开成就** | 70+ Steam |
| **Era 隐式曲线** | producer count 推动 focus 乘区（O5） |
| **Scripts** | 34 SO（LTE_Tree / MasterLtEDatabase / StarDatabase / EventTuningTracker / I2 Loc / Steam Ach / Offer / ProfileIcon 等） |
| **Achievement 子类** | 660（60 Achievement + 99 AchievementNorm + 501 AchievementFactory） |
| **Story Chapter** | 6（EventStoryChapter） |
| **Event** | 23 EventId |
| **Kardashev 升阶** | 7 tier，附 Sagan currency |

**核心数值档**：

| 字段 | 值 |
|------|-----|
| 主货币 | Entropy（贯穿全程） |
| Era 顺序 | 单向线性推进（Origin → Singularity） |
| Era 持续 | ~8h typical progression × 12 era |
| Producer | 30+（按 era 顺序解锁） |
| Producer 价格 | entropy 主，1-time purchase chain |
| Upgrade 3 档 | tap / automation / boost |
| Creature 4 tier + Golden | tier 1–4 质变；Golden 终极 |
| 12 era | 主角 producer count 推动 focus 乘区（O5 实证） |
| Big Bang prestige | 软（era 内触发，得 cubits） |
| Madness prestige | 硬（跨 era，得 megastars） |
| Kardashev Ascension | 终局（升阶，得 sagan） |
| Codex | 主数据结构（LTE_Tree + LTEData + MasterLtEDatabase 聚合） |
| Achievement rarity | 4–5 档（common/rare/epic/legendary via BadgeTier） |
| Event | 23 EventId + 6 StoryChapter |

**常见配方**：

```text
# 12 era 线性推进
era_index 0..11 单调推进
  → 触发 era upgrade event（解锁下一 era）
  → era_index += 1
  
# 主线 producer 1-time purchase
producers[era_index + N] = new building
  cost = entropy × era_modifier
  1-time purchase 后 producer 永久给 entropy/tick

# 3 层 prestige
Big Bang (era 内)
  ↑ 得 cubits
  ↓ 触发时清本 era producer
Madness (跨 era)
  ↑ 得 megastars
  ↓ 清所有 era producer（保留 upgrade + permanent）
Kardashev Ascension (终局)
  ↑ tier 1..7 得 sagan
  ↓ 重置 + 进入更高 tier

# Creature 收集 tier 跳
creature_base → tier 1 → tier 2 → tier 3 → tier 4 → Golden
  Pattern T 跳级 + 4 等级阶梯

# Soft prestige 公式（C2S Big Bang）
cubit = floor(total_entropy / X) ^ 0.5 × cap  # 标准 dual prestige 公式
megastar = floor(total_cubits / Y) ^ 0.5 × cap  # 跨 era 软 prestige
```

**常见变体**：

- Era 数 8–15（12 是实测）
- Prestige 层 2–5（C2S 是 3 层，是结构最深的）
- Creature 卡可改为"卡片收集 / 装饰"等

**起始最小集**：

```text
- 1 个主货币 + ≥3 层 prestige currency
- 1 个 era 系统（≥5 era，每 era 1 个新 producer + 1 个 currency）
- 1 个 Codex / Achievement 数据结构（聚合所有 upgrade 节点）
- 1 个跨 era 永久 upgrade 树（O13 时空多层循环）
- 1 个 long-tail 成就系统（公开 + 隐藏）
- 1 个 live ops SDK 接口（IAP / 推送 / 分析）
```

**调优旋钮**：

| 症状 | 改 | 步长 |
|------|----|------|
| Era 1 → Era 2 太慢 | producer 数量 + 1 / era mod -0.1 | 拉前 |
| 3 层 prestige 失效 | cubits 与 megastars 不共用 cap | 必备 |
| CodEx 数据库太大 | SO 拆分 + 单独 AchievementMap | 必须 |
| 推送 / 商店乱触发 | Offer / Notification 加入 trigger 限制 | 加 switch |
| Kardashev 升阶太慢 | sagan 公式系数 ×1.5 | 拉前 |

**反模式**：

- ❌ 单一 prestige currency 假装 3 层（必须 3 套 currency + 3 套公式）
- ❌ era 顺序无质变点（每 era 必须有 1 个新 currency 或 1 个新 producer）
- ❌ "永久"与"暂态"currency 共用 cap
- ❌ Producer count 推动 era，但 era 内无 focus 乘区（O5 缺位）
- ❌ Achievement 用枚举而非工厂模式（A2S 实证 660 子类用 Factory + Norm）
- ❌ 单人长期开发不上 live ops SDK（IAP/Push/Analytics）

---

### 2.9 模式挑选流程

1. **M0**：明确游戏的题材与核心动词
2. **对照 §2 八种模式档案的特征表**，选最像的 1 个
3. **多个模式都像** → 选主导动词对应的（如同时"探险 + 区域"挑 A；"探险 + 长程运营"挑 H）
4. **不属于 §2 任何一个** → 用 §3 通用基础搭最小，按需从 §2 各模式"借"特征段，并在 §10 写 changelog 记录"自定义档案"

---

## 3. 通用基础：成本 / 产出 / Reset 公式与字段约定

> 当 §2 模式档案与新游戏不完全匹配时，本节提供通用基础公式。

### 3.1 统一三字段（推荐默认实现）

所有付费项（升级、研究、永久、里程碑）共用同一形状：

```text
price(level) = cost × 10^cost_e × cost_inc^level × price_multiplier
```

| 字段 | 含义 | 调参直觉 |
|------|------|----------|
| `cost` | 尾数（1–9.99） | 微调"感觉贵一点" |
| `cost_e` | 数量级（0, 1, 2…） | **主旋钮**：±0.5 改变半个数量级 |
| `cost_inc` | 每级倍率 | **陡峭度**：决定几级后触顶 |

`price_multiplier` 默认 1.0；折扣永久项可把它压到 < 1（也可用 3-tuple 负数 `a` 表达，见模式 D）。

### 3.2 六种曲线族

| 族 | 用途 | 公式 / 配置 | 最低配 |
|----|------|-------------|--------|
| **C1** 硬 Cap | 人口、核心单位数，逼 Reset | `100 × 1.5^n` 或超指数 | 有 Reset 时必有 |
| **C2** 指数 / 线性 | 日常升级主轴 | `base × r^level` 或线性 | 必有 |
| **C3** 一次性 Unlock | 机制开关 | `max_level = 1` | 有机制解锁时 |
| **C4** 多项式软 Cap | 后期 sink | `base × (1 + level^2)` | 无 Reset 时与 C2 搭配 |
| **C5** 树深度 | 科技树 | `cost = depth × coeff` | 有树时 |
| **C6** 查表 Gate | 章节、剧情节点 | 无闭合公式，查表 | 有章节时 |

C1 标准超指数：

```text
level == 1:  cost = c0
level >= 2:  cost = floor(A + B × level^(P + Q × level^R) × K)
```

### 3.3 `cost_inc` 阶梯

| 档位 | `cost_inc` | 语义 | 何时用 |
|------|------------|------|--------|
| 线性永久 | `1` | 每级同价 | Prestige perk |
| 缓坡 | `1.5 ~ 2` | 温和成长 | 次要技能、建筑数量 |
| 标准主轴 | `5 ~ 10` | `cost_inc=10` 每级 ×10 | **默认主升级** |
| 软顶 | `16 ~ 100` | 很快买不起 | capacity / storage / milestone |
| 硬顶 | `1000 ~ 2000` | 3 级内跨多个数量级 | 破墙、终局层 |
| Gnorp X-rockets 反例 | `5.0` | **避免**：买 1-2 次就破产 | 见 §9 反模式 |

### 3.4 累计成本反推（C1 调参法）

```text
1. 定 N（短游戏 8–12，中型 15–25）
2. 估玩家到触顶时累计主货币 S
3. 令 Σ price(0..N-1) ≈ S × 0.6~0.8（留 20–40% 给其他 sink）
4. 固定 cost_inc，反推 cost × 10^cost_e
```

### 3.5 产线类型 T1–T5

| 类型 | 触发 | 典型产出 | 典型 sink |
|------|------|----------|-----------|
| T1 离散输入 | 点击 / 操作 | 主货币 | — |
| T2 定时脉冲 | 时钟 | 主货币 | 自动化升级 |
| T3 进度条 | 进度满结算 | 副产物 | 槽位升级 |
| T4 采集 | tick | 材料 | 区域升级 |
| T5 放置乘算 | 建造后常驻 | 乘入 T1–T4 | 放置成本 |

### 3.6 标准乘法链

```text
local_output =
    base
  × Π 线性升级(1 + level × p/100)
  × Π 复合升级(1 + p/100)^level
  × Π 条件永久
  × cross_axis          # 默认 1.0；战斗→经济等跨轴反馈时用

add_resource(type, local_output, apply_global=true):
    amount = local_output × (global_multiplier(type) if apply_global else 1)
    库存 += amount
    触发 on_resource_added(type, amount)
```

**购买赠送资源必须 `apply_global=false`**。

### 3.7 Reset 与永久状态

```text
meta_level       # 累计 Reset 等级（账号级，Reset 通常不降低）
run_xp_buffer    # 本 run 经验缓冲
run_points       # 本 run 待分配永久点
```

Reset XP / Cap 三种模式见 core/05-reset-systems.md。

### 3.8 3-tuple 属性引擎（模式 D 通用基底）

```text
class Attribute:
    multiplier = 1
    exponent = 1
    raw = 0
    add(a, m, e=0, e_count=0):
        raw += a * (1.0 + (m / multiplier)) * multiplier * exponent
        multiplier += m
        if e > 0:
            exp = pow(e, e_count)
            raw *= exp
            exponent *= exp
```

`e_count`：一次性条目用 `1`；可升级条目用当前 `level`（购买次数）。
读档时必须从零重建再按稳定顺序重放全部 `add`（否则双倍）。

---

## 4. 起步 JSON 模板（中型 MVP）

> 用 §2 选定模式后，拷下面起步 JSON，按该模式档案的"特征表"字段替换 `cost_inc` / 节点数 / currency 等。

```json
{
  "currencies": {
    "primary":   { "id": "primary",   "name": "主货币" },
    "secondary": { "id": "secondary", "name": "副产物" },
    "prestige":  { "id": "prestige",  "name": "转生点" }
  },
  "production": {
    "click": { "type": "T1", "base": 1, "resource": "primary" },
    "auto":  { "type": "T2", "base": 0.5, "interval_s": 1, "resource": "primary" }
  },
  "upgrades": {
    "upgrade_click_power": {
      "tier": "core", "currency": "primary",
      "cost": 1, "cost_e": 1, "cost_inc": 10,
      "max_level": 10,
      "levels": [1,2,3,4,5,6,7,8,10],
      "jump_multiplier": 10,
      "effect": { "type": "compound", "target": "click", "p": 20 }
    },
    "upgrade_auto_rate": {
      "tier": "core", "currency": "primary",
      "cost": 5, "cost_e": 2, "cost_inc": 10,
      "max_level": 10,
      "levels": [1,2,3,4,5,6,7,8,10],
      "jump_multiplier": 10,
      "effect": { "type": "compound", "target": "auto", "p": 15 }
    },
    "unlock_auto": {
      "tier": "toggle", "currency": "primary",
      "cost": 1, "cost_e": 2, "cost_inc": 1,
      "max_level": 1,
      "effect": { "type": "unlock", "target": "auto" }
    }
  },
  "perks": {
    "perk_global_income": {
      "max_level": 10, "point_cost": 1,
      "effect": { "type": "linear", "target": "primary", "p": 5 }
    }
  },
  "constants": {
    "version": "1.0",
    "xp_cap":   { "mode": "Cap-1", "base": 100, "growth": 1.6 },
    "xp_rate":  0.01,
    "max_meta_level": 100,
    "reset_visibility_target_pct": [5, 30]
  }
}
```

**进入特定模式时的字段替换**：

| 选定模式 | 主要替换字段 | 改法 |
|---------|------------|------|
| A · Cozy 探险 | 删除 `currencies.prestige` 与 `perks` | 无 reset |
| B · 塔层+区域 | 加 `tower_costs` 表 + `walls[]` | C6 查表 |
| C · 多时代 | 改 `currencies` 为 30 节点 DAG + 双 prestige | P2 |
| D · 节点流水线 | 加 `attributes` 3-tuple + `services[]` | AME + PR |
| E · 物理合成 | 改 reset 为单 Talent Point | Pattern T 4 tier |
| F · 农场战斗 | 加 `equipments / sigils / evolutions` 表 | sigil 字段 |
| G · 塔防神器 | 加 `artifacts[]`（3 type：collect/passive/access） | O14 |
| H · 长程运营 | 加 3 层 prestige + 12 era 列表 + achievement | P2 + O1 + 终局 |

---

## 5. 引擎伪代码（最小实现）

### 5.1 购买

```text
purchase(id):
    cost = get_cost(id, current_level)   # 见 §5.2
    if not can_afford(cost): return
    pay(cost)
    current_level = next_level(id, current_level)
    emit purchased(id)
    if grants_resource:
        add_resource(type, amount, apply_global=false)
```

### 5.2 成本（带跳级）

```text
formula(id, L):
    u = upgrades[id]
    return u.cost × 10^u.cost_e × u.cost_inc^L × price_multiplier

next_level(id, current_level):
    return upgrades[id].levels 中第一个 > current_level 的值

get_cost(id, current_level):
    u = upgrades[id]
    nxt = next_level(id, current_level)
    if u 有跳级且 nxt 是跳级满档:
        return formula(id, nxt - 1) × u.jump_multiplier
    return formula(id, current_level)
```

### 5.3 读档重建（模式 D 必备）

```text
function rebuild_attributes():
    state.attributes = {}   # 清空
    for src in stable_order(saved_sources):
        apply(src, state.attributes)
# 必须从空重建，禁止在已有 state 上累加（会双倍）
```

### 5.4 产线 tick（T2 例）

```text
every interval:
    local = auto.base × chains
    add_resource("primary", local, apply_global=true)
```

### 5.5 Reset（双 prestige 例，P2 实证）

```text
Big Bang reset:
    clear era_producers
    grant cubits = floor(total_entropy / X)^0.5 × cap
    keep permanent + unlocked_upgrades

Madness reset:
    clear all era_producers
    grant megastars = floor(total_cubits / Y)^0.5 × cap2
    keep permanent + unlocked_upgrades + cubits

Kardashev Ascension:
    tier += 1
    grant sagan = floor(tier^2 × Z)
    keep permanent + cubits + megastars
```

---

## 6. 调优手册（症状 → 旋钮）

> 每个症状列首选旋钮与步长。**一次只动一个**。多数症状在 §2 各模式档案的"调优旋钮"小节有具体值。

### 6.1 5 个必测指标

| 指标 | 目标 |
|------|------|
| 首次 Reset 时间 | 落在所选模式档案的"核心数值档"区间内 |
| Reset #1 → #2 间隔 | 比 #1 短（除模式 A 无 reset / 模式 H 三层 reset 跨度大） |
| Reset 后首个 buff 感知 | < 30 s |
| 各 currency 在 M3 的存量 | 限制资源应触顶或成瓶颈 |
| 玩家最常走的 3 条产线 | 与所选模式特征一致 |

建议 5–10 名目标受众玩到首次 Reset，打 log。

### 6.2 通用症状 → 旋钮

| 症状 | 先改 | 步长 |
|------|------|------|
| 整体太快 | 主轴 `cost_e` **+0.5** | 半数量级 |
| 整体太慢 | 主轴 `cost_e` **−0.5** | 半数量级 |
| 某 build 完爆 | 该线 `cost_inc` ↑ 或加 `requirement` | `cost_inc ×1.5~2` |
| 某 build 废号 | 该线 `cost_e` ↓ 或效果 `p` ↑ | `p +2~5` |
| Reset 太弱 | prestige 公式系数 ↑ 或永久 `p` ↑ | 使立即收益进 5–30% |
| Reset 太强 | 永久 `p` ↓ 或点数产出 ↓ | 避免下局跳过产线 |
| 跳 10 没人买 | `jump_multiplier` ↓ 或跳级数值 ↑ | 保持价值/成本合理 |
| 资源堆满无 sink | 加 C4 sink 或提高 C1 触顶 | — |
| M0→M3 太空 | 加中间里程碑 | 不先狂改 cost |

### 6.3 模式专属症状参考

- 模式 A：M0 太空 → 加开关技能；区域没意义 → 加 1 个 biodiversity
- 模式 B：升塔太快 → cost ×1.5；墙破得太快 → HP ×2
- 模式 C：时代太慢 → 加 currency 而非狂改 cost
- 模式 D：service 软重置滥用 → cost 不再随 refund 线性增长
- 模式 E：CE 太慢 → shard_value `4^CE` → `5^CE`
- 模式 F：跨 run 池过强 → Treasury node level cap 降低
- 模式 G：防守压力大 → 灾变 +5 或 boss HP ×1.5
- 模式 H：era 推进慢 → producer count +1 / era_mod -0.1

### 6.4 调优纪律

```text
[ ] 改前存档 / 记当前指标
[ ] 只改 1 个字段（或同一语义的一组）
[ ] 写 changelog：字段、旧值、新值、原因
[ ] 同批玩家重测
[ ] 对比 5 类指标
```

**禁止**：一次改 5 个变量；改配置不写原因。

---

## 7. 交付检查清单

### 7.1 结构

- [ ] 已选 §2 一个模式档案，并在 README 标注
- [ ] 资源是 DAG，主货币路径 2–3 条说得清（模式 C 长 DAG 可放缩）
- [ ] 至少 1 个限制资源
- [ ] 成本曲线 ≥ 2 种（按模式档案要求）
- [ ] 核心轴 ≤ 3，长成长轴带跳级（除模式 A 4 条 / B 多区域）
- [ ] 全局乘区只在入库乘一次
- [ ] 永久点店与 Prestige 货币店计价语义不混用

### 7.2 节奏

- [ ] M0 30 s 内有清晰动作
- [ ] 首次 Reset / Final 落在所选模式档案区间
- [ ] 单次 Reset 收益 +5–30%，30 s 内可感知（模式 A 不适用）
- [ ] 每阶段有质变点，不只是数字变大

### 7.3 数据

- [ ] 顶级配置为对象（id 作 key）
- [ ] 付费项含 `cost` / `cost_e` / `cost_inc`
- [ ] `currency` 引用货币表
- [ ] `constants` 含 XP cap（如有 reset）
- [ ] 购买赠送资源走 `apply_global=false`

### 7.4 模式专属（按所选档案勾选）

- 模式 A：4 生态区解锁，每区 1 biodiversity skill
- 模式 B：4 堵墙 + 跨轴 feedback + 12 区域独立 UI
- 模式 C：双 prestige + 9 era + 4 季节 calendar
- 模式 D：3-tuple 单一引擎 + 6-type transfer + service 软重置
- 模式 E：compression event + 跨建筑 inspiration + Reclamation 防失控
- 模式 F：7 主题 sin run + multi-phase equipment
- 模式 G：multi-phase artifact（collect/passive/access）+ multi-tier prestige
- 模式 H：3 层 prestige + 12 era + live ops SDK

---

## 8. 公式速查卡

```text
# 成本（§3.1）
price(L) = cost × 10^cost_e × cost_inc^L × price_mult
Σ(0..N-1) ≈ price(0) × (cost_inc^N - 1) / (cost_inc - 1)

# 产出入库（§3.6）
amount = local × typed_bonuses × bottleneck_bonuses

# 线性 / 复合
linear(L)    = 1 + L × p/100
compound(L)  = (1 + p/100)^L

# Reset XP cap（Cap-1）
cap(L) = base × growth^L

# 跳级
cost(10) = cost(9) × jump_mult          # jump_mult ∈ [5, 20]
value_ratio(10/8) ∈ [2, 5]

# Reset 收益安全区
immediate_primary_bonus ∈ [5%, 30%]

# cost_inc 阶梯
永久 1~2 | 主轴 10 | 里程碑 100 | 破墙 2000

# Gnorp X-rockets 反例（避免）
cost_inc = 5.0 → 单升级 3M → 15M → 76M（玩家跟不）

# 3-tuple 引擎（§3.8）
add(a, m, e, e_count):
    raw += a * (1 + m/multiplier) * multiplier * exponent
    multiplier += m
    if e > 0: raw *= pow(e, e_count); exponent *= pow(e, e_count)

# dual prestige（P2，§3.7 + 模式 C/H）
paragon = min(value × 0.01 × ratio, 2 × ratio)
burnedParagon = min(value × 0.01 × ratio, 4 × ratio)  # dark-future ×2
```

---

## 9. 反模式速查

> 全部反模式的唯一权威目录见 [docs/anti-patterns.md](anti-patterns.md)。本节按模式档案归纳最易踩的反模式。

### 9.1 跨模式共有

| 反模式 | 后果 |
|--------|------|
| 整体套用 §3 通用基础，忽略 §2 模式 | 主角动词与数值脱节 |
| 跨模式"挑喜欢的字段" | 字段集合解耦，导致 schema 碎片 |
| 一次改 5 个变量 | 无法归因 |
| 改配置不写 changelog | 无法回滚 |

### 9.2 §2 各模式反模式

- **模式 A**：引入 Reset / prestige currency / permanent upgrades；稀有度 5 档（含"普通"档）；核心轴 >5 条
- **模式 B**：升塔用纯指数公式；12 区域无独立 UI；O3 与 O4 指标不一致
- **模式 C**：双 prestige 共用 cap；科技用纯指数曲线（应固定价 + 全局乘区）；currency 隐式兑换
- **模式 D**：dispatcher 知道 node type；3-tuple `add()` 不幂等；discount 字段独立存在（应用负数 `a`）；service 触发 reboot 信号
- **模式 E**：升级用 `5.0^n`（Gnorp X-rockets 反例）；prestige 多 currency 共用 cap；跨建筑 source == target
- **模式 F**：sins currency 共用 cap 但又分 7 个升阶轨道；装备 tier 用纯指数曲线
- **模式 G**：神器用单 effect（必须 collect + passive 至少 2 阶段）；塔防与挖方子系统互不影响
- **模式 H**：单一 prestige currency 假装 3 层；era 顺序无质变点；"永久"与"暂态"currency 共用 cap；无 AchievementFactory 模式（660 子类散落是反模式）

### 9.3 core / 传统反模式（沿用 framework）

| 反模式 | 后果 |
|--------|------|
| 只有指数 sink、无 Reset / 永久 | 硬顶流失 |
| 永久仅加法、成本纯指数 | 永久追不上曲线 |
| 全局加成在多处乘算 | 数值膨胀 |
| 数值写死代码不抽配置 | 无法调参与版本对比 |
| Reset #1 < 5 min | 廉价，无 attachment |
| Reset #1 > 4 hr（中型）/ > 8 hr（超长） | 挫败 |
| Reset 后无立即可见 buff | 不愿 Reset |
| Reset 后主产出 +100%+ | 下局跳过产线直奔 Reset |
| 所有升级同档 | 决策疲劳或无目标 |
| 核心轴 > 5 | 货币分散 |
| 跳级太便宜 / 太贵 / 性价比倒挂 | 无目标 / 放弃 / 不跳 |
| 全资源互通兑换 | 失去 DAG，不知先刷哪个 |
| 资源 > 10 且无阶段解锁 | 认知过载（模式 H 长 DAG 分阶段除外） |
| Prestige currency > 3 且无共享总 cap | 决策疲劳 |
| 短长期分层 currency 共用 cap | 长期轨失效 |

---

*拷贝本文件即可在任意项目中使用。Step 1：选 §2 模式档案；Step 2：拷 §4 起步 JSON + §5 引擎伪代码；Step 3：按 §6 调优。所有数值锚点都来自真实 case 实证，避免"行业经验"陷阱。*
