# Case → Framework 贡献流程指南

> 本文档回答："**跑完一个 case 之后, 哪些内容值得反向沉淀到 framework?** 以及**如何沉淀?**"
>
> 适用对象: framework 维护者, 在向 `cases/<game>/` 添加新 case 后做 framework 演进时使用.
> 与 [CONTRIBUTING.md](../CONTRIBUTING.md) 互补 — CONTRIBUTING 答 "如何新增 Pattern/Case", 本文档答 "**何时**应该新增 Pattern/Optional/反模式/Schema".

---

## 目录

1. [为什么需要这个流程](#1-为什么需要这个流程)
2. [流程总览: 6 个阶段](#2-流程总览-6-个阶段)
3. [阶段 1: case 完成度自检](#3-阶段-1-case-完成度自检)
4. [阶段 2: 差异分析 (case vs framework)](#4-阶段-2-差异分析-case-vs-framework)
5. [阶段 3: 候选贡献清单](#5-阶段-3-候选贡献清单)
6. [阶段 4: 决策矩阵 (沉淀/不沉淀/部分沉淀)](#6-阶段-4-决策矩阵-沉淀不沉淀部分沉淀)
7. [阶段 5: 执行沉淀](#7-阶段-5-执行沉淀)
8. [阶段 6: CI 接入与回归保护](#8-阶段-6-ci-接入与回归保护)
9. [附录 A: 自动化检查脚本](#9-附录-a-自动化检查脚本)
10. [附录 B: 决策模板 (Markdown)](#10-附录-b-决策模板-markdown)
11. [反模式 (沉淀流程本身的)](#11-反模式-沉淀流程本身的)
12. [附录 C: 游戏界面（UI）完成标准](#12-附录-c-游戏界面ui完成标准)
13. [流程图 (单页速查)](#13-流程图-单页速查)
14. [配套](#14-配套)
15. [历史与维护](#15-历史与维护)

---

## 1. 为什么需要这个流程

Framework 的设计模式 (Pattern / Optional / Schema) **来自具体游戏的逆向分析** — 这意味着 framework 本身**会随着 case 增多而演化**:

| 现象 | 后果 | 解决 |
|------|------|------|
| 新 case 跑完没人评估 → framework 永远不增长 | Pattern 数量停滞, 新题材无模式可用 | 跑完 case 必走本流程 |
| 每个 case 都"沉淀" → framework 膨胀 | 大量"一次性"模式污染通用层 | 走"决策矩阵"过滤 |
| 沉淀时不更新 CHANGELOG / 反模式 / 索引 | 文档与代码脱节 | CI 强制校验 |

**核心原则**:

1. **Framework 是通用设计语言, case 是实证库** — 沉淀前问"这个 case 独有还是所有增量游戏都需要?"
2. **沉淀 = 提炼抽象 + 反模式 + Schema, 不 = 抄数据** — 数据归 case, 抽象归 framework
3. **每加一个 Pattern / Optional 必须有 1+ 实证, 实证缺位时不能上线**

---

## 2. 流程总览: 6 个阶段

```text
┌─────────────────────────────────────────────────────────────────┐
│  Stage 1: case 完成度自检                                        │
│  - 必含 metadata.json / README.md / mapping.json / derived/     │
│  - 必含 UI：ui-layout.json 达「结构可复原」(附录 C)               │
│  - python scripts/verify-case-metadata.py 通过                    │
│  - python scripts/case-to-framework.py --report 通过              │
│                                                                  │
│  ↓ (如果失败 → 先补 case, 不要沉淀)                              │
│                                                                  │
│  Stage 2: 差异分析                                               │
│  - 列 case 中的所有 system (resources/items/crops/...)             │
│  - 对每个 system 标 framework 覆盖: ✅/🆕/⚠️/❌                  │
│  - 工具: scripts/case-to-framework-coverage.py (本流程新增)       │
│                                                                  │
│  ↓ (如果发现 🆕 或 ⚠️ 项 → 进入 stage 3)                         │
│                                                                  │
│  Stage 3: 候选贡献清单                                           │
│  - 对每个 🆕 / ⚠️ 项, 写"是否可抽象为通用 pattern/optional"评估   │
│  - 评估维度: 通用性 / 复杂度 / 已有 case 复用 / 文档成本          │
│  - 输出: candidates.md (附录 B 模板)                              │
│                                                                  │
│  ↓ (筛选后 → 进入 stage 4)                                       │
│                                                                  │
│  Stage 4: 决策矩阵                                               │
│  - 4 个候选: 沉淀 / 部分沉淀 / 不沉淀 / 推迟                      │
│  - 每个决策写"原因 + 影响 + 副作用"                               │
│  - 强制: 不沉淀的也要在 candidates.md 记录理由                    │
│                                                                  │
│  ↓ (沉淀/部分沉淀项 → 进入 stage 5)                              │
│                                                                  │
│  Stage 5: 执行沉淀                                               │
│  - 5 个子任务 (见下)                                              │
│  - 每个子任务有"完成定义" (DoD)                                    │
│  - 全部分子任务完成才视为沉淀成功                                  │
│                                                                  │
│  ↓                                                                │
│                                                                  │
│  Stage 6: CI 接入与回归保护                                      │
│  - python scripts/run-all-checks.ps1 全部通过                     │
│  - python scripts/case-to-framework-coverage.py (新) 通过          │
│  - 在 CHANGELOG.md 记录, 附 case 引用                             │
│  - 至少 1 个其他 case 不被新 pattern/optional 破坏                 │
└─────────────────────────────────────────────────────────────────┘
```

**核心原则**: 6 个阶段是**强制顺序**; 跳阶段 = 反模式 (见 § 11).

---

## 3. 阶段 1: case 完成度自检

**目标**: case 必须达到 framework 维护级别的完整度, 才能进入沉淀评估. **不完整的 case 沉淀 = 把垃圾提炼到 framework 里**.

**通过标准**:

```bash
# 1. metadata ↔ README 一致
python scripts/verify-case-metadata.py

# 2. mapping.json → framework-view 生成成功
python scripts/case-to-framework.py <case_name> --report

# 3. case data 通过 schema 校验 (顶层 dict / 无 $schema / JSON 合法)
python scripts/validate-schemas.py

# 4. Markdown 内部链接无坏链
python scripts/check-md-links.py
```

另加 **人工 / 文档自检**（脚本暂未强制）:

| 检查项 | 通过条件 | 详见 |
|--------|----------|------|
| 游戏界面 | `ui-layout.json` 达到「结构可复原」 | [附录 C](#12-附录-c-游戏界面ui完成标准) |
| README 挂钩 | README 有 UI 专节，链到 `ui-layout.json`；`metadata.main_systems` 含 UI 项 | 附录 C § C.4 |
| mapping | `mapping.json` 有 `ui-layout.json` 条目（可映射到 O9，无强制 schema） | 附录 C § C.4 |

**全部通过** → 进入 stage 2. **任一失败** → 先修 case, 不要进 stage 2.

> **反模式**: case 还没跑完就先沉淀 → framework 污染  
> **反模式**: 只有面板名录 / 热键列表、没有区域几何 + 组件清单 → **不算** UI 完成（见附录 C）

---

## 4. 阶段 2: 差异分析 (case vs framework)

**目标**: 系统性列出 case 的所有 system, 标记 framework 是否覆盖.

**做法**:

1. **列 case system**: 从 `cases/<game>/README.md § 核心系统` 或 `metadata.json → main_systems` 提取
2. **逐个对照 framework 概念**:
   - `core/02-resources.md` (主货币/副货币/终局货币)
   - `core/03-production-lines.md` (产线 / DAG)
   - `core/04-upgrade-economy.md` (升级 / 成本曲线)
   - `core/05-reset-systems.md` (Reset / cap)
   - `core/06-permanent-upgrades.md` (永久项)
   - `patterns/pattern-X-*.md` (12 个 pattern)
   - `optional/oXX-*.md` (O1-O11 + O13, 缺 O12)
   - `schemas/*.schema.json` (8 个 schema)

3. **标记 4 类**:
   - ✅ **已覆盖** — case system 直接对应已有 pattern/optional
   - 🆕 **未覆盖 (新)** — case system 在 framework 完全没有对应, 可能是新 pattern/optional 候选
   - ⚠️ **部分覆盖** — framework 有类似概念但 case 实现不同/更复杂/更通用
   - ❌ **不适用** — case 独有 (e.g. Shelldiver 的"水母"), 1 个 case 不足以抽象

**工具**: `python scripts/case-to-framework-coverage.py <case_name>` (见 § 9 附录 A) 会自动生成 4 类标记的 markdown 表格.

**输出**:

- `cases/<case>/derived/coverage-report.md` — 单 case 覆盖度 + reverse-link 段
- `docs/case-candidates.md` — 全库候选索引 (自动 🆕/⚠️ + 命名候选 O14+)
- `cases/<case>/derived/candidates.md` — 阶段 3-4 决策记录 (手工维护, 见附录 B)

**Reverse-link (P2)**: coverage 脚本会检查 pattern header 声明的『来源 case』是否在 case README 中被反向引用。`--check` 模式下缺失会 **CI 失败**。

**何时进入 stage 3**:

- 🆕 数 ≥ 1: 必进入
- ⚠️ 数 ≥ 2: 必进入
- 仅 ✅ + ❌: 可跳过 (但建议仍写一份"评估记录"以备后案参考)

---

## 5. 阶段 3: 候选贡献清单

**目标**: 把 🆕 / ⚠️ 转化为可决策的"候选贡献项".

**评估维度 (每个候选 4 维评分 1-3)**:

| 维度 | 1 分 | 2 分 | 3 分 |
|------|------|------|------|
| **通用性** | 仅本 case 有, 其他题材不需要 | 2-3 个题材可能用 | 几乎所有增量游戏都会用 |
| **复杂度** | 极简 (≤ 5 字段) | 中等 (5-20 字段) | 复杂 (≥ 20 字段) |
| **已实证 case 数** | 仅本 case | 1 个其他 case 类似 | ≥ 2 个 case 类似 |
| **文档成本** | 仅 README 段 | 新 1 个 pattern/optional 文件 | 新 1 个 pattern + 1 个 schema |

**评分总和高 → 优先级高**.

**判断"是否需要新 Pattern" vs "强化现有 Optional"**:

- 系统**核心抽象不同** (e.g. per-resource unique ability 是 Pattern, 现有 Pattern S 是 item affix) → 新 Pattern
- 系统是现有 Optional 的**变体** (e.g. 7-sin prestige 是 O7 的 N 倍) → 强化现有 Optional
- 系统是 framework 缺口的**首次填补** (e.g. O6 一直"无实证") → 用新 case 做实证, 不新加 pattern

**判断"是否需要新 Schema"**:

- 数据是已有 schema 的子集 → 复用
- 数据有独立概念 (e.g. unique ability ≠ upgrade) → 新 schema
- 5+ 字段 + 跨 pattern 引用 → 新 schema

**输出**: `cases/<case>/derived/candidates.md` (附录 B 模板). 决策完成后, `case-to-framework-coverage.py` 会把结果同步到 [docs/case-candidates.md](case-candidates.md) 的「命名候选」表。

---

## 6. 阶段 4: 决策矩阵

**目标**: 对每个候选贡献项做最终决策.

**4 种决策**:

| 决策 | 触发条件 | 后续动作 |
|------|---------|---------|
| **沉淀** | 评分 ≥ 9 / 12 且通用性 ≥ 3 | 进入 stage 5 |
| **部分沉淀** | 评分 6-8 / 12 | 只在 README 加段, 不开新 pattern 文件 |
| **不沉淀** | 评分 ≤ 5 / 12 | 在 candidates.md 记录理由, 后续 case 再观察 |
| **推迟** | 通用性争议 / 缺其他 case 实证 | 标"等下个 case 再评估", 不写 framework |

**强制规则**:

- **不沉淀的也要在 candidates.md 写理由** (避免下个 case 重提同一候选)
- **推迟 ≥ 2 个 case** 才能最终决定不沉淀 (一次推迟 = 暂缓, 不是结论)
- **沉淀必须配反模式** (新 pattern 必含"反模式"段, 至少 3 条)

**输出**: `cases/<case>/derived/candidates.md` 终稿, 含每个候选的决策 + 理由.

---

## 7. 阶段 5: 执行沉淀

**目标**: 把"沉淀"决策落地为 framework 的实际改动.

**5 个子任务** (按顺序, 每个有 DoD):

### 5.1 新增 / 修改 pattern / optional 文件

**DoD**:

- 文件名遵守约定 (`pattern-X-name.md` / `oNN-name.md`)
- 必含段: 公式 / 反模式 (≥ 3 条) / 适用场景 / 配套 / 数据 Schema (有 schema 的)
- 顶部 metadata: 代号 / 来源 (指本 case) / 首次出现 (指 core/optional 文档)
- 引用使用相对路径

### 5.2 更新索引

**DoD**:

- `patterns/README.md` 索引表追加新行
- `optional/README.md` 索引表追加新行
- 涉及的相关 `core/*.md` 加"相关实战模式"段
- `schemas/README.md` 追加新 schema 行 (用 `python scripts/build-schema-index.py`)

### 5.3 更新反模式目录

**DoD**:

- 新反模式在对应专题文档写详细描述
- 在 `docs/anti-patterns.md` 追加一行 (带链接)
- 不要在根 README 重写 (根 README 指向 anti-patterns.md)

### 5.4 跑所有 CI 检查

**DoD**: `python scripts/run-all-checks.ps1` 全部 5 项通过:

- Schema and data consistency
- CHANGELOG sync invariants
- Markdown internal links
- Case metadata sync
- Schema index freshness

### 5.5 CHANGELOG 记录

**DoD**:

- `CHANGELOG.md` 顶部 `[Unreleased]` 段加新子段
- 标注: 新增 / 强化 / 替换 / 废弃
- 引用本 case: "**来源**: `cases/<game>/` (xxx system 实证)"
- 列出影响的 framework 概念 (新 pattern 编号 / optional 编号 / schema 编号)

**子任务顺序**: 5.1 → 5.2 → 5.3 → 5.4 → 5.5

**任一子任务失败 → 整次沉淀回滚** (撤销 5.1-5.3 的所有文件改动, 重新评估).

---

## 8. 阶段 6: CI 接入与回归保护

**目标**: 防止后续 case 沉淀时破坏已有 pattern, 也防止 framework 改动破坏已有 case.

**3 件事**:

1. **`scripts/case-to-framework-coverage.py`** (本流程新增) 接入 CI
   - 跑全部 case, 输出每个 case 的 framework 覆盖状态
   - 失败条件: 任何 case 的覆盖报告与上次 commit 不一致 (新增 case 必更新)
2. **在 `scripts/run-all-checks.ps1` 追加新检查**
   - 顺序: 现有 5 项 + 新检查
   - 失败码与现有 5 项一致
3. **新 pattern / optional 至少 1 个其他 case 在 README § framework 覆盖度清单 引用**
   - 防"挂名 pattern" (沉淀后没人用)
   - 由 `case-to-framework-coverage.py` 校验

**回归保护目标**: framework 任何改动后, **6 个 case 全部仍能通过 case-to-framework.py + verify-case-metadata.py**.

---

## 9. 附录 A: 自动化检查脚本

本流程新增 1 个脚本: **`scripts/case-to-framework-coverage.py`**.

**功能**: 自动扫描 `cases/<game>/`, 提取该 case 的所有 system 名称, 对照 framework 现有 pattern / optional / schema, 输出覆盖报告.

**用法**:

```bash
# 单个 case
python scripts/case-to-framework-coverage.py agrivore

# 全部 case
python scripts/case-to-framework-coverage.py

# 接入 CI (--check 模式: 报告与上次一致才退出 0)
python scripts/case-to-framework-coverage.py --check
```

**输出**: `cases/<game>/derived/coverage-report.md`

**报告格式**:

| Case System | Framework 覆盖 | 类型 | 备注 |
|------------|--------------|------|------|
| 6 货币 (coins/seeds/gems/crowns) | core/02 | ✅ | 主/副/终局三层匹配 |
| 26 crops (Tier1..4 + Golden) | core/03 + Pattern C | ✅ | 已有 multi-region |
| 13 item types | Pattern S | ✅ | 成长轴分档 |
| **35 evolutions** | ❌ | 🆕 | 候选: Pattern EM |
| **7 sins + 11 RunEffect** | O6 (无实证) | ⚠️ | 候选: O6 加实证 |
| 4 sigils | Pattern S (变体) | ✅ | 物品 affix 槽位 |
| 1 set bonus | Pattern S (变体) | ✅ | 套装 |
| 8 quest types | core/06 | ✅ | 任务系统 |
| 5 lifetime stats | core/05 + core/06 | ✅ | Reset + 永久 |
| **6 per-crop unique abilities** | ❌ | 🆕 | 候选: Pattern URA |

**实现概要**:

```python
# scripts/case-to-framework-coverage.py
# 1. 读 cases/<case>/mapping.json (data_file + framework_schema)
# 2. 读 cases/<case>/README.md § 核心系统
# 3. 读 cases/<case>/metadata.json → main_systems
# 4. 读 framework 索引 (patterns/README.md + optional/README.md)
# 5. 4 类标记算法:
#    - mapping.framework_schema 在 framework 索引中 → ✅
#    - mapping.framework_schema 标记"无实证" → ⚠️
#    - system 不在 mapping 中且 framework 无对应 → 🆕
#    - system 明确属本 case 独有 (e.g. "水母") → ❌
# 6. 写 cases/<case>/derived/coverage-report.md
```

**CI 接入**: `scripts/run-all-checks.ps1` 追加 `python scripts/case-to-framework-coverage.py --check`.

---

## 10. 附录 B: 决策模板 (Markdown)

每个 case 跑完, 在 `cases/<case>/derived/candidates.md` 写以下内容:

```markdown
# <case-name> · framework 候选贡献清单

> 由 stage 3-4 流程生成, stage 5 执行.
> 每个候选: 评估 4 维评分 + 决策 + 理由 + 影响范围.

---

## 候选 1: <名称> (e.g. "Per-Resource Unique Ability")

- **来源**: `cases/<case>/unique-skills.json` (6 unique skills, 1:1 绑定到 26 crops)
- **framework 现状**: 无对应 pattern/optional/schema
- **评分**:
  - 通用性: 3/3 (几乎所有带"产线"+"战斗"题材都可能用)
  - 复杂度: 2/3 (11 字段, 中等)
  - 已实证 case: 1/3 (仅本 case)
  - 文档成本: 2/3 (新 1 个 pattern + 1 个 schema)
  - **总分**: 8/12
- **决策**: 部分沉淀
- **理由**: 评分 8 边界值, 通用性 3 但实证不足. 不开新 pattern, 在 `core/05-unique-abilities.md` 加段描述"per-resource 绑定"模式, 等下个 case 实证后再升级为 pattern.
- **影响范围**: 1 个 core 文档, 0 个新 pattern, 0 个新 schema
- **副作用**: 后续 case 看到此段可能误以为是 pattern, 需 README 加"⚠️ 半实证段, 非通用 pattern" 警告

---

## 候选 2: <名称> ...

(重复)
```

---

## 11. 反模式 (沉淀流程本身的)

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| case 没跑完就沉淀 | 垃圾进 framework | 阶段 1 自检失败不进入阶段 2 |
| 跳过阶段 2 直接沉淀 | 凭印象判断, 漏掉真贡献 | 必走 coverage 报告 |
| 候选评分 < 6 仍沉淀 | framework 膨胀 | 走"不沉淀"或"推迟"决策 |
| 推迟 ≥ 1 次就永久不沉淀 | 错失真贡献 | 推迟必须配"等下个 case 再评估" |
| 新 pattern 不写反模式 | 后人踩坑无警告 | 5.1 必含 ≥ 3 条反模式 |
| 不更新索引 | 找不到新加的 pattern | 5.2 必跑 build-schema-index.py |
| 沉淀不写 CHANGELOG | 无法追溯 | 5.5 必填 |
| 沉淀破坏现有 case | 回归 | 5.4 必跑 run-all-checks.ps1, 5 项通过 |
| 沉淀只在新 case 加引用, 其他 case 不引 | 挂名 pattern | 5.1 必查 6 个 case README 都有引用 |
| 沉淀前不通知 reviewer | 单人决策风险大 | 必开 PR + @ 至少 1 reviewer |
| 把 case data 直接抄到 framework | 失去通用性 | framework 写抽象, data 留 case |
| 沉淀后忘跑 coverage --check | CI 漂移 | 阶段 6 必接 CI |
| UI 只写面板名 / 热键、无几何无组件树 | 无法按 case 复原界面结构 | 附录 C：必达「结构可复原」 |
| 把截图 / 整包 sprite 当 UI 完成标准 | 仓库膨胀、版权风险、仍缺结构 | 截图与像素资产**不要求**入库 |
| 用 ImGui/调试库名冒充主 HUD 描述 | 误导 M8 实现 | 分清主 HUD 技术栈与调试依赖 |

---

## 12. 附录 C: 游戏界面（UI）完成标准

> **一句话**: case 的 UI 文档以「**结构可复原**」为完成定义 — 有人只读 case，应能搭出与原作**同构**的 HUD（分区、组件树、热键/开关流），**不要求**像素级皮相复刻，也**不要求**把截图或 sprite 像素入库。

实证参考: [cases/dwarf-eat-mountain/ui-layout.json](../cases/dwarf-eat-mountain/ui-layout.json)（O9）。framework 侧对应 [optional/o09-interaction-qol.md](../optional/o09-interaction-qol.md)（M8 阶段才进引擎；case 仍须先写清 UI）。

### C.1 完成定义（DoD）

| 层级 | 是否必达 | 内容 |
|------|----------|------|
| 信息架构 | ✅ 必达 | 有哪些 panel / modal / toast；文案可追溯到 loc 或源码符号 |
| 交互地图 | ✅ 必达 | 打开/关闭方式、热键、批量购买、模式提示（enchant/swap 等） |
| **区域几何** | ✅ **必达** | 逻辑画布尺寸；各 HUD 区域 `rect` 或锚点；关键 chrome 的 **measured** 尺寸 |
| **组件清单** | ✅ **必达** | 按面板列出组件树（chip / 行模板 / 节点边框 / tooltip 字段…） |
| 截图入库 | ❌ 不要求 | 可用截图**量**坐标，但 case 不强制提交图片 |
| sprite 像素 | ❌ 不要求 | 记 sprite **名 + w×h** 即可；不入库图集 |
| bytecode 绝对锚点 | ❌ 不要求 | 未反编译的 x/y 可标 `confidence: inferred`，须写 basis |

**验收口令**: 只看 `ui-layout.json` + README UI 节，能否画出 ASCII 线框并列出每个面板的子控件？能 → 通过；只能复述「有个升级面板」→ 不通过。

### C.2 必交文件与推荐形状

```text
cases/<game>/
├── ui-layout.json          # 必含（有可玩 UI 的 case）
├── README.md               # 必有 UI 专节，链到 ui-layout.json
├── metadata.json           # main_systems 含 UI；data_completeness.ui_layout 说明状态
└── mapping.json            # 推荐：ui-layout → O9（无强制 schema）
```

`ui-layout.json` **最低字段**:

```text
_rebuild_standard: { target, not_required[], status }
coordinate_space:  { w, h, origin, unit, confidence, evidence }   # 例: 640×360
geometry.regions[]:
  - id, rect|{anchor}, confidence (measured|inferred), role
  - basis?          # inferred 必填：如何由 sprite/热键推出
  - sprites?        # measured 尺寸 {name,w,h}
components:         # 按面板
  - TopBar / MainPanel / UpgPanel / Modal… 的 children 或 row_template
hotkeys / settings_groups   # 交互与选项分组
```

`_rebuild_standard.status` 建议枚举:

| 值 | 含义 |
|----|------|
| `pass` | 关键区域均为 measured |
| `pass_with_inferred_anchors` | 画布/条/图标等已测；部分 panel x/y 为 inferred（**可接受通过**） |
| `fail` / 缺文件 | 阶段 1 不通过 |

### C.3 measured vs inferred

| confidence | 来源示例 | 用途 |
|------------|----------|------|
| `measured` | ROOM 宽高、SPRT `w/h`、明确全屏底图精灵 | 硬锚点，重建时优先锁死 |
| `inferred` | 「地面带高 60 → 贴底 y=H-60」；侧栏宽≈3–4 个 32px tile | 可微调；**必须**写 `basis` |

反模式: 把猜测坐标标成 measured；或只有 ASCII 示意、没有任何 `rect`/尺寸表。

### C.4 README / metadata / mapping 挂钩

- README: 专节（如 `§ 界面布局`）含 ASCII 线框 + 已测锚点表 + 指向 `ui-layout.json`
- `metadata.json`: `main_systems` 含 UI 项；`data_completeness.ui_layout` 写明 structure-rebuildable / 缺口
- `mapping.json`: `data_file: ui-layout.json`，`framework_schema` 可写 `(无强制 schema — Optional O9)`

差异分析（阶段 2）时: UI 系统对照 **O9**；若仅有文案无几何 → 标 ⚠️ 或阶段 1 直接打回。

### C.5 与 AI-first / M8 的关系

- Case 写 UI = **实证文档**（给 M1 参考、给 M8 接线），**不是**在 framework 里实现渲染。
- 引擎流程仍遵守 [ai-first-workflow.md](ai-first-workflow.md): M0–M7 headless；O9 进引擎属 **M8**。
- 沉淀 UI 抽象到 framework: 仍走本流程阶段 2–5；多数情况 **复用 O9**，勿为单游戏再开 Optional，除非附录 B 评分通过。

### C.6 快速检查清单

- [ ] 存在 `ui-layout.json`，且含 `geometry.regions` + `components`
- [ ] `coordinate_space` 有逻辑分辨率 + evidence
- [ ] 至少 1 条区域/精灵尺寸为 `measured`（不能全靠臆造）
- [ ] inferred 区域均有 `basis`
- [ ] TopBar / 主操作面 / 升级或等价情境面板 / 至少一类 Modal 有组件树
- [ ] 热键或等价输入与面板 open 关系写清
- [ ] README 有 UI 节并链接本文件；未把「缺截图」当作未完成理由

---

## 13. 流程图 (单页速查)

```text
跑完 case
  ↓
[阶段 1] case 完成度自检（含附录 C UI「结构可复原」）
  ↓ 通过
[阶段 2] coverage report (✅/🆕/⚠️/❌)
  ↓ 有 🆕 或 ⚠️
[阶段 3] candidates.md (4 维评分)
  ↓
[阶段 4] 4 种决策 (沉淀/部分/不沉淀/推迟)
  ↓ 沉淀/部分沉淀
[阶段 5] 5 个子任务 (新文件 → 索引 → 反模式 → CI → CHANGELOG)
  ↓
[阶段 6] CI 接入 + 回归保护
  ↓
完成 (framework 增长)
```

---

## 14. 配套

- **基础**: [CONTRIBUTING.md](../CONTRIBUTING.md) — 文档结构约定
- **基础**: [CHANGELOG.md](../CHANGELOG.md) — 变更追溯
- **工具**: [scripts/case-to-framework.py](../scripts/case-to-framework.py) — case data → framework-view
- **工具**: [scripts/verify-case-metadata.py](../scripts/verify-case-metadata.py) — case 元信息校验
- **工具**: [scripts/case-to-framework-coverage.py](../scripts/case-to-framework-coverage.py) — (本流程新增) 覆盖度报告 + reverse-link + 候选索引
- **工具**: [scripts/check-changelog-size.py](../scripts/check-changelog-size.py) — CHANGELOG 体积守门 (P3)
- **索引**: [docs/case-candidates.md](case-candidates.md) — 全库候选贡献自动索引
- **UI 标准**: 本文 [附录 C](#12-附录-c-游戏界面ui完成标准) — 结构可复原；实证 [cases/dwarf-eat-mountain/ui-layout.json](../cases/dwarf-eat-mountain/ui-layout.json)
- **数据**: [patterns/README.md](../patterns/README.md) — 12 个 pattern 索引
- **数据**: [optional/README.md](../optional/README.md) — 12 个 optional 索引
- **数据**: [schemas/README.md](../schemas/README.md) — 8 个 schema 索引

---

## 15. 历史与维护

- **2026-07-01**: 首次创建, 配合 [cases/agrivore/](../cases/agrivore/) (Unity 6 增量农场) 落地
- **2026-07-01 (P2/P3)**: 接入 reverse-link CI、`docs/case-candidates.md` 命名候选表、[cases/dwarf-eat-mountain/derived/candidates.md](../cases/dwarf-eat-mountain/derived/candidates.md) 首份阶段 4 决策
- **2026-07-13**: 新增 [附录 C](#12-附录-c-游戏界面ui完成标准) — case UI 以「结构可复原」（区域几何 + 组件清单）为完成定义；阶段 1 自检挂钩；实证 DEM
- **维护者**: framework 维护者
- **触发时机**: 每次新增 case 后必走一次
- **下一次 review**: framework 增长到 15+ pattern 或 5+ new case 时
