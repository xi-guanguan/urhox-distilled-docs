# Case → Framework 候选贡献索引

> 由 `scripts/case-to-framework-coverage.py` 自动生成。
> 每次跑脚本都会刷新本文件。
> 累计 61 个自动检测候选 + 3 个命名候选。

## 命名候选 (Named Candidates — 需阶段 4 决策)

case README 或 `derived/candidates.md` 中显式提出的 O14+ / Pattern 候选。

| Case | ID | 描述 | 决策 | 理由 |
|------|-----|------|------|------|
| [dwarf-eat-mountain](../cases/dwarf-eat-mountain/README.md) | **O14** | multi-phase artifact | 推迟 | 通用性高但仅 1 个实证。先在 DEM case 内完整文档化 3 类 effect 分类; 等第 2 个带 multi-phase loot 的 case ( |
| [dwarf-eat-mountain](../cases/dwarf-eat-mountain/README.md) | **O15** | 巢穴产怪 | 推迟 | 题材偏 TD, 与 O3 有重叠但抽象层不同。等 Shelldiver 式"区域敌人"或第二个 TD incremental case 再评估是否独立 O15, |
| [dwarf-eat-mountain](../cases/dwarf-eat-mountain/README.md) | **O16** | 矮人兵种 | 不沉淀 | 高度绑定 DEM 矮人题材; 抽象为"worker unit types"会与 Kittens Game 的 kitten jobs / Upload Labs |

## 自动候选 (按 case 分组 — coverage 🆕/⚠️)

### [agrivore](../cases/agrivore/README.md) (1 候选)

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)

### [cell-to-singularity](../cases/cell-to-singularity/README.md) (2 候选)

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **5b. 界面布局与交互 (UI Layout) — O9 实证** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

### [dwarf-eat-mountain](../cases/dwarf-eat-mountain/README.md) (5 候选)

- ⚠️ **dens** (mapping.json) — 映射不充分: (无直接 schema — 反派主体)
- ⚠️ **calamities** (mapping.json) — 映射不充分: (无直接 schema — 事件系统)
- ⚠️ **mountains** (mapping.json) — 映射不充分:  终局内容)
- ⚠️ **dwarves** (mapping.json) — 映射不充分: (无直接 schema — 工人类型)
- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)

### [gnorp](../cases/gnorp/README.md) (12 候选)

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **资源系统(3 个货币)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **建筑系统(14 个)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Gnorp 单位系统(8 个类型)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **状态效果系统(5 种)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Compression 机制(10 级 + Finale)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Prestige / Talent Points 系统** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Talents 系统(41 个,6 档)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Inspirations 系统(11 个跨建筑 modifier)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **升级 / 永久购买经济(各建筑 ~70+)** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **Achievements(17 个)与 Hats** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **15b. 界面布局与交互 (UI Layout) — O9 实证** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

### [scritchy-scratchy](../cases/scritchy-scratchy/README.md) (5 候选)

- 🆕 **ui-layout** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **系统一览（8 modules）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **映射与派生** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **数据完整度诚实声明** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **文件清单** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

### [shelldiver](../cases/shelldiver/README.md) (15 候选)

- ⚠️ **modules** (mapping.json) — 映射不充分: (无直接 schema — 元信息)
- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **模块结构（11 个）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **资源系统（6 个货币）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **生态区子系统（O11 简化版 — 4 区）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **水母清单（12 sprite + 沼泽变体）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **稀有度系统（Pattern R — 3 档）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **技能系统（88 个 — Pattern S / T / B + D 全覆盖）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗字段（87 个 bonus_*）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗武器（A + B 双武器）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **站点与自动化（9_stations_automation）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **盟友系统（10_allies）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **⚠️ 关于 Reset 系统** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **11b. 界面布局与交互 (UI Layout) — O9 实证** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **进度阶段（11 个模块的 progression 字段汇总）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

### [space-rock-breaker](../cases/space-rock-breaker/README.md) (7 候选)

- 🆕 **artifacts** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **ui-layout** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **plinko** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **sectors** (mapping.json) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **系统一览（8 modules）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **映射与派生** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **文件清单** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

### [tower-wizard](../cases/tower-wizard/README.md) (14 候选)

- ⚠️ **ui-layout** (mapping.json) — 映射不充分: (无强制 schema — Optional O9 Interaction QoL)
- 🆕 **塔层系统（10 档 + 升塔成本）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **区域子系统（O11 完整版 — 12 区域）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **资源系统（11 个货币）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗与墙体（O3 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **状态效果系统（Pattern E 实证 — 5 种）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **技能系统（80 个 — Pattern S/T/B 全覆盖）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **祝福系统（40 个 — Pattern C 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **训练系统（4 个 — 跨区域乘区）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **国家系统（22 个 — O11 跨区域实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **转生系统（双轨 — O7 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **副进度条（O2 实证 — 3 条）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **QoL 机制（O9 实证）** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)
- 🆕 **战斗乘区链** (README.md § 章节) — 无对应 framework schema (README 章节, 待评估)

## 下一步

1. 对每个候选 system 跑 [case-to-framework-contribute.md § 阶段 4 决策矩阵](case-to-framework-contribute.md#6-阶段-4-决策矩阵)
2. 决策为'沉淀'的 → 进入 [阶段 5 执行](case-to-framework-contribute.md#7-阶段-5-执行沉淀)
3. 决策为'不沉淀'的 → 在 case README 的 system 段加 `framework_evidence: intentionally-not-contributed` 标注

## 触发评估的阈值

| 指标 | 阈值 | 含义 |
|------|------|------|
| 同一 system 出现在 ≥ 2 个 case | 必评估 | 强通用信号 |
| 同一 system 出现在 ≥ 3 个 case | 必沉淀 | 重复损失 > 沉淀成本 |
| 单一 case 独有 system | 可选 | 需要 `framework_evidence` 标注 |
