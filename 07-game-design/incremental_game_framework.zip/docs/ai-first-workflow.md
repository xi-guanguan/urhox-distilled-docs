# AI 优先 / 自动化测试优先工作流

> 本框架的**工程落地哲学**：先让 AI agent 能驱动 headless 引擎跑通玩法与数值，再用批量模拟验证平衡，**最后**才做 UI 与界面。
>
> 策划流程见 [GAME_DESIGN_GUIDE.md](../GAME_DESIGN_GUIDE.md)（AI 引导：一键托管 / 方案体检 / 逐步问答 → M0–M8）；本文是程序员 / AI agent 的权威对接文档。中途修改走 `mid-game-balance-fix`。

---

## 1. 核心命题

增量游戏的设计天然是**数据驱动**的。本框架把交付物分成四层，**严格按顺序推进**：

```text
L1 设计文档 + JSON 配置     ← M0-M5（策划 / data-architect）
L2 headless 引擎 + CLI      ← M6（core-engineer）
L3 批量模拟 + 平衡报告       ← M7（auto-tester + balance-mathematician）
L4 UI / 渲染 / 交互          ← M8（可选，M7 健康度通过后再做）
```

**不做的事（M0-M7 阶段）**：

- 界面布局、按钮交互、美术、动画、屏幕适配
- 依赖 GUI 框架的可玩 demo
- 以人工试玩作为**唯一**平衡验证手段

**必须做的事**：

- JSON 配置可被 schema 校验
- headless 引擎可通过 CLI 批量模拟
- 同 seed 同策略 → 同结果（确定性回归）
- 数值调优基于 5 类自动化指标，而非主观感受

---

## 2. 为什么 UI 放最后

| 先做 UI 的问题 | 先做 headless 的收益 |
|----------------|---------------------|
| 数值 bug 被界面掩盖，难以归因 | tick 级 log，精确到字段 |
| 人工试玩慢、不可复现 | 1000 次模拟分钟级完成 |
| AI agent 无法操作界面 | CLI + Strategy 接口可编程决策 |
| 改数值要重新编译 / 打包 | 改 JSON → 重跑模拟即可 |
| 平衡讨论停留在"感觉太慢" | P50/P90 首次 reset tick 可量化 |

> **O9（交互 QoL）**、长按、Tooltip、跳级视觉反馈等，全部属于 **M8** 范畴——引擎逻辑已在 M6-M7 验证通过后再接入。

---

## 3. 里程碑对照（M6-M8）

| 阶段 | 交付物 | 验证方式 | 委派 agent |
|------|--------|---------|-----------|
| **M6** | `src/` headless 引擎 + CLI | `python -m game --max-ticks 10000` 正常输出 JSON | `core-engineer` |
| **M7** | `tests/reports/` 批量模拟报告 + changelog | 1000 次模拟 100% 完成率 + 5 类指标健康 | `auto-tester` → `balance-mathematician` |
| **M8** | 游戏界面设计 + 可选渲染 | `docs/ui-layout.md` + `ui/ui-layout.json` 达结构可复原；再绑引擎；UI 不含业务逻辑 | `new-incremental-game` 按 [GAME_DESIGN_GUIDE §5 M8](../GAME_DESIGN_GUIDE.md#m8--游戏界面设计可选m7-通过后)（无单独 UI skill） |

M6 最小可玩标准（headless）：

- 1 个 currency + 1 条产线 + 1 个 upgrade 可购买
- tick 循环稳定，无 NaN / Inf / 溢出
- `--seed 42` 两次运行结果一致

M7 通过标准：

- 吞吐：1000 runs × 50000 ticks，100% 完成
- 平衡：无单一 build path 占 >80% 升级分布
- 节奏：首次 reset tick P50 在设计目标 ±30% 内
- 异常：0 条 🔴 阻断级异常

---

## 4. headless 引擎 CLI 契约

所有游戏项目的引擎**必须**实现以下 CLI 接口（语言不限，Python 仅为示例）：

```bash
# 单次运行到指定 tick
python -m game --config data/ --max-ticks 10000 --seed 42

# 批量模拟 N 次
python -m game --config data/ --runs 1000 --max-ticks 50000 --output results.json

# 指定策略
python -m game --config data/ --strategy greedy --runs 100

# 状态快照（回归对比）
python -m game --config data/ --snapshot 1000,5000,10000 --output snapshot.json

# 存档回归
python -m game --config data/ --save snapshot.json --load snapshot.json
```

### 输出 JSON 格式

```json
{
  "run_id": 0,
  "seed": 42,
  "total_ticks": 50000,
  "reset_count": 12,
  "final_state": { "currencies": {}, "upgrades": {}, "permanent_points": 45 },
  "timeline": [
    { "tick": 1800, "event": "first_reset", "xp": 150 }
  ]
}
```

### Strategy 接口（AI agent 可注入决策）

```python
class Strategy(ABC):
    @abstractmethod
    def decide(self, state: dict) -> list[str]:
        """返回 action 列表，如 ['purchase:click_power_1', 'reset']"""
        ...
```

内置策略：`random` / `greedy` / `balanced` / 自定义 JSON 决策表。

---

## 5. 自动化测试矩阵

| 测试类 | 命令 | 目标 |
|--------|------|------|
| 吞吐 | `--runs 1000 --max-ticks 10000` | 100% 完成率，无崩溃 |
| 平衡 | `--runs 100 --strategy greedy` | 无 build path 完爆 |
| 边界 | `--max-ticks 1` / `--max-ticks 1000000` | 极短/极长不溢出 |
| 确定性 | `--runs 10 --seed 42` | 同 seed 同结果 |
| 策略对比 | 多策略各 100 次 | 贪心 vs 均衡 vs 随机 |

### 5 类核心指标

| 指标 | 统计方式 | 健康范围 |
|------|---------|---------|
| 首次 reset tick | P50 / P90 / P99 | 按 M3 时间轴设定（通常 300-7200 ticks @ 60tick/s） |
| 资源利用率 | 各 currency 触顶率 | 限制资源 ≥50% 利用率 |
| build path 分布 | 各 upgrade 最终 level | 无单一升级占 >80% |
| reset 频率 | 每 N tick 一次 reset | 曲线平滑，无突变 |
| 永久点累积 | 1000 runs 后分布 | P90 在设计目标 ±20% |

### 异常检测（阻断级 🔴）

- 数值溢出（`> 1e308` 或 NaN / Inf）
- 零产出持续 >1000 tick
- reset 后 run 状态未清空
- 永久点负增长

完整规则见 skill `auto-tester`（`skills/auto-tester/SKILL.md`）。

---

## 6. AI Skill 编排

完整索引：[PLUGIN.md](../PLUGIN.md) · Skills：[skills/](../skills/)

### 两条入口 skill

| 场景 | 入口 Skill | 分组 |
|------|-----------|------|
| 从 0 开始 | `new-incremental-game`（先选引导路径 A/B/C） | design |
| 中途修正 | `mid-game-balance-fix` | validation |

总路由：`using-incremental-framework`（design）

**新游戏引导路径**（权威：[GAME_DESIGN_GUIDE.md §2](../GAME_DESIGN_GUIDE.md#2-开场路由含三路径)）：

| 路径 | 开发者负担 | 适用 |
|------|-----------|------|
| A 一键托管 | 约 5 题 + 两处确认 | 简单玩法、想快点出原型 |
| B 方案体检 | 先交材料，再答缺口题 | 已有设计/草稿 |
| C 逐步问答 | 按 M0–M8 一题一题 | 想细抠每个决策 |

三条路径交付物相同；工程层（本文 M6–M8）不因路径而变。

### 专项 Skill（按层）

| Skill | 触发时机 | 职责 | 分组 |
|-------|---------|------|------|
| `new-incremental-game` | 新游戏立项 | M0-M7 总控 | design |
| `mid-game-balance-fix` | 玩法/数值修正 | S1-S4 诊断与编排 | validation |
| `game-designer` | M0-M4 | 概念、DAG、时间轴、Pattern 勾选 | design |
| `case-consultant` | M1 | 选参考 case | design |
| `data-architect` | M5 / 加内容 | JSON 骨架与 Schema | data |
| `balance-mathematician` | M5/M7 / 调平衡 | 填数值、模拟驱动调优 | data |
| `core-engineer` | M6 / bug | headless 引擎 + CLI | engine |
| `pattern-integrator` | M6 / 新系统 | 集成 Pattern | engine |
| `optional-integrator` | M6 / 新系统 | 集成 Optional（不含 O9 UI） | engine |
| `auto-tester` | M7 / 修正后 | 批量模拟 + 报告 | validation |
| `quality-validator` | M7 收尾 | CI 门禁 | validation |

**委派原则**：每个 skill 只改自己层的文件——策划改 `docs/` + `data/`，引擎改 `src/`，测试改 `tests/`。

---

## 7. 项目目录（推荐）

```text
my-game/
├── docs/                    # M0-M4 设计文档
│   ├── game-concept.md
│   ├── dag.md
│   ├── timeline.md
│   └── pattern-decisions.md
├── data/                    # M5 JSON 配置
│   ├── currencies.json
│   ├── upgrades.json
│   └── ...
├── src/                     # M6 headless 引擎
│   ├── __main__.py          # CLI 入口
│   ├── engine.py
│   └── strategy.py
├── tests/                   # M7 自动化
│   ├── results/             # 模拟原始 JSON
│   ├── reports/             # Markdown 统计报告
│   └── analyze_results.py   # 报告生成脚本
└── ui/                      # M8（M7 通过后再建）
    └── ...
```

> `ui/` 目录在 M7 健康度 ✅ 之前**不应存在**。若已有 UI 原型，业务逻辑须下沉到 `src/` 引擎层。

---

## 8. 与框架文档的对应关系

| 需求 | 文档 |
|------|------|
| 策划引导（三路径 → M0-M8） | [GAME_DESIGN_GUIDE.md](../GAME_DESIGN_GUIDE.md) |
| Core 机制 | [core/](../core/) |
| 伪代码参考 | [examples/pseudocode/](../examples/pseudocode/) |
| 数值手册 | [docs/numerical-design.md](numerical-design.md) |
| 反模式（含 UI 先行） | [docs/anti-patterns.md](anti-patterns.md) |
| CI 校验 | [scripts/README.md](../scripts/README.md) |

---

## 9. 一句话总结

> **JSON → headless 引擎 → 1000 次模拟 → 调数值 → 最后才做 UI**
>
> 能跑模拟的游戏才是可验证的游戏；能改 JSON 重跑的游戏才是可迭代的游戏。
