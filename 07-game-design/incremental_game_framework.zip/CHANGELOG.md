﻿# Changelog

> 框架的所有变更记录。按版本倒序排列。

---

## [Unreleased]

### GAME_DESIGN_GUIDE — 三路径引导，降低心智负担（2026-07-15）

- **开场路由加第 2 题**：新游戏先选 **一键托管 / 方案体检 / 逐步问答**（白话说明，不堆术语）
- **§3 一键托管** — 约 5 个关键题；AI 补全 M0–M4；仅 M0 概念 + M4 勾选强制确认
- **§4 方案体检** — 先收设计材料，只问缺口/矛盾，再写成标准交付物
- **§5 逐步问答** — 原 M0–M8 长问卷；措辞更白话（「资源关系图」「重置变强」等）
- **同步** — `new-incremental-game` / `game-designer` / `using-incremental-framework`、`commands/new-game`、`PLUGIN.md`、`README.md`、`docs/ai-first-workflow.md`、`CONTRIBUTING.md`；M8 锚点改为 §5 M8

### GAME_DESIGN_GUIDE — 改为 AI 引导脚本（2026-07-14）

- **重写 [GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md)** — 读者改为 AI：一次一问、过关再进，引导开发者完成新游戏 M0–M8
- **范围收窄** — 中途修改不再展开；开场路由到 skill `mid-game-balance-fix`
- **结构** — §1 角色硬规则 → §2 开场路由 → §3 M0–M8 引导脚本；Case/Pattern/反模式/目录树收入附录
- **交叉引用** — skills / PLUGIN / commands / README / ai-first-workflow 中 M8 锚点改为 §3 M8

### Plugin skills — 对齐 M8 游戏界面设计（2026-07-13）

- **`new-incremental-game` / `using-incremental-framework` / `game-designer` / `commands/new-game`** — M0–M8 表述与路由同步；M8 无新 skill，走 GDG §2 M8
- **`.cursor-plugin/plugin.json` → 0.3.2** — description 含 M0-M8 / ui-layout
- **`PLUGIN.md` / `docs/ai-first-workflow.md`** — M8 交付物与委派说明
- **`case-consultant` + GDG M1** — 索引扩至 10 case（含 Scritchy Scratchy / Space Rock Breaker）；读取协议含 UI 专节
- **两新 case README** — UI 专节补 ASCII 线框 + 锚点表（附录 C）

### GAME_DESIGN_GUIDE — 补全 M8 游戏界面设计（2026-07-13）

- **扩写 [GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) §2 M8** — 从「可选绑渲染」升级为完整**游戏界面设计**流程：信息架构 → 区域几何 → 组件树 → 热键/O9 → 再皮相
- **交付物约定** — `my-game/docs/ui-layout.md` + `my-game/ui/ui-layout.json`（与 case 附录 C「结构可复原」同构）
- **参考范式表** — DEM / Agrivore / Upload Labs / Gnorp / CTS / Space Rock Breaker / Scritchy Scratchy / Shelldiver / Tower Wizard
- **反模式 / 速查 / 目录树** — 同步补「无几何不通过」「复用 O9」与附录 C / O9 链接

### Plugin commands — 对齐 Superpowers（2026-07-10）

- **主 commands 保留 2 个** — `new-game`、`fix-balance`；`run-sim`、`validate` 标为 deprecated，指向 `auto-tester` / `quality-validator` skill
- **触发词去重** — `mid-game-balance-fix` 负责中途诊断编排；`balance-mathematician` 负责已有模拟报告后的单旋钮调优

### Cursor Plugin — 对齐 Superpowers 单 plugin 结构（2026-07-10）

- **根级 manifest** — 恢复 [`.cursor-plugin/plugin.json`](.cursor-plugin/plugin.json)；[`marketplace.json`](.cursor-plugin/marketplace.json) 改为单 plugin `source: "."`
- **平铺 skills/commands** — 12 个 skill 移至 [`skills/`](skills/)；4 个 command 移至 [`commands/`](commands/)
- **移除 `plugins/` 多子插件目录** — Cursor UI 与 Superpowers 一致，按 plugin 名分组展示
- **移除 `agents/`** — 能力全在 skills，不再维护 subagent 文件

### Cursor Plugin — 对齐 Superpowers 架构（2026-07-10）

- **Marketplace 多子插件** — [`.cursor-plugin/marketplace.json`](.cursor-plugin/marketplace.json) 使用 `pluginRoot: plugins`，4 个分类：`incremental-design` / `incremental-data` / `incremental-engine` / `incremental-validation`
- **Skills 为主体** — 原 11 个 subagent 正文迁移为 12 个 `plugins/*/skills/*/SKILL.md`；编排逻辑在 `new-incremental-game` / `mid-game-balance-fix` 中通过调用 skill 完成
- **移除错误结构** — 删除根级 `skills/`、`commands/`、`.cursor-plugin/plugin.json` 及 `agents/*.md`（保留迁移对照 [agents/README.md](agents/README.md)）
- **更新** [PLUGIN.md](PLUGIN.md)、[docs/ai-first-workflow.md](docs/ai-first-workflow.md)、[README.md](README.md)、[scripts/install-cursor-plugin.ps1](scripts/install-cursor-plugin.ps1)

### Cursor Plugin  packaging (2026-07-10)

- **新增 [`.cursor-plugin/marketplace.json`](.cursor-plugin/marketplace.json)** — 修复 Customize「从文件夹添加」报 No marketplace manifest found
- **修复 manifest** — 移除 `hooks` 自定义路径；补标准 [`hooks/hooks.json`](hooks/hooks.json)；版本 `0.1.1`
- **新增 [`scripts/install-cursor-plugin.ps1`](scripts/install-cursor-plugin.ps1)** — 本地 junction 安装（CodeUp 等非 GitHub 远程无法用 `/add-plugin`）
- **PLUGIN.md 排查** — 「没有 manifest」常见原因与本地安装步骤

### 仓库清理 — 移除无效/可再生成文件 (2026-07-10)

- **删除 `audit/`** — 一次性臃肿度分析脚本与报告，非框架交付物；移除已追踪的 `audit/deep_coverage.py`
- **清理 `_tools/` 中间产物** — 删除 `extracted/`（含 21MB strings.txt）、`Assembly-CSharp.il`（11MB）、`__pycache__/`；保留 41 个提取脚本（~171KB）供 case 维护者本地使用
- **更新 [.gitignore](.gitignore)** — 显式忽略 `audit/`、`_tools/**/extracted/`、`_tools/**/*.il`
- **修复 [optional/o06-area-focus.md](optional/o06-area-focus.md)** — 移除对已删 audit 文档的断链

### AI 优先 / 自动化测试优先 — Subagent 体系 (2026-07-10)

- **新增 11 个 Cursor subagent**（[.cursor/agents/](.cursor/agents/)）— 拆分为编排/设计/数据/实现/验证五层；两条入口：`design-orchestrator`（从 0）+ `mid-game-fixer`（中途修正）
- **新增 agent**：`game-designer`（M0-M4）、`mid-game-fixer`（场景 A-E）、[.cursor/agents/README.md](.cursor/agents/README.md)（索引与委派图）
- **修复 agent frontmatter** — `case-consultant` / `data-architect` / `pattern-integrator` / `optional-integrator` 补齐 `name` + `description`

### AI 优先 / 自动化测试优先工作流重构 — 文档层 (2026-07-10)

框架工程定位从「策划文档 + 可玩 demo」调整为 **AI 调用优先 + 自动化测试优先 + headless 先行**：

- **新增 [docs/ai-first-workflow.md](docs/ai-first-workflow.md)** — 工程落地哲学权威文档：四层交付顺序（JSON → headless 引擎 → 批量模拟 → UI）、CLI 契约、测试矩阵、AI agent 编排
- **[GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) 工作流重构** — M6 改为 headless 引擎（无 UI）；M7 改为批量模拟 + 自动化指标调优；新增 M8（UI，M7 通过后可选）；项目目录增加 `tests/` + `ui/`
- **[README.md](README.md) 定位更新** — 顶部强调 AI/自动化优先；Checklist 拆分为 M6-M7 工程化 + M8 UI 层
- **同步更新** — [core/README.md](core/README.md)、[examples/README.md](examples/README.md)、[docs/anti-patterns.md](docs/anti-patterns.md)、[.cursor/agents/design-orchestrator.md](.cursor/agents/design-orchestrator.md)

### 归档 CHANGELOG 历史（2026-07-14）

- **归档** 2026-07-10 之前全部条目 → [CHANGELOG/archive/CHANGELOG-history-pre-2026-07-10.md](CHANGELOG/archive/CHANGELOG-history-pre-2026-07-10.md)
- 根 CHANGELOG 仅保留近期 Unreleased（体积守门 soft=600 / hard=900）

> 历史版本见 [CHANGELOG/archive/](CHANGELOG/archive/)

### CI 健康修复（2026-07-14）

- **断链** — `CONTRIBUTING.md` 统一指向 `patterns/conflicts.md`（不再提不存在的 `optional/conflicts.md`）
- **README** — 案例数 8→10；目录树对齐 `cases/<game>/`；应用案例表补 Scritchy Scratchy / Space Rock Breaker
- **schema** — `biome.schema.json` 去掉不存在的 `medieval-alchemy` 引用，改为 O11
- **link checker** — `CHANGELOG/archive/` 内历史断链按 CHANGELOG 同等降级为 info
- **coverage** — 再生 case coverage 报告与 `docs/case-candidates.md`，消除 CI 漂移


