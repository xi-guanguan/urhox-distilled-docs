﻿# 增量游戏设计框架

> **题材无关的增量游戏设计框架**：Core 机制（5 篇）+ 实战 Pattern（12 个）+ Optional 模块（12 个）+ 应用案例（10 个）+ 落地示例 + Schema。
>
> **工程定位**：**AI 调用优先 + 自动化测试优先**——先跑通 headless 玩法与数值（M6-M7），最后才做 UI 与界面（M8）。详见 [docs/ai-first-workflow.md](docs/ai-first-workflow.md)。

```
模式写 .md，数值写项目 *.json，验证靠批量模拟
```

实战 Pattern（P/R/S/B/D/T）源自 [cases/shelldiver/README.md](cases/shelldiver/README.md) 的设计沉淀。Pattern E（状态 Stack）+ O11（多区域）来自 [cases/tower-wizard/README.md](cases/tower-wizard/README.md) 的实证沉淀（5 种状态效果 + 12 区域子系统）。[cases/kittens-game/README.md](cases/kittens-game/README.md) 提供了 9 平行轨道的超大规模增量样本（58 资源 / 39 建筑 / 62 科技 / 137 升级 / 37 转生 perk / 8 行星 / 8 种族），并实证了 3 个新候选 Pattern（P2 双向转生货币 / C7 自选永久 debuff / O13 时空多层循环）。[cases/upload-labs/README.md](cases/upload-labs/README.md) 提供了 Godot 4 节点流水线增量样本（8 货币 / 57 属性 / 103 window / 86 升级 / 47 research / 18 perk / 3 milestone / 24 achievement / 42 request / 7 boost / 3 service 软重置），并实证了 3 个新候选 Pattern（AME 3-tuple 属性 / N 节点流水线图 / PR Service 软重置）。[cases/gnorp/README.md](cases/gnorp/README.md) 提供了物理模拟型增量样本（3 货币 / 14 建筑 / 8 Gnorp 类型 / 5 status effect / 35 talents / 11 inspirations / 10+1 compression / 17 成就 / 75 upgrades），并**实证 8 个 Pattern（B/C/D/E/P/R/S/T）+ 11 个 Optional（O1-O5 / O7-O11 / O13，未含 O6）**（Pattern + Optional 合计覆盖面最广的案例），是框架的"集成测试场"。[cases/agrivore/README.md](cases/agrivore/README.md) 提供了 Unity 6 农场 + 战斗 + 7 罪孽主题 + Treasury 跨 run 技能树样本（6 货币 / 32 资源 / 7 sins / 24 sigil / 17 set-bonus / 30 quest / 31 achievement），并实证了 Pattern R（7 罪孽稀有度 meta 倍率）。[cases/dwarf-eat-mountain/README.md](cases/dwarf-eat-mountain/README.md) 提供了 GameMaker Studio 矮人挖山 + 塔防样本（14 建筑 / 199 升级 / 124 artifacts / 102 prestige / 27 ore / 30 calamity / 10 dwarf），并提出 3 个候选 Optional（O14 多阶段神器 effect / O15 巢穴产怪 / O16 矮人兵种）。[cases/cell-to-singularity/README.md](cases/cell-to-singularity/README.md) 提供了 Unity 2021+ 单人 9 年长期运营的进化科普增量样本（6 货币 / 12 era / 30+ 产线 / 12+ 升级 / 12+ creature / 70+ 成就 / 3 层 prestige 嵌套 / 243 enum / 34 ScriptableObject），并实证 Pattern B/S/T/R/P2/E + O1/O2/O3/O5/O7/O11/O13（**现实长期演进样本**，与 agrivore 同为 Unity 案例但走无 Addressables 路径）。沉淀后即视为通用，不依赖具体题材。

---

## 目录结构

```
incremental_game_framework/
├── README.md              # 你在这里
├── .cursor-plugin/        # Cursor Plugin（对齐 Superpowers）
│   ├── plugin.json        # 主 manifest
│   └── marketplace.json   # From folder 安装
├── skills/                # 12 个 skill（平铺）
├── commands/              # 4 个 slash commands
├── hooks/                 # hooks-cursor.json
├── PLUGIN.md              # Plugin 安装与用法
│
├── GAME_DESIGN_GUIDE.md   # AI 引导脚本：三路径（一键托管/方案体检/逐步问答）→ M0–M8
├── CHANGELOG.md           # 变更记录
├── CONTRIBUTING.md        # 如何新增 Pattern / Case
│
> 根级 4 个 `.md` 按**阅读顺序**排列（不是字母序）：先看 README → 流程 → 历史 → 贡献。
│
├── core/                  # 必读 MVP（5 篇，编号 02-06）
│   ├── README.md          # 总览（原 01 游戏循环已并入此处，编号保留空位）
│   ├── 02-resources.md
│   ├── 03-production-lines.md
│   ├── 04-upgrade-economy.md
│   ├── 05-reset-systems.md
│   └── 06-permanent-upgrades.md
│
├── patterns/              # 实战模式（12 个 Pattern）
│   ├── README.md
│   ├── pattern-r-rarity.md
│   ├── pattern-d-dual-pool.md
│   ├── pattern-s-skill-tiers.md
│   ├── pattern-b-binary-unlock.md
│   ├── pattern-t-tier-jump.md
│   ├── pattern-c-cross-building-inspiration.md  # 跨建筑 Inspiration 链（Gnorp 实证）
│   ├── pattern-e-status-stack.md        # 状态效果 Stack（理论沉淀）
│   ├── pattern-p2-dual-prestige.md     # 双 prestige 货币（KG 实证）
│   ├── pattern-c7-opt-in-debuff.md     # 自选永久 debuff（KG 实证）
│   ├── pattern-ame-3tuple-attribute.md # 3-tuple 属性统一（Upload Labs 实证）
│   ├── pattern-n-node-pipeline.md      # 节点流水线图（Upload Labs 实证）
│   └── pattern-pr-service-soft-reset.md# Service 软重置（Upload Labs 实证）
│
├── optional/              # Optional 模块（O1-O13）
│   ├── README.md
│   ├── o01-chapter-gates.md
│   ├── o02-endgame-progress-bars.md
│   ├── o03-challenge-axis.md
│   ├── o04-cross-axis-feedback.md
│   ├── o05-bottleneck-balance.md       # ✨ 已强化：两档乘区（Focus + Broad）
│   ├── o06-area-focus.md
│   ├── o07-dual-reset-track.md
│   ├── o08-support-systems.md
│   ├── o09-interaction-qol.md
│   ├── o10-pacing-milestones.md
│   ├── o11-multi-region.md             # 多区域子系统（理论沉淀）
│   └── o13-temporal-multicycle.md      # 时空多层循环（Kittens Game 实证）
│
├── cases/                 # 应用案例（10 个；每个 case 自包含子目录）
│   ├── README.md          # 案例索引与目录约定（权威）
│   ├── shelldiver/        # GMS 潜水 + 稀有度
│   ├── tower-wizard/      # Godot 建塔 + 状态 Stack
│   ├── kittens-game/      # JS 猫村 + 跨周期
│   ├── upload-labs/       # Godot 节点流水线
│   ├── gnorp/             # 物理模拟 + 跨建筑 inspiration
│   ├── agrivore/          # Unity 农场 + 原罪
│   ├── dwarf-eat-mountain/# GMS 挖山塔防
│   ├── cell-to-singularity/# Unity 进化科普长期运营
│   ├── scritchy-scratchy/ # Unity 刮刮卡
│   └── space-rock-breaker/# Unity 太空采矿
│
├── examples/              # 落地示例
│   ├── README.md
│   ├── pseudocode/         # 关键算法的伪代码
│   │   ├── add-resource.md
│   │   ├── gain-xp.md
│   │   ├── purchase.md
│   │   ├── apply-status-effect.md      # Pattern E 伪代码
│   │   ├── region-manager.md           # O11 伪代码
│   │   └── inspiration-resolver.md     # Pattern C 伪代码
│   └── configs/            # 数据 JSON 示例
│       ├── example-upgrades.json
│       ├── example-permanent.json
│       ├── example-rarity.json
│       ├── example-tier-jump.json
│       ├── example-status-effect.json   # Pattern E 配置
│       ├── example-multi-region.json    # O11 配置
│       └── example-cross-building-inspiration.json  # Pattern C 配置
│
├── schemas/               # JSON Schema（8 个；索引见 schemas/README.md）
│   ├── README.md
│   ├── upgrade.schema.json
│   ├── permanent-upgrade.schema.json
│   ├── rarity.schema.json
│   ├── constants.schema.json
│   ├── status-effect.schema.json
│   ├── multi-region.schema.json
│   ├── cross-building-inspiration.schema.json
│   └── biome.schema.json
│
├── docs/                  # 跨模块权威文档
│   ├── ai-first-workflow.md
│   ├── anti-patterns.md
│   ├── numerical-design.md
│   ├── case-to-framework-contribute.md
│   └── case-candidates.md             # coverage 脚本生成
│
└── scripts/               # CI / 校验脚本
    ├── README.md
    ├── validate-schemas.py
    ├── verify-changelog.py
    ├── check-md-links.py
    ├── verify-case-metadata.py
    ├── build-schema-index.py
    ├── case-to-framework.py
    ├── case-to-framework-coverage.py
    ├── check-changelog-size.py
    ├── run-all-checks.ps1
    └── requirements.txt
```

---

## 核心命题

> 单局成本常呈指数/超指数增长，玩家期望持续变强、解锁内容。

| 层次 | 作用 |
|------|------|
| **Run** | 操作、产线、资源、升级 |
| **Reset** | 触顶 → 永久乘区 |
| **Endgame** | 第二目标、结局（可选，O2/O3 等） |

---

## 设计原则

- 产出与加成以 **连乘** 为主；加法只用于 `base + flat`
- **C1 超指数 sink** 须配 Reset + 永久项，否则易硬顶流失
- **全局加成只在入库乘一次**（见 [core/02](core/02-resources.md)）
- 公式在 Markdown，数值在 JSON；不写死某一作品的 tier 表或 Reset 点数
- 实战 Pattern 是 **模式沉淀**，不是项目默认值——所有数值需在项目 `*.json` 中重写

---

## 阅读路径

### 🎯 Cursor Plugin（Cursor 里用框架）

安装与 slash 命令见 **[PLUGIN.md](PLUGIN.md)** — 单 plugin、12 个 skills、2 个主 commands（`new-game`、`fix-balance`；`run-sim`/`validate` 已 deprecated）。

### 🎯 策划侧工作流（给 AI 引导开发者）

- **新游戏**：[GAME_DESIGN_GUIDE.md](GAME_DESIGN_GUIDE.md) 是 **AI 引导脚本**，开场先选合作方式：
  - **一键托管** — 约 5 个关键题，其余 AI 做（适合简单玩法）
  - **方案体检** — 你先丢设计，AI 找缺口/矛盾再补全
  - **逐步问答** — 按 M0→M8 一题一题过（适合想细抠每个决策）
  - 三条路径最终交付物相同：设计文档 → JSON → headless → 模拟 →（可选）界面
- **中途修改**：走 skill `mid-game-balance-fix`（诊断 → 归类 A–E → 改 JSON + 重跑模拟），不要用设计指南展开
- **填数值 / 调平衡**：直接用 [docs/numerical-design.md](docs/numerical-design.md)（先按 game mode 选 §2 的 8 种模式档案，再按 §3 通用公式 + §4 起步模板实现，按 §6 调优）
- **工程落地 / AI agent 对接**：读 [docs/ai-first-workflow.md](docs/ai-first-workflow.md)；Plugin skills 见 [PLUGIN.md](PLUGIN.md)

### 🟢 MVP（先读这 5 篇）

按顺序阅读，建立最小可玩框架：

1. [core/02-resources.md](core/02-resources.md) — 资源分层、入库、`global_multiplier`
2. [core/03-production-lines.md](core/03-production-lines.md) — T1-T5 触发、局部链
3. [core/04-upgrade-economy.md](core/04-upgrade-economy.md) — 购买流程、C1-C6 成本曲线
4. [core/05-reset-systems.md](core/05-reset-systems.md) — Reset、Cap 模式
5. [core/06-permanent-upgrades.md](core/06-permanent-upgrades.md) — 永久商店、Pattern C

### 🟡 实战模式（战斗/资源型增量必读）

按相关性阅读：

- [Pattern S 成长轴分档](patterns/pattern-s-skill-tiers.md) — 核心 8+跳 10 / 次要 3-5 / 开关 1-2
- [Pattern T 等级跳跃](patterns/pattern-t-tier-jump.md) — 核心轴顶级质变点（跳点视节奏：Shelldiver 8→10、Gnorp 9→10）
- [Pattern R 概率叠加](patterns/pattern-r-rarity.md) — 多档稀有度 + 跨种类 meta
- [Pattern D 双资源池](patterns/pattern-d-dual-pool.md) — 1 个限制资源跨多链路
- [Pattern B 二进制开关](patterns/pattern-b-binary-unlock.md) — 1-2 级机制解锁
- [Pattern E 状态效果 Stack](patterns/pattern-e-status-stack.md) — 细粒度状态效果（DOT / 易伤 / 缓速）统一结构 ✨
- [Pattern AME 3-tuple 属性](patterns/pattern-ame-3tuple-attribute.md) — 全部 effect 用 `[a, m, e]` 单一引擎（Upload Labs 实证）✨
- [Pattern N 节点流水线图](patterns/pattern-n-node-pipeline.md) — 玩家摆放 + 配线 + 6-type transfer engine（Upload Labs 实证）✨
- [Pattern PR Service 软重置](patterns/pattern-pr-service-soft-reset.md) — 代币消费触发单 sub-tree refund（Upload Labs 实证）✨
- [Pattern P2 双 Prestige 货币](patterns/pattern-p2-dual-prestige.md) — 短期 + 长期双 currency（KG 实证）
- [Pattern C7 自选永久 debuff](patterns/pattern-c7-opt-in-debuff.md) — 主动 toggle 减益换 prestige 加速度（KG 实证）

### 🔵 Optional（按需扩展）

| 类别 | 代号 |
|------|------|
| 章节与终局 | [O1](optional/o01-chapter-gates.md) + [O2](optional/o02-endgame-progress-bars.md) |
| 战斗与双轨 Reset | [O3](optional/o03-challenge-axis.md) + [O4](optional/o04-cross-axis-feedback.md) + [O7](optional/o07-dual-reset-track.md) |
| 辅助与节奏 | [O5](optional/o05-bottleneck-balance.md) + [O6](optional/o06-area-focus.md) + [O8](optional/o08-support-systems.md) + [O9](optional/o09-interaction-qol.md) + [O10](optional/o10-pacing-milestones.md) |
| 系统规模 | [O11](optional/o11-multi-region.md) ✨（产线 >10 时按区域分组） + [O13](optional/o13-temporal-multicycle.md)（时空多层循环，**Kittens Game 实证**） |

### 🟣 落地与验证

- [examples/pseudocode/](examples/pseudocode/) — 关键算法伪代码（Python + TypeScript）
- [examples/configs/](examples/configs/) — 配置 JSON 示例（含 $schema 引用）
- [schemas/](schemas/) — JSON Schema 定义，可用于校验 / 类型生成

---

## 命名约定

### 成本曲线 C 前缀

- **C1-C6**：成本曲线族（见 [core/04](core/04-upgrade-economy.md)）
- **C-a / C-b / C-c / C-d**：条件专精 Pattern 子类（见 [core/06](core/06-permanent-upgrades.md)）

### 实战模式 P 前缀

| 代号 | 名称 | 一句话定义 |
|------|------|----------|
| **P-R** | 概率叠加资源 | 多档稀有度 + 跨种类 meta 倍率 |
| **P-D** | 双资源池共享 | 1 个限制资源同时挂多链路放大器 |
| **P-S** | 成长轴分档 | 核心 8+跳 10 / 次要 3-5 / 开关 1-2 |
| **P-B** | 二进制开关 | 1-2 级机制解锁，无成长曲线 |
| **P-T** | 等级跳跃 | 核心轴顶级质变点（跳点视节奏，如 8→10 / 9→10） |
| **P-E** | 状态效果 Stack | 细粒度状态效果（DOT / 易伤 / 缓速 / 增伤）的统一 stack 结构 |
| **P-AME** | 3-tuple 属性统一 | 全部 effect 用 `[a, m, e]` 三元组表达，单一 `Attribute.add()` 引擎 |
| **P-N** | 节点流水线图 | 玩家摆放 node + 配线，1 个 6-type transfer engine |
| **P-PR** | Service 软重置 | 代币消费触发单 sub-tree refund + 可选 window 销毁 |
| **P-P2** | 双 Prestige 货币 | 短期 + 长期两种 prestige currency，各自 cap / 公式 / 永久项 |
| **P-C7** | 自选永久 debuff | 玩家主动 toggle 永久减益换 prestige 加速度 |

---

## 落地 Checklist

### Core MVP

- [ ] 入库管道；全局只乘一次
- [ ] 成本曲线 ≥2 种（含 C1）
- [ ] 单轨 Reset + 永久商店
- [ ] 产线共用局部乘法链
- [ ] 至少一种 Pattern C（条件专精）

### 实战 Pattern MVP（战斗/资源型题材）

- [ ] Pattern S：3 档成长轴（核心/次要/开关）
- [ ] Pattern T：至少 1 条核心轴跳 9→10
- [ ] Pattern R：多档稀有度 + meta 倍率

### Optional（按勾选）

- [ ] O1 tier 与 cost 表
- [ ] O2 副进度条 cap
- [ ] O3 挑战目标 + 强度汇总
- [ ] O4 与 O3 指标一致
- [ ] O5（若 O1 多资源 Gate）
- [ ] O6 / O7 / O8 / O9 所选子项

### 工程化（M6-M7，UI 之前）

- [ ] headless 引擎 + CLI（`python -m game --max-ticks N`）
- [ ] 批量模拟 1000 次，100% 完成率
- [ ] 5 类自动化指标健康（见 [docs/ai-first-workflow.md](docs/ai-first-workflow.md)）
- [ ] 配置文件 `$schema` 引用对应 Schema
- [ ] 关键算法参考 [examples/pseudocode/](examples/pseudocode/)
- [ ] 数值变更更新 [CHANGELOG.md](CHANGELOG.md)

### UI 层（M8，M7 通过后再做）

- [ ] UI 不含业务逻辑，绑定已验证引擎
- [ ] O9 交互 QoL 在此阶段接入

---

## 反模式

> 完整反模式目录（唯一权威源）见 [docs/anti-patterns.md](docs/anti-patterns.md)。
> 根 README 只列跨模块最高频 5 条；Pattern / Optional / 工程层 / 流程反模式请移步权威源。

| 反模式 | 后果 |
|--------|------|
| 数值写死代码不抽配置 | 无法调参与版本对比 |
| 只有指数 sink、无 Reset/永久 | 硬顶流失 |
| 全局加成在多处乘算 | 数值膨胀 |
| 无终点且无软顶 | 动机衰竭 |
| 抄固定 tier / Reset 点数当标准 | 误套其他题材 |

---

## 应用案例

每个 case 都是**用本框架从零实现的完整说明书**，包含数值表 + 伪代码 + framework 映射 + 反模式自检。所有内容自包含在 `cases/` 内。

| 案例 | 题材 | 引擎参考 | 模式沉淀 | 数据规模 |
|------|------|---------|---------|---------|
| [cases/shelldiver/README.md](cases/shelldiver/README.md) | 海底潜水 + 战斗 + 收集稀有水母 | GameMaker 2024.x GEN8 | Pattern R / S / T / B + O8 / O10 / O11 | 6 货币 / 4 区域 / 88 技能 / 87 字段 |
| [cases/tower-wizard/README.md](cases/tower-wizard/README.md) | 巫师建塔 + 魔法召唤 + 破墙终局 | Godot 4.2.3 | Pattern B / S / T / E + O1-O11 | 11 资源 / 12 区域 / 80 技能 / 40 祝福 / 22 国家 / 5 状态 / 4 墙 |
| [cases/kittens-game/README.md](cases/kittens-game/README.md) | 猫村管理 + 9 时代 + 跨周期转生 | ES5 JavaScript + Dojo 1.7 | Pattern B / C / D / E / P / R / S / T + O1 / O3 / O5 / O11 | 58 资源 / 39 建筑 / 62 科技 / 137 升级 / 8 行星 / 8 种族 |
| [cases/upload-labs/README.md](cases/upload-labs/README.md) | 节点流水线 + 文件下载验证 + AI 喂养 | Godot 4.x | Pattern B / C / D / E / P / P2 / R / S / T / AME / N / PR + O1 / O3 / O5 / O11 | 8 货币 / 57 属性 / 95 window / 86 升级 / 47 research / 18 perk / 3 milestone / 16 achievement / 28 request |
| [cases/gnorp/README.md](cases/gnorp/README.md) | 物理模拟 + 战略增量 + 跨建筑 inspiration | Go+LLVM (单 exe) | **Pattern B / C / D / E / P / R / S / T 全 + O1-O13 全** | 3 货币 / 14 建筑 / 8 Gnorp / 5 status / 41 talents / 16 inspirations / 10+1 compression / 17 成就 |
| [cases/agrivore/README.md](cases/agrivore/README.md) | 农场 + 战斗 + 7 罪孽主题 + Treasury 跨 run 技能树 | Unity 6 + Addressables 2.7.3 | Pattern R（7 罪孽稀有度 meta）+ O1 / O3 / O5 / O8 | 6 货币 / 32 资源 / 4 区域 / 5 作物链 / 12 技能链 / 7 sins / 24 sigil / 17 set-bonus / 30 quest / 31 achievement |
| [cases/dwarf-eat-mountain/README.md](cases/dwarf-eat-mountain/README.md) | 矮人挖山 + 塔防 + 灾变 + 6 终局山 + 三类神器 effect | GameMaker Studio 2.3+ (GEN8 IFF) | Pattern B / S / T + O1 / O5 / O10 / O11 + **3 候选 O14 (多阶段神器 effect) / O15 (巢穴产怪) / O16 (矮人兵种)** | 14 建筑 / 199 升级 / 124 artifacts / 102 prestige / 27 ore / 5 den / 30 calamity / 6 mountain / 10 dwarf |
| [cases/cell-to-singularity/README.md](cases/cell-to-singularity/README.md) | 文明进化科普 + 12 era + 3 层 prestige 嵌套 + Creature 收集 | Unity 2021+ (built-in, 无 Addressables) + I2 Loc + PlayFab | Pattern B / S / T / R / P2 / E + O1 / O2 / O3 / O5 / O7 / O11 / O13 | 6 货币 / 12 era / 30+ 产线 / 12+ 升级 / 12+ creature / 70+ 成就 / 243 enum / 34 SO / 1,215 MonoBehaviour |
| [cases/scritchy-scratchy/README.md](cases/scritchy-scratchy/README.md) | 刮刮卡桌面 + peek/陷阱 + Bot/Mundo + JP Prestige | Unity IL2CPP + Addressables | Pattern S + O9（UI） | 3 货币 / 4 catalogue / 11+ 卡 / 6 升级类 / 9 gadgets / 8 JP 永久 / 34 成就 |
| [cases/space-rock-breaker/README.md](cases/space-rock-breaker/README.md) | 太空采矿射击 + Plinko + UpgradeTreeKit + Boss Prestige | Unity IL2CPP + URP + Addressables | Pattern S + O9（UI） | Credits/Fuel/Universal Ore / ~100 UD_ / 19 PD_ / 8 武器 / 15 成就 |

**新做一款游戏的最小步骤**：

1. 复制接近题材的 case 数据目录到新项目
2. 修改 JSON 数值
3. 复用 case 中的伪代码
4. 用 framework schemas 校验

---

## 更新与维护

- 变更记录：[CHANGELOG.md](CHANGELOG.md)
- 贡献指南：[CONTRIBUTING.md](CONTRIBUTING.md)