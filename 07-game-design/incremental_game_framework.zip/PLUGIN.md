# Incremental Game Framework — Cursor Plugin

> AI-first incremental game design: headless engine, batch simulation, balance before UI. New games pick a guidance path (一键托管 / 方案体检 / 逐步问答) in `GAME_DESIGN_GUIDE.md` §2. M8 = structure-rebuildable UI design (`GAME_DESIGN_GUIDE.md` §5 M8), not a separate skill.

## 架构（对齐 Superpowers）

与 [Superpowers](https://github.com/obra/superpowers) 相同：**单 plugin + 根级平铺目录**。

```text
incremental_game_framework/
├── .cursor-plugin/
│   ├── plugin.json          ← Cursor 主 manifest
│   └── marketplace.json     ← From folder 安装用
├── skills/                  ← 12 个 SKILL.md（框架能力主体）
├── commands/                ← 4 个 slash commands
├── hooks/hooks-cursor.json
├── core/ patterns/ cases/ docs/ schemas/   ← 知识库（非 plugin 层）
└── ...
```

| 层 | Superpowers | 本框架 |
|----|-------------|--------|
| Manifest | `.cursor-plugin/plugin.json` | 同 |
| Skills | `skills/*/SKILL.md`（14 个） | `skills/*/SKILL.md`（12 个） |
| Commands | `commands/*.md` | 同 |
| Agents | 仅 `code-reviewer` | **无**（能力全在 skills） |
| Hooks | `hooks/hooks-cursor.json` | 同 |

Customize 里应出现 **「Incremental Game Framework」** 分组（与 Superpowers 并列），而不是散落到 User。

## 12 个 Skills（逻辑分组）

| Group | Skills |
|-------|--------|
| design | `using-incremental-framework`, `new-incremental-game`, `game-designer`, `case-consultant` |
| data | `data-architect`, `balance-mathematician` |
| engine | `core-engineer`, `pattern-integrator`, `optional-integrator` |
| validation | `auto-tester`, `quality-validator`, `mid-game-balance-fix` |

总路由：`using-incremental-framework`

**引导三路径**：`new-incremental-game` 开场按 `GAME_DESIGN_GUIDE.md` §2 让用户选一键托管 / 方案体检 / 逐步问答，不要默认长问卷。

**M8 界面设计**：无第 13 个 skill。用户说「做 HUD / ui-layout / M8」且 M7 已通过时，由 `new-incremental-game` 按 `GAME_DESIGN_GUIDE.md` §5 M8 产出 `docs/ui-layout.md` + `ui/ui-layout.json`（附录 C）。

## 安装

### 方式 A — 从文件夹添加（推荐）

1. Cursor → **Customize** → **Add plugin** → **From folder**
2. 选择**仓库根目录**
3. **Developer: Reload Window**

### 方式 B — GitHub 公开仓库

```text
/add-plugin <your-github-repo-url>
```

CodeUp 等非 GitHub 源请用方式 A。

> **注意**：junction 指向仓库外目录会被 Cursor 拒绝；From folder 更可靠。

---

## Manifest 排查

| 检查项 | 路径 |
|--------|------|
| Plugin manifest | `.cursor-plugin/plugin.json` |
| Marketplace | `.cursor-plugin/marketplace.json`（`plugins[0].source: "."`） |
| Skills | `skills/<name>/SKILL.md` |

```powershell
Test-Path ".cursor-plugin\plugin.json"
Test-Path ".cursor-plugin\marketplace.json"
Test-Path "skills\using-incremental-framework\SKILL.md"
```

若仍看到 **12 个 subagent** 或旧 skill（`run-simulation`、`tune-balance`），是 Cursor **缓存停在旧 commit `cff052f`**，不是仓库问题：

```powershell
powershell -File scripts/refresh-cursor-plugin-cache.ps1
```

然后 Customize 移除 plugin → Reload → From folder 重新添加仓库根。

**正确状态（当前 HEAD）**：

| 项 | 应有 |
|----|------|
| Subagents | **0**（本 plugin 无 agents） |
| Skills 分组 | **Incremental Game Framework × 12** |
| plugin.json | 无 `"agents"` 字段 |

## Slash commands

与 Superpowers 一致：**能力在 skills**；commands 仅保留两个主入口，其余 deprecated。

| Command | 状态 | 作用 |
|---------|------|------|
| `new-game` | ✅ 主入口 | M0-M7 立项 → skill `new-incremental-game` |
| `fix-balance` | ✅ 主入口 | 中途诊断修正 → skill `mid-game-balance-fix` |
| `run-sim` | ⚠️ deprecated | 请用 skill `auto-tester` |
| `validate` | ⚠️ deprecated | 请用 skill `quality-validator` |

---

## 在其他游戏项目里用

1. 安装 plugin（方式 A）
2. 在新项目建 `docs/`、`data/`、`src/`
3. 对话：「用 incremental framework 做一款太空放置」或 `/new-game`

[docs/ai-first-workflow.md](docs/ai-first-workflow.md)
