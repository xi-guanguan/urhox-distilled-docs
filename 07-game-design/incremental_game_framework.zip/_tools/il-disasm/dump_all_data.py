#!/usr/bin/env python3
"""Extract ALL MonoBehaviour data from all Unity asset/bundle files.

Game data like ItemSO, CropData, SinData are stored as ScriptableObject
MonoBehaviours inside the shared assets. We try to dump everything
and post-filter by class name.
"""
import UnityPy
import json
import os
from pathlib import Path

GAME = Path(r"D:\program files (x86)\steam\steamapps\common\Agrivore")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\all_mb.json")
OUT.parent.mkdir(exist_ok=True, parents=True)


def trim_value(v, depth=0, max_depth=6):
    if depth >= max_depth:
        return f"<depth-{depth} {type(v).__name__}>"
    if v is None:
        return None
    if isinstance(v, (int, float, bool)):
        return v
    if isinstance(v, str):
        return v[:300] if len(v) > 300 else v
    if isinstance(v, bytes):
        return f"<bytes len={len(v)}>"
    if isinstance(v, list):
        return [trim_value(x, depth + 1) for x in v[:200]]
    if isinstance(v, dict):
        out = {}
        for k, val in v.items():
            if k in ("references", "m_Script", "m_GameObject", "m_EditorClassIdentifier"):
                continue
            out[k] = trim_value(val, depth + 1)
        return out
    return f"<unhandled {type(v).__name__}>"


all_files = []
for root, _, files in os.walk(GAME):
    for f in files:
        if f.endswith((".assets", ".bundle", ".asset", ".resS")):
            p = Path(root) / f
            try:
                sz = p.stat().st_size
                if sz > 0 and sz < 500_000_000:
                    all_files.append(p)
            except Exception:
                pass

print(f"Found {len(all_files)} candidate files")

# Group data by m_Script.file_id + m_Script.path_id (the unique object ref)
# but m_Script is often empty. Fallback: use m_Name + content fingerprint.
out: dict[str, list[dict]] = {}
total = 0
script_class_counter: dict[str, int] = {}

for p in all_files:
    try:
        env = UnityPy.load(str(p))
    except Exception:
        continue
    for obj in env.objects:
        if obj.type.name != "MonoBehaviour":
            continue
        try:
            tree = obj.read_typetree()
        except Exception:
            continue
        if not isinstance(tree, dict):
            continue
        script = tree.get("m_Script", {})
        script_class = None
        if isinstance(script, dict):
            if script.get("file_id", 0) == 0:
                script_class = (script.get("m_Name") or "").replace(" ", "").strip() or "Unknown"
        if not script_class:
            script_class = tree.get("m_Name", "Unknown") or "Unknown"
        if script_class == "Unknown":
            continue
        out.setdefault(script_class, []).append({
            "source_file": str(p.relative_to(GAME)),
            "path_id": obj.path_id,
            "name": tree.get("m_Name"),
            "data": trim_value(tree, max_depth=5),
        })
        script_class_counter[script_class] = script_class_counter.get(script_class, 0) + 1
        total += 1

print(f"Total MB/SO instances: {total}")
print(f"Unique script classes: {len(out)}")
for k, c in sorted(script_class_counter.items(), key=lambda x: -x[1])[:50]:
    print(f"  {k}: {c}")

# Save full dump
with OUT.open("w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(f"Wrote {OUT} ({OUT.stat().st_size / 1024:.0f} KB)")
