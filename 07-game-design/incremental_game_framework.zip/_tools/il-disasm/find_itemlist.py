import UnityPy
env = UnityPy.load(r'D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\level0')
n = 0
for obj in env.objects:
    if obj.type.name != 'MonoBehaviour':
        continue
    try:
        tree = obj.read_typetree()
    except Exception:
        continue
    if not isinstance(tree, dict):
        continue
    if 'items' in tree and isinstance(tree['items'], list) and len(tree['items']) > 0:
        print(f'  {obj.path_id} name={tree.get("m_Name")} items_len={len(tree["items"])}')
        first = tree['items'][0]
        print(f'    first item type: {type(first).__name__}')
        if isinstance(first, dict):
            print(f'    first item keys: {list(first.keys())[:20]}')
        n += 1
        if n > 3:
            break
print(f'count: {n}')
