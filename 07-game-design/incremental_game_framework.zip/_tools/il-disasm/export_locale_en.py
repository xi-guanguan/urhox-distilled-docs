"""Export the full English localization string table for the game.

The table is a StringTable MonoBehaviour containing m_TableData (list of
{m_Id, m_Localized, m_Metadata}).  We export ID -> text as a dict.

Also exports the SharedTableData keys (m_KeyName etc).
"""
import UnityPy
import json
from pathlib import Path

BUNDLE = Path(r"D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\StreamingAssets\aa\StandaloneLinux64\localization-string-tables-english(en)_assets_all.bundle")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\locale_en.json")

env = UnityPy.load(str(BUNDLE))

# Find the StringTable MonoBehaviour
out = {
    "string_table": [],
    "shared_keys": [],
}

for obj in env.objects:
    if obj.type.name == "MonoBehaviour":
        tree = obj.read_typetree()
        if "m_TableData" in tree:
            out["string_table"] = tree["m_TableData"]
        elif "m_Keys" in tree or "m_KeyName" in tree:
            out["shared_keys"] = tree
        else:
            print(f"  unknown MB keys: {list(tree.keys())[:15]}")

print(f"string_table size: {len(out['string_table'])}")
print(f"shared_keys: {len(out['shared_keys']) if isinstance(out['shared_keys'], dict) else '?'}")

# Convert table: list of {m_Id, m_Localized, m_Metadata}
texts: dict[str, str] = {}
for entry in out["string_table"]:
    eid = entry.get("m_Id")
    txt = entry.get("m_Localized")
    if eid is not None and txt is not None:
        texts[str(eid)] = txt

# Save full export
with OUT.open("w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(f"Wrote {OUT} ({OUT.stat().st_size / 1024:.0f} KB)")

# Also write a flat id->text dump for easy reference
flat_out = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\locale_en_flat.json")
with flat_out.open("w", encoding="utf-8") as f:
    json.dump(texts, f, indent=2, ensure_ascii=False)
print(f"Wrote {flat_out}")
print(f"Total unique ids: {len(texts)}")

# Show samples
for k, v in list(texts.items())[:15]:
    print(f"  {k}: {v!r}")
