import UnityPy
import sys
target = sys.argv[1] if len(sys.argv) > 1 else r'D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\level0'
env = UnityPy.load(target)
n = 0
for obj in env.objects:
    if obj.type.name != 'MonoBehaviour':
        continue
    try:
        tree = obj.read_typetree()
    except Exception:
        continue
    if not isinstance(tree, dict):
        continue
    keys = list(tree.keys())
    if 'itemName' in tree or 'cropType' in tree or 'sinType' in tree or 'sigilType' in tree or 'uniqueSkillType' in tree or 'setName' in tree:
        print(f'  {obj.path_id} name={tree.get("m_Name")} keys={keys[:15]}')
        n += 1
        if n > 30:
            break
print(f'sample count: {n}')
