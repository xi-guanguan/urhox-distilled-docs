#!/usr/bin/env python3
import json
data = json.load(open(r'D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\class_fields.json', encoding='utf-8'))
for cname in ['ItemSO', 'EquipmentData', 'CropData', 'SinData', 'Sigil', 'SetBonusSO', 'WeaponData', 'CropUniqueSkillData', 'UniqueSkillData', 'SkillTreeNode', 'NodeSO', 'NodeUnlock']:
    print(f'=== {cname} ===')
    for f in data.get(cname, []):
        h = f'  H={f["header"]!r}' if f['header'] else ''
        t = f'  T={f["tooltip"]!r}' if f['tooltip'] else ''
        s = ' [SF]' if f['is_serialized_field'] else ''
        print(f'  {f["access"]:<8} {f["type"][:55]:<55} {f["name"]}{s}{h}{t}')
    print()
