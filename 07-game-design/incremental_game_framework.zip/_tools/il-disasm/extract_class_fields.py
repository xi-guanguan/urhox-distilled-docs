#!/usr/bin/env python3
"""Extract public field signatures from a class in Assembly-CSharp.il.

Improved version: stop at "} // end of class X" comment.
"""
import re
import json
import sys
from pathlib import Path

IL = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\Assembly-CSharp.il")


def find_class_end(il_text: list[str], class_name: str) -> int:
    """Find end-of-class line (comment) and return its index."""
    end_pat = re.compile(rf"\}}\s*//\s*end\s+of\s+class\s+{re.escape(class_name)}\s*$")
    for i, line in enumerate(il_text):
        if end_pat.search(line):
            return i
    raise ValueError(f"end of class {class_name} not found")


def find_class_start(il_text: list[str], class_name: str) -> int:
    pat = re.compile(rf'^\s*\.class\s+public[^"]*\b{re.escape(class_name)}\b\s*$')
    for i, line in enumerate(il_text):
        if pat.match(line):
            return i
    raise ValueError(f"class {class_name} not found")


def extract_fields_for_class(il_text: list[str], class_name: str) -> list[dict]:
    start = find_class_start(il_text, class_name)
    end = find_class_end(il_text, class_name)
    fields: list[dict] = []
    i = start + 1
    pat_field = re.compile(
        r"^\s*\.field\s+"
        r"(?P<access>public|private|protected|internal|family)"
        r"\s+(?P<static>static\s+)?"
        r"(?P<type>[^\s]+(?:\s+[^\s]+)?)\s+"
        r"(?P<name>\w+)"
    )
    pat_header = re.compile(r'HeaderAttribute::\'\.ctor\'\(string\)')
    pat_tooltip = re.compile(r'TooltipAttribute::\'\.ctor\'\(string\)')
    pat_serializefield = re.compile(r'SerializeField::\'\.ctor\'\(')
    while i < end:
        line = il_text[i]
        m = pat_field.match(line)
        if m:
            ftype = m.group("type").strip()
            fname = m.group("name")
            is_static = bool(m.group("static"))
            access = m.group("access")
            j = i + 1
            header = None
            tooltip = None
            is_serialized = False
            while j < end and not pat_field.match(il_text[j]) and ".method " not in il_text[j]:
                cur = il_text[j]
                if pat_serializefield.search(cur):
                    is_serialized = True
                if "HeaderAttribute" in cur and "'.ctor'" in cur and "//" in cur:
                    hm = re.search(r'//\s*\.\.\.(.*?)\.\.', cur)
                    if hm:
                        txt = hm.group(1).strip()
                        try:
                            txt = txt.encode().decode("unicode_escape", errors="replace")
                        except Exception:
                            pass
                        header = txt
                if "TooltipAttribute" in cur and "'.ctor'" in cur and "//" in cur:
                    tm = re.search(r'//\s*\.\.\.(.*?)\.\.', cur)
                    if tm:
                        txt = tm.group(1).strip()
                        try:
                            txt = txt.encode().decode("unicode_escape", errors="replace")
                        except Exception:
                            pass
                        tooltip = txt
                j += 1
                if j - i > 200:
                    break
            fields.append({
                "name": fname,
                "type": ftype,
                "access": access,
                "static": is_static,
                "is_serialized_field": is_serialized,
                "header": header,
                "tooltip": tooltip,
            })
            i = j
        else:
            i += 1
    return fields


def main():
    targets = sys.argv[1:] if len(sys.argv) > 1 else [
        "ItemSO", "ItemData", "EquipmentData", "CropData", "SinData",
        "Sigil", "SetBonusSO", "SetBonus", "BaseSetBonusFunctionality",
        "WeaponData", "BowSO", "SwordSO",
        "RunConfiguration", "CropSkillTreeConfig", "CropSkillSpawnSettings",
        "EquipmentStatNodeTemplate", "EquipmentStatValueOverride", "EquipmentStatEntry",
        "CropNodeSpawnSettings", "HarvestIntervalTotalsByCropCount",
        "HarvestIntervalScalingSettings", "CropValueNodeSlotConfig",
        "CropValueNodesForCropOrder", "GoldenUnlockRule", "NextCropUnlockRule",
        "DynamicSkillTreeNodeSO", "EquipmentSpawnSettings", "UniqueSkillSpawnSettings",
        "CropUniqueSkillData", "UniqueSkillData", "SinRunEffectDefinition",
        "SinRunBehaviorSO", "EvolutionSkillData", "EvolutionUnlockNode",
        "SkillTreeNode", "NodeSO", "NodeUnlock", "LifetimeStatDefinition",
        "RunStatDefinition", "PrestigeSO", "PBAR_Reward", "PBAR_RewardSO",
        "CrownReward", "SinDataCenter", "CropDataCenter", "EquipmentDataCenter",
        "UniqueSkillDataCenter", "StatusEffectSO", "DamageOverTimeEffectSO",
        "ElectricChainEffectSO", "StatusEffectController", "WeaponManager",
        "WeaponSelectionManager", "UniversalWeaponManager", "CropSpawner",
        "TierCropSpawner", "CropPrefabDatabase", "SinManager", "SigilManager",
        "SigilClass", "StatsData", "LifetimeStatConfigSO", "RunSummaryConfigSO",
        "RunConfiguration", "CropSkillSpawnSettings", "CropSkillTreeConfig",
    ]
    out: dict[str, list[dict]] = {}
    text = IL.read_text(encoding="utf-8", errors="replace").splitlines()
    for cname in targets:
        try:
            out[cname] = extract_fields_for_class(text, cname)
            print(f"  {cname}: {len(out[cname])} fields")
        except ValueError as e:
            print(f"  {cname}: SKIP ({e})")
    OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\class_fields.json")
    OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
