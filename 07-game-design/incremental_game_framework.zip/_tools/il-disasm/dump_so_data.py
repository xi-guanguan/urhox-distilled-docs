#!/usr/bin/env python3
"""Extract ScriptableObject (and MonoBehaviour) instance data from
resources.assets and any other *.assets / .bundle files in the game.

For each instance, we read the typetree and emit JSON containing:
  - script class name (m_Script)
  - m_Name
  - all primitive/serializable fields
"""
import UnityPy
import json
import os
from pathlib import Path

GAME = Path(r"D:\program files (x86)\steam\steamapps\common\Agrivore")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\so_data.json")
OUT.parent.mkdir(exist_ok=True, parents=True)


def is_primitive(v):
    return isinstance(v, (int, float, bool, str)) or v is None


def is_unity_prim(v):
    if isinstance(v, dict):
        return False
    if isinstance(v, (int, float, bool, str)) or v is None:
        return True
    if isinstance(v, bytes):
        return True
    return False


def trim_value(v, depth=0, max_depth=4):
    """Make a value JSON-safe and not too deep; references are summarized."""
    if depth >= max_depth:
        return f"<depth-{depth} {type(v).__name__}>"
    if v is None:
        return None
    if isinstance(v, (int, float, bool, str)):
        if isinstance(v, str) and len(v) > 300:
            return v[:300] + "..."
        return v
    if isinstance(v, bytes):
        try:
            return v.decode("utf-8", errors="replace")[:200]
        except Exception:
            return f"<bytes len={len(v)}>"
    if isinstance(v, list):
        return [trim_value(x, depth + 1) for x in v[:50]]
    if isinstance(v, dict):
        out = {}
        for k, val in v.items():
            if k in ("references", "m_Script", "m_GameObject", "m_Curve",
                     "m_Keyframe", "m_EditorClassIdentifier"):
                continue
            out[k] = trim_value(val, depth + 1)
        return out
    return f"<unhandled {type(v).__name__}>"


# Walk all bundle / assets files
all_files = []
for root, _, files in os.walk(GAME):
    for f in files:
        if f.endswith(".assets") or f.endswith(".bundle") or f.endswith(".asset"):
            p = Path(root) / f
            # Skip very small / large generic Unity files
            try:
                sz = p.stat().st_size
                if sz > 0:
                    all_files.append(p)
            except Exception:
                pass

# Resources.assets is the most important
print(f"Found {len(all_files)} candidate files")

out: dict[str, list[dict]] = {}
total_so = 0

for p in all_files:
    try:
        env = UnityPy.load(str(p))
    except Exception as e:
        continue
    for obj in env.objects:
        if obj.type.name != "MonoBehaviour":
            continue
        try:
            tree = obj.read_typetree()
        except Exception:
            try:
                raw = obj.get_raw_data()
                if not raw:
                    continue
            except Exception:
                continue
            continue
        if not isinstance(tree, dict):
            continue
        # Get script class name
        script = tree.get("m_Script", {})
        script_class = None
        if isinstance(script, dict):
            # file_id -1 means internal; we just record m_Name instead
            script_class = script.get("m_Name") if script.get("file_id", 0) == 0 else f"ext:{script.get('path_id')}"
        # Many SO don't expose m_Script info; fall back to m_Name
        if not script_class:
            script_class = tree.get("m_Name", "Unknown")
        # Strip "ScriptableObject" suffix from script class names
        if isinstance(script_class, str):
            script_class = script_class.replace(" ", "").strip()
        # Filter: keep only meaningful SO/MB (not transforms, etc.)
        # We rely on the fact that all SerializeField-bearing classes are MB/SO.
        out.setdefault(script_class, []).append({
            "source_file": str(p.relative_to(GAME)),
            "path_id": obj.path_id,
            "name": tree.get("m_Name"),
            "data": trim_value(tree, max_depth=5),
        })
        total_so += 1

print(f"Total MB/SO instances: {total_so}")
print(f"Unique script classes: {len(out)}")
for k, v in sorted(out.items(), key=lambda x: -len(x[1])):
    print(f"  {k}: {len(v)} instances")

# Write full dump
with OUT.open("w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(f"Wrote {OUT}")
