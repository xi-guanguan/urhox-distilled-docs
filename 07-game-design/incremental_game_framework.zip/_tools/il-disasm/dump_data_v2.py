"""Dump all MonoBehaviour typetrees from all assets/bundles, with m_Script
file_id/path_id fall back to type fingerprint."""
import UnityPy
import json
import os
from pathlib import Path

GAME = Path(r"D:\program files (x86)\steam\steamapps\common\Agrivore")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\all_mb_v2.json")
OUT.parent.mkdir(exist_ok=True, parents=True)


def trim_value(v, depth=0, max_depth=6):
    if depth >= max_depth:
        return f"<depth-{depth} {type(v).__name__}>"
    if v is None:
        return None
    if isinstance(v, (int, float, bool)):
        return v
    if isinstance(v, str):
        return v[:300] if len(v) > 300 else v
    if isinstance(v, bytes):
        return f"<bytes len={len(v)}>"
    if isinstance(v, list):
        return [trim_value(x, depth + 1) for x in v[:200]]
    if isinstance(v, dict):
        out = {}
        for k, val in v.items():
            if k in ("references", "m_Script", "m_GameObject", "m_EditorClassIdentifier"):
                continue
            out[k] = trim_value(val, depth + 1)
        return out
    return f"<unhandled {type(v).__name__}>"


all_files = []
for root, _, files in os.walk(GAME):
    for f in files:
        if f.endswith((".assets", ".bundle", ".asset", ".resS")):
            p = Path(root) / f
            try:
                sz = p.stat().st_size
                if sz > 0 and sz < 500_000_000:
                    all_files.append(p)
            except Exception:
                pass

print(f"Found {len(all_files)} files")

# We want to find SOs that have:
#   - itemName
#   - cropType
#   - sinType
#   - sigilType
#   - uniqueSkillType
#   - setName
#   - equipmentType
#   - weaponType
#   - skillName (CropUniqueSkillData)
#   - formattedSetName
target_fields = ('itemName', 'cropType', 'sinType', 'sigilType',
                 'uniqueSkillType', 'setName', 'equipmentType',
                 'weaponType', 'skillName', 'formattedSetName',
                 'uniqueSkillName', 'sinName', 'cropValueBonusDefault')

out_records = []
total = 0
for p in all_files:
    try:
        env = UnityPy.load(str(p))
    except Exception:
        continue
    for obj in env.objects:
        if obj.type.name != 'MonoBehaviour':
            continue
        try:
            tree = obj.read_typetree()
        except Exception:
            continue
        if not isinstance(tree, dict):
            continue
        if any(k in tree for k in target_fields):
            out_records.append({
                "source_file": str(p.relative_to(GAME)),
                "path_id": obj.path_id,
                "name": tree.get("m_Name"),
                "data": trim_value(tree, max_depth=5),
            })
            total += 1

print(f"Matching records: {total}")
with OUT.open("w", encoding="utf-8") as f:
    json.dump(out_records, f, indent=2, ensure_ascii=False)
print(f"Wrote {OUT} ({OUT.stat().st_size / 1024:.0f} KB)")

# Print a few samples
for r in out_records[:5]:
    print(f'-- {r["source_file"]}  pid={r["path_id"]}  name={r["name"]}')
    d = r["data"]
    print(f'   keys: {list(d.keys())[:15]}')
