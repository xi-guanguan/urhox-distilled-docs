#!/usr/bin/env python3
"""Extract all public enum values from Assembly-CSharp.il."""
import re
import json
from pathlib import Path

IL = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\Assembly-CSharp.il")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\enums.json")

# Match: .field public static literal valuetype T N = int32(V)
RE_LIT = re.compile(
    r'\.field\s+public\s+static\s+literal\s+valuetype\s+(\w+)\s+(\w+)\s*=\s*int32\(([^)]+)\)'
)

enums: dict[str, dict[str, int]] = {}
with IL.open(encoding="utf-8", errors="replace") as f:
    for line in f:
        m = RE_LIT.search(line)
        if not m:
            continue
        etype, name, val = m.group(1), m.group(2), m.group(3)
        if val.startswith("0x") or val.startswith("0X"):
            ival = int(val, 16)
        else:
            ival = int(val)
        enums.setdefault(etype, {})[name] = ival

# Sort entries by value
out: dict[str, dict[str, int]] = {}
for k in sorted(enums):
    out[k] = dict(sorted(enums[k].items(), key=lambda x: x[1]))

OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"Wrote {OUT}")
print(f"Total enum types: {len(out)}")
for k, v in out.items():
    print(f"  {k}: {len(v)} values")
