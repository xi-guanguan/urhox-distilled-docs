import UnityPy
env = UnityPy.load(r'D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\StreamingAssets\aa\catalog.bin')
print('Resources found in catalog:')
for k, v in env.container.items():
    tname = v.type.name if hasattr(v, 'type') else '?'
    print(f'  {k} -> {tname}')
