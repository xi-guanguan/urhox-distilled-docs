from pathlib import Path
import AddressablesTools
data = Path(r'D:\program files (x86)\steam\steamapps\common\Agrivore\Agrivore_Data\StreamingAssets\aa\catalog.bin').read_bytes()
catalog = AddressablesTools.parse_binary(data)
print(f"Total keys: {len(catalog.Resources)}")
# List all resources
for key, locs in catalog.Resources.items():
    loc = locs[0]
    typ = loc.Type.__name__ if hasattr(loc.Type, '__name__') else str(loc.Type)
    obj = loc.Data.Object if loc.Data else None
    extra = ''
    if obj:
        extra = f"  Crc={obj.Crc}  BundlePath={obj.BundlePath if hasattr(obj,'BundlePath') else '?'}"
    print(f"  {key}\n    Type={typ}  InternalId={loc.InternalId}  HashCode={loc.HashCode}{extra}")
