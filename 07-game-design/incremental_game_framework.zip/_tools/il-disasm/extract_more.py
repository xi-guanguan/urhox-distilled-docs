#!/usr/bin/env python3
"""Extract fields for more important classes."""
import sys
sys.path.insert(0, r'D:\Projects\Skills\incremental_game_framework\_tools\il-disasm')
from extract_class_fields import extract_fields_for_class
from pathlib import Path
import json

IL = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\Assembly-CSharp.il")
text = IL.read_text(encoding="utf-8", errors="replace").splitlines()

targets = [
    "WeaponManager", "WeaponSelectionManager", "UniversalWeaponManager",
    "WeaponSelectionMapping", "SigilManager", "SigilClass",
    "LifetimeStatManager", "LifetimeStatConfigSO", "LifetimeStatRowElement",
    "RunStatDefinition", "RunStatType", "RunSummaryConfigSO", "RunSummaryRowElement",
    "PrestigeManager", "PrestigeSO", "PBAR_Reward", "PBAR_RewardSO", "CrownReward",
    "AchievmentManager", "SettingsManager", "SaveManager", "ShopManager",
    "CropSpawner", "TierCropSpawner", "CropPrefabDatabase", "CropDataCenter",
    "EquipmentDataCenter", "UniqueSkillDataCenter", "SinDataCenter",
    "CropManager", "CropData", "CropSkillSpawnSettings", "CropSkillTreeConfig",
    "SkillSelectManager", "SkillNodePersistTag", "SkillSelectionConverter",
    "PreRunSelectionScreen", "UniqueSkillType", "EquipmentType",
    "CropData", "CropSpawnerType", "CropType", "CropTier", "TierCropSpawnRate",
    "CropMoodData", "CropRespawnSource", "CropRespawnContext", "CropRespawn",
    "CropSpawnSettings", "CropUniqueSkillData", "UniqueSkillData",
    "CropSkillTreeConfig", "CropNodeSpawnSettings", "CropValueNodeSlotConfig",
    "CropValueNodesForCropOrder", "GoldenUnlockRule", "NextCropUnlockRule",
    "DynamicSkillTreeManager", "DynamicSkillTreeNodeSO", "UniqueSkillSpawnSettings",
    "EquipmentSpawnSettings", "EquipmentStatNodeTemplate", "EquipmentStatValueOverride",
    "EquipmentStatEntry", "HarvestIntervalTotalsByCropCount", "HarvestIntervalScalingSettings",
    "EvolutionSkillData", "EvolutionUnlockNode", "EvolutionManager", "EvolutionId",
    "EvolutionTargetType", "EvolutionModifier", "EvolutionModifierType", "EvolutionTargetType",
    "EquipmentUnlockNode", "CropUnlockNode", "UniqueSkillUnlockNode", "SinEvolutionUnlockNode",
    "WeaponEvolutionUnlockNode", "PhalanxFormationUnlockNode", "PotatoElectricEvolutionUnlockNode",
    "SpearShotEvolutionUnlockNode", "SwordEvolutionUnlockNode", "SunburnEvolutionUnlockNode",
    "CornPopcornEvolutionUnlockNode", "DroneAttackEvolutionUnlockNode", "TractorEvolutionUnlockNode",
    "VillagersEvolutionUnlockNode", "BatsEvolutionUnlockNode", "StarfruitRainEvolutionUnlockNode",
    "GreenHouseEvolutionUnlockNode", "SpectralArrowsEvolutionUnlockNode", "DarkMatterEvolutionUnlockNode",
    "CrossLaserEvolutionUnlockNode", "SunBurn", "SunBurnDrift", "SunburnSpawner",
    "StatManager", "RunConfiguration", "KingFeedManager", "KingMoodManager", "KingMoodEntry",
    "SetBonusManager", "SetBonusSO", "FarmerSet", "BaseSetBonusFunctionality",
    "BuffManager", "IBuffVisibility",
    "QuestManager", "QuestDefinitionSO", "QuestInstance", "QuestDifficulty", "QuestType",
    "ItemReward", "CropHarvestedEvent", "WeaponAttackEvent", "EnemyKilledEvent", "CurrencyEarnedEvent",
    "QuestProgressEvent", "QuestCompletedEvent", "QuestDataLoadedEvent",
    "FarmData", "FarmSelectManager", "FarmLocalizedText", "FogOfWarNode",
    "HubPanelManager", "PreRunSelectionScreen",
    "TreasurySkillTree", "TreasuryManager",
    "LifetimeStatDefinition", "LifetimeStatConfigSO", "RunSummaryConfigSO",
]

out = {}
for c in targets:
    try:
        out[c] = extract_fields_for_class(text, c)
        print(f"  {c}: {len(out[c])} fields")
    except ValueError as e:
        print(f"  {c}: SKIP")

OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\il-disasm\extracted\class_fields_v2.json")
with OUT.open("w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(f"Wrote {OUT}")
