import json
import re
from collections import defaultdict

loc = json.load(open('D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json', encoding='utf-8'))

# Analyze artifact effects
print('=== Artifact effect patterns ===')
patterns = {
    'Collect:': 0,
    'Passive:': 0,
    'Required to access': 0,
    'Collect only': 0,
    'Passive only': 0,
    'No effect (key only)': 0,
}

artifacts = [(k, loc[k]) for k in loc.keys() if k.startswith('artifact.') and k.endswith('.name')]
print(f'Total artifacts: {len(artifacts)}')
print()

# Group: same artifact may have name + desc
artifact_ids = set()
for k, _ in artifacts:
    # e.g., artifact.bag_of_overflowing_gold.name
    aid = k.replace('artifact.', '').replace('.name', '')
    artifact_ids.add(aid)
print(f'Unique artifact IDs: {len(artifact_ids)}')
print()

# Effect types
type_counts = defaultdict(int)
for aid in sorted(artifact_ids):
    name = loc.get(f'artifact.{aid}.name', '?')
    desc = loc.get(f'artifact.{aid}.desc', '')
    has_collect = 'Collect:' in desc
    has_passive = 'Passive:' in desc
    has_required = 'Required to access' in desc
    if has_collect and has_passive:
        type_counts['collect+passive'] += 1
    elif has_collect:
        type_counts['collect_only'] += 1
    elif has_passive:
        type_counts['passive_only'] += 1
    elif has_required:
        type_counts['required_to_access'] += 1
    elif desc.strip() == '':
        type_counts['no_desc'] += 1
    else:
        type_counts['flavor_only'] += 1

print('=== Artifact effect type distribution ===')
for t, n in sorted(type_counts.items(), key=lambda x: -x[1]):
    print(f'  {t}: {n}')

# Sample 10 collect+passive artifacts
print()
print('=== Sample collect+passive artifacts (5) ===')
count = 0
for aid in sorted(artifact_ids):
    desc = loc.get(f'artifact.{aid}.desc', '')
    if 'Collect:' in desc and 'Passive:' in desc:
        name = loc.get(f'artifact.{aid}.name', '?')
        print(f'  {aid}: {name}')
        # Truncate desc
        print(f'    {desc[:200]}')
        count += 1
        if count >= 5: break
