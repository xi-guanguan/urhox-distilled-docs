import re
from collections import Counter

lines = open('_tools/dem-extract/extracted/strings.txt', encoding='utf-8').read().split('\n')

# Find unique "initializer" / table-like functions
# Patterns observed: initializeOre, initializeBuildings, selectDrops
tables = Counter()
for s in lines:
    s = s.strip()
    if not s: continue
    # Find function names like 'initializeX' or 'selectX' or 'X@STRUCT' (the UPPER table name)
    m = re.search(r'(initialize|select|load|setup|build)\s*([A-Z][a-zA-Z]+)', s)
    if m:
        tables[m.group(0)] += 1
    # Also look for ALL_CAPS tables like @LOOT@, @BUILDINGS@
    m = re.search(r'@([A-Z][A-Z0-9_]{2,40})@', s)
    if m:
        tables[f'@{m.group(1)}@'] += 1

print(f'=== {len(tables)} unique table-like names ===')
for t, n in tables.most_common(100):
    print(f'  {t}: {n}')
