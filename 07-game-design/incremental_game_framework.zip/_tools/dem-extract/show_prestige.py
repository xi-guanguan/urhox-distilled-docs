import json
import re
from collections import defaultdict

loc = json.load(open('D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json', encoding='utf-8'))

# All prestige node names
print('=== All 102 prestige nodes (sampled) ===')
prestige_names = [k for k in loc.keys() if k.startswith('prestige.') and k.endswith('.name')]
print(f'Total: {len(prestige_names)}')
print()
# Show first 30 with descriptions
for k in prestige_names[:30]:
    name = loc[k]
    desc_key = k.replace('.name', '.desc')
    desc = loc.get(desc_key, '')[:100]
    print(f'  {k}: {name}')
    print(f'    {desc}...')

print()
print('=== Categories of prestige nodes (by prefix after p_) ===')
prefixes = defaultdict(int)
for k in prestige_names:
    base = k.replace('prestige.p_', '').replace('.name', '')
    # First word(s) before underscore
    parts = base.split('_')
    cat = parts[0] if len(parts) > 1 else base
    prefixes[cat] += 1
for cat, n in sorted(prefixes.items(), key=lambda x: -x[1])[:20]:
    print(f'  {cat}: {n}')
