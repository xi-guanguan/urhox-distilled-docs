import json
import re
from collections import defaultdict

loc = json.load(open('D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json', encoding='utf-8'))

# Find building keys, show all 14
print('=== Buildings (sample 5) ===')
buildings = [k for k in loc.keys() if k.startswith('building.') and k.endswith('.name')]
for k in buildings[:5]:
    name = loc[k]
    desc_key = k.replace('.name', '.desc')
    desc = loc.get(desc_key, '')[:150]
    print(f'  {k}: {name}')
    print(f'    desc: {desc}...')

print()
print('=== Prestige nodes (sample 5) ===')
prestige = [k for k in loc.keys() if k.startswith('prestige.') and k.endswith('.name')]
for k in prestige[:5]:
    name = loc[k]
    desc_key = k.replace('.name', '.desc')
    desc = loc.get(desc_key, '')[:150]
    print(f'  {k}: {name}')
    print(f'    desc: {desc}...')

print()
print('=== Calamities (sample 5) ===')
calamities = [k for k in loc.keys() if k.startswith('calamity.') and k.endswith('.name')]
for k in calamities[:5]:
    name = loc[k]
    print(f'  {k}: {loc[k]}')

print()
print('=== Ores (all 27) ===')
ores = [k for k in loc.keys() if k.startswith('ore.') and k.endswith('.name')]
for k in ores:
    print(f'  {k}: {loc[k]}')

print()
print('=== Dens (all 5) ===')
dens = [k for k in loc.keys() if k.startswith('den.') and k.endswith('.name')]
for k in dens:
    name = loc[k]
    desc = loc.get(k.replace('.name', '.desc'), '')[:150]
    print(f'  {k}: {name}')
    print(f'    desc: {desc}...')

print()
print('=== Mountains (all 6) ===')
mountains = [k for k in loc.keys() if k.startswith('mountain.')]
for k in mountains:
    print(f'  {k}: {loc[k][:120]}')
