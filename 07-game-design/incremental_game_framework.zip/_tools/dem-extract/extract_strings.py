#!/usr/bin/env python3
"""extract_strings.py — 解析 GameMaker data.win 的 STRG chunk.

STRG 格式 (GMS 2.3+, LE):
- 4 bytes: count of strings (N)
- N × 4 bytes: pointer to each string (LE, relative to STRG data start)
- N strings: each is 4-byte length (LE) + UTF-8 bytes + null terminator

输出: str_list = ["string1", "string2", ...]
     index_map = {string: index}
"""
import struct
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def parse_strg(data: bytes) -> list[str]:
    """解析 STRG chunk data. data 从 STRG 内部偏移 (跳过 'STRG' + 4 字节 size) 开始.

    GMS 2.3+ STRG format (LE):
    - 4 bytes: count
    - count × 4 bytes: pointer to each string (LE, relative to START OF STRINGS)
    - count null-terminated strings
    """
    if len(data) < 4:
        return []
    count = struct.unpack('<I', data[0:4])[0]
    print(f"  String count: {count}")

    ptr_table_end = 4 + count * 4
    if ptr_table_end > len(data):
        print(f"  WARNING: pointer table size {ptr_table_end} > data size {len(data)}")
        return []

    pointers = []
    for i in range(count):
        ptr = struct.unpack('<I', data[4 + i*4:4 + i*4 + 4])[0]
        pointers.append(ptr)

    strings = []
    bad = 0
    for i, ptr in enumerate(pointers):
        abs_offset = ptr_table_end + ptr
        if abs_offset >= len(data):
            strings.append('')
            bad += 1
            continue
        end = data.find(b'\x00', abs_offset)
        if end == -1:
            end = len(data)
        s = data[abs_offset:end].decode('utf-8', errors='replace')
        strings.append(s)
    if bad:
        print(f"  WARNING: {bad} strings had bad pointers, replaced with ''")
    return strings


def main():
    if len(sys.argv) < 2:
        print("Usage: python extract_strings.py <data.win> [output.txt]")
        sys.exit(1)
    fp = Path(sys.argv[1])
    data = fp.read_bytes()

    if data[:4] != b'FORM':
        print("ERROR: not a FORM file")
        sys.exit(1)
    form_size = struct.unpack('<I', data[4:8])[0]
    form_data = data[12:12+form_size]

    KNOWN = {
        'STRG', 'CODE', 'VARI', 'FUNC', 'TXTR', 'SPRT', 'AGRP', 'BGND', 'PATH',
        'SCPT', 'GLOB', 'SHDR', 'FONT', 'TMLN', 'OBJT', 'ROOM', 'DAFL', 'TPAG',
        'EMBI', 'LANG', 'MAST', 'AUDO', 'SOND', 'OPTN', 'EXTN', 'LSTG',
        'PSEM', 'PSYS', 'STRU', 'INDX', 'CHRP', 'FEDS', 'ACRV', 'TAGS',
        'UILR', 'FEAT',
    }

    pos = 0
    strg_data = None
    while pos + 8 <= len(form_data):
        name = form_data[pos:pos+4].decode('ascii', errors='replace')
        size = struct.unpack('<I', form_data[pos+4:pos+8])[0]
        if name not in KNOWN:
            pos += 1
            continue
        if name == 'STRG':
            strg_data = form_data[pos+8:pos+8+size]
            print(f"  STRG chunk at offset {pos}, size {size}")
            break
        pos += 8 + size + (size % 2)

    if strg_data is None:
        print("ERROR: STRG chunk not found")
        sys.exit(1)

    strings = parse_strg(strg_data)
    print(f"  Extracted: {len(strings)} strings")

    if len(sys.argv) > 2:
        out = Path(sys.argv[2])
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text('\n'.join(strings), encoding='utf-8')
        print(f"  Wrote: {out}")

    if len(strings) > 0:
        print(f"\n=== Sample (first 10) ===")
        for i, s in enumerate(strings[:10]):
            print(f"  [{i}] {s[:100]}{'...' if len(s) > 100 else ''}")
        print(f"\n=== Sample (last 10) ===")
        for i in range(max(0, len(strings)-10), len(strings)):
            s = strings[i]
            print(f"  [{i}] {s[:100]}{'...' if len(s) > 100 else ''}")

if __name__ == "__main__":
    main()
