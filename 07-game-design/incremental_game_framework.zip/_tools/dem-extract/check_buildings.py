import json
b = json.load(open('cases/dwarf-eat-mountain/buildings.json', encoding='utf-8'))
for building in b['buildings']:
    print(f"  {building['id']} ({building['upgrade_count']} upgrades): {building['name_en']}")
