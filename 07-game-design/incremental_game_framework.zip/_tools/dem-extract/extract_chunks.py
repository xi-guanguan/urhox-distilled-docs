#!/usr/bin/env python3
"""extract_chunks.py — 解析 GameMaker data.win 的 IFF/FORM 块结构.

输出每个 chunk 名称 + 大小 + 偏移, 不解析 chunk 内容.
这是 extract_strings.py / extract_enums.py 的前置步骤.

GameMaker data.win 是 IFF 格式:
- 文件头: 'FORM' + 4 字节大端 size
- 内部: 多个子 chunk, 每个 'XXXX' + 4 字节 size

常见 chunk:
- STRG: 字符串表 (所有 game 中出现的字符串)
- CODE: 字节码 (function/script body)
- VARI: 变量 (GameMaker instance variables)
- FUNC: 函数表
- TXTR: 纹理
- SPRT: 精灵
- INST: instance (object instance in room)
"""
import struct
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

def parse_iff(data: bytes, base: int = 0, max_size: int = 0) -> list[dict]:
    """递归解析 IFF chunks. Returns list of {name, offset, size, data_offset}.

    GameMaker Studio 2.3+ uses Little-endian IFF.
    GameMaker 2.3+ 的 chunk 名固定在已知集合中, 用白名单过滤 false positives.
    """
    KNOWN_CHUNKS = {
        'STRG', 'CODE', 'VARI', 'FUNC', 'TXTR', 'SPRT', 'AGRP', 'BGND', 'PATH',
        'SCPT', 'GLOB', 'SHDR', 'FONT', 'TMLN', 'OBJT', 'ROOM', 'DAFL', 'TPAG',
        'EMBI', 'LANG', 'MAST', 'AUDO', 'SOND', 'OPTN', 'EXTN', 'LSTG',
        'PSEM', 'PSYS', 'STRU', 'INDX', 'CHRP', 'FEDS', 'ACRV', 'TAGS',
        'UILR', 'FEAT',
    }

    chunks = []
    pos = 0
    last_chunk_end = 0
    while pos + 8 <= len(data):
        name = data[pos:pos+4]
        if not name:
            break
        name_str = name.decode('ascii', errors='replace')
        if name_str not in KNOWN_CHUNKS:
            pos += 1
            continue
        size = struct.unpack('<I', data[pos+4:pos+8])[0]
        if size > len(data) - pos - 8:
            chunks.append({'name': name_str, 'offset': base + pos, 'size': size, 'data_offset': base + pos + 8, 'truncated': True})
            break
        chunks.append({'name': name_str, 'offset': base + pos, 'size': size, 'data_offset': base + pos + 8, 'truncated': False})
        pos += 8 + size + (size % 2)
        last_chunk_end = pos
        if max_size and pos >= max_size:
            break
    return chunks

def main():
    if len(sys.argv) < 2:
        print("Usage: python extract_chunks.py <data.win> [filter_name]")
        sys.exit(1)
    fp = Path(sys.argv[1])
    if not fp.exists():
        print(f"ERROR: {fp} not found")
        sys.exit(1)
    data = fp.read_bytes()
    print(f"File: {fp}")
    print(f"Size: {len(data)} bytes ({len(data)/1024:.1f} KB)")
    print(f"Magic: {data[:4].decode('ascii', errors='replace')}")
    print()
    if data[:4] != b'FORM':
        print("ERROR: not a FORM file")
        sys.exit(1)
    form_size = struct.unpack('<I', data[4:8])[0]
    form_type = data[8:12].decode('ascii', errors='replace')
    print(f"FORM type: {form_type}")
    print(f"FORM declared size: {form_size} bytes")
    print(f"File size: {len(data)} bytes (minus 8 byte header)")
    actual_size = min(form_size, len(data) - 12)
    print()
    chunks = parse_iff(data[12:12+actual_size], base=12, max_size=actual_size)
    print(f"=== {len(chunks)} chunks ===")
    print(f"{'Name':<8} {'Size':>12} {'%':>6}  {'Offset':>10}")
    total = sum(c['size'] for c in chunks)
    for c in chunks:
        pct = c['size'] / total * 100 if total else 0
        flag = " (truncated)" if c.get('truncated') else ""
        print(f"{c['name']:<8} {c['size']:>12} {pct:>5.1f}%  {c['offset']:>10}{flag}")

    if len(sys.argv) > 2:
        filter_name = sys.argv[2]
        for c in chunks:
            if c['name'] == filter_name:
                out = fp.with_suffix(f".{filter_name}.bin")
                out.write_bytes(data[c['data_offset']:c['data_offset']+c['size']])
                print(f"\nExtracted {filter_name} -> {out}")

if __name__ == "__main__":
    main()
