import re

lines = open('_tools/dem-extract/extracted/strings.txt', encoding='utf-8').read().split('\n')

# Find non-shader, non-script, non-empty strings of reasonable length
def is_useful(s):
    if not s: return False
    s = s.strip()
    if len(s) < 3 or len(s) > 200: return False
    if 'gml_Script' in s: return False
    if '@anon' in s: return False
    if '@ImGui' in s and len(s) < 100: return False
    if s.startswith('ImGui'): return False
    if s.startswith('gml_'): return False
    if 'scr_' in s and len(s) < 50: return False
    if re.match(r'^[a-zA-Z0-9_]{1,30}$', s): return False  # pure identifier
    if any(kw in s for kw in ['alphaShadow', 'smoothstep', 'vTexcoord', 'gl_FragColor', 'varying', 'uniform ', 'attribute ']):
        return False
    return True

useful_indices = []
for i, s in enumerate(lines):
    if is_useful(s):
        useful_indices.append((i, s))

print(f'Useful: {len(useful_indices)} / {len(lines)}')
print()
print('=== First 50 useful strings ===')
for i, s in useful_indices[:50]:
    print(f'  [{i:5d}] {s[:140]}')
