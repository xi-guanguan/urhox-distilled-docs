"""parse_vari.py — Extract VARI chunk from data.win (GMS variable definitions).

VARI format (LE):
- 4 bytes: instance var count
- For each: variable definitions (name, type, etc.)
"""
import struct
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CHUNKS = {'STRG', 'CODE', 'VARI', 'FUNC', 'TXTR', 'SPRT', 'AGRP', 'BGND', 'PATH',
          'SCPT', 'GLOB', 'SHDR', 'FONT', 'TMLN', 'OBJT', 'ROOM', 'DAFL', 'TPAG',
          'EMBI', 'LANG', 'MAST', 'AUDO', 'SOND', 'OPTN', 'EXTN', 'LSTG',
          'PSEM', 'PSYS', 'STRU', 'INDX', 'CHRP', 'FEDS', 'ACRV', 'TAGS',
          'UILR', 'FEAT'}

def find_chunk(data, target):
    pos = 12
    while pos + 8 <= len(data):
        name = data[pos:pos+4].decode('ascii', errors='replace')
        if name not in CHUNKS:
            pos += 1
            continue
        size = struct.unpack('<I', data[pos+4:pos+8])[0]
        if name == target:
            return pos + 8, size
        pos += 8 + size + (size % 2)
    return None, None


def parse_vari(data, start, size):
    pos = start
    end = start + size
    if pos + 4 > end:
        return []
    count = struct.unpack('<I', data[pos:pos+4])[0]
    pos += 4
    print(f"VARI count: {count}")

    names = []
    for i in range(min(count, 50)):  # first 50 only
        if pos + 12 > end:
            break
        # Format: instance_id(4) var_count(4) then var defs
        instance_id = struct.unpack('<I', data[pos:pos+4])[0]
        var_count = struct.unpack('<I', data[pos+4:pos+8])[0]
        names.append((instance_id, var_count))
        pos += 8
        # Skip variable definitions: each has a name pointer (4) + occurrence count (4) + offset
        for j in range(var_count):
            if pos + 8 > end: break
            str_idx = struct.unpack('<i', data[pos:pos+4])[0]  # signed
            occ_count = struct.unpack('<I', data[pos+4:pos+8])[0]
            pos += 8
            pos += 4 * occ_count
        if pos > end:
            break
    return names


def main():
    fp = Path(sys.argv[1])
    data = fp.read_bytes()
    chunk_start, chunk_size = find_chunk(data, 'VARI')
    if chunk_start is None:
        print("VARI chunk not found")
        return
    print(f"VARI at offset {chunk_start}, size {chunk_size}")
    parse_vari(data, chunk_start, chunk_size)

if __name__ == '__main__':
    main()
