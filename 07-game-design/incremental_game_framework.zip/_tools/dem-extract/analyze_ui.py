import json
import re
from collections import defaultdict

loc = json.load(open('D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json', encoding='utf-8'))

# UI keys analysis
print('=== UI categories ===')
ui_cats = defaultdict(int)
for k in loc.keys():
    if k.startswith('ui.'):
        # ui.X.Y → cat=X
        parts = k.split('.')
        if len(parts) >= 2:
            ui_cats[parts[1]] += 1
for cat, n in sorted(ui_cats.items(), key=lambda x: -x[1])[:20]:
    print(f'  ui.{cat}: {n}')

print()
print('=== Sample UI strings (stat names) ===')
for k in sorted(loc.keys()):
    if k.startswith('ui.') and any(s in k for s in ['total_gold', 'ores', 'gems', 'mithril', 'dpm', 'gpm']):
        v = loc[k]
        if len(v) < 60:
            print(f'  {k}: {v}')

print()
print('=== Title screens / major UI ===')
for k in sorted(loc.keys()):
    if k.startswith('ui.') and (k.endswith('.title') or 'intro' in k or 'header' in k or 'ascend' in k or 'gate_' in k):
        v = loc[k]
        if len(v) < 200:
            print(f'  {k}: {v[:120]}')
