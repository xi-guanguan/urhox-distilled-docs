import json
import re
from collections import Counter, defaultdict

loc = json.load(open('D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json', encoding='utf-8'))

# Group by prefix (e.g., artifact.X.desc → category=artifact)
by_prefix = defaultdict(list)
for key in loc.keys():
    if '.' in key:
        prefix = key.split('.')[0]
        by_prefix[prefix].append(key)
    else:
        by_prefix['_root'].append(key)

print(f'=== {len(by_prefix)} top-level categories ===')
for cat, keys in sorted(by_prefix.items(), key=lambda x: -len(x[1])):
    print(f'  {cat}: {len(keys)} keys')

print()
print('=== Sub-categories per top-level ===')
for cat in sorted(by_prefix.keys()):
    if cat == '_root': continue
    sub = Counter()
    for k in by_prefix[cat]:
        # e.g., artifact.bag_of_overflowing_gold.desc → sub='desc'/'name'
        m = re.match(rf'{re.escape(cat)}\.[^.]*\.(\w+)$', k)
        if m:
            sub[m.group(1)] += 1
    if sub:
        print(f'  {cat}: {dict(sub)}')
