"""find_known_strings.py — Look for known game data strings in data.win bytecode.

We know the strings ARE in the bytecode (e.g., 'cobblestone', 'iron', 'marble' are
referenced as constant identifiers). The data.win contains:
- Static arrays in CODE chunk with struct literals like:
  { name: "T1_Small_Gold", base_value: 1, tier: 1 }
- These literals are stored in the SCPT chunk

We look for typical ore/calamity/den identifiers by their pattern in the bytecode.
"""
import struct
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CHUNKS = {'STRG', 'CODE', 'VARI', 'FUNC', 'TXTR', 'SPRT', 'AGRP', 'BGND', 'PATH',
          'SCPT', 'GLOB', 'SHDR', 'FONT', 'TMLN', 'OBJT', 'ROOM', 'DAFL', 'TPAG',
          'EMBI', 'LANG', 'MAST', 'AUDO', 'SOND', 'OPTN', 'EXTN', 'LSTG',
          'PSEM', 'PSYS', 'STRU', 'INDX', 'CHRP', 'FEDS', 'ACRV', 'TAGS',
          'UILR', 'FEAT'}

def find_chunk(data, target):
    pos = 12
    while pos + 8 <= len(data):
        name = data[pos:pos+4].decode('ascii', errors='replace')
        if name not in CHUNKS:
            pos += 1
            continue
        size = struct.unpack('<I', data[pos+4:pos+8])[0]
        if name == target:
            return pos + 8, size
        pos += 8 + size + (size % 2)
    return None, None


def find_known_string_refs(data, scpt_start, scpt_size, str_table):
    """Look for string indices in SCPT that reference known ore/calamity/den strings."""
    # Common patterns: 0xff ff ff ff = local string index follows
    # Just search for known terms as ASCII in the raw data
    known = [
        b'small_gold_ore', b'medium_gold_ore', b'large_gold_ore',
        b'pure_gold', b'adamantine', b'eonite', b'coreheart', b'oathgold',
        b'sungold', b'diamond', b'ruby', b'emerald', b'sapphire',
        b'topaz', b'amethyst', b'ametrine', b'peridot', b'mithril',
        b'goblin_den', b'dark_castle', b'troll_cave', b'ancient_vault',
        b'goblin_caverns', b'troll_lair', b'minor_rockfall', b'rockfall', b'rockslide',
        b'triple_seal_gate', b'goblin_king_spire', b'dragons_peak',
        b'architects_summit', b'balrogs_pit', b'great_world_spire',
        b'demodwarf', b'priest', b'brewmaster', b'stonecaller',
        b'ruinsmith', b'runesmith', b'bulldozer',
    ]

    scpt_data = data[scpt_start:scpt_start + scpt_size]
    found = {}
    for kw in known:
        positions = []
        start = 0
        while True:
            idx = scpt_data.find(kw, start)
            if idx == -1:
                break
            positions.append(idx)
            start = idx + 1
        if positions:
            found[kw.decode('ascii')] = len(positions)
    return found


def main():
    fp = Path(sys.argv[1])
    data = fp.read_bytes()
    scpt_start, scpt_size = find_chunk(data, 'SCPT')
    if scpt_start is None:
        print("SCPT chunk not found")
        return
    print(f"SCPT at offset {scpt_start}, size {scpt_size}")

    found = find_known_string_refs(data, scpt_start, scpt_size, None)
    print(f"\n=== Found {len(found)} known identifiers ===")
    for k, n in sorted(found.items(), key=lambda x: -x[1])[:50]:
        print(f'  {k}: {n} occurrences')

if __name__ == '__main__':
    main()
