import re

lines = open('_tools/dem-extract/extracted/strings.txt', encoding='utf-8').read().split('\n')
patterns = [
    r'^dem_',
    r'_name',
    r'_desc',
    r'^obj_',
    r'^scr_',
    r'^spr_',
    r'^snd_',
    r'^rm_',
    r'^bg_',
    r'kCalm',
    r'kBerserk',
    r'kExcited',
    r'PASSIVE',
    r'COLLECT',
    r'CALAMITY',
    r'^mood_',
    r'mithril',
    r'gold per',
    r'carrying capacity',
    r'frostfire',
    r'coolant',
    r'kill_threshold',
    r'gold_cap',
    r'seed_',
    r'relic_',
    r'calamity_',
]
counts = {p: 0 for p in patterns}
for s in lines:
    s = s.strip()
    if not s: continue
    for pat in patterns:
        if re.search(pat, s, re.IGNORECASE):
            counts[pat] += 1
print('=== Internal naming pattern counts ===')
for pat, n in counts.items():
    if n > 0:
        print(f'  {pat!r}: {n}')

print()
print('=== Top 10 longest strings ===')
long_strings = [(i, s) for i, s in enumerate(lines) if 200 < len(s.strip()) < 800]
long_strings.sort(key=lambda x: -len(x[1]))
for i, s in long_strings[:10]:
    print(f'  [{i}] ({len(s)} chars) {s[:200]}')
    print()
