"""find_id_indices.py — Find GMS string pool index for known identifiers.

GMS uses the STRG chunk as a string pool. Code references strings by 4-byte index
into the string table. So if we can identify the index for known strings
(e.g., 'small_gold_ore', 'goblin_den'), we can find their context in the bytecode.

Strategy:
1. Load the strings.txt (extracted from STRG)
2. For each known identifier, find its index
3. Search SCPT chunk for that index as a 4-byte LE integer
"""
import struct
import sys
from pathlib import Path
from collections import Counter

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

CHUNKS = {'STRG', 'CODE', 'VARI', 'FUNC', 'TXTR', 'SPRT', 'AGRP', 'BGND', 'PATH',
          'SCPT', 'GLOB', 'SHDR', 'FONT', 'TMLN', 'OBJT', 'ROOM', 'DAFL', 'TPAG',
          'EMBI', 'LANG', 'MAST', 'AUDO', 'SOND', 'OPTN', 'EXTN', 'LSTG',
          'PSEM', 'PSYS', 'STRU', 'INDX', 'CHRP', 'FEDS', 'ACRV', 'TAGS',
          'UILR', 'FEAT'}


def find_chunk(data, target):
    pos = 12
    while pos + 8 <= len(data):
        name = data[pos:pos+4].decode('ascii', errors='replace')
        if name not in CHUNKS:
            pos += 1
            continue
        size = struct.unpack('<I', data[pos+4:pos+8])[0]
        if name == target:
            return pos + 8, size
        pos += 8 + size + (size % 2)
    return None, None


def main():
    fp = Path(sys.argv[1])
    data = fp.read_bytes()
    scpt_start, scpt_size = find_chunk(data, 'SCPT')
    print(f"SCPT at offset {scpt_start}, size {scpt_size}")
    scpt_data = data[scpt_start:scpt_start + scpt_size]

    # Load strings
    strings = open('_tools/dem-extract/extracted/strings.txt', encoding='utf-8').read().split('\n')
    print(f"Loaded {len(strings)} strings")

    # Find index of each known identifier
    known = [
        'small_gold_ore', 'medium_gold_ore', 'large_gold_ore',
        'small_pure_gold', 'medium_pure_gold', 'large_pure_gold',
        'huge_pure_gold', 'massive_pure_gold',
        'adamantine', 'eonite', 'coreheart', 'oathgold', 'sungold',
        'diamond', 'pink_diamond', 'ruby', 'emerald', 'sapphire',
        'topaz', 'amethyst', 'ametrine', 'peridot',
        'white_pearl', 'watermelon_tourmaline', 'deep_sapphire',
        'mystical_diamond', 'mithril',
        'goblin_den', 'dark_castle', 'troll_cave', 'ancient_vault', 'mithril_vein',
        'goblin_caverns', 'troll_lair',
        'minor_rockfall', 'rockfall', 'rockslide', 'gemstorm', 'rain_of_gems',
        'triple_seal_gate', 'goblin_king_spire', 'dragons_peak',
        'architects_summit', 'balrogs_pit', 'great_world_spire',
        'demodwarf', 'priest', 'brewmaster', 'stonecaller',
        'runesmith', 'bulldozer', 'scientist',
    ]

    name_to_idx = {}
    for kw in known:
        for i, s in enumerate(strings):
            if s == kw:
                name_to_idx[kw] = i
                break

    print(f"\n=== Found {len(name_to_idx)}/{len(known)} known identifiers in STRG ===")
    missing = [k for k in known if k not in name_to_idx]
    if missing:
        print(f"Missing: {missing[:10]}")

    # For each known id, count occurrences in SCPT
    print(f"\n=== Occurrences in SCPT (as 4-byte LE integer) ===")
    scpt_results = {}
    for kw, idx in name_to_idx.items():
        idx_bytes = struct.pack('<i', idx)  # signed int
        count = 0
        pos = 0
        while True:
            p = scpt_data.find(idx_bytes, pos)
            if p == -1: break
            count += 1
            pos = p + 1
        scpt_results[kw] = count

    for kw, n in sorted(scpt_results.items(), key=lambda x: -x[1])[:40]:
        if n > 0:
            print(f'  {kw} (idx={name_to_idx[kw]}): {n} refs in SCPT')

if __name__ == '__main__':
    main()
