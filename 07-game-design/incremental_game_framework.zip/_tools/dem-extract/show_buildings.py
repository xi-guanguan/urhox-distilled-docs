import json
import re
from collections import defaultdict

loc = json.load(open('D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json', encoding='utf-8'))

# Group buildings by their base name (not the .upg.X subtree)
buildings = defaultdict(list)
for k in loc.keys():
    if k.startswith('building.') and k.endswith('.name'):
        # 'building.artillery_hall.name' → base='artillery_hall'
        # 'building.artillery_hall.upg.the_great_duke_cannon.name' → base='artillery_hall', upg='the_great_duke_cannon'
        parts = k.split('.')
        if len(parts) == 3:  # building.X.name (top-level building)
            buildings[parts[1]].append(('top', k))
        elif len(parts) == 5:  # building.X.upg.Y.name (upgrade)
            buildings[parts[1]].append(('upg', k))

print(f'=== {len(buildings)} buildings ===')
for bname, items in sorted(buildings.items()):
    tops = [k for tag, k in items if tag == 'top']
    upgs = [k for tag, k in items if tag == 'upg']
    display = loc.get(tops[0], '?') if tops else '?'
    print(f'  {bname} ({display}): {len(upgs)} upgrades')
    for u in upgs[:3]:
        upg_name = loc[u]
        print(f'    - {u}: {upg_name}')

print()
print('=== All 14 buildings + their upgrades count ===')
total_upgrades = 0
for bname in sorted(buildings.keys()):
    upgs = [k for tag, k in buildings[bname] if tag == 'upg']
    total_upgrades += len(upgs)
print(f'Total upgrades across all buildings: {total_upgrades}')

# Now show the actual structure of one building (artillery_hall)
print()
print('=== Artillery Hall: all keys ===')
for k in sorted(loc.keys()):
    if k.startswith('building.artillery_hall.'):
        val = loc[k][:80]
        print(f'  {k}: {val}')
