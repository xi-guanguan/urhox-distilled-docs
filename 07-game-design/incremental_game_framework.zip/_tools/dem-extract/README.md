# dem-extract — Dwarf Eats Mountain data.win 提取工具

> 用于 `cases/dwarf-eat-mountain/` case 的 GMS (GameMaker Studio 2.3+) 二进制数据提取工具。
> 与 Agrivore 用的 `il-disasm/` 不同 (Unity 用 C# IL disassembly), 这里用 GMS 的 IFF/FORM 块结构解析。

## 数据源

- `D:\program files (x86)\steam\steamapps\common\Dwarf Eat Mountain\data.win` (1.5MB IFF/FORM 二进制)
- `D:\program files (x86)\steam\steamapps\common\Dwarf Eat Mountain\DEM_loc.json` (1236 keys, JSON 英文本地化)
- `D:\program files (x86)\steam\steamapps\common\Dwarf Eat Mountain\loc/{ch,de,fr,pt-BR,ru,sp}.json` (6 种翻译)

## 工具一览

| 脚本 | 作用 |
|------|------|
| `extract_chunks.py` | 解析 GMS data.win 的 IFF/FORM 块结构 (28 chunks) |
| `extract_strings.py` | 解析 STRG chunk (15,263 declared strings, 56% of file) |
| `extract_taxonomy.py` | 从 DEM_loc.json 提取完整游戏内容分类 (输出 cases/dwarf-eat-mountain/*.json) |
| `analyze_loc.py` | 分析 DEM_loc.json 的 top-level 分类 (8 类: building/ui/artifact/prestige/calamity/ore/den/mountain) |
| `analyze_artifacts.py` | 分析 124 artifact 的 effect_type 分布 (collect_only/passive_only/collect+passive) |

## GMS IFF/FORM 格式

GMS data.win 是 IFF 格式 (与 PNG/AIFF 相同设计), **little-endian** (与 IFF 标准 big-endian 相反):

```
FORM  [size 4-byte LE]  GEN8  [chunk1]  [chunk2]  ...
                          └─── chunk header: 'XXXX' + 4-byte size + data
```

28 个 chunk (按文件偏移):

| Chunk | Size | 说明 |
|-------|------|------|
| STRG  | 881K (56%) | String pool (15,263 strings) |
| TXTR  | 244K (16%) | Textures |
| SHDR  | 115K (7%)  | Shaders (Juju Adams Gooey) |
| OBJT  | 72K  (5%)  | Object definitions |
| SCPT  | 68K  (4%)  | Script bytecode |
| FONT  | 64K  (4%)  | Font assets |
| SPRT  | 55K  (4%)  | Sprite assets |
| 其他  | < 30K      | 辅助 chunk |

## 用法

```bash
cd _tools/dem-extract

# 1. 列出 data.win 的所有 chunk
python extract_chunks.py "D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/data.win"

# 2. 提取 STRG string pool 到 extracted/strings.txt
python extract_strings.py "D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/data.win" extracted/strings.txt

# 3. 从 DEM_loc.json 提取所有 taxonomy 到 cases/dwarf-eat-mountain/
python extract_taxonomy.py

# 4. 分析本地化分类
python analyze_loc.py

# 5. 分析 artifact effect_type
python analyze_artifacts.py
```

## 输出

`extract_taxonomy.py` 生成 9 个 JSON:

- `cases/dwarf-eat-mountain/resources.json` (6 货币)
- `cases/dwarf-eat-mountain/buildings.json` (14 建筑 + 199 升级)
- `cases/dwarf-eat-mountain/artifacts.json` (124 artifact)
- `cases/dwarf-eat-mountain/prestige.json` (102 节点)
- `cases/dwarf-eat-mountain/ores.json` (27 ore)
- `cases/dwarf-eat-mountain/dens.json` (5 den)
- `cases/dwarf-eat-mountain/calamities.json` (30 calamity)
- `cases/dwarf-eat-mountain/mountains.json` (6 special mountain)
- `cases/dwarf-eat-mountain/dwarves.json` (10 dwarf type)

`extracted/` 目录存 GMS 原始二进制提取:

- `extracted/data.STRG.bin` (881K, 完整 string pool)
- `extracted/data.SCPT.bin` (68K, script bytecode)
- `extracted/data.OBJT.bin` (72K, object definitions)
- `extracted/data.SPRT.bin` (55K, sprite headers)
- `extracted/strings.txt` (15,263 strings, 一行一个)

## 与 Agrivore (Unity) 的对比

| 维度 | Agrivore (Unity) | DEM (GMS) |
|------|------------------|-----------|
| 数据存储 | ScriptableObject (`.asset` files) | Inline struct literal in GML code |
| 枚举 | C# enum (38 个, 478 values) | 字符串 namespace 约定 (`@LOOT@`, `@BUILDINGS@`) |
| 字段 schema | 可从 IL disassembly 完整提取 (50 main classes) | 数据嵌入 bytecode, 无独立 schema |
| 本地化 | Addressables bundle (625 EN strings) | JSON 文件 (1236 EN keys) |
| 数据可见性 | 公开字段名 + 序列化值 | 仅公开字段名; 数值靠运行时观察 |
| 工具 | `il-disasm/` (monodis + 文本解析) | `dem-extract/` (IFF chunk 解析 + JSON 解析) |

## 已知限制

1. **GMS bytecode 不能直接解析**: 完整 GML 反编译需要 UndertaleModTool (C# 工具), 超出 Python 范围
2. **String pool 中的 5879/15263 字符串指针超出 chunk 边界**: GMS 在 2.3+ 引入的新格式导致部分指针错位 (可能是 ZIG/ZAG 压缩或不同 string 子表)
3. **数据完整性严重依赖 DEM_loc.json**: GMS data.win 中只能看到函数名, 数值在 GML 代码中
