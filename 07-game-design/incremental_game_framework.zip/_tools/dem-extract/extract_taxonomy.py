#!/usr/bin/env python3
"""extract_taxonomy.py — Extract full game taxonomy from DEM_loc.json.

Outputs:
- buildings.json: 14 buildings + 200 upgrades
- artifacts.json: 124 artifacts
- prestige.json: 102 prestige nodes
- ores.json: 27 ore types
- dens.json: 5 dens
- calamities.json: 30 calamities
- mountains.json: 6 special mountains
- resources.json: 6 currency types
- dwarves.json: dwarf types (mentioned in building upgrades)
"""
import json
import re
import sys
from pathlib import Path
from collections import defaultdict

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

LOC_PATH = Path("D:/program files (x86)/steam/steamapps/common/Dwarf Eat Mountain/DEM_loc.json")
OUT_DIR = Path("cases/dwarf-eat-mountain")


# 1. 资源 (currencies) - 从 ore + ui 提取
CURRENCY_DEFS = [
    {
        "id": "gold",
        "name_en": "Gold",
        "tier": "primary",
        "earn_sources": ["ore sold by runners", "dwarven mithril compactor (gpm)", "tribute from artifacts"],
        "spend_sources": ["building purchase", "upgrade purchase", "rituals (forge/stonecaller)", "running a spelunker"],
        "framework_concept": "core/02 primary currency",
    },
    {
        "id": "ore",
        "name_en": "Ore (27 subtypes)",
        "tier": "primary_resource",
        "subtypes": ["small_gold_ore", "medium_gold_ore", "large_gold_ore",
                     "small_pure_gold", "medium_pure_gold", "large_pure_gold", "huge_pure_gold", "massive_pure_gold",
                     "adamantine", "eonite", "coreheart", "oathgold", "sungold",
                     "diamond", "pink_diamond", "ruby", "emerald", "sapphire", "topaz",
                     "amethyst", "ametrine", "peridot", "white_pearl", "watermelon_tourmaline",
                     "deep_sapphire", "mystical_diamond", "mithril"],
        "earn_sources": ["miners dig from mountain"],
        "spend_sources": ["sold to gold (in-game coin_to_gold conversion)", "rituals (some ores unlock upgrades)"],
        "framework_concept": "core/02 multi-currency resource",
    },
    {
        "id": "mithril",
        "name_en": "Mithril",
        "tier": "cross_run",
        "earn_sources": ["mithril_vein (den) destroyed", "demodwarf bombs", "some artifacts", "den_artifact_chance prestige"],
        "spend_sources": ["demodwarf bomb purchase (1st tier)", "building upgrades in some trees", "The Forge rituals"],
        "framework_concept": "O5 (cross-run) currency",
    },
    {
        "id": "pp",
        "name_en": "PP (Prestige Points)",
        "tier": "cross_run",
        "earn_sources": ["consuming a mountain", "some artifacts (Crown of Kings +5, Nauglamir +8, etc.)", "chaos_orb"],
        "spend_sources": ["prestige tree (102 nodes)"],
        "framework_concept": "O5 (cross-run) currency",
    },
    {
        "id": "faith",
        "name_en": "Faith",
        "tier": "secondary",
        "earn_sources": ["priest's blessing", "Shrine (SHRINE) building", "Hallowed Choir Icon artifact"],
        "spend_sources": ["Shrine upgrades (Expand Holy Grounds)"],
        "framework_concept": "core/02 secondary currency (specialized)",
    },
    {
        "id": "soul",
        "name_en": "Soul",
        "tier": "secondary",
        "earn_sources": ["some artifacts (Soul Mask, Wizard's Orb, Hallowed Choir Icon)", "The Forge rituals"],
        "spend_sources": ["Runesmith-related upgrades (forge soul)"],
        "framework_concept": "core/02 secondary currency (specialized)",
    },
]


def extract_buildings(loc):
    """14 buildings + 200 upgrades. Building keys: building.X.name / building.X.desc.
    Upgrade keys: building.X.upg.Y.name / .desc.
    """
    buildings = {}
    for k in loc.keys():
        if not k.startswith("building."):
            continue
        parts = k.split(".")
        # building.X.name (3 parts) or building.X.desc (3 parts) — top-level building
        # building.X.upg.Y.name (5 parts) or .desc (5 parts) — upgrade
        if len(parts) == 3 and parts[2] in ("name", "desc"):
            bname = parts[1]
            if bname not in buildings:
                buildings[bname] = {"id": bname, "upgrades": []}
            buildings[bname][parts[2]] = loc[k]
        elif len(parts) == 5 and parts[2] == "upg" and parts[4] in ("name", "desc"):
            bname = parts[1]
            uname = parts[3]
            attr = parts[4]
            if bname not in buildings:
                buildings[bname] = {"id": bname, "upgrades": []}
            # Find or create upgrade entry
            upg = next((u for u in buildings[bname]["upgrades"] if u["id"] == uname), None)
            if not upg:
                upg = {"id": uname, "order": len(buildings[bname]["upgrades"]) + 1}
                buildings[bname]["upgrades"].append(upg)
            upg[attr] = loc[k]

    # Build final list
    out = []
    for bname, data in buildings.items():
        out.append({
            "id": bname,
            "name_en": data.get("name", bname),
            "desc_en": data.get("desc", "")[:200],
            "tier_depth": 0,
            "upgrade_count": len(data["upgrades"]),
            "upgrades": data["upgrades"],
        })
    return out


def extract_artifacts(loc):
    """124 artifacts with name + desc + effect_type classification."""
    artifacts = []
    for k in sorted(loc.keys()):
        if not k.startswith("artifact.") or not k.endswith(".name"):
            continue
        aid = k.replace("artifact.", "").replace(".name", "")
        desc = loc.get(f"artifact.{aid}.desc", "")
        has_collect = "Collect:" in desc
        has_passive = "Passive:" in desc
        has_required = "Required to access" in desc
        if has_collect and has_passive:
            effect_type = "collect+passive"
        elif has_collect:
            effect_type = "collect_only"
        elif has_passive:
            effect_type = "passive_only"
        elif has_required:
            effect_type = "required_to_access"
        elif desc.strip():
            effect_type = "flavor_only"
        else:
            effect_type = "no_desc"
        artifacts.append({
            "id": aid,
            "name_en": loc[k],
            "desc_en": desc,
            "effect_type": effect_type,
            "has_collect": has_collect,
            "has_passive": has_passive,
            "is_required_key": has_required,
        })
    return artifacts


def extract_prestige(loc):
    """102 prestige nodes."""
    nodes = []
    for k in sorted(loc.keys()):
        if not k.startswith("prestige.p_") or not k.endswith(".name"):
            continue
        nid = k.replace("prestige.p_", "").replace(".name", "")
        desc = loc.get(f"prestige.p_{nid}.desc", "")
        nodes.append({
            "id": nid,
            "name_en": loc[k],
            "desc_en": desc,
        })
    return nodes


def extract_ores(loc):
    """27 ore types from ore.X.name."""
    ores = []
    for k in sorted(loc.keys()):
        if not k.startswith("ore.") or not k.endswith(".name"):
            continue
        oid = k.replace("ore.", "").replace(".name", "")
        ores.append({
            "id": oid,
            "name_en": loc[k],
        })
    return ores


def extract_dens(loc):
    """5 dens from den.X.name + .desc."""
    dens = []
    for k in sorted(loc.keys()):
        if not k.startswith("den.") or not k.endswith(".name"):
            continue
        did = k.replace("den.", "").replace(".name", "")
        dens.append({
            "id": did,
            "name_en": loc[k],
            "desc_en": loc.get(f"den.{did}.desc", ""),
        })
    return dens


def extract_calamities(loc):
    """30 calamities from calamity.X.name."""
    calamities = []
    for k in sorted(loc.keys()):
        if not k.startswith("calamity.") or not k.endswith(".name"):
            continue
        cid = k.replace("calamity.", "").replace(".name", "")
        calamities.append({
            "id": cid,
            "name_en": loc[k],
        })
    return calamities


def extract_mountains(loc):
    """6 special mountains from mountain.special.X."""
    mountains = []
    for k in sorted(loc.keys()):
        if not k.startswith("mountain.special."):
            continue
        mid = k.replace("mountain.special.", "")
        mountains.append({
            "id": mid,
            "name_en": loc[k],
        })
    return mountains


def extract_dwarves(loc):
    """Dwarf types referenced in building upgrades."""
    # From building.loc data we see: miner, runner, demodwarf, brewmaster, priest,
    # scientist, stonecaller, runesmith, bulldozer, cybordwarf
    DWARF_TYPES = {
        "miner": "khazad_greathold + miners_guild — digs ore from mountain",
        "runner": "khazad_greathold — carries ore to base, can be stunned by rocks",
        "brewmaster": "meadhall — produces buff potions (Ox-Lung Lager, Bling-Barrel Brew)",
        "priest": "shrine — generates Faith, has blessings",
        "scientist": "laboratory — required for advanced research, can be replaced by stonecaller/runesmith (Triune Prism)",
        "stonecaller": "geode_sanctum — generates bonus ores, can claim Maw drops",
        "runesmith": "the_great_forge — required for Forge ritual, can refund ritual costs",
        "demodwarf": "demolition_shack — places bombs, throws Big Bad Bomb with bobomb_idol buff",
        "cybordwarf": "laboratory (prestige p_cyberdwarf) — advanced scientist type",
        "bulldozer": "manufactorum — manufactured unit, has HP and special attacks",
    }
    dwarves = []
    for did, desc in DWARF_TYPES.items():
        dwarves.append({
            "id": did,
            "name_en": did.replace("_", " ").title(),
            "desc_en": desc,
        })
    return dwarves


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    loc = json.loads(LOC_PATH.read_text(encoding="utf-8"))
    print(f"Loaded {len(loc)} localization keys")

    resources = {"currencies": CURRENCY_DEFS}
    (OUT_DIR / "resources.json").write_text(
        json.dumps(resources, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  resources.json: {len(CURRENCY_DEFS)} currencies")

    buildings = extract_buildings(loc)
    (OUT_DIR / "buildings.json").write_text(
        json.dumps({"buildings": buildings}, ensure_ascii=False, indent=2), encoding="utf-8")
    total_upgrades = sum(b["upgrade_count"] for b in buildings)
    print(f"  buildings.json: {len(buildings)} buildings, {total_upgrades} upgrades")

    artifacts = extract_artifacts(loc)
    (OUT_DIR / "artifacts.json").write_text(
        json.dumps({"artifacts": artifacts}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  artifacts.json: {len(artifacts)} artifacts")

    prestige = extract_prestige(loc)
    (OUT_DIR / "prestige.json").write_text(
        json.dumps({"prestige_nodes": prestige}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  prestige.json: {len(prestige)} prestige nodes")

    ores = extract_ores(loc)
    (OUT_DIR / "ores.json").write_text(
        json.dumps({"ores": ores}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  ores.json: {len(ores)} ore types")

    dens = extract_dens(loc)
    (OUT_DIR / "dens.json").write_text(
        json.dumps({"dens": dens}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  dens.json: {len(dens)} dens")

    calamities = extract_calamities(loc)
    (OUT_DIR / "calamities.json").write_text(
        json.dumps({"calamities": calamities}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  calamities.json: {len(calamities)} calamities")

    mountains = extract_mountains(loc)
    (OUT_DIR / "mountains.json").write_text(
        json.dumps({"special_mountains": mountains}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  mountains.json: {len(mountains)} special mountains")

    dwarves = extract_dwarves(loc)
    (OUT_DIR / "dwarves.json").write_text(
        json.dumps({"dwarves": dwarves}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  dwarves.json: {len(dwarves)} dwarf types")


if __name__ == "__main__":
    main()
