"""Peek at MonoBehaviour typetrees in resources.assets."""
import UnityPy
from pathlib import Path

env = UnityPy.load(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data\resources.assets")
count = 0
for obj in env.objects:
    if obj.type.name != "MonoBehaviour":
        continue
    try:
        t = obj.read_typetree()
    except Exception as e:
        continue
    keys = [k for k in t.keys() if k not in ('m_GameObject', 'm_Enabled', 'm_Script', 'm_Name', 'm_EditorHideFlags', 'm_EditorClassIdentifier')]
    script = t.get("m_Script", {})
    print(f"  obj path_id={obj.path_id}  script.fileID={script.get('m_FileID') if script else None}  fields={keys[:15]}")
    count += 1
    if count >= 8:
        break
