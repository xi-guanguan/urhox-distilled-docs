# _tools/cts-disasm/ — Cell to Singularity 提取工具

> 本目录是 [cases/cell-to-singularity](../../cases/cell-to-singularity/README.md) 案例的提取工具集。
> 与 `_tools/il-disasm/` (Agrivore) 和 `_tools/dem-extract/` (Dwarf Eat Mountain) 平行。

## 工具清单

| 脚本 | 用途 | 输入 | 输出 |
|------|------|------|------|
| `extract_enums.py` | 从 `Assembly-CSharp.dll` 提取所有 enum 类型 + 值 | DLL | `extracted/enums.json` |
| `extract_class_fields.py` | 提取 71 个核心类的字段 schema (name + type + access) | DLL + `field_sig.py` | `extracted/class_fields.json` |
| `field_sig.py` | FieldSig blob 解码器 (ECMA-335 II.23.2.4)，被 extract_class_fields.py 引用 | dnfile PE | n/a (库) |
| `dump_typedefs.py` | 统计 TypeDef base class 分布 (探索性工具) | DLL | stdout |
| `inspect_const.py` | 调试 Constant table value 编码 | DLL | stdout |
| `scan_so_distribution.py` | 扫描所有 level/asset 文件的 MonoBehaviour 数量 | Data 目录 | stdout |
| `scan_so_by_class.py` | 尝试按 class name 分类 ScriptableObject (player build 受限) | resources.assets | stdout |
| `scan_scripts.py` | 找所有 MonoScript 引用 (在 player build 中几乎为空) | Data 目录 | stdout |
| `peek_typetree.py` | peek MonoBehaviour typetree (player build 中 typetree 被剥离) | resources.assets | stdout |
| `categorize_enums.py` | 把 243 enum 按 game system 分类 | `extracted/enums.json` | `cases/cell-to-singularity/enums.json` |
| `emit_case_data.py` | 生成 case data JSON (resources/buildings/...) | enums.json + class_fields.json | `cases/cell-to-singularity/*.json` |

## 提取方法对比

| 步骤 | Agrivore (Unity 6 + Addressables) | Cell to Singularity (Unity 2021+ + built-in) |
|------|----------------------------------|---------------------------------------------|
| 1. Enum 提取 | `monodis` → IL 文本 → 正则 | `dnfile` → walk TypeDef + Constant table |
| 2. Field schema | `monodis` → IL 文本 → 正则 | `dnfile` → walk Field table + 解析 FieldSig blob |
| 3. SO 实例数值 | UnityPy + AddressablesTools + ilspycmd | **不可行** (player build 中 m_Script 引用 Library) |
| 4. Localization | UnityPy + AddressablesTools bundle | **不可行** (I2 Loc 同样引用断链) |

**结论**: C2S 案例**只到 schema 层** (enum + class field)。SO 实例数值需 AssetRipper / AssetStudio 二次提取。

## 运行顺序

```bash
# 0. 一次性
python _tools/cts-disasm/dump_typedefs.py        # 探索 TypeDef 分布
python _tools/cts-disasm/inspect_const.py        # 调试 Constant 编码
python _tools/cts-disasm/scan_so_distribution.py # 找 SO 在哪个 level

# 1. 主提取
python _tools/cts-disasm/extract_enums.py        # 243 enum / 2197 values
python _tools/cts-disasm/extract_class_fields.py # 71 class / 588 fields

# 2. 派生 case data
python _tools/cts-disasm/categorize_enums.py     # → cases/cell-to-singularity/enums.json
python _tools/cts-disasm/emit_case_data.py       # → cases/cell-to-singularity/*.json

# 3. Framework 验证
python scripts/case-to-framework.py cell-to-singularity
python scripts/case-to-framework-coverage.py cell-to-singularity
python scripts/validate-schemas.py
```

## 已知限制

1. **Player build 中 m_Script 引用断链**: Unity 在 player build 中把 MonoScript 数据剥离到 Library, UnityPy 1.25 + dnfile 0.18.0 都无法解析。**AssetRipper 0.5+ / AssetStudio 0.16+** 可以解。
2. **TypeTree 被剥离**: Player build 不包含完整 TypeTree 信息, UnityPy 只能拿到 m_Script + 几个固定字段。
3. **常量类型错位**: C2S IL 把某些 int 默认值编码为 R4 (0x08) 4 字节, 我们的 extractor 接受所有 numeric ConstantType 然后按 4 字节 LE 解, 但 Type=8 (R4) 偶尔会包含非 int 数据。
4. **Nested enum 范围误判**: 嵌套 enum 与父类共享 FieldList 范围, 部分 enum 的"成员"会包含父类 const 字段。

## 依赖

- `dnfile` 0.18.0 (`pip install dnfile`)
- `pefile` (dnfile 依赖)
- `UnityPy` 1.25.0 (`pip install UnityPy`) — 仅 scan_*.py 需要
