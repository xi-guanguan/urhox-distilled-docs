"""Scan all relevant asset files in Cell-to-Singularity install and report
MonoBehaviour/ScriptableObject distribution to find where the game's
data SO instances live."""
from __future__ import annotations
import sys
from pathlib import Path
import UnityPy
from collections import Counter

DATA = Path(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data")
LEVELS = [DATA / f"level{i}" for i in range(10)] + [DATA / "globalgamemanagers", DATA / "resources.assets", DATA / "sharedassets0.assets"]
LEVELS = [p for p in LEVELS if p.exists()]

MONO = "MonoBehaviour"

def main() -> int:
    for p in LEVELS:
        try:
            env = UnityPy.load(str(p))
        except Exception as e:
            print(f"  {p.name}: SKIP ({type(e).__name__})")
            continue
        mb_count = 0
        script_counter: Counter = Counter()
        for obj in env.objects:
            if obj.type.name == MONO:
                mb_count += 1
                try:
                    tree = obj.read_typetree()
                    script = tree.get("m_Script", {})
                    if isinstance(script, dict):
                        guid = script.get("m_ExportedFileHash", b"") or script.get("m_DefaultReferences", b"") or ""
                        # try to extract a class name from script.fileID
                        fid = script.get("m_FileID", 0)
                        # we can't easily get class name without m_Name. Use fileID as proxy
                        script_counter[fid] += 1
                except Exception:
                    pass
        print(f"  {p.name}: {mb_count} MonoBehaviours; top fileID: {script_counter.most_common(5)}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
