"""Decode a FieldSig (ECMA-335 II.23.2.4) type blob.

Input bytes start with calling convention byte (0x06 = Field) followed by
type encoding. Returns a human-readable type string.

This is a simplified decoder handling common cases:
- E_T_VOID, E_T_BOOLEAN, E_T_CHAR, E_T_I1/I2/I4/I8, E_T_U1/U2/U4/U8, E_T_R4/R8
- E_T_STRING, E_T_OBJECT
- E_T_CLASS (followed by TypeDefOrRef coded index)
- E_T_VALUETYPE (followed by TypeDefOrRef coded index)
- E_T_GENERICINST (followed by E_T_CLASS/E_T_VALUETYPE + type + num + type args)
- E_T_SZARRAY (followed by element type)
- E_T_ARRAY (followed by element type + rank + bounds)

References:
  - https://www.ecma-international.org/wp-content/uploads/ECMA-335_6th_edition_june_2012.pdf
    (ECMA-335 II.23.1.16 ELEMENT_TYPE_*)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator


# ELEMENT_TYPE_*
E_T_END = 0x00
E_T_VOID = 0x01
E_T_BOOLEAN = 0x02
E_T_CHAR = 0x03
E_T_I1 = 0x04
E_T_U1 = 0x05
E_T_I2 = 0x06
E_T_U2 = 0x07
E_T_I4 = 0x08
E_T_U4 = 0x09
E_T_I8 = 0x0A
E_T_U8 = 0x0B
E_T_R4 = 0x0C
E_T_R8 = 0x0D
E_T_STRING = 0x0E
E_T_PTR = 0x0F
E_T_BYREF = 0x10
E_T_VALUETYPE = 0x11
E_T_CLASS = 0x12
E_T_VAR = 0x13
E_T_ARRAY = 0x14
E_T_GENERICINST = 0x15
E_T_TYPEDBYREF = 0x16
E_T_I = 0x18
E_T_U = 0x19
E_T_FNPTR = 0x1B
E_T_OBJECT = 0x1C
E_T_SZARRAY = 0x1D
E_T_MVAR = 0x1E
E_T_CMOD_REQD = 0x1F
E_T_CMOD_OPT = 0x20
E_T_INTERNAL = 0x21
E_T_MODIFIER = 0x40
E_T_SENTINEL = 0x41
E_T_PINNED = 0x45


_PRIM = {
    E_T_VOID: "void",
    E_T_BOOLEAN: "bool",
    E_T_CHAR: "char",
    E_T_I1: "sbyte",
    E_T_U1: "byte",
    E_T_I2: "short",
    E_T_U2: "ushort",
    E_T_I4: "int",
    E_T_U4: "uint",
    E_T_I8: "long",
    E_T_U8: "ulong",
    E_T_R4: "float",
    E_T_R8: "double",
    E_T_STRING: "string",
    E_T_OBJECT: "object",
    E_T_I: "nint",
    E_T_U: "nuint",
    E_T_TYPEDBYREF: "typedref",
}


def _read_uleb128(it: Iterator[int]) -> int:
    """Read a ULEB128 encoded int."""
    result = 0
    shift = 0
    for b in it:
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            return result
        shift += 7
    return result


def _read_typedef_or_ref(pe, blob_pos: int, coded: int, table_streams: dict) -> str:
    """Decode a TypeDefOrRef coded index and return its name.

    coded: raw 3-bit tag (0=TypeDef, 1=TypeRef, 2=TypeSpec).
    blob_pos: 4-byte aligned index into TypeDefOrRef table (not used here, but
    dnfile gives the row directly via coded.row).
    """
    # Stub: callers use dnfile's resolution instead
    return "?"


def decode_field_sig(pe, blob: bytes) -> str:
    """Decode a FieldSig blob (starting with calling convention byte 0x06)."""
    if not blob:
        return "?"
    if blob[0] != 0x06:
        return f"unhandled-cconv({blob[0]:#x})"
    rest = blob[1:]
    return _decode_type(pe, rest, 0)[0]


def _decode_type(pe, blob: bytes, pos: int) -> tuple[str, int]:
    md = pe.net.mdtables
    if pos >= len(blob):
        return "?", pos
    b = blob[pos]
    pos += 1

    if b in _PRIM:
        return _PRIM[b], pos

    if b == E_T_CLASS or b == E_T_VALUETYPE:
        name, pos = _resolve_typedef_or_ref(pe, blob, pos)
        if name.startswith("TypeDefOrRef("):
            return f"unresolved-type", pos
        prefix = "class " if b == E_T_CLASS else "valuetype "
        return f"{prefix}{name}", pos

    if b == E_T_GENERICINST:
        # Followed by E_T_CLASS or E_T_VALUETYPE, then type, then GenArgCount (ULEB128), then type args
        inner_b = blob[pos]
        pos += 1
        type_name, pos = _resolve_typedef_or_ref(pe, blob, pos)
        # GenArgCount
        n, sz = _read_uleb128_at(blob, pos)
        pos += sz
        args = []
        for _ in range(n):
            arg, pos = _decode_type(pe, blob, pos)
            args.append(arg)
        return f"{type_name}<{', '.join(args)}>", pos

    if b == E_T_SZARRAY:
        elem, pos = _decode_type(pe, blob, pos)
        return f"{elem}[]", pos

    if b == E_T_ARRAY:
        elem, pos = _decode_type(pe, blob, pos)
        # rank (ULEB128) + numSizes (ULEB128) + sizes + numLoBounds (ULEB128) + loBounds
        rank, sz = _read_uleb128_at(blob, pos); pos += sz
        num_sizes, sz = _read_uleb128_at(blob, pos); pos += sz
        pos += num_sizes * 4
        num_lo, sz = _read_uleb128_at(blob, pos); pos += sz
        pos += num_lo * 4
        return f"{elem}[,]", pos  # simplified — show as multi-dim

    if b == E_T_PTR:
        elem, pos = _decode_type(pe, blob, pos)
        return f"{elem}*", pos

    if b == E_T_BYREF:
        elem, pos = _decode_type(pe, blob, pos)
        return f"ref {elem}", pos

    if b == E_T_VAR:
        n, sz = _read_uleb128_at(blob, pos)
        return f"!{n}", pos + sz

    if b == E_T_MVAR:
        n, sz = _read_uleb128_at(blob, pos)
        return f"!!{n}", pos + sz

    return f"unhandled({b:#x})", pos


def _uleb_size(blob: bytes) -> int:
    """Return the number of bytes consumed by the leading ULEB128 in blob."""
    i = 0
    while i < len(blob):
        if not (blob[i] & 0x80):
            return i + 1
        i += 1
    return len(blob)


def _read_uleb128_at(blob: bytes, pos: int) -> tuple[int, int]:
    """Read a ULEB128 at `pos`; return (value, num_bytes_consumed)."""
    result = 0
    shift = 0
    i = pos
    while i < len(blob):
        b = blob[i]
        result |= (b & 0x7F) << shift
        i += 1
        if not (b & 0x80):
            return result, i - pos
        shift += 7
    return result, i - pos


def _resolve_typedef_or_ref(pe, blob: bytes, pos: int) -> tuple[str, int]:
    """Resolve a TypeDefOrRef coded index from blob at pos, returning (name, new_pos).

    TypeDefOrRef is 2-bit tag + row index. The row index size depends on the
    max row count of the 3 tables (TypeDef, TypeRef, TypeSpec):
        total_bits = 2 + ceil(log2(max_count + 1))
        bytes = ceil(total_bits / 8)
    For 4398 rows: total_bits = 2 + 13 = 15 bits -> 2 bytes.
    """
    md = pe.net.mdtables
    if md is None:
        return "?", pos
    n = max(md.TypeDef.num_rows, md.TypeRef.num_rows, md.TypeSpec.num_rows)
    import math
    total_bits = 2 + math.ceil(math.log2(n + 1))
    nbytes = math.ceil(total_bits / 8)
    if pos + nbytes > len(blob):
        return f"coded-truncated", pos
    coded = int.from_bytes(blob[pos:pos + nbytes], "little")
    tag = coded & 0x3
    row = coded >> 2
    new_pos = pos + nbytes
    if tag == 0 and 0 < row <= md.TypeDef.num_rows:
        r = md.TypeDef.rows[row - 1]
        tn = r.TypeName.value if r.TypeName and r.TypeName.value else ""
        ns = r.TypeNamespace.value if r.TypeNamespace and r.TypeNamespace.value else ""
        return (f"{ns}.{tn}" if ns else tn), new_pos
    if tag == 1 and 0 < row <= md.TypeRef.num_rows:
        r = md.TypeRef.rows[row - 1]
        tn = r.TypeName.value if r.TypeName and r.TypeName.value else ""
        ns = r.TypeNamespace.value if r.TypeNamespace and r.TypeNamespace.value else ""
        return (f"{ns}.{tn}" if ns else tn), new_pos
    if tag == 2 and 0 < row <= md.TypeSpec.num_rows:
        return f"TypeSpec#{row}", new_pos
    return f"TypeDefOrRef(tag={tag}, row={row})", new_pos


def _resolve_typedef_or_ref_int(pe, coded_index: int) -> str:
    """Legacy helper — not used in current decoder, kept for reference."""
    return f"coded={coded_index:#x}"
