#!/usr/bin/env python3
"""Extract all public enum values from Cell-to-Singularity's Assembly-CSharp.dll.

Uses dnfile (pure-Python .NET metadata reader). Walks the TypeDef table
to find all enums (types that extend System.Enum), then enumerates their
value fields via the Constant table (Field parent).

Output: _tools/cts-disasm/extracted/enums.json
        {
          "<EnumName>": {
            "<valueName>": <int_value>,
            ...
          },
          ...
        }
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import dnfile

DLL = Path(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data\Managed\Assembly-CSharp.dll")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\cts-disasm\extracted\enums.json")


# Constant type codes (ECMA-335 II.22.9) that we treat as int-compatible values.
# Cell to Singularity's IL appears to encode even int defaults as R4 (type 8), so we
# accept all numeric ConstantType codes and decode the blob as 4-byte little-endian.
_CONST_INT_TYPES = {1, 2, 3, 4, 5, 6, 7, 8}


def decode_constant(value) -> int | None:
    """Constant.Value is a dnfile.stream.HeapItemBinary; its `.value` is bytes.
    Decode as 4-byte little-endian unsigned int. Drop if the blob isn't 1-4 bytes."""
    if value is None:
        return None
    raw = getattr(value, "value", None)
    if raw is None:
        return None
    if isinstance(raw, int):
        return raw
    if not isinstance(raw, (bytes, bytearray)):
        return None
    if not (1 <= len(raw) <= 4):
        return None
    try:
        return int.from_bytes(raw, "little", signed=False)
    except Exception:
        return None


def main() -> int:
    if not DLL.exists():
        print(f"[ERR] {DLL} not found", file=sys.stderr)
        return 1

    pe = dnfile.dnPE(str(DLL))
    md = pe.net.mdtables
    if md is None or not md.TypeDef or not md.Field or not md.Constant or not md.TypeRef:
        print("[ERR] missing required metadata tables", file=sys.stderr)
        return 1

    # 1. Find TypeRef to System.Enum
    sys_enum_ref = None
    for tr_row in md.TypeRef.rows:
        tn = tr_row.TypeName.value if tr_row.TypeName and tr_row.TypeName.value else ""
        ns = tr_row.TypeNamespace.value if tr_row.TypeNamespace and tr_row.TypeNamespace.value else ""
        if tn == "Enum" and ns == "System":
            sys_enum_ref = tr_row
            break
    if sys_enum_ref is None:
        print("[ERR] System.Enum TypeRef not found", file=sys.stderr)
        return 1

    # 2. Find all TypeDef rows whose Extends -> System.Enum
    # dnfile resolves Extends to a row object via .row attribute (TypeDefOrRef coded index)
    enum_typedef_rows: list = []
    for td_row in md.TypeDef.rows:
        if td_row.Extends and td_row.Extends.row is sys_enum_ref:
            enum_typedef_rows.append(td_row)

    print(f"Found {len(enum_typedef_rows)} enum types")

    # 3. Build a map: Field row -> [Constant row]  (Constant.Parent is a HasConstant coded index)
    # We need efficient lookup. dnfile Constant rows have .Parent which is a coded index;
    # .Parent.row resolves to the actual row. For HasConstant (table 4: Field), .row is a FieldRow.
    # Build set of field rows that have a constant.
    field_const: dict[int, int] = {}  # id(field_row) -> constant int value
    for c_row in md.Constant.rows:
        if c_row.Parent and c_row.Parent.table and c_row.Parent.table.name == "Field":
            t = c_row.Type.value if hasattr(c_row.Type, "value") else c_row.Type
            if t in _CONST_INT_TYPES:
                val = decode_constant(c_row.Value)
                if val is not None:
                    field_const[id(c_row.Parent.row)] = val

    # 4. For each enum, collect members by field range
    # FieldList_Index is 1-based; row.struct.FieldList_Index gives us the start
    # TypeDef is sorted by FieldList, so each type's fields are contiguous from its start
    # to next type's start - 1.
    field_rows = list(md.Field.rows)

    # Sort enum typedefs by FieldList_Index
    enum_typedef_rows.sort(key=lambda r: r.struct.FieldList_Index)

    enums: dict[str, dict[str, int]] = {}
    for i, td_row in enumerate(enum_typedef_rows):
        ns = str(td_row.TypeNamespace.value) if td_row.TypeNamespace and td_row.TypeNamespace.value else ""
        name = str(td_row.TypeName.value) if td_row.TypeName and td_row.TypeName.value else ""
        full = f"{ns}.{name}" if ns else name

        start = td_row.struct.FieldList_Index  # 1-based
        if i + 1 < len(enum_typedef_rows):
            end = enum_typedef_rows[i + 1].struct.FieldList_Index
        else:
            end = md.Field.num_rows + 1  # +1 because start is 1-based inclusive
        # Range is [start, end) in 1-based
        members: dict[str, int] = {}
        for f_idx_1based in range(start, end):
            f_idx_0 = f_idx_1based - 1
            if f_idx_0 < 0 or f_idx_0 >= len(field_rows):
                continue
            f_row = field_rows[f_idx_0]
            fname = f_row.Name.value if f_row.Name and f_row.Name.value else None
            if not fname:
                continue
            val = field_const.get(id(f_row))
            if val is not None:
                members[fname] = val
        if members:
            enums[full] = dict(sorted(members.items(), key=lambda x: x[1]))

    out = dict(sorted(enums.items()))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"Wrote {OUT}")
    print(f"Total enum types: {len(out)}")
    total_values = sum(len(v) for v in out.values())
    print(f"Total enum values: {total_values}")
    for k in list(out.keys())[:25]:
        print(f"  {k}: {len(out[k])} values  e.g. {list(out[k].items())[:3]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
