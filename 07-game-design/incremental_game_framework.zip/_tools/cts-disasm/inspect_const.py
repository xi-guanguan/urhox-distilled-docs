"""Inspect Constant table to learn the value encoding."""
import dnfile

pe = dnfile.dnPE(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data\Managed\Assembly-CSharp.dll")
md = pe.net.mdtables

CT = {0: "Class", 1: "Boolean", 2: "Char", 3: "R8", 4: "I4", 5: "U4", 6: "I8", 7: "U8", 8: "R4", 9: "String", 0xC: "String"}

# Find first 8 int-typed constant rows (Type in 1..8 = non-string)
shown = 0
for i, c in enumerate(md.Constant.rows):
    t = c.Type.value if hasattr(c.Type, "value") else c.Type
    if t in (1, 2, 3, 4, 5, 6, 7, 8):
        v = c.Value
        try:
            raw = v.value_bytes
        except Exception:
            raw = None
        try:
            data = v.value
        except Exception:
            data = None
        parent = c.Parent
        if parent and parent.table:
            pname = parent.table.name
            prow = parent.row
            if prow is not None:
                fname = prow.struct.name if hasattr(prow.struct, "name") else None
                if not fname:
                    fname = prow.struct.Name if hasattr(prow.struct, "Name") else None
            else:
                fname = "?"
        else:
            pname = "?"
            fname = "?"
        print(f"row {i}: type={t} ({CT.get(t, '?')}), bytes={raw!r}, parent={pname}.{fname}, data={data!r}")
        shown += 1
        if shown >= 8:
            break
