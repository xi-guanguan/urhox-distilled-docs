"""Dump all TypeDef names grouped by base class.

Walks the TypeDef table; for each type, resolves Extends to its base type.
Then groups types by base class and prints the count.
"""
import dnfile
from collections import Counter, defaultdict

DLL = r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data\Managed\Assembly-CSharp.dll"

pe = dnfile.dnPE(DLL)
md = pe.net.mdtables

# Build a lookup: row_index -> TypeName
typedef_name = {}
for i, r in enumerate(md.TypeDef.rows):
    tn = r.TypeName.value if r.TypeName and r.TypeName.value else ""
    ns = r.TypeNamespace.value if r.TypeNamespace and r.TypeNamespace.value else ""
    full = f"{ns}.{tn}" if ns else tn
    typedef_name[i] = full

# Count by immediate base
base_counter = Counter()
types_by_base = defaultdict(list)
for i, r in enumerate(md.TypeDef.rows):
    base = "(none)"
    if r.Extends and r.Extends.row is not None:
        brow = r.Extends.row
        if hasattr(brow, "TypeName"):
            btn = brow.TypeName.value if brow.TypeName and brow.TypeName.value else ""
            bns = brow.TypeNamespace.value if brow.TypeNamespace and brow.TypeNamespace.value else ""
            base = f"{bns}.{btn}" if bns else btn
    base_counter[base] += 1
    types_by_base[base].append(typedef_name[i])

# Print top bases
print("=== Top 30 base classes ===")
for base, c in base_counter.most_common(30):
    print(f"  {base}: {c}")
print()
print("=== Base classes with 'ScriptableObject' / 'MonoBehaviour' / 'Object' / 'Component' ===")
for base, c in base_counter.most_common():
    if any(k in base for k in ("ScriptableObject", "MonoBehaviour", "Component", "Object")):
        print(f"  {base}: {c}  (e.g. {types_by_base[base][:3]})")
