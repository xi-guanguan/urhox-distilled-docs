"""Find all MonoScript objects across all asset files and report
class names + GUIDs so we can resolve MonoBehaviour m_Script refs."""
from __future__ import annotations
import sys
from pathlib import Path
import UnityPy
from collections import Counter

DATA = Path(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data")
ALL_FILES = sorted([DATA / f"level{i}" for i in range(10) if (DATA / f"level{i}").exists()]) + \
            [DATA / "resources.assets", DATA / "globalgamemanagers", DATA / "sharedassets0.assets"]


def main() -> int:
    total_mono_script = 0
    class_counter: Counter = Counter()
    for p in ALL_FILES:
        try:
            env = UnityPy.load(str(p))
        except Exception:
            continue
        n = 0
        for obj in env.objects:
            if obj.type.name == "MonoScript":
                try:
                    st = obj.read_typetree()
                    cls_name = st.get("m_ClassName", "?")
                    ns = st.get("m_Namespace", "")
                    full = f"{ns}.{cls_name}" if ns else cls_name
                    class_counter[full] += 1
                    n += 1
                except Exception:
                    pass
        if n:
            print(f"  {p.name}: {n} MonoScript")
        total_mono_script += n
    print(f"Total MonoScript: {total_mono_script}, unique classes: {len(class_counter)}")
    # Top 40 classes
    for cls, c in class_counter.most_common(60):
        print(f"    {c:4d}  {cls}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
