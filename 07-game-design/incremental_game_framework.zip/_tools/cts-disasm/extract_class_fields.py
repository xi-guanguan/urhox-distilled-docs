#!/usr/bin/env python3
"""Extract public field signatures from selected classes in
Cell-to-Singularity's Assembly-CSharp.dll.

Uses dnfile to walk the TypeDef + Field tables. For each target class,
emits a list of fields with:
  - name
  - type (raw .NET type signature as string)
  - access (FieldAttributes access mask)
  - static
  - literal (const)

For ScriptableObject types, additionally extract custom attribute
visibility hints (SerializeField, Header, Tooltip) when present.

Output: _tools/cts-disasm/extracted/class_fields.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import dnfile
from dnfile.enums import MetadataTables
sys.path.insert(0, str(Path(__file__).parent))
from field_sig import decode_field_sig

DLL = Path(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data\Managed\Assembly-CSharp.dll")
OUT = Path(r"D:\Projects\Skills\incremental_game_framework\_tools\cts-disasm\extracted\class_fields.json")

# Curated target classes — covers all 34 SO types + key MonoBehaviours +
# Achievement / Event / Currency / LTE core classes.
TARGETS = [
    # === ScriptableObject (all 34) ===
    "Sound_Pack", "Virtual_Steam_Ach_DB", "AchievementIdMap", "Badge_Info",
    "Cells.TheBeyond.Data.FaderShaderSubstitutionGroup",
    "ContentPromoScriptableObject", "DecisionPanelContentSO",
    "DialogCollection", "Doober", "EventTuningTracker", "EventTuningTrackerUpdate",
    "Game.Scripts.Tuning.ReportDefinition", "GoogleSheetsForUnity.ConnectionData",
    "I2.Loc.ILocalizeTarget", "I2.Loc.LanguageSourceAsset",
    "LTEData", "LTE_Master_Rule", "LTE_Tree", "Lte_PrefabData",
    "MasterLtEDatabase", "Notification", "Offer", "OfferEvent",
    "PerLanguageAssetConfig`1", "PrizeSegments", "ProfileIcon", "ProfileIconPack",
    "ProtoShape2DGlobals", "RankRule", "SfxInfo",
    "StarDatabase", "StarDatabase_Lootbox", "VectorArraySO",
    # === Core MonoBehaviours (sampled) ===
    "GameControllerBase", "GameView", "UIItem", "UIBasePanel",
    "Achievement", "AchievementFactory", "AchievementNorm",
    "BaseStore", "InitableStore", "Tutorial", "NodeBase",
    "CosmeticBase", "PrizeCutsceneBase", "StateMappingBase", "AutoSim",
    "AbstractDashboard",
    # === Tuning/event system (sampled) ===
    "EventId", "Events", "EventState", "EventMode", "EventError",
    "EventStoryChapter", "RebootPersona", "BadgeTier", "BeyondTabState",
    "ConversionStage", "CurrencyType", "Currency", "BoostLevel", "ZoomTierID",
    "ModifierOperator",
    # === Cells namespaces (sampled) ===
    "Cells.Util.RowDataBacking", "Cells.Util.RowDataType",
    "Cells.TheBeyond.TransitionStyle",
    "Lunch.Cells.Gamepad.GamepadWidgetId", "Lunch.Cells.Gamepad.GamepadVariant",
    "Game.Scripts.Event.Currency",
    # === Upgrade system ===
    "upgradeType", "upgradeSubType",
]


def access_str(flags_int: int) -> str:
    """FieldAccess mask: 0x0007 = private/fam_or_assem/assembly/family/fam_or_assem/public."""
    a = flags_int & 0x0007
    return ["private", "fam_or_assem", "assembly", "family", "fam_or_assem", "public"][min(a, 5)] if a < 6 else f"unknown({a})"


def render_type(type_str: str) -> str:
    """Reduce .NET type sig like 'class [UnityEngine]UnityEngine.GameObject' to 'UnityEngine.GameObject'."""
    s = type_str.strip()
    # Strip leading 'class ', 'valuetype ', 'class [ns]'
    for prefix in ("class [", "valuetype [", "class ", "valuetype "):
        if s.startswith(prefix):
            s = s[len(prefix):]
            # If after strip starts with ], drop it
            if s.startswith("]"):
                s = s[1:]
            break
    return s


def main() -> int:
    if not DLL.exists():
        print(f"[ERR] {DLL} not found", file=sys.stderr)
        return 1

    pe = dnfile.dnPE(str(DLL))
    md = pe.net.mdtables
    if not md.TypeDef or not md.Field:
        print("[ERR] missing TypeDef/Field tables", file=sys.stderr)
        return 1

    # Build map: short name -> list of (namespace, full_name, field_list_index, row_index)
    typedef_lookup: dict[str, list[tuple[str, str, int, int]]] = {}
    for td_idx, td_row in enumerate(md.TypeDef.rows):
        tn = td_row.TypeName.value if td_row.TypeName and td_row.TypeName.value else ""
        ns = td_row.TypeNamespace.value if td_row.TypeNamespace and td_row.TypeNamespace.value else ""
        if not tn:
            continue
        typedef_lookup.setdefault(tn, []).append((ns, f"{ns}.{tn}" if ns else tn, td_row.struct.FieldList_Index, td_idx))

    # Field rows (0-indexed) for range lookups
    field_rows = list(md.Field.rows)
    n_fields = md.Field.num_rows

    # For each target, locate the TypeDef and emit fields
    out: dict[str, list[dict]] = {}
    unresolved: list[str] = []
    for target in TARGETS:
        short = target.split(".")[-1].split("`")[0]  # strip generic marker
        candidates = typedef_lookup.get(short, [])
        # Filter by namespace match
        target_ns = ".".join(target.split(".")[:-1]) if "." in target else ""
        chosen = None
        for ns, full, fli, idx in candidates:
            if ns == target_ns:
                chosen = (ns, full, fli, idx)
                break
        if chosen is None and len(candidates) == 1:
            chosen = candidates[0]
        if chosen is None:
            unresolved.append(target)
            continue
        ns, full, fli_1based, _ = chosen

        # Sort candidates by FieldList_Index to determine end of range
        # We need to know the next typedef's FieldList_Index.
        # Build a global sorted list of typedefs by FieldList_Index
        # (rebuild once outside loop for speed).
        pass

    # Pre-build sorted typedef list (by FieldList_Index)
    typedefs_sorted = sorted(
        [(r.TypeName.value if r.TypeName and r.TypeName.value else "",
          r.TypeNamespace.value if r.TypeNamespace and r.TypeNamespace.value else "",
          r.struct.FieldList_Index,
          i) for i, r in enumerate(md.TypeDef.rows)],
        key=lambda x: x[2],
    )

    def find_end(start_1based: int) -> int:
        """End is exclusive 1-based index."""
        for nm, ns, fli, idx in typedefs_sorted:
            if fli > start_1based:
                return fli
        return n_fields + 1

    for target in TARGETS:
        short = target.split(".")[-1].split("`")[0]
        candidates = typedef_lookup.get(short, [])
        target_ns = ".".join(target.split(".")[:-1]) if "." in target else ""
        chosen = None
        for ns, full, fli, idx in candidates:
            if ns == target_ns:
                chosen = (ns, full, fli, idx)
                break
        if chosen is None and len(candidates) == 1:
            chosen = candidates[0]
        if chosen is None:
            continue  # unresolved list was already populated

        ns, full, fli_1based, _ = chosen
        end_1based = find_end(fli_1based)
        fields_out: list[dict] = []
        for f_idx_1based in range(fli_1based, end_1based):
            f_idx_0 = f_idx_1based - 1
            if f_idx_0 < 0 or f_idx_0 >= len(field_rows):
                continue
            fr = field_rows[f_idx_0]
            fname = fr.Name.value if fr.Name and fr.Name.value else None
            if not fname:
                continue
            # Skip compiler-generated fields
            if fname.startswith("<") or fname.startswith("__"):
                continue
            type_str = decode_field_sig(pe, fr.Signature.value)
            flags_int = int(fr.Flags.value) if fr.Flags is not None and hasattr(fr.Flags, "value") else 0
            access = access_str(flags_int)
            is_static = bool(flags_int & 0x0010)
            is_literal = bool(flags_int & 0x0040)
            is_initonly = bool(flags_int & 0x0020)
            fields_out.append({
                "name": fname,
                "type": render_type(type_str),
                "access": access,
                "static": is_static,
                "literal": is_literal,
                "readonly": is_initonly,
            })
        out[full] = fields_out

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {OUT}")
    print(f"Classes extracted: {len(out)} / {len(TARGETS)}")
    print(f"Unresolved: {len(unresolved)}")
    for u in unresolved:
        print(f"  - {u}")
    # Quick stats
    total_fields = sum(len(v) for v in out.values())
    print(f"Total fields: {total_fields}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
