"""Scan resources.assets and identify MonoBehaviours by their script class.

UnityPy reads the asset's TypeTree. For MonoBehaviour objects, the tree
contains m_Script (a PPtr to a MonoScript asset which has a class name).

Output: a class-name -> count map.
"""
from __future__ import annotations
import sys
from pathlib import Path
import UnityPy
from collections import Counter

DATA = Path(r"D:\Program Files (x86)\Steam\steamapps\common\Cell to Singularity\CellToSingularity_Data")
RES = DATA / "resources.assets"


def main() -> int:
    env = UnityPy.load(str(RES))
    print(f"Loaded {RES.name}: {len(env.objects)} objects")
    class_counter: Counter = Counter()
    script_failed = 0
    for obj in env.objects:
        if obj.type.name != "MonoBehaviour":
            continue
        try:
            tree = obj.read_typetree()
        except Exception:
            continue
        # m_Script is a PPtr dict: {"m_FileID": int, "m_PathID": int, ...}
        script = tree.get("m_Script", {})
        if not script:
            script_failed += 1
            continue
        # To get the class name, we need to read the referenced MonoScript
        # UnityPy's typetree is a serialized form; m_Script points to a
        # MonoScript object in the same file (or external).
        path_id = script.get("m_PathID", 0)
        file_id = script.get("m_FileID", 0)
        if file_id != 0:
            # external file ref; skip
            class_counter[f"external:{file_id}"] += 1
            continue
        # local file ref: read the MonoScript object
        try:
            script_obj = env.objects[path_id]
            if script_obj.type.name == "MonoScript":
                st = script_obj.read_typetree()
                cls_name = st.get("m_ClassName", "?")
                ns = st.get("m_Namespace", "")
                full = f"{ns}.{cls_name}" if ns else cls_name
                class_counter[full] += 1
            else:
                class_counter[f"ref-not-script:{script_obj.type.name}"] += 1
        except Exception:
            class_counter["ref-failed"] += 1
    print(f"  Class count: {len(class_counter)}")
    for cls, c in class_counter.most_common(40):
        print(f"    {c:6d}  {cls}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
