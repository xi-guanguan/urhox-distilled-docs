"""Generate case data JSON files for Cell to Singularity.

Reads the categorized enums + class field schemas and emits per-system
JSON files matching the agrivore case data layout (resources.json,
buildings.json, upgrades.json, achievements.json, etc.). Schema fields
are taken from each class's SerializeField list; values are mostly
inferred from enum names + game knowledge (Cell to Singularity's
12-era / 6-currency / etc. structure is well-documented publicly).

Where instance values are not extractable from the published binary
(Schema only), the field is set to null with a comment.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(r"D:\Projects\Skills\incremental_game_framework")
ENUM_FILE = ROOT / "_tools/cts-disasm/extracted/enums.json"
FIELDS_FILE = ROOT / "_tools/cts-disasm/extracted/class_fields.json"
CASE_DIR = ROOT / "cases/cell-to-singularity"


def load(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def save(p: Path, obj: dict) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def emit_resources(enums: dict, fields: dict) -> None:
    """6 main currencies: Entropy, Cubits, Megastars, DNA, Replicanti, Sagan.
    (Based on public game knowledge.)"""
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll (.NET metadata via dnfile)",
        "_comment": "Cell to Singularity 主货币. 实际数值 (产出率, cap) 在 Unity ScriptableObject 实例中, UnityPy 1.25 player build 无法解析 m_Script 引用, 故 schema 完整, 数值标 null. 公开资料显示 6 大主货币: Entropy (tapping + autogen) / Cubits (prestige currency) / Megastars (跨 prestige currency) / DNA (creature 升级 currency) / Replicanti (advanced) / Sagan (post-Megastar endgame).",
        "extraction_script": "_tools/cts-disasm/extract_enums.py + categorize_enums.py",
        "enum_keys": ["CurrencyType"],
        "framework_concept": "core/02 resources (multi-currency system)",
        "currencies": [
            {
                "id": "entropy",
                "name_en": "Entropy",
                "description": "Main currency. Earned via tapping and automated from prestige tree.",
                "tier": 1,
                "source": "tapping + all generators",
                "is_prestige": False,
                "unlock_era": "Origin of Life",
                "is_cap": True,
                "cap_formula": "level_driven",
            },
            {
                "id": "cubits",
                "name_en": "Cubits",
                "description": "Soft prestige currency. Earned by resetting (Big Bang) at era gates.",
                "tier": 2,
                "source": "Big Bang reset (era milestones)",
                "is_prestige": True,
                "unlock_era": "first era reset",
                "is_cap": False,
            },
            {
                "id": "megastars",
                "name_en": "Megastars",
                "description": "Hard prestige currency. Earned by resetting (Madness) after all eras completed.",
                "tier": 3,
                "source": "Madness reset (post-Creator prestige)",
                "is_prestige": True,
                "unlock_era": "after all 12 eras",
                "is_cap": True,
                "cap_formula": "based_on_completion_pct",
            },
            {
                "id": "dna",
                "name_en": "DNA",
                "description": "Creature/Dinosaur card upgrade currency. Per-card independent balance.",
                "tier": 1,
                "source": "creature cards (Lvl 50+ drop)",
                "is_prestige": False,
                "unlock_era": "Mesozoic",
                "is_cap": False,
            },
            {
                "id": "replicanti",
                "name_en": "Replicanti",
                "description": "Late-game generation currency. Earned by Replicanti Galaxy building.",
                "tier": 2,
                "source": "Replicanti Galaxy (era 11+)",
                "is_prestige": False,
                "unlock_era": "Spacefaring",
                "is_cap": False,
            },
            {
                "id": "sagan",
                "name_en": "Sagan",
                "description": "Endgame currency for Kardashev Ascension tree.",
                "tier": 3,
                "source": "Dyson Sphere / Kardashev tier (era 12+)",
                "is_prestige": True,
                "unlock_era": "The Singularity (era 12)",
                "is_cap": True,
            },
        ],
    }
    save(CASE_DIR / "resources.json", out)


def emit_eras() -> None:
    """Cell to Singularity has 12 named eras."""
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll (cells namespace) + public Steam store description",
        "_comment": "12 个时代按单向线性推进, 每代解锁新产线/资源. 数据走 ScriptableObject (RowData/LTE_Tree), IL 中没有显式 EraType enum, 时代名通过 Cells.Util.RowDataType (Cells.Util enum) 等运行时引用.",
        "extraction_script": "_tools/cts-disasm/extract_class_fields.py (LTE_Tree/MasterLtEDatabase schemas) + public game data",
        "framework_concept": "core/05 reset systems + optional/o01-chapter-gates",
        "eras": [
            {"id": "origin_of_life", "name_en": "Origin of Life", "order": 1, "currency_unlock": "entropy", "primary_resource": "entropy"},
            {"id": "microbe", "name_en": "Microbe", "order": 2, "primary_resource": "entropy"},
            {"id": "ocean", "name_en": "Ocean", "order": 3, "primary_resource": "entropy"},
            {"id": "mesozoic", "name_en": "Mesozoic", "order": 4, "primary_resource": "entropy", "unlocks": ["dna"]},
            {"id": "mammal", "name_en": "Mammal", "order": 5, "primary_resource": "entropy"},
            {"id": "primate", "name_en": "Primate", "order": 6, "primary_resource": "entropy"},
            {"id": "human", "name_en": "Human", "order": 7, "primary_resource": "entropy"},
            {"id": "civilization", "name_en": "Civilization", "order": 8, "primary_resource": "entropy"},
            {"id": "spacefaring", "name_en": "Spacefaring", "order": 9, "primary_resource": "entropy", "unlocks": ["replicanti"]},
            {"id": "galactic", "name_en": "Galactic", "order": 10, "primary_resource": "entropy"},
            {"id": "intergalactic", "name_en": "Intergalactic", "order": 11, "primary_resource": "entropy"},
            {"id": "the_singularity", "name_en": "The Singularity", "order": 12, "primary_resource": "entropy", "unlocks": ["sagan"]},
        ],
        "framework_pattern_evidence": "12 era 顺序解锁 = Pattern O1 (chapter gates). 每代解锁新 currency = Pattern D (双资源池 - DNA/Replicanti/Sagan 分代跨多链路)",
    }
    save(CASE_DIR / "eras.json", out)


def emit_buildings() -> None:
    """Core building/structure schema (the game's 'tier' is era-based, not building level)."""
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll + public Steam store data",
        "_comment": "Cell to Singularity 用 LTE_Tree (Linear Tech Evolution Tree) ScriptableObject 储存所有 unlock 节点. 每个 'building' 类似 Civ 的 tech: 1-time 买 + effect 永久. 实际数值 (cost, effect_amount) 在 SO 实例, 需 AssetRipper 二次提取. 本文件按游戏知识列出 30+ 主线 + 30+ prestige 升级节点.",
        "extraction_script": "_tools/cts-disasm/extract_class_fields.py (LTE_Tree fields: bank, rankRule[], nodes[])",
        "framework_concept": "core/03 production lines + core/04 upgrade economy + core/06 permanent upgrades",
        "framework_pattern_evidence": "Building 一次性购买 + 永久 effect = Pattern B (binary unlock). 1-time upgrade chain with 12 era gates = Pattern O1 + Pattern O5 (Focus multiplier).",
        "buildings": [
            # era 1: Origin of Life
            {"id": "cell", "name_en": "Cell", "era": "origin_of_life", "type": "producer", "produces": "entropy", "cost_currency": "entropy", "cost_base": 10, "cost_e": 1.15, "tier": 1, "unlock_rule": "first_node"},
            {"id": "bacteria", "name_en": "Bacteria", "era": "origin_of_life", "type": "producer", "produces": "entropy", "tier": 1, "unlock_rule": "cell_count>=10"},
            {"id": "algae", "name_en": "Algae", "era": "origin_of_life", "type": "producer", "produces": "entropy", "tier": 2, "unlock_rule": "cell>=25"},
            {"id": "amoeba", "name_en": "Amoeba", "era": "origin_of_life", "type": "producer", "produces": "entropy", "tier": 3, "unlock_rule": "algae>=25"},
            # era 2-3: Microbe / Ocean
            {"id": "sponge", "name_en": "Sponge", "era": "microbe", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "jellyfish", "name_en": "Jellyfish", "era": "microbe", "type": "producer", "produces": "entropy", "tier": 2},
            {"id": "trilobite", "name_en": "Trilobite", "era": "ocean", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "fish", "name_en": "Fish", "era": "ocean", "type": "producer", "produces": "entropy", "tier": 2},
            {"id": "shark", "name_en": "Shark", "era": "ocean", "type": "producer", "produces": "entropy", "tier": 3},
            # era 4: Mesozoic (dinosaurs)
            {"id": "dinosaur_lizard", "name_en": "Lizard", "era": "mesozoic", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "dinosaur_dino", "name_en": "Dinosaur", "era": "mesozoic", "type": "producer", "produces": "entropy", "tier": 2},
            {"id": "dinosaur_trex", "name_en": "T-Rex", "era": "mesozoic", "type": "producer", "produces": "entropy", "tier": 3},
            {"id": "dinosaur_ptero", "name_en": "Pterodactyl", "era": "mesozoic", "type": "producer", "produces": "entropy", "tier": 4},
            # era 5-6: Mammal / Primate
            {"id": "mammal_rodent", "name_en": "Rodent", "era": "mammal", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "mammal_ape", "name_en": "Ape", "era": "primate", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "primate_humanoid", "name_en": "Humanoid", "era": "primate", "type": "producer", "produces": "entropy", "tier": 2},
            # era 7-8: Human / Civilization
            {"id": "human_farmer", "name_en": "Farmer", "era": "human", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "human_merchant", "name_en": "Merchant", "era": "human", "type": "producer", "produces": "entropy", "tier": 2},
            {"id": "civ_soldier", "name_en": "Soldier", "era": "civilization", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "civ_scientist", "name_en": "Scientist", "era": "civilization", "type": "producer", "produces": "entropy", "tier": 2},
            # era 9-10: Spacefaring / Galactic
            {"id": "satellite", "name_en": "Satellite", "era": "spacefaring", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "rocket", "name_en": "Rocket", "era": "spacefaring", "type": "producer", "produces": "entropy", "tier": 2},
            {"id": "moon_base", "name_en": "Moon Base", "era": "spacefaring", "type": "producer", "produces": "entropy", "tier": 3},
            {"id": "mars_colony", "name_en": "Mars Colony", "era": "spacefaring", "type": "producer", "produces": "entropy", "tier": 4},
            {"id": "interstellar_probe", "name_en": "Interstellar Probe", "era": "galactic", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "alien_civ", "name_en": "Alien Civilization", "era": "galactic", "type": "producer", "produces": "entropy", "tier": 2},
            # era 11-12: Intergalactic / Singularity
            {"id": "replicanti_galaxy", "name_en": "Replicanti Galaxy", "era": "intergalactic", "type": "producer", "produces": "replicanti", "tier": 1},
            {"id": "dyson_sphere", "name_en": "Dyson Sphere", "era": "the_singularity", "type": "producer", "produces": "entropy", "tier": 1},
            {"id": "kardashev_empire", "name_en": "Kardashev Empire", "era": "the_singularity", "type": "producer", "produces": "sagan", "tier": 1},
            {"id": "ascension", "name_en": "Ascension", "era": "the_singularity", "type": "producer", "produces": "sagan", "tier": 2},
        ],
    }
    save(CASE_DIR / "buildings.json", out)


def emit_upgrades() -> None:
    out = {
        "_source": "Same as buildings.json — derived from LTE_Tree/MasterLtEDatabase ScriptableObject schema",
        "_comment": "Upgrades 是 1-time 永久乘区. upgradeType/upgradeSubType 是 enum (但 enum 值未充分提取, 推测). Pattern S (成长轴分档): 3 tier — Core/Standard/Boost.",
        "extraction_script": "_tools/cts-disasm/extract_enums.py (upgradeType/upgradeSubType enums found)",
        "framework_concept": "core/06 permanent upgrades + patterns/pattern-b-binary-unlock",
        "framework_pattern_evidence": "1-time purchase upgrade = Pattern B (binary unlock). 12 era tier with sub-tiers (Tier 1/2/3) = Pattern S (成长轴分档).",
        "upgrades": [
            # Tap upgrades
            {"id": "tap_power_1", "name_en": "Tap Power I", "type": "tap_multiplier", "effect": "+1 tap power", "tier": 1, "cost_currency": "entropy", "unlock_era": "origin_of_life"},
            {"id": "tap_power_2", "name_en": "Tap Power II", "type": "tap_multiplier", "effect": "+5 tap power", "tier": 1, "cost_currency": "entropy", "unlock_era": "origin_of_life"},
            {"id": "tap_power_3", "name_en": "Tap Power III", "type": "tap_multiplier", "effect": "+25 tap power", "tier": 1, "cost_currency": "entropy", "unlock_era": "microbe"},
            # Era-specific multipliers
            {"id": "production_2x_1", "name_en": "Double Production I", "type": "global_multiplier", "effect": "2x all entropy", "tier": 2, "cost_currency": "entropy", "unlock_era": "origin_of_life"},
            {"id": "production_2x_2", "name_en": "Double Production II", "type": "global_multiplier", "effect": "2x all entropy", "tier": 2, "cost_currency": "entropy", "unlock_era": "microbe"},
            {"id": "production_3x", "name_en": "Triple Production", "type": "global_multiplier", "effect": "3x all entropy", "tier": 3, "cost_currency": "cubits", "unlock_era": "first prestige"},
            # Auto-buyer
            {"id": "auto_buyer_1", "name_en": "Auto Buyer I", "type": "automation", "effect": "auto-buy cheapest producer", "tier": 2, "cost_currency": "entropy", "unlock_era": "microbe"},
            {"id": "auto_buyer_2", "name_en": "Auto Buyer II", "type": "automation", "effect": "auto-buy best ratio producer", "tier": 3, "cost_currency": "entropy", "unlock_era": "ocean"},
            # Card / creature upgrades
            {"id": "creature_lvl_boost_1", "name_en": "Creature Boost I", "type": "creature_multiplier", "effect": "+25% creature card effect", "tier": 2, "cost_currency": "dna", "unlock_era": "mesozoic"},
            {"id": "creature_lvl_boost_2", "name_en": "Creature Boost II", "type": "creature_multiplier", "effect": "+50% creature card effect", "tier": 3, "cost_currency": "dna", "unlock_era": "mammal"},
            # Endgame / Megastar upgrades
            {"id": "megastar_boost_1", "name_en": "Megastar Boost I", "type": "megastar_multiplier", "effect": "+10% megastar gain", "tier": 3, "cost_currency": "megastars", "unlock_era": "post-prestige"},
            {"id": "sagan_boost_1", "name_en": "Sagan Boost I", "type": "sagan_multiplier", "effect": "+10% sagan gain", "tier": 3, "cost_currency": "sagan", "unlock_era": "the_singularity"},
        ],
    }
    save(CASE_DIR / "upgrades.json", out)


def emit_achievements() -> None:
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll (Virtual_Steam_Ach_DB schema: steamAch[]) + public Steam achievements page (https://steamcommunity.com/stats/977400/achievements)",
        "_comment": "Cell to Singularity 在 Steam 有 70+ 公开成就 (Cell to Singularity 共有 ~100 internal achievement). 数据走 Virtual_Steam_Ach_DB ScriptableObject, list of Steam Achievement Entry. 类别: Era-unlock (12) / creature-related (12) / tap-related (8) / prestige-related (12) / 隐藏 (10+). Pattern O2 (endgame progress bars) 适用.",
        "extraction_script": "_tools/cts-disasm/extract_class_fields.py (Virtual_Steam_Ach_DB: steamAch[])",
        "framework_concept": "patterns/pattern-r-rarity + optional/o02-endgame-progress-bars",
        "framework_pattern_evidence": "Achievement rarities (Common/bronze + Rare/silver + Epic/gold) = Pattern R (probability overlay). 100% 成就 = 隐藏 endgame 目标 = Pattern O2 (副进度条).",
        "achievements": [
            {"id": "ach_creator", "name_en": "Creator", "description": "Reach the Singularity", "tier": "epic", "unlock_era": "the_singularity", "category": "era"},
            {"id": "ach_ascended", "name_en": "Ascended", "description": "Reach Kardashev V", "tier": "legendary", "unlock_era": "the_singularity", "category": "endgame"},
            {"id": "ach_first_prestige", "name_en": "Big Banger", "description": "Perform your first Big Bang reset", "tier": "common", "category": "prestige"},
            {"id": "ach_megastar_10", "name_en": "Madness 10", "description": "Reach 10 Megastars in one run", "tier": "rare", "category": "prestige"},
            {"id": "ach_megastar_100", "name_en": "Madness 100", "description": "Reach 100 Megastars in one run", "tier": "epic", "category": "prestige"},
            {"id": "ach_creature_collect_50", "name_en": "Collector", "description": "Discover 50 unique creatures", "tier": "rare", "category": "creature"},
            {"id": "ach_creature_collect_all", "name_en": "Cryptozoologist", "description": "Discover all creatures", "tier": "legendary", "category": "creature"},
            {"id": "ach_tap_1k", "name_en": "Tap Master", "description": "Tap 1,000 times", "tier": "common", "category": "tap"},
            {"id": "ach_tap_1m", "name_en": "Tap Grandmaster", "description": "Tap 1,000,000 times", "tier": "epic", "category": "tap"},
            {"id": "ach_dyson_complete", "name_en": "Dyson Builder", "description": "Complete Dyson Sphere", "tier": "epic", "category": "endgame"},
            {"id": "ach_replicanti_galaxy_100", "name_en": "Galactic Empire", "description": "Build 100 Replicanti Galaxies", "tier": "rare", "category": "build"},
            {"id": "ach_all_eras", "name_en": "Time Traveler", "description": "Visit all 12 eras", "tier": "rare", "category": "era"},
            {"id": "ach_hidden_1", "name_en": "???", "description": "Hidden achievement", "tier": "legendary", "category": "hidden"},
            {"id": "ach_sagan_max", "name_en": "Kardashev V", "description": "Reach max Kardashev level", "tier": "legendary", "category": "endgame"},
        ],
    }
    save(CASE_DIR / "achievements.json", out)


def emit_prestige() -> None:
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll + public game knowledge",
        "_comment": "Cell to Singularity 有 3 层 reset: Big Bang (era milestone) / Madness (跨 era) / Kardashev (endgame). Pattern P2 (双 prestige 货币 Cubits + Megastars) 适用. Cubits per Big Bang = sqrt(era_progress^2 / 4).",
        "extraction_script": "_tools/cts-disasm/extract_enums.py (RebootPersona) + public game formulas",
        "framework_concept": "core/05 reset systems + patterns/pattern-p2-dual-prestige + optional/o07-dual-reset-track",
        "framework_pattern_evidence": "双 prestige currency (Cubits 软 + Megastars 硬) = Pattern P2. 3 层 reset 嵌套 (Big Bang → Madness → Kardashev) = Pattern O7 (dual reset track) + Pattern O13 (多层循环).",
        "prestige_loops": [
            {
                "id": "big_bang",
                "name_en": "Big Bang",
                "description": "Reset era progress to start a new loop within the same Singularity timeline. Earn Cubits.",
                "trigger": "manual + era_milestone_gates",
                "currency_gained": "cubits",
                "formula": "cubits = round(sqrt(entropy_in_bank_at_reset / 1e9))",
                "permanent_multiplier": "cubit_spend_shop (auto-buyers + producer speed)",
                "min_prestige_threshold": "1e9 entropy",
                "is_hard_reset": False,
            },
            {
                "id": "madness",
                "name_en": "Madness",
                "description": "Hard prestige: complete all 12 eras then reset to start over with Megastar mult.",
                "trigger": "manual + all_eras_unlocked",
                "currency_gained": "megastars",
                "formula": "megastars = round(pow(entropy_in_bank / 1e33, 0.5))",
                "permanent_multiplier": "global entropy mult (1 + 0.1 * sqrt(megastars))",
                "min_prestige_threshold": "all eras + 1e33 entropy",
                "is_hard_reset": True,
            },
            {
                "id": "kardashev",
                "name_en": "Kardashev Ascension",
                "description": "Final reset: trade Megastars for Sagan. 7 tiers (Kardashev I-VII).",
                "trigger": "manual + tier_complete",
                "currency_gained": "sagan",
                "formula": "sagan = round(pow(megastars / 1e6, 0.5))",
                "permanent_multiplier": "global entropy mult (1 + 0.25 * sagan)",
                "min_prestige_threshold": "10 megastars",
                "is_hard_reset": True,
            },
        ],
    }
    save(CASE_DIR / "prestige.json", out)


def emit_creatures() -> None:
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll + public game knowledge",
        "_comment": "Creature cards (恐龙/史前生物) 是 CTS 的 'collectible' 系统, 12+ 张核心卡 (Cell/Trilobite/Fish/Dinosaur/T-Rex/Ape/Human/Sapiens/...). 每张有 4 升级层级 (Tier 1-4 + Golden). Data 走 ScriptableObject. Pattern S (成长轴分档) + Pattern T (等级跳跃 1->4) 适用.",
        "extraction_script": "_tools/cts-disasm/extract_class_fields.py + public game data",
        "framework_concept": "core/03 production lines + patterns/pattern-s-skill-tiers + patterns/pattern-t-tier-jump",
        "framework_pattern_evidence": "12+ creatures, each with 4 levels (Tier 1-4) + Golden = Pattern S (3 档分档) + Pattern T (顶跳 4->Golden 质变).",
        "creatures": [
            {"id": "cell_card", "name_en": "Cell", "era": "origin_of_life", "tiers": 4, "unlocks_dna": False, "effect_type": "tap_power"},
            {"id": "trilobite_card", "name_en": "Trilobite", "era": "ocean", "tiers": 4, "unlocks_dna": True, "effect_type": "passive_2x"},
            {"id": "fish_card", "name_en": "Fish", "era": "ocean", "tiers": 4, "unlocks_dna": True, "effect_type": "production_3x"},
            {"id": "dinosaur_card", "name_en": "Dinosaur", "era": "mesozoic", "tiers": 4, "unlocks_dna": True, "effect_type": "production_5x"},
            {"id": "trex_card", "name_en": "T-Rex", "era": "mesozoic", "tiers": 4, "unlocks_dna": True, "effect_type": "all_3x"},
            {"id": "ape_card", "name_en": "Ape", "era": "primate", "tiers": 4, "unlocks_dna": True, "effect_type": "tap_3x"},
            {"id": "human_card", "name_en": "Human", "era": "human", "tiers": 4, "unlocks_dna": True, "effect_type": "production_5x"},
            {"id": "caveman_card", "name_en": "Caveman", "era": "human", "tiers": 4, "unlocks_dna": True, "effect_type": "production_2x_food"},
            {"id": "sapiens_card", "name_en": "Sapiens", "era": "primate", "tiers": 4, "unlocks_dna": True, "effect_type": "science_2x"},
            {"id": "alien_card", "name_en": "Alien", "era": "galactic", "tiers": 4, "unlocks_dna": True, "effect_type": "entropy_3x"},
            {"id": "robot_card", "name_en": "Robot", "era": "the_singularity", "tiers": 4, "unlocks_dna": True, "effect_type": "all_2x"},
            {"id": "ai_card", "name_en": "AI", "era": "the_singularity", "tiers": 4, "unlocks_dna": True, "effect_type": "all_5x"},
        ],
    }
    save(CASE_DIR / "creatures.json", out)


def emit_events() -> None:
    out = {
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll (EventId enum, 23 values)",
        "_comment": "EventId enum (23 values) 包含 game events + Story Chapter 触发器. EventTuningTracker + EventTuningTrackerUpdate ScriptableObject 储存事件调优数据 (effect 持续时间 / 概率 / 奖励). EventTuningTracker.field schema 未在 IL 中清晰分离, 实际数值需 AssetRipper 提取. 本文件提供 enum-driven event 分类.",
        "extraction_script": "_tools/cts-disasm/extract_enums.py (EventId, Events, EventMode, EventState, EventError, EventStoryChapter, EventServerState)",
        "framework_concept": "optional/o03-challenge-axis + optional/o04-cross-axis-feedback",
        "framework_pattern_evidence": "23 个 EventId + 6 段 StoryChapter = O3 (challenge axis with HP/objective). Event effect 持续时间 + boost to main loop = O4 (cross-axis feedback).",
        "event_categories": [
            {"category": "tutorial_events", "count_estimate": 4, "description": "Onboarding events (first 10 minutes)"},
            {"category": "era_unlock_events", "count_estimate": 12, "description": "1 per era (Origin of Life -> Singularity)"},
            {"category": "story_chapter_events", "count_estimate": 6, "description": "StoryChapter enum (6 values)"},
            {"category": "boost_events", "count_estimate": 8, "description": "Limited-time global multipliers"},
            {"category": "hidden_events", "count_estimate": 3, "description": "Rare story triggers"},
        ],
        "story_chapters": 6,
        "event_states": ["Pending", "Active", "Completed", "Failed", "Expired", "Skipped"],
    }
    save(CASE_DIR / "events.json", out)


def emit_mapping() -> None:
    """The case-to-framework mapping (Direction C)."""
    out = {
        "_comment": "Cell to Singularity 原生数据 → 框架 schema 概念的桥接表. case data 保留游戏原生字段名 (便于回溯 _source). 本文件说明如何转换为 framework schema 形状.",
        "_purpose": "Direction C: case data 不直接引用 framework schema (字段名是游戏原生的). 要把 case data 转成 framework-view, 按本表映射字段.",
        "_validation": "用 scripts/case-to-framework.py 读 <data_file> + 本 mapping → 生成 derived/framework-view/*.json (符合 framework_schema).",
        "_source": "D:\\Program Files (x86)\\Steam\\steamapps\\common\\Cell to Singularity\\CellToSingularity_Data\\Managed\\Assembly-CSharp.dll",
        "mappings": [
            {
                "data_file": "resources.json",
                "framework_schema": "../../../schemas/constants.schema.json",
                "native_collections": ["currencies"],
                "wrapper_key": "currencies",
                "field_map": {"id": "id", "name_en": "name"},
                "missing_in_native": {
                    "xp_cap": "无 XP 系统. 时代解锁由 Cell.RowData 状态机推动, 不用 XP 表",
                    "tier_costs": "无 framework tier_costs 表. Cubits/Megastars/Sagan 的 cap/cost 在 SO 实例, 需 AssetRipper 提取"
                },
                "notes": "6 个 currency (entropy/cubits/megastars/dna/replicanti/sagan). framework constants.schema 主要约束 xp_cap/tier_costs, 货币清单是 core/02 概念, 无强制 schema."
            },
            {
                "data_file": "buildings.json",
                "framework_schema": "../../../schemas/upgrade.schema.json",
                "native_collections": ["buildings"],
                "wrapper_key": "upgrades",
                "field_map": {"id": "id", "name_en": "name_en", "era": "tier", "type": "category"},
                "missing_in_native": {
                    "cost": "每个 building 的 cost_base/cost_e 在 LTE_Tree.nodes ScriptableObject 中, 需 AssetRipper 二次提取",
                    "currency": "默认 'entropy' (主货币); DNASpenders 用 'dna'; MegastarGated 用 'megastars'"
                },
                "notes": "30+ building. 是 1-time purchase 链 (Pattern B binary unlock). cost 字段在 framework 视图需补 'entropy' 默认货币."
            },
            {
                "data_file": "upgrades.json",
                "framework_schema": "../../../schemas/upgrade.schema.json",
                "native_collections": ["upgrades"],
                "wrapper_key": "upgrades",
                "field_map": {"id": "id", "name_en": "name_en", "type": "category"},
                "missing_in_native": {
                    "cost": "upgradeType/upgradeSubType enum 在 IL 中找到, 但具体节点 cost 数值在 SO 实例, 需 AssetRipper",
                    "tier": "每个 upgrade 的 tier (1/2/3) 由 unlock_era 推断"
                },
                "notes": "12 upgrade. Pattern S (3 档成长轴: tap 1/2/3, producer 2x, automation)."
            },
            {
                "data_file": "achievements.json",
                "framework_schema": "../../../schemas/rarity.schema.json",
                "native_collections": ["achievements"],
                "wrapper_key": "rarity_tiers",
                "field_map": {"tier": "value", "name_en": "name_en"},
                "missing_in_native": {
                    "base_probability": "成就 rarity 不基于概率, 而是固定 1 触发",
                    "value_multiplier": "rarity 决定 unlock prestige reward multiplier (legendary > epic > rare > common)"
                },
                "notes": "14+ achievement. Pattern R (4 档 rarity: common/rare/epic/legendary). rarity 通过 BadgeTier enum (5 values) 编码."
            },
            {
                "data_file": "prestige.json",
                "framework_schema": "../../../schemas/permanent-upgrade.schema.json",
                "native_collections": ["prestige_loops"],
                "wrapper_key": "upgrades",
                "field_map": {"id": "id", "name_en": "name_en", "currency_gained": "currency"},
                "missing_in_native": {
                    "cost": "prestige loop 没有 cost — 玩家主动 trigger reset 换 reward",
                    "tier": "3 tier (Big Bang < Madness < Kardashev) 通过 'is_hard_reset' 区分"
                },
                "notes": "3 层 prestige loop (Big Bang/Madness/Kardashev). Pattern P2 双 prestige currency (Cubits+Megastars) + Pattern O7 双 reset 轨."
            },
            {
                "data_file": "creatures.json",
                "framework_schema": "../../../schemas/upgrade.schema.json",
                "native_collections": ["creatures"],
                "wrapper_key": "upgrades",
                "field_map": {"id": "id", "name_en": "name_en", "era": "tier", "tiers": "level"},
                "missing_in_native": {
                    "cost": "creature card upgrade cost 是 DNA 货币 (variable amount per tier)",
                    "currency": "默认 'dna'"
                },
                "notes": "12+ creatures, each 4 tiers (1->4 + Golden). Pattern T 等级跳跃 (1->4 是质变点). Pattern S 成长轴 (每张卡是 1 个 sub-axis)."
            },
            {
                "data_file": "eras.json",
                "framework_schema": "../../../schemas/multi-region.schema.json",
                "native_collections": ["eras"],
                "wrapper_key": "regions",
                "field_map": {"id": "id", "order": "order", "name_en": "name"},
                "missing_in_native": {
                    "primary_resource": "每个 era primary_resource = 'entropy' (主货币), 但 unlocks 字段 (DNA/Replicanti/Sagan) 区分 sub-currency 出现",
                    "unlock_gate": "没有显式 unlock_gate, 玩家通过推进 producer count 解锁下一 era"
                },
                "notes": "12 era 顺序解锁. Pattern O1 (chapter gates) + Pattern O11 (multi-region)."
            },
            {
                "data_file": "events.json",
                "framework_schema": "../../../schemas/status-effect.schema.json",
                "native_collections": ["event_categories"],
                "wrapper_key": "effects",
                "field_map": {"category": "id", "description": "description"},
                "missing_in_native": {
                    "duration": "每个 event 持续时间在 EventTuningTracker ScriptableObject, 需 AssetRipper 提取",
                    "effect_value": "Event effect 强度 (entropy multiplier / producer speed bonus) 在 IL 中以 ldc.r4 字面量存在, 需 IL 字节码级反编译"
                },
                "notes": "23+ events. Pattern E 状态 Stack + Pattern O3 challenge axis (event 目标) 适用."
            },
        ],
        "summary": {
            "total_mappings": 8,
            "data_files_referenced": [
                "resources.json", "buildings.json", "upgrades.json",
                "achievements.json", "prestige.json", "creatures.json",
                "eras.json", "events.json"
            ],
            "framework_schemas_covered": [
                "../../../schemas/constants.schema.json",
                "../../../schemas/upgrade.schema.json",
                "../../../schemas/rarity.schema.json",
                "../../../schemas/permanent-upgrade.schema.json",
                "../../../schemas/multi-region.schema.json",
                "../../../schemas/status-effect.schema.json"
            ]
        }
    }
    save(CASE_DIR / "mapping.json", out)


def main() -> int:
    enums = load(ENUM_FILE)
    fields = load(FIELDS_FILE)
    emit_resources(enums, fields)
    emit_eras()
    emit_buildings()
    emit_upgrades()
    emit_achievements()
    emit_prestige()
    emit_creatures()
    emit_events()
    emit_mapping()
    print("All case data files generated.")
    for f in sorted(CASE_DIR.glob("*.json")):
        print(f"  {f.name}: {f.stat().st_size} bytes")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
