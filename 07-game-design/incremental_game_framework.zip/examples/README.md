# Examples 落地示例

> 提供伪代码与配置示例，让框架可以被实际工程化。
>
> **headless 先行**：伪代码是 M6 引擎实现的直接参考；配置 JSON 是 M5 数据 + M7 模拟输入。UI 层（M8）不在此目录。

---

## headless 引擎对接

实现 M6 引擎时，按以下顺序读伪代码并跑 CLI 验证：

1. [add-resource.md](pseudocode/add-resource.md) → [purchase.md](pseudocode/purchase.md) → [gain-xp.md](pseudocode/gain-xp.md)（Core MVP）
2. 按 M4 勾选表追加 Pattern 伪代码
3. 用 [configs/](configs/) 示例 JSON 作为 `--config` 输入跑模拟

完整 CLI 契约见 [docs/ai-first-workflow.md §4](../docs/ai-first-workflow.md#4-headless-引擎-cli-契约)。

---

## 目录

| 路径 | 用途 |
|------|------|
| [pseudocode/](pseudocode/) | 关键算法的语言无关伪代码 |
| [configs/](configs/) | 数据 JSON 示例（含 $schema 引用） |

---

## 伪代码

| 文件 | 对应框架文档 | 用途 |
|------|------------|------|
| [add-resource.md](pseudocode/add-resource.md) | [core/02-resources.md § 统一入库](../core/02-resources.md#统一入库) | 资源入库 + global_multiplier |
| [gain-xp.md](pseudocode/gain-xp.md) | [core/05-reset-systems.md § 经验与升级](../core/05-reset-systems.md#经验与升级) | Reset XP → 永久点 |
| [purchase.md](pseudocode/purchase.md) | [core/04-upgrade-economy.md § 购买流程](../core/04-upgrade-economy.md#购买流程) | 升级购买 + Pattern T/S 集成 |
| [apply-status-effect.md](pseudocode/apply-status-effect.md) ✨ | [patterns/pattern-e](../patterns/pattern-e-status-stack.md) | 状态效果 Stack：apply / tick / 战斗乘区 |
| [region-manager.md](pseudocode/region-manager.md) ✨ | [optional/o11](../optional/o11-multi-region.md) | 多区域子系统：unlock / supervision / 跨区域乘区 |
| [inspiration-resolver.md](pseudocode/inspiration-resolver.md) ✨ | [patterns/pattern-c-cross-building-inspiration](../patterns/pattern-c-cross-building-inspiration.md) | 跨建筑 Inspiration 链：互斥槽 + 可叠加链 + 3 类触发 |

### 风格

- 提供 Python + TypeScript 两种风格，便于不同技术栈迁移
- 重点放在**函数契约**和**反模式**，不绑定具体语言

---

## 伪代码 ↔ 配置对照表

每个伪代码至少有一个对应的配置示例可用于 Schema 验证：

| 框架概念 | 伪代码 | 配置示例 | Schema |
|---------|--------|---------|--------|
| 资源入库（Core 02） | [add-resource.md](pseudocode/add-resource.md) | — | — |
| 购买流程 + C1-C6 曲线（Core 04 + Pattern S/T） | [purchase.md](pseudocode/purchase.md) | [example-upgrades.json](configs/example-upgrades.json) + [example-tier-jump.json](configs/example-tier-jump.json) | [upgrade.schema.json](../schemas/upgrade.schema.json) |
| 永久升级（Core 06） | [purchase.md](pseudocode/purchase.md) 通用版 | [example-permanent.json](configs/example-permanent.json) | [permanent-upgrade.schema.json](../schemas/permanent-upgrade.schema.json) |
| XP / Reset（Core 05） | [gain-xp.md](pseudocode/gain-xp.md) | — | — |
| 稀有度（Pattern R） | — | [example-rarity.json](configs/example-rarity.json) | [rarity.schema.json](../schemas/rarity.schema.json) |
| 状态效果 Stack（Pattern E） | [apply-status-effect.md](pseudocode/apply-status-effect.md) | [example-status-effect.json](configs/example-status-effect.json) | [status-effect.schema.json](../schemas/status-effect.schema.json) |
| 多区域子系统（O11） | [region-manager.md](pseudocode/region-manager.md) | [example-multi-region.json](configs/example-multi-region.json) | [multi-region.schema.json](../schemas/multi-region.schema.json) |
| 跨建筑 Inspiration 链（Pattern C·跨建筑变体） | [inspiration-resolver.md](pseudocode/inspiration-resolver.md) | [example-cross-building-inspiration.json](configs/example-cross-building-inspiration.json) | [cross-building-inspiration.schema.json](../schemas/cross-building-inspiration.schema.json) |

> 说明：每个 Pattern / Optional 在 examples 目录中**伪代码 + 配置**成对出现；无伪代码的配置（如 example-rarity）只展示数据形态，不展示运行逻辑。

---

## 配置示例

| 文件 | 对应 Schema | 用途 |
|------|------------|------|
| [example-upgrades.json](configs/example-upgrades.json) | [schemas/upgrade.schema.json](../schemas/upgrade.schema.json) | 升级数据（C1-C6 曲线 + Pattern S 三档） |
| [example-permanent.json](configs/example-permanent.json) | [schemas/permanent-upgrade.schema.json](../schemas/permanent-upgrade.schema.json) | 永久升级（线性/复合/Grant） |
| [example-rarity.json](configs/example-rarity.json) | [schemas/rarity.schema.json](../schemas/rarity.schema.json) | 稀有度（对应 Pattern R） |
| [example-tier-jump.json](configs/example-tier-jump.json) | [schemas/upgrade.schema.json](../schemas/upgrade.schema.json) | 等级跳跃（对应 Pattern T） |
| [example-status-effect.json](configs/example-status-effect.json) ✨ | [schemas/status-effect.schema.json](../schemas/status-effect.schema.json) | 状态效果 Stack（对应 Pattern E） |
| [example-multi-region.json](configs/example-multi-region.json) ✨ | [schemas/multi-region.schema.json](../schemas/multi-region.schema.json) | 多区域子系统（对应 O11） |
| [example-cross-building-inspiration.json](configs/example-cross-building-inspiration.json) ✨ | [schemas/cross-building-inspiration.schema.json](../schemas/cross-building-inspiration.schema.json) | 跨建筑 Inspiration 链（对应 Pattern C·跨建筑变体） |

### 使用

```bash
# 验证示例配置 vs Schema
npx ajv validate -s ../schemas/upgrade.schema.json -d configs/example-upgrades.json
```

---

## 新增示例

1. 在 `pseudocode/` 或 `configs/` 创建新文件
2. 在文件开头标注对应框架文档
3. 在 [CHANGELOG.md](../CHANGELOG.md) 记录新增

---

## 反模式（写示例时）

| 反模式 | 后果 |
|--------|------|
| 用具体游戏数值（+5% / +10%） | 误把示例当默认值 |
| 跳过反模式段 | 失去教学价值 |
| 绑定单一语言 | 阻碍跨技术栈迁移 |
| 没有 $schema 引用 | 无法被 Schema 验证 |