# 伪代码 · apply_status_effect（Pattern E）

> **框架模块**：[patterns/pattern-e-status-stack.md](../../patterns/pattern-e-status-stack.md)
> **数据 Schema**：[schemas/status-effect.schema.json](../../schemas/status-effect.schema.json)
> **配置示例**：[examples/configs/example-status-effect.json](../configs/example-status-effect.json)

## Python 伪代码

```python
from dataclasses import dataclass, field
from typing import Callable, Optional
import time

@dataclass
class StatusEffect:
    effect_id: str
    name: str
    max_stacks: int
    duration: float           # -1 = 永久
    stacking_policy: str      # "refresh" | "extend" | "stack"
    percent_increase: float
    tick_interval: Optional[float] = None
    damage_per_tick: Optional[float] = None
    tag: str = "neutral"
    decay_exempt: bool = False

@dataclass
class ActiveEffect:
    effect: StatusEffect
    stacks: int
    expires_at: float
    last_tick_at: float

class StatusEffectManager:
    def __init__(self, effects_data: list[dict]):
        self.effects = {e["effect_id"]: StatusEffect(**e) for e in effects_data}
        self.active: dict[str, ActiveEffect] = {}
        self.hooks: dict[str, list[Callable]] = {"apply": [], "tick": [], "expire": []}

    def apply(self, effect_id: str, source_multiplier: float = 1.0):
        """应用 / 刷新 / 叠层状态效果。"""
        effect = self.effects[effect_id]
        now = time.time()

        if effect_id in self.active:
            active = self.active[effect_id]
            old_stacks = active.stacks

            if effect.stacking_policy == "refresh":
                active.expires_at = now + effect.duration
            elif effect.stacking_policy == "extend":
                active.expires_at = max(active.expires_at, now) + effect.duration
            elif effect.stacking_policy == "stack":
                active.stacks = min(active.stacks + 1, effect.max_stacks)
                active.expires_at = now + effect.duration

            # 触发 on_apply 钩子（用于音效 / UI 闪动）
            for hook in self.hooks["apply"]:
                hook(effect_id, old_stacks, active.stacks)
        else:
            self.active[effect_id] = ActiveEffect(
                effect=effect,
                stacks=1,
                expires_at=now + (10**9 if effect.duration < 0 else effect.duration),
                last_tick_at=now,
            )
            for hook in self.hooks["apply"]:
                hook(effect_id, 0, 1)

    def tick(self, dt: float, decay_start: float = 0):
        """每帧 / 固定 0.1s 调一次：衰减 + DOT tick。"""
        now = time.time()
        expired = []

        for effect_id, active in self.active.items():
            effect = active.effect

            # 1) 过期判定
            if effect.duration >= 0 and now >= active.expires_at:
                expired.append(effect_id)
                continue

            # 2) 衰减（除 Frozen 外的元素效果）
            if not effect.decay_exempt and decay_start > 0:
                excess = max(0, active.stacks - decay_start)
                decay = (excess / 100) ** 1.15
                active.stacks = max(0, active.stacks - int(decay))

            # 3) DOT tick
            if (effect.tick_interval is not None
                and now - active.last_tick_at >= effect.tick_interval):
                damage = effect.damage_per_tick * active.stacks
                # 调用战斗伤害系统的接口
                self._on_dot_tick(effect_id, damage)
                active.last_tick_at = now

        for effect_id in expired:
            active = self.active.pop(effect_id)
            for hook in self.hooks["expire"]:
                hook(effect_id, active.stacks)

    def combat_multiplier(self) -> float:
        """战斗中所有状态效果对伤害的乘区贡献。"""
        mult = 1.0
        for active in self.active.values():
            e = active.effect
            if e.percent_increase > 0:
                mult *= (1 + active.stacks * e.percent_increase / 100.0)
        return mult

    def _on_dot_tick(self, effect_id: str, damage: float):
        # 注入到战斗伤害系统
        pass
```

## TypeScript 伪代码

```typescript
interface StatusEffect {
    effect_id: string;
    max_stacks: number;
    duration: number;          // -1 = 永久
    stacking_policy: "refresh" | "extend" | "stack";
    percent_increase: number;
    tick_interval?: number;
    damage_per_tick?: number;
    tag: "physical" | "magical" | "curse" | "elemental" | "neutral";
    decay_exempt?: boolean;
}

interface ActiveEffect {
    effect: StatusEffect;
    stacks: number;
    expiresAt: number;
    lastTickAt: number;
}

class StatusEffectManager {
    private effects = new Map<string, StatusEffect>();
    private active = new Map<string, ActiveEffect>();
    private onApply: ((id: string, oldS: number, newS: number) => void)[] = [];
    private onTick:  ((id: string, damage: number) => void)[] = [];
    private onExpire:((id: string, stacks: number) => void)[] = [];

    constructor(effectsData: StatusEffect[]) {
        effectsData.forEach(e => this.effects.set(e.effect_id, e));
    }

    apply(effect_id: string): void {
        const effect = this.effects.get(effect_id)!;
        const now = performance.now() / 1000;
        const existing = this.active.get(effect_id);

        if (existing) {
            const oldStacks = existing.stacks;
            switch (effect.stacking_policy) {
                case "refresh":
                    existing.expiresAt = now + effect.duration;
                    break;
                case "extend":
                    existing.expiresAt = Math.max(existing.expiresAt, now) + effect.duration;
                    break;
                case "stack":
                    existing.stacks = Math.min(existing.stacks + 1, effect.max_stacks);
                    existing.expiresAt = now + effect.duration;
                    break;
            }
            this.onApply.forEach(h => h(effect_id, oldStacks, existing.stacks));
        } else {
            this.active.set(effect_id, {
                effect,
                stacks: 1,
                expiresAt: now + (effect.duration < 0 ? 1e9 : effect.duration),
                lastTickAt: now,
            });
            this.onApply.forEach(h => h(effect_id, 0, 1));
        }
    }

    tick(decayStart: number = 0): void {
        const now = performance.now() / 1000;
        const expired: string[] = [];

        for (const [id, active] of this.active) {
            const { effect } = active;

            if (effect.duration >= 0 && now >= active.expiresAt) {
                expired.push(id);
                continue;
            }

            if (!effect.decay_exempt && decayStart > 0) {
                const excess = Math.max(0, active.stacks - decayStart);
                const decay = Math.pow(excess / 100, 1.15);
                active.stacks = Math.max(0, active.stacks - Math.floor(decay));
            }

            if (effect.tick_interval !== undefined
                && now - active.lastTickAt >= effect.tick_interval) {
                const damage = (effect.damage_per_tick ?? 0) * active.stacks;
                this.onTick.forEach(h => h(id, damage));
                active.lastTickAt = now;
            }
        }

        for (const id of expired) {
            const active = this.active.get(id)!;
            this.active.delete(id);
            this.onExpire.forEach(h => h(id, active.stacks));
        }
    }

    combatMultiplier(): number {
        let mult = 1.0;
        for (const { effect, stacks } of this.active.values()) {
            if (effect.percent_increase > 0) {
                mult *= 1 + stacks * effect.percent_increase / 100;
            }
        }
        return mult;
    }
}
```

## 集成点

```text
战斗伤害链（来自 core/03-production-lines.md）：

damage = base
       × (1 + 永久挑战加成)
       × statusManager.combatMultiplier()       # ← 这里
       × (1 + 易伤层数 × debuff_pct / 100)
       × 战斗技能
       × 派系 / 科技
```

## 验收清单

- [ ] 状态效果支持 refresh / extend / stack 三种策略
- [ ] duration = -1 表示永久直到被刷新 / 驱散
- [ ] 每 0.1s tick 跑一次衰减
- [ ] 衰减公式：`stacks -= (max(0, stacks - decay_start) / 100) ^ 1.15`
- [ ] `decay_exempt = true` 的效果（如 Frozen）不参与衰减
- [ ] 战斗伤害链正确串联 `combatMultiplier()`
- [ ] DOT 与玩家技能伤害走**同一条**伤害乘区链