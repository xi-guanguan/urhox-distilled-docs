# add_resource 伪代码

> 完整定义见 [core/02-resources.md § 统一入库](../../core/02-resources.md#统一入库)

## Python 风格伪代码

```python
def add_resource(
    resource_type: str,
    base_amount: float,
    apply_global: bool = True
) -> float:
    """Add resource with global multiplier pipeline."""
    if base_amount <= 0:
        return 0.0

    multiplier = global_multiplier(resource_type) if apply_global else 1.0
    final_amount = base_amount * multiplier

    state.resources[resource_type] += final_amount

    # Side effect: drive reset XP, stats, quests
    on_resource_added(resource_type, final_amount)

    return final_amount


def global_multiplier(resource_type: str) -> float:
    """Compute composite multiplier for resource type."""
    return typed_bonuses(resource_type) * bottleneck_bonuses(resource_type)


def typed_bonuses(resource_type: str) -> float:
    """Compute bonuses from permanent / collection / meta."""
    perm = product_of_linear_perms(resource_type) * product_of_compound_perms(resource_type)
    coll = 1 + sum_of_collections(resource_type)        # O8
    meta = product_of_meta_buildings(resource_type)
    return perm * coll * meta


def bottleneck_bonuses(resource_type: str) -> float:
    """Default 1.0; enable O5 to override."""
    if not o5_enabled:
        return 1.0
    return compute_bottleneck_bonus(resource_type)
```

## TypeScript 风格伪代码

```typescript
interface ResourceState {
  amount: number;
  unlocked: boolean;
}

interface GameState {
  resources: Record<string, ResourceState>;
  perms: Record<string, number>;     // permanent upgrade levels
  collections: Record<string, number>; // O8
  metaBuildings: Record<string, number>;
}

function addResource(
  state: GameState,
  type: string,
  baseAmount: number,
  applyGlobal: boolean = true
): number {
  if (baseAmount <= 0) return 0;

  const multiplier = applyGlobal ? globalMultiplier(state, type) : 1;
  const finalAmount = baseAmount * multiplier;

  state.resources[type].amount += finalAmount;
  onResourceAdded(state, type, finalAmount);

  return finalAmount;
}
```

## 调用约定

| 场景 | `apply_global` |
|------|---------------|
| 产线正常产出 | `true` |
| 购买赠送资源 | `false` |
| 任务奖励 | `false` |
| Reset Grant | `false` |
| 概率稀有掉落 | `true`（让 rarity_multiplier 也享受 global） |

## 集成点

```text
所有资源入账唯一入口（来自 core/02-resources.md）：

产线 tick / 点击 / 掉落 ──→ add_resource(type, amount, apply_global)
                              ├─ global_multiplier            # typed_bonuses × bottleneck(O5)
                              └─ on_resource_added(...)        # → 驱动 Reset XP / 统计 / 任务(O3)

# 上游：core/03-production-lines.md 的产线产出
# 下游：gain-xp.md（Reset XP）、O3 挑战进度、O10 里程碑
```

## 反模式

- 跳过 `on_resource_added` → Reset XP / 任务 / 统计丢失
- `apply_global=false` 用于产线 → 失去全局加成
- 直接修改 `state.resources[type]` 不经过此函数 → 旁路审计