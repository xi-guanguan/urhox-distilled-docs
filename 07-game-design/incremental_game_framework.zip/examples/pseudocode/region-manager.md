# 伪代码 · Region Manager（O11）

> **框架模块**：[optional/o11-multi-region.md](../../optional/o11-multi-region.md)
> **数据 Schema**：[schemas/multi-region.schema.json](../../schemas/multi-region.schema.json)
> **配置示例**：[examples/configs/example-multi-region.json](../configs/example-multi-region.json)

## Python 伪代码

```python
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class Region:
    id: str
    name: str
    unlock_gate: dict
    primary_resource: str
    production_lines: list[str]
    ui_panel: str
    totem_type: Optional[str] = None
    supervision_pct: float = 0.0

@dataclass
class GlobalMultiplier:
    id: str
    applies_to: list[str]
    scope: str  # "all" | "matching_resource" | "matching_region"
    formula: str  # 表达式字符串

class RegionManager:
    def __init__(self, regions_data: list[dict], globals_data: list[dict]):
        self.regions: dict[str, Region] = {
            r["id"]: Region(**r) for r in regions_data
        }
        self.unlocked: set[str] = set()
        self.supervision: dict[str, float] = {}        # region_id -> expires_at
        self.global_mults = [GlobalMultiplier(**g) for g in globals_data]

    def is_unlocked(self, region_id: str) -> bool:
        return region_id in self.unlocked

    def try_unlock(self, region_id: str, player_state: dict) -> bool:
        """检查是否满足 Gate 条件，满足则解锁。"""
        region = self.regions[region_id]
        if region_id in self.unlocked:
            return False

        gate = region.unlock_gate
        if "tower_level" in gate and player_state.get("tower_level", 0) < gate["tower_level"]:
            return False
        if "resources" in gate:
            for r, qty in gate["resources"].items():
                if player_state["resources"].get(r, 0) < qty:
                    return False
        if "broken_wall_level" in gate:
            if player_state.get("broken_wall_level", 0) < gate["broken_wall_level"]:
                return False
        if "prerequisite_region" in gate:
            if gate["prerequisite_region"] not in self.unlocked:
                return False

        self.unlocked.add(region_id)
        return True

    def supervision_click(self, region_id: str, duration: float = 0.2):
        """点击区域激活短时监督（O6 区域焦点）。"""
        if region_id not in self.unlocked:
            return
        self.supervision[region_id] = duration

    def tick_supervision(self, dt: float):
        now = 0.0
        for rid in list(self.supervision.keys()):
            self.supervision[rid] -= dt
            if self.supervision[rid] <= 0:
                del self.supervision[rid]

    def resource_multiplier(
        self, region_id: str, resource_id: str, player_state: dict
    ) -> float:
        """区域 + 资源 的最终乘区（含跨区域乘区）。"""
        if region_id not in self.unlocked:
            return 1.0

        region = self.regions[region_id]
        mult = 1.0

        # 1) 区域监督（O6 焦点）
        if region_id in self.supervision:
            mult *= 1 + region.supervision_pct / 100.0

        # 2) 跨区域乘区（全局）
        for gm in self.global_mults:
            if gm.scope == "all" or resource_id in gm.applies_to:
                level = player_state.get(f"{gm.id}_level", 0)
                # 这里只展示一个简单示例公式：
                if "*" in gm.applies_to or resource_id in gm.applies_to:
                    mult *= 1 + 0.05 * level   # 简化公式

        return mult

    def active_regions(self) -> list[str]:
        return list(self.unlocked)
```

## TypeScript 伪代码

```typescript
interface Region {
    id: string;
    name: string;
    unlock_gate: {
        tower_level?: number;
        resources?: Record<string, number>;
        broken_wall_level?: number;
        prerequisite_region?: string;
        achievement_id?: string;
    };
    primary_resource: string;
    production_lines: string[];
    ui_panel: string;
    totem_type?: string;
    supervision_pct: number;
}

interface GlobalMultiplier {
    id: string;
    applies_to: string[];   // ["*"] = all
    scope: "all" | "matching_resource" | "matching_region";
    formula: string;
}

class RegionManager {
    private regions = new Map<string, Region>();
    private unlocked = new Set<string>();
    private supervision = new Map<string, number>();
    private globals: GlobalMultiplier[];

    constructor(regionsData: Region[], globalsData: GlobalMultiplier[]) {
        regionsData.forEach(r => this.regions.set(r.id, r));
        this.globals = globalsData;
    }

    tryUnlock(regionId: string, player: PlayerState): boolean {
        if (this.unlocked.has(regionId)) return false;
        const r = this.regions.get(regionId);
        if (!r) return false;

        const g = r.unlock_gate;
        if (g.tower_level !== undefined && player.tower_level < g.tower_level) return false;
        if (g.resources) {
            for (const [res, qty] of Object.entries(g.resources)) {
                if ((player.resources[res] ?? 0) < qty) return false;
            }
        }
        if (g.broken_wall_level !== undefined
            && player.broken_wall_level < g.broken_wall_level) return false;
        if (g.prerequisite_region && !this.unlocked.has(g.prerequisite_region)) return false;

        this.unlocked.add(regionId);
        return true;
    }

    supervisionClick(regionId: string, duration: number = 0.2): void {
        if (!this.unlocked.has(regionId)) return;
        this.supervision.set(regionId, duration);
    }

    tickSupervision(dt: number): void {
        for (const [id, time] of this.supervision) {
            const next = time - dt;
            if (next <= 0) this.supervision.delete(id);
            else this.supervision.set(id, next);
        }
    }

    resourceMultiplier(regionId: string, resourceId: string, player: PlayerState): number {
        if (!this.unlocked.has(regionId)) return 1.0;
        const region = this.regions.get(regionId)!;
        let mult = 1.0;

        if (this.supervision.has(regionId)) {
            mult *= 1 + region.supervision_pct / 100;
        }

        for (const gm of this.globals) {
            const matches = gm.scope === "all"
                || gm.applies_to.includes(resourceId)
                || gm.applies_to.includes("*");
            if (matches) {
                const level = (player as any)[`${gm.id}_level`] ?? 0;
                mult *= 1 + 0.05 * level;     // 简化
            }
        }

        return mult;
    }

    activeRegions(): string[] {
        return Array.from(this.unlocked);
    }
}
```

## 集成点

```text
区域产出链（来自 core/03-production-lines.md）：

final_output(region, resource) =
    local_chain × regionManager.resourceMultiplier(region, resource, player)
                 ↑
                 ↑ 这里注入跨区域乘区 + 监督
```

## 验收清单

- [ ] 区域解锁 Gate 支持 tower_level / resources / broken_wall_level / prerequisite_region / achievement_id
- [ ] 区域点击激活 0.2s 监督
- [ ] 跨区域乘区走 `global_multipliers`，不在区域内部硬绑
- [ ] 活跃区域数 = 节奏旋钮（10-30 个区域时建议 ≤8 活跃）
- [ ] 区域独立 UI 面板 / 主资源 / 升级
- [ ] 监督加成与跨区域乘区走**乘法链**而非加法