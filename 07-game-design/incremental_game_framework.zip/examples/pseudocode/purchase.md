# purchase 伪代码

> 完整定义见 [core/04-upgrade-economy.md § 购买流程](../../core/04-upgrade-economy.md#购买流程)

## Python 风格伪代码

```python
def purchase(state: GameState, upgrade_id: str) -> bool:
    """
    Attempt to purchase a level increment of an upgrade.
    Returns True on success, False if can't afford.
    """
    upgrade = UPGRADES[upgrade_id]
    cost = get_cost(upgrade, state.levels[upgrade_id])

    if not can_afford(state, cost):
        return False

    pay(state, cost)
    state.levels[upgrade_id] += upgrade.level_increment
    emit_purchased(upgrade_id)

    if upgrade.grants_resource:
        add_resource(state, upgrade.grant_type, upgrade.grant_amount, apply_global=False)

    return True


def get_cost(upgrade: Upgrade, level: int) -> dict[str, float]:
    """Compute cost for current level based on curve type."""
    if upgrade.curve == "C1":   # Super-exponential
        if level == 1:
            return upgrade.c0
        return floor(
            upgrade.A + upgrade.B * level ** (upgrade.P + upgrade.Q * level ** upgrade.R)
        ) * upgrade.K
    elif upgrade.curve == "C2":  # Exponential / linear
        if upgrade.linear:
            return {upgrade.resource: upgrade.base + upgrade.k * level}
        return {upgrade.resource: upgrade.base * (upgrade.r ** level)}
    elif upgrade.curve == "C3":  # One-time
        return upgrade.fixed_cost
    elif upgrade.curve == "C4":  # Polynomial
        return {upgrade.resource: round(upgrade.base * (1 + level ** 2))}
    elif upgrade.curve == "C5":  # Tree depth
        return {"tree_currency": upgrade.depth * upgrade.coeff}
    elif upgrade.curve == "C6":  # Lookup gate
        return GATE_COSTS[(upgrade.from_tier, upgrade.to_tier)]
    raise ValueError(f"Unknown curve: {upgrade.curve}")
```

## Pattern T 跳跃（跳到最高级，如 8→10）

```python
def get_cost_tier_jump(upgrade: Upgrade, level: int) -> float:
    """Pattern T: tier jump for [1..8 + 10] upgrades (跳 8→10，跳过 9)."""
    if upgrade.tier_jump and level == 10:
        return get_cost(upgrade, 9) * upgrade.jump_multiplier
    return get_cost(upgrade, level)
```

## Pattern S 分类

```python
def classify_upgrade(upgrade: Upgrade) -> str:
    """Pattern S: assign tier ladder slot."""
    effect_per_level = upgrade.average_value_gain / get_cost(upgrade, 1)[upgrade.resource]
    if effect_per_level > THRESHOLD_HIGH:
        return "core"      # Pattern T 跳 10
    if effect_per_level > THRESHOLD_LOW:
        return "secondary" # 3-5 级
    return "toggle"        # Pattern B 1-2 级
```

## 集成点

```text
升级购买链（来自 core/04-upgrade-economy.md）：

UI 点击 ──→ purchase(upgrade)
              ├─ can_afford(cost)                    # 校验资源
              ├─ get_cost / get_cost_tier_jump       # C1-C6 + Pattern T
              ├─ deduct + apply_effect               # 扣费 + 生效
              └─ grants_resource(..., apply_global=False)  # 赠送资源走 add-resource.md

# 上游：core/04-upgrade-economy.md 成本曲线、pattern-t/pattern-s 分档
# 下游：add-resource.md（赠送资源）、O5 折扣（修饰 cost）
```

## 反模式

- 跳过 `can_afford` 检查 → 资源为负
- `grants_resource` 不传 `apply_global=False` → 全局加成重复
- `get_cost` 用浮点不 floor → 累积误差
- 跳跃 cost 用普通曲线 → 失去 Pattern T 意图