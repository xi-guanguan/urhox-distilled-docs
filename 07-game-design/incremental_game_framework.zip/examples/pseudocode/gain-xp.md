# gain_xp 伪代码

> 完整定义见 [core/05-reset-systems.md § 经验与升级](../../core/05-reset-systems.md#经验与升级)

## Python 风格伪代码

```python
def gain_xp(state: GameState, incoming: float) -> int:
    """
    Convert incoming XP into permanent points.
    Returns the number of permanent points awarded (0 or more).
    """
    xp = incoming

    while xp > 0:
        # Compute room until next level-up
        cap = compute_cap(state.meta_level)
        room = cap - state.run_xp_buffer

        if room <= 0:
            # Already at cap → instant level up
            state.run_xp_buffer = 0
            state.meta_level += 1
            state.run_points += 1
            continue

        # Fill room with available XP
        add = min(xp, room)
        state.run_xp_buffer += add
        xp -= add

        if state.run_xp_buffer >= cap:
            state.run_xp_buffer = 0
            state.meta_level += 1
            state.run_points += 1

    return state.run_points  # points earned this call


def compute_cap(meta_level: int) -> float:
    """Cap-1 mode: base × growth^level."""
    return CAP_BASE * CAP_GROWTH ** meta_level


def compute_cap_v2(meta_level: int) -> float:
    """Cap-2 mode: base × mult(level) × growth^(level^exp(level))."""
    mult = CAP_MULT_TABLE[meta_level]
    return CAP_BASE * mult * CAP_GROWTH ** (meta_level ** CAP_EXP)


# XP source hook
def on_resource_added(state: GameState, type: str, amount: float):
    if type == PRIMARY_RESOURCE:
        gain_xp(state, amount * XP_RATE)
    elif type == SECONDARY_RESOURCE:
        gain_xp(state, amount * XP_RATE_SECONDARY)
    # Pattern P-A / P-B / P-C: project decides which sources count
```

## Cap 模式

| 模式 | 公式 | 何时用 |
|------|------|-------|
| Cap-1 | `base × growth^level` | 简单线性指数（多数情况） |
| Cap-2 | `base × mult(level) × growth^(level^exp(level))` | 需阶段性突破 |
| Cap-3 | 低等级查表 + 高等级公式 | 项目早期需要特殊曲线 |

## XP 源 Pattern

| Pattern | 来源 | 典型权重 |
|---------|------|---------|
| P-A | 主资源入库 | 1.0× |
| P-B | 任意资源产出 | 0.5× ~ 1.0× |
| P-C | 里程碑（O1） | 固定值 |

## 集成点

```text
Reset XP 累积链（来自 core/05-reset-systems.md）：

add-resource.md::on_resource_added(type, amount)
        └─ gain_xp(state, amount × XP_RATE)        # ← 这里
                ├─ compute_cap(meta_level)          # cap 曲线
                └─ run_points += 1                  # 满 cap → 可花在永久商店

# 上游：add-resource.md（资源入账触发 XP）
# 下游：core/06-permanent-upgrades.md（run_points 购买永久项）、O2 终局进度条
```

## 反模式

- XP 来源未经过 `gain_xp` → 失去 cap 校验
- 跳过 `room` 检查 → 数值溢出
- Cap 公式与 Reset 点数不联动 → 后期失衡