# 伪代码 · resolve_inspiration（Pattern C·跨建筑 Inspiration 链）

> **框架模块**：[patterns/pattern-c-cross-building-inspiration.md](../../patterns/pattern-c-cross-building-inspiration.md)
> **数据 Schema**：[schemas/cross-building-inspiration.schema.json](../../schemas/cross-building-inspiration.schema.json)
> **配置示例**：[examples/configs/example-cross-building-inspiration.json](../configs/example-cross-building-inspiration.json)

跨建筑 inspiration 解析:源建筑达成条件 → 目标建筑单位获得增益。核心是把"互斥槽"(同 target 建筑选 1)和"可叠加链"(不同 source 累乘)分开处理。

## Python 伪代码

```python
from dataclasses import dataclass
from typing import Optional

@dataclass
class TriggerCondition:
    type: str                       # "unit_count" | "state_active" | "resource_owned"
    source_unit: Optional[str] = None
    flag: Optional[str] = None
    resource: Optional[str] = None
    value: float = 0

@dataclass
class Effect:
    stat: str                       # 被修改的属性
    op: str                         # "mul" | "add" | "mul_per" | "proc"
    value: float
    per_unit: Optional[str] = None  # op=mul_per 时累乘的单位
    cap: Optional[float] = None     # 累加上限(防爆炸)

@dataclass
class Inspiration:
    id: str
    source_building: str
    target_unit: str
    trigger_condition: TriggerCondition
    effect: Effect
    type: str = "passive"           # "passive" | "active"
    stackable: bool = False         # True=可叠加; False=同 target 建筑内互斥

class InspirationResolver:
    def __init__(self, inspirations: list[dict]):
        self.inspirations = [self._parse(i) for i in inspirations]
        # 玩家在每个 target 建筑的互斥槽选中的 inspiration id
        self.selected_exclusive: dict[str, str] = {}

    def _parse(self, d: dict) -> Inspiration:
        return Inspiration(
            id=d["id"],
            source_building=d["source_building"],
            target_unit=d["target_unit"],
            trigger_condition=TriggerCondition(**d["trigger_condition"]),
            effect=Effect(**d["effect"]),
            type=d.get("type", "passive"),
            stackable=d.get("stackable", False),
        )

    def check_trigger(self, insp: Inspiration, state) -> bool:
        """3 类触发条件判定。"""
        c = insp.trigger_condition
        if c.type == "unit_count":
            return state.unit_count(c.source_unit) >= c.value
        if c.type == "state_active":
            return state.is_active(c.flag)
        if c.type == "resource_owned":
            return state.resource(c.resource) >= c.value
        return False

    def apply_effect(self, eff: Effect, state) -> float:
        """把一个 effect 折算成乘区贡献(add/proc 也归一为乘区或单独累加)。"""
        if eff.op == "mul":
            return eff.value
        if eff.op == "add":
            return 1.0 + eff.value            # 调用方决定是否合并到加法池
        if eff.op == "mul_per":
            n = state.unit_count(eff.per_unit)
            total = eff.value * n
            if eff.cap is not None:
                total = min(total, eff.cap)
            return 1.0 + total
        if eff.op == "proc":
            # proc 不是乘区,写入触发概率池,这里返回中性 1.0
            state.add_proc(eff.stat, eff.value)
            return 1.0
        return 1.0

    def resolve(self, target_unit: str, state) -> float:
        """返回 target 单位的最终 inspiration 乘区。"""
        mult = 1.0

        # 1) 互斥槽:玩家选中的那个(若满足 trigger)
        sel_id = self.selected_exclusive.get(target_unit)
        if sel_id:
            sel = next((i for i in self.inspirations if i.id == sel_id), None)
            if sel and self.check_trigger(sel, state):
                mult *= self.apply_effect(sel.effect, state)

        # 2) 可叠加链:不同 source 发出的、stackable=True
        for insp in self.inspirations:
            if insp.target_unit != target_unit or not insp.stackable:
                continue
            if self.check_trigger(insp, state):
                mult *= self.apply_effect(insp.effect, state)

        return mult

    def select_exclusive(self, target_unit: str, inspiration_id: str):
        """玩家在某 target 建筑的互斥槽里选一个(点圆圈)。再次点同一个=取消。"""
        if self.selected_exclusive.get(target_unit) == inspiration_id:
            del self.selected_exclusive[target_unit]   # toggle off
        else:
            self.selected_exclusive[target_unit] = inspiration_id
```

## TypeScript 伪代码

```typescript
interface TriggerCondition {
    type: "unit_count" | "state_active" | "resource_owned";
    source_unit?: string;
    flag?: string;
    resource?: string;
    value?: number;
}

interface Effect {
    stat: string;
    op: "mul" | "add" | "mul_per" | "proc";
    value: number;
    per_unit?: string;
    cap?: number | null;
}

interface Inspiration {
    id: string;
    source_building: string;
    target_unit: string;
    trigger_condition: TriggerCondition;
    effect: Effect;
    type?: "passive" | "active";
    stackable?: boolean;
}

class InspirationResolver {
    private inspirations: Inspiration[];
    private selectedExclusive = new Map<string, string>();  // target_unit -> insp id

    constructor(inspirations: Inspiration[]) {
        this.inspirations = inspirations;
    }

    checkTrigger(insp: Inspiration, state: GameState): boolean {
        const c = insp.trigger_condition;
        switch (c.type) {
            case "unit_count":   return state.unitCount(c.source_unit!) >= (c.value ?? 0);
            case "state_active": return state.isActive(c.flag!);
            case "resource_owned": return state.resource(c.resource!) >= (c.value ?? 0);
        }
    }

    applyEffect(eff: Effect, state: GameState): number {
        switch (eff.op) {
            case "mul": return eff.value;
            case "add": return 1 + eff.value;
            case "mul_per": {
                const n = state.unitCount(eff.per_unit!);
                let total = eff.value * n;
                if (eff.cap != null) total = Math.min(total, eff.cap);
                return 1 + total;
            }
            case "proc": state.addProc(eff.stat, eff.value); return 1.0;
        }
    }

    resolve(targetUnit: string, state: GameState): number {
        let mult = 1.0;

        const selId = this.selectedExclusive.get(targetUnit);
        if (selId) {
            const sel = this.inspirations.find(i => i.id === selId);
            if (sel && this.checkTrigger(sel, state)) {
                mult *= this.applyEffect(sel.effect, state);
            }
        }

        for (const insp of this.inspirations) {
            if (insp.target_unit !== targetUnit || !insp.stackable) continue;
            if (this.checkTrigger(insp, state)) {
                mult *= this.applyEffect(insp.effect, state);
            }
        }

        return mult;
    }

    selectExclusive(targetUnit: string, inspirationId: string): void {
        if (this.selectedExclusive.get(targetUnit) === inspirationId) {
            this.selectedExclusive.delete(targetUnit);     // toggle off
        } else {
            this.selectedExclusive.set(targetUnit, inspirationId);
        }
    }
}
```

## 集成点

```text
单位产出链（来自 core/03-production-lines.md）：

unit_output = base_output
            × local_multiplier_chain                       # 产线局部乘区
            × inspirationResolver.resolve(unit_id, state)  # ← 这里(跨建筑增益)

# 也可挂在 O8 辅助系统的 typed_bonuses,或 O4 cross_axis
```

## 验收清单

- [ ] inspiration 为 4-tuple(source_building / target_unit / trigger_condition / effect)
- [ ] source_building 与 target 单位所属建筑不同(跨建筑)
- [ ] 3 类触发条件(unit_count / state_active / resource_owned)都可判定
- [ ] 互斥槽(stackable=false)每 target 建筑只生效 1 个
- [ ] 可叠加(stackable=true)按不同 source 累乘
- [ ] mul_per 型有 cap 防后期爆炸
- [ ] 未满足 trigger 的 inspiration 返回中性 1.0
- [ ] 互斥槽支持 toggle off(再次点同一个=取消)
