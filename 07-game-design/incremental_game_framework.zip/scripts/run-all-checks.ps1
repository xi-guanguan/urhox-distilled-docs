<#
.SYNOPSIS
    Run all consistency checks (schema / CHANGELOG sync / Markdown links).
.DESCRIPTION
    Any failing check exits with a non-zero code. Use locally before commit and in CI.
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts/run-all-checks.ps1
#>

# Make Python emit UTF-8 to avoid mojibake on Windows GBK consoles.
$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

$repoRoot = Split-Path -Parent $PSScriptRoot
Push-Location $repoRoot

$checks = @(
    @{ Name = "Schema and data consistency"; Cmd = "python scripts/validate-schemas.py" },
    @{ Name = "CHANGELOG sync invariants";    Cmd = "python scripts/verify-changelog.py" },
    @{ Name = "Markdown internal links";      Cmd = "python scripts/check-md-links.py" },
    @{ Name = "Case metadata sync";           Cmd = "python scripts/verify-case-metadata.py" },
    @{ Name = "Schema index freshness";       Cmd = "python scripts/build-schema-index.py --check" },
    @{ Name = "Case framework coverage";      Cmd = "python scripts/case-to-framework-coverage.py --check" },
    @{ Name = "CHANGELOG size guard";         Cmd = "python scripts/check-changelog-size.py --check" }
)

$failed = @()
foreach ($c in $checks) {
    Write-Host ""
    Write-Host "===== $($c.Name) =====" -ForegroundColor Cyan
    Invoke-Expression $c.Cmd
    if ($LASTEXITCODE -ne 0) {
        $failed += $c.Name
    }
}

Pop-Location

Write-Host ""
if ($failed.Count -gt 0) {
    Write-Host ("FAILED: " + ($failed -join ", ")) -ForegroundColor Red
    exit 1
}
Write-Host "ALL CHECKS PASSED" -ForegroundColor Green
exit 0
