#!/usr/bin/env python3
"""build-schema-index.py — 自动生成 schemas/README.md 的 Schema 索引表。

扫描 schemas/*.schema.json，重写 README 中 AUTO-GENERATED 标记段之间的表格。
可选 x-framework-ref 扩展字段填充「对应框架」列。

用法：
    python scripts/build-schema-index.py           # 写入 schemas/README.md
    python scripts/build-schema-index.py --check   # 只检查是否漂移（CI 用）

退出码：0 = 一致；1 = 漂移或未找到 marker。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
SCHEMAS_DIR = ROOT / "schemas"
README = SCHEMAS_DIR / "README.md"

START = "<!-- AUTO-GENERATED START -->"
END = "<!-- AUTO-GENERATED END -->"


def load_schema(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def build_table_rows() -> str:
    rows: list[str] = []
    rows.append("| Schema | 用途 | 对应框架 |")
    rows.append("|--------|------|---------|")

    for sf in sorted(SCHEMAS_DIR.glob("*.schema.json")):
        schema = load_schema(sf)
        title = schema.get("title") or sf.stem
        desc = schema.get("description") or ""
        fw_ref = schema.get("x-framework-ref") or "—"
        link = f"[{sf.name}]({sf.name})"
        rows.append(f"| {link} | {desc or title} | {fw_ref} |")

    return "\n".join(rows)


def replace_section(readme_text: str, new_table: str) -> str:
    if START not in readme_text or END not in readme_text:
        raise ValueError(f"schemas/README.md 缺少 {START} / {END} marker")
    before, rest = readme_text.split(START, 1)
    _, after = rest.split(END, 1)
    return f"{before}{START}\n\n{new_table}\n\n{END}{after}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="只检查索引是否最新")
    args = parser.parse_args()

    if not README.exists():
        print(f"缺少 {README}", file=sys.stderr)
        return 1

    new_table = build_table_rows()
    current = README.read_text(encoding="utf-8")

    try:
        updated = replace_section(current, new_table)
    except ValueError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1

    if args.check:
        if updated == current:
            print("[OK]   schemas/README.md 索引与 schema 文件一致")
            return 0
        print("[FAIL] schemas/README.md 索引已漂移，请运行: python scripts/build-schema-index.py")
        return 1

    README.write_text(updated, encoding="utf-8")
    print(f"已更新 {README.relative_to(ROOT)}（{len(list(SCHEMAS_DIR.glob('*.schema.json')))} 个 schema）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
