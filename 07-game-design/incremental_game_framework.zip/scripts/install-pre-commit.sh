#!/usr/bin/env bash
# Install a git pre-commit hook that runs framework consistency checks.
# Usage: bash scripts/install-pre-commit.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOOKS_DIR="$REPO_ROOT/.git/hooks"
HOOK_PATH="$HOOKS_DIR/pre-commit"

if [ ! -d "$REPO_ROOT/.git" ]; then
    echo "Not a git repository: $REPO_ROOT" >&2
    exit 1
fi

mkdir -p "$HOOKS_DIR"

cat > "$HOOK_PATH" << 'EOF'
#!/bin/sh
# incremental_game_framework pre-commit — run consistency checks before commit.
# Installed by scripts/install-pre-commit.ps1 or scripts/install-pre-commit.sh

REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT" || exit 1

if command -v pwsh >/dev/null 2>&1; then
    pwsh -NoProfile -ExecutionPolicy Bypass -File "$REPO_ROOT/scripts/run-all-checks.ps1"
elif command -v powershell >/dev/null 2>&1; then
    powershell -NoProfile -ExecutionPolicy Bypass -File "$REPO_ROOT/scripts/run-all-checks.ps1"
else
    echo "pre-commit: need pwsh or powershell to run scripts/run-all-checks.ps1" >&2
    exit 1
fi

if [ $? -ne 0 ]; then
    echo "pre-commit: consistency checks failed. Fix issues or skip with git commit --no-verify" >&2
    exit 1
fi
EOF

chmod +x "$HOOK_PATH"
echo "Installed pre-commit hook: $HOOK_PATH"
echo "Each commit will run scripts/run-all-checks.ps1 (use --no-verify to skip)."
