#!/usr/bin/env python3
"""validate-schemas.py — Schema 与数据一致性校验。

校验内容：
1. schemas/*.schema.json 自身是合法 Draft-07 schema
2. examples/configs/*.json 中带 $schema 的都能通过对应 schema
3. cases/<case>/mapping.json 结构合法（mappings 数组 + 每条必含字段）
4. cases/<case>/ 下的实体 JSON 都有 _source（可追溯），metadata.json 也有 _source
5. case data 不再残留 $schema（应走 mapping 桥接）

退出码：0 = 全通过；1 = 有失败。

依赖：pip install jsonschema
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

try:
    from jsonschema import Draft7Validator, SchemaError
except ImportError:
    print("缺少依赖：pip install jsonschema", file=sys.stderr)
    sys.exit(2)

ROOT = Path(__file__).resolve().parent.parent

# 不要求 _source 的 case data 文件（派生索引 / 纯结构索引）
SOURCE_EXEMPT = {
    "metadata.json",  # 单独检查（要求 _source）
}

problems: list[str] = []


def load(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def check_schemas_valid() -> dict[str, dict]:
    schemas: dict[str, dict] = {}
    print("--- 1. schema 自检 (Draft-07) ---")
    for sf in sorted((ROOT / "schemas").glob("*.schema.json")):
        try:
            schema = load(sf)
            Draft7Validator.check_schema(schema)
            schemas[sf.name] = schema
            print(f"  [OK]   {sf.name}")
        except (SchemaError, json.JSONDecodeError) as e:
            problems.append(f"schema 非法: {sf.name}: {e}")
            print(f"  [FAIL] {sf.name}: {e}")
    return schemas


def check_example_configs():
    print("\n--- 2. examples/configs/*.json 对 schema 校验 ---")
    for cf in sorted((ROOT / "examples" / "configs").glob("*.json")):
        cfg = load(cf)
        ref = cfg.get("$schema") if isinstance(cfg, dict) else None
        if not ref:
            print(f"  [skip] {cf.name}（无 $schema）")
            continue
        schema_path = (cf.parent / ref).resolve()
        if not schema_path.exists():
            problems.append(f"{cf.name} 的 $schema 指向不存在: {ref}")
            print(f"  [FAIL] {cf.name}: $schema 不存在 {ref}")
            continue
        schema = load(schema_path)
        errs = list(Draft7Validator(schema).iter_errors(cfg))
        if errs:
            for e in errs[:5]:
                loc = "/".join(str(x) for x in e.absolute_path) or "(root)"
                problems.append(f"{cf.name} @ {loc}: {e.message}")
            print(f"  [FAIL] {cf.name}（{len(errs)} 处）")
        else:
            print(f"  [OK]   {cf.name} -> {Path(ref).name}")


def check_mappings():
    print("\n--- 3. cases/<case>/mapping.json 结构 ---")
    found = False
    for mf in sorted((ROOT / "cases").glob("*/mapping.json")):
        found = True
        m = load(mf)
        rel = mf.relative_to(ROOT)
        if not isinstance(m, dict) or "mappings" not in m or not isinstance(m["mappings"], list):
            problems.append(f"{rel}: 缺 mappings 数组")
            print(f"  [FAIL] {rel}: 缺 mappings 数组")
            continue
        bad = False
        for i, entry in enumerate(m["mappings"]):
            for key in ("data_file", "framework_schema"):
                if key not in entry:
                    problems.append(f"{rel} mappings[{i}]: 缺 {key}")
                    bad = True
        print(f"  [{'FAIL' if bad else 'OK'}]   {rel}（{len(m['mappings'])} 条）")
    if not found:
        print("  [warn] 未找到任何 mapping.json")


def check_case_data_meta():
    print("\n--- 4. 每个 case 的 metadata.json 含 _source（追溯权威源）---")
    for case_dir in sorted((ROOT / "cases").iterdir()):
        if not case_dir.is_dir():
            continue
        meta = case_dir / "metadata.json"
        rel = meta.relative_to(ROOT)
        if not meta.exists():
            problems.append(f"{case_dir.name}: 缺 metadata.json")
            print(f"  [FAIL] {case_dir.name}: 缺 metadata.json")
            continue
        data = load(meta)
        if "_source" not in data:
            problems.append(f"{rel}: metadata 缺 _source")
            print(f"  [FAIL] {rel}: 缺 _source")
        else:
            print(f"  [OK]   {case_dir.name}/metadata.json")

    print("\n--- 5. case data：顶层 dict、无 $schema、JSON 合法 ---")
    n_files = 0
    n_no_source = 0
    for jf in sorted((ROOT / "cases").rglob("*.json")):
        if "derived" in jf.parts:
            continue
        rel = jf.relative_to(ROOT)
        try:
            data = load(jf)
        except json.JSONDecodeError as e:
            problems.append(f"{rel}: JSON 解析失败 {e}")
            print(f"  [FAIL] {rel}: 解析失败")
            continue
        if not isinstance(data, dict):
            problems.append(f"{rel}: 顶层应为 dict 包装，不能是 {type(data).__name__}")
            print(f"  [FAIL] {rel}: 顶层非 dict")
            continue
        if "$schema" in data:
            problems.append(f"{rel}: case data 不应含 $schema（应走 mapping 桥接）")
            print(f"  [FAIL] {rel}: 残留 $schema")
            continue
        n_files += 1
        if jf.name not in ("mapping.json", "metadata.json") and "_source" not in data:
            n_no_source += 1
    print(f"  [OK]   {n_files} 个 case data 文件均为 dict 顶层且无 $schema")
    if n_no_source:
        # 软建议：不阻断 CI（case 级 _source 由 metadata.json 提供）
        print(f"  [info] {n_no_source} 个文件无 per-file _source（可追溯到 case metadata.json，建议但不强制）")


def main() -> int:
    schemas = check_schemas_valid()
    check_example_configs()
    check_mappings()
    check_case_data_meta()

    print("\n=== 汇总 ===")
    if problems:
        print(f"校验失败：共 {len(problems)} 处问题")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
