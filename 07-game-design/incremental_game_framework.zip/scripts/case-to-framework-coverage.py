#!/usr/bin/env python3
"""case-to-framework-coverage.py — 自动生成 case 的 framework 覆盖度报告.

读 cases/<case>/ 的 mapping.json + README.md § 核心系统 + metadata.json →
对照 framework 现有 pattern/optional/schema 索引 → 输出 4 类覆盖标记 (✅/🆕/⚠️/❌).

附加检查 (P2 阶段新增):
  1. Pattern reverse-link 完整性: 每个 pattern 文档 header 标注的"来源 case"是否
     在该 case 的 README 中被反向引用 (代号/全名/文件名)
  2. Candidate for contribution: 累计所有 case 的 🆕/⚠️ system, 推到
     docs/case-to-framework-contribute.md 的"阶段 3 候选清单"

用法:
    python scripts/case-to-framework-coverage.py            # 全部 case
    python scripts/case-to-framework-coverage.py agrivore   # 单个 case
    python scripts/case-to-framework-coverage.py --check    # CI 模式: 报告与上次一致才退出 0

退出码: 0 = 一致 / 1 = 漂移或 --check 失败 / 2 = 输入错误.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
CASES = ROOT / "cases"
DOCS = ROOT / "docs"

H1_RE = re.compile(r"^#\s+[^#]")
FENCE_RE = re.compile(r"^\s*```")


def strip_fences(text: str) -> str:
    out: list[str] = []
    in_fence = False
    for line in text.splitlines():
        if FENCE_RE.match(line):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def load_framework_index() -> dict[str, set[str]]:
    """读 patterns/optional/schemas 索引, 返回 {framework_concept_id: {case_hits}}."""
    index: dict[str, set[str]] = {
        "pattern": set(),
        "optional": set(),
        "schema": set(),
    }

    pat_dir = ROOT / "patterns"
    if pat_dir.exists():
        for f in pat_dir.glob("pattern-*.md"):
            m = re.match(r"pattern-([a-zA-Z0-9]+?)-", f.name)
            if m:
                token = m.group(1).upper()
                if token and token[0].isalpha():
                    index["pattern"].add(token)

    opt_dir = ROOT / "optional"
    if opt_dir.exists():
        for f in opt_dir.glob("o*.md"):
            m = re.match(r"o(\d+)-", f.name)
            if m:
                index["optional"].add(f"O{m.group(1)}")

    schema_dir = ROOT / "schemas"
    if schema_dir.exists():
        for f in schema_dir.glob("*.schema.json"):
            stem = f.stem
            if stem.endswith(".schema"):
                stem = stem[:-len(".schema")]
            index["schema"].add(stem)

    return index


def is_optional_reference_only() -> set[str]:
    """检测哪些 optional 当前标记为'参考形态/无实证'."""
    result: set[str] = set()
    opt_readme = ROOT / "optional" / "README.md"
    if opt_readme.exists():
        text = opt_readme.read_text(encoding="utf-8")
        for m in re.finditer(r"\|\s*(O\d+)\s*\|.*?(无实证|参考形态)", text):
            result.add(m.group(1))
    opt_dir = ROOT / "optional"
    if opt_dir.exists():
        for f in opt_dir.glob("o*.md"):
            text = f.read_text(encoding="utf-8")
            if "无实证" in text and "参考形态" in text:
                m = re.match(r"o(\d+)-", f.name)
                if m:
                    result.add(f"O{m.group(1)}")
    return result


def classify_system(sys_name: str, mapping_schemas: list[str], fw_index: dict[str, set[str]], ref_only_optionals: set[str]) -> tuple[str, str]:
    """对单个 system 给出 4 类覆盖标记.

    Returns: (mark, detail)
        mark ∈ {"✅", "🆕", "⚠️", "❌"}
    """
    if not mapping_schemas:
        return "🆕", "无对应 framework schema (README 章节, 待评估)"

    real = []
    missing = []
    for s in mapping_schemas:
        s_norm = s.replace(".schema.json", "").strip()
        s_base = s_norm.split("/")[-1] if "/" in s_norm else s_norm

        s_optional_match = re.match(r"(O\d+)", s_base)
        if s_optional_match and s_optional_match.group(1) in ref_only_optionals:
            missing.append(f"{s_base} (参考形态/无实证)")
            continue

        if s_base in fw_index["schema"]:
            real.append(s_base)
        else:
            missing.append(s_base)

    if real and not missing:
        return "✅", f"已映射到 {len(real)} 个 schema: {', '.join(real)}"
    if missing and not real:
        return "⚠️", f"映射不充分: {', '.join(missing)}"
    if real and missing:
        return "⚠️", f"部分有实证 ({', '.join(real)}) + 部分为参考形态 ({', '.join(missing)})"

    return "❌", f"映射目标不在 framework: {', '.join(mapping_schemas)}"


def extract_case_systems(case_dir: Path) -> list[dict]:
    """从 case 的 mapping.json + README + metadata.json 提取所有 system."""
    systems: list[dict] = []
    seen_ids: set[str] = set()

    mapping_file = case_dir / "mapping.json"
    if mapping_file.exists():
        try:
            m_data = json.loads(mapping_file.read_text(encoding="utf-8"))
            for entry in m_data.get("mappings", []):
                data_file = entry.get("data_file", "?")
                fw_schema = entry.get("framework_schema", "")
                wrapper = entry.get("wrapper_key", "")
                sys_id = data_file.replace(".json", "")
                if sys_id in seen_ids:
                    continue
                seen_ids.add(sys_id)
                systems.append({
                    "id": sys_id,
                    "name": f"{sys_id} ({wrapper})" if wrapper else sys_id,
                    "framework_schemas": [fw_schema] if fw_schema else [],
                    "source": "mapping.json",
                })
        except Exception as e:
            print(f"  [warn] {case_dir.name}/mapping.json 解析失败: {e}", file=sys.stderr)

    readme = case_dir / "README.md"
    if readme.exists():
        text = strip_fences(readme.read_text(encoding="utf-8"))

        SKIP_PATTERNS = (
            "数据完整性", "完整性", "提取方法", "引用", "致谢",
            "framework", "Framework", "反模式", "工具",
            "覆盖度", "自检", "映射总览", "整合进框架",
            "游戏概述", "概述", "规模概览", "核心系统",
            "Project ", "Prerequisites", "Installation", "Usage",
            "落地 Checklist", "工程化", "交付清单", "数据来源",
            "Epilogue", "可信度", "核心循环", "NEW Pattern",
        )

        for m in re.finditer(r"^##\s+(\d+\.?\s+)?([^\n]+?)\s*$", text, re.MULTILINE):
            section_name = m.group(2).strip()
            if not section_name:
                continue
            if any(skip in section_name for skip in SKIP_PATTERNS):
                continue
            if len(section_name) > 60:
                continue
            if not re.search(r"[\u4e00-\u9fff]", section_name) and len(section_name.split()) < 2:
                continue
            sys_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", section_name.lower())[:50]
            if sys_id in seen_ids:
                continue
            seen_ids.add(sys_id)
            systems.append({
                "id": sys_id,
                "name": section_name,
                "framework_schemas": [],
                "source": "README.md § 章节",
            })

    return systems


def parse_pattern_source_claim(pattern_path: Path) -> str | None:
    """从 pattern 文档 header 解析"来源 case"声明.

    期望格式: > **来源**: ... [cases/<name>/README.md ...] ...
    返回 case name (str) 或 None.
    """
    if not pattern_path.exists():
        return None
    text = pattern_path.read_text(encoding="utf-8")
    for line in text.splitlines()[:20]:  # 限制在 header 范围
        m = re.search(r"cases/([a-z0-9-]+)/README\.md", line)
        if m:
            return m.group(1)
    return None


def build_pattern_reverse_index() -> dict[str, list[tuple[str, str]]]:
    """建立 case → [(pattern_short, pattern_path)] 反向索引.

    pattern_short = 简称 (P-AME, P-R, ...) 用于 case README 匹配.
    """
    result: dict[str, list[tuple[str, str]]] = {}
    pat_dir = ROOT / "patterns"
    if not pat_dir.exists():
        return result

    for pf in pat_dir.glob("pattern-*.md"):
        m_short = re.match(r"pattern-([a-zA-Z0-9]+?)-", pf.name)
        if not m_short:
            continue
        token = m_short.group(1).upper()
        if not token or not token[0].isalpha():
            continue
        case_name = parse_pattern_source_claim(pf)
        if not case_name:
            continue
        result.setdefault(case_name, []).append((token, pf.name))

    return result


def check_pattern_reverse_link(case_dir: Path) -> dict:
    """检查 case 的 pattern reverse-link 完整性.

    Returns:
        {
            "claimed": [(pattern_token, "ok"|"missing"), ...],   # pattern 声明本 case 是来源
            "missing": [pattern_token, ...]                       # case README 引用了但 pattern 未声明
        }
    """
    reverse_index = build_pattern_reverse_index()
    case_name = case_dir.name
    claimed = reverse_index.get(case_name, [])

    readme_path = case_dir / "README.md"
    if not readme_path.exists():
        return {"claimed": [(t, "missing") for t, _ in claimed], "missing": []}
    readme_text = readme_path.read_text(encoding="utf-8").lower()

    result_claimed = []
    for token, pfname in claimed:
        token_lower = token.lower()
        # 多种匹配方式: 简称 (P-AME), pattern 全名, 文件名
        in_readme = (
            token in readme_text  # 简称 "AME" / "N" / "PR" / "P2" / "C7"
            or token_lower in readme_text  # 小写
            or f"pattern-{pfname.replace('pattern-', '').replace('.md', '')}" in readme_text
            or f"p-{token_lower}" in readme_text  # P-AME 形式
            or f"p-{token}" in readme_text  # P-AME 形式
        )
        result_claimed.append((token, "ok" if in_readme else "missing"))

    return {"claimed": result_claimed, "missing": []}


NAMED_CANDIDATE_RE = re.compile(
    r"(?:framework\s+候选\s*|候选\s*|framework\s+应记[^。\n]*?)(O1[4-9]|O[2-9]\d)\s*(?:\(([^)]+)\))?",
    re.IGNORECASE,
)
FRAMEWORK_CANDIDATE_RE = re.compile(
    r"framework\s+应记[^。\n]*?((O1[4-9]|O[2-9]\d)[^。\n]*)",
    re.IGNORECASE,
)


def extract_named_candidates(case_dir: Path) -> list[dict]:
    """从 case README / metadata 提取显式命名的 framework 候选 (O14 等)."""
    found: list[dict] = []
    seen: set[str] = set()

    readme = case_dir / "README.md"
    if readme.exists():
        text = readme.read_text(encoding="utf-8")
        for m in NAMED_CANDIDATE_RE.finditer(text):
            oid = m.group(1).upper()
            if oid in seen:
                continue
            seen.add(oid)
            line_start = text.rfind("\n", 0, m.start()) + 1
            line_end = text.find("\n", m.start())
            line = text[line_start:line_end if line_end != -1 else None].strip()
            label = m.group(2).strip() if m.group(2) else oid
            found.append({
                "id": oid,
                "label": label,
                "source_line": line[:120],
                "source": "README.md",
            })
        for m in FRAMEWORK_CANDIDATE_RE.finditer(text):
            oid = m.group(2).upper()
            if oid in seen:
                continue
            seen.add(oid)
            snippet = m.group(1).strip()
            found.append({
                "id": oid,
                "label": snippet[:80],
                "source_line": snippet[:120],
                "source": "README.md (framework 应记)",
            })

    meta = case_dir / "metadata.json"
    if meta.exists():
        try:
            data = json.loads(meta.read_text(encoding="utf-8"))
            for item in data.get("framework_candidates", []):
                oid = str(item.get("id", "")).upper()
                if not oid or oid in seen:
                    continue
                seen.add(oid)
                found.append({
                    "id": oid,
                    "label": item.get("name", oid),
                    "decision": item.get("decision"),
                    "reason": item.get("reason"),
                    "source": "metadata.json",
                })
        except Exception:
            pass

    return found


def load_candidate_decisions(case_dir: Path) -> dict[str, dict]:
    """读 cases/<case>/derived/candidates.md 中已记录的决策 (若有)."""
    path = case_dir / "derived" / "candidates.md"
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8")
    decisions: dict[str, dict] = {}
    current_id: str | None = None
    for line in text.splitlines():
        m = re.match(r"^##\s+候选\s+\d+:\s*(.+)$", line)
        if m:
            oid_m = re.search(r"\b(O1[4-9]|O[2-9]\d)\b", m.group(1))
            current_id = oid_m.group(1).upper() if oid_m else None
            if current_id:
                decisions[current_id] = {}
            continue
        if current_id and line.startswith("- **决策**:"):
            decisions[current_id]["decision"] = line.split(":", 1)[1].strip().strip("*")
        if current_id and line.startswith("- **理由**:"):
            decisions[current_id]["reason"] = line.split(":", 1)[1].strip()
    return decisions


def audit_reverse_links_all_cases() -> list[tuple[str, str, str]]:
    """扫描所有含 README 的 case, 返回 [(case, pattern_token, pattern_file), ...] 缺失项."""
    missing: list[tuple[str, str, str]] = []
    reverse_index = build_pattern_reverse_index()
    for case_dir in sorted(CASES.iterdir()):
        if not case_dir.is_dir() or not (case_dir / "README.md").exists():
            continue
        result = check_pattern_reverse_link(case_dir)
        for token, status in result["claimed"]:
            if status != "ok":
                pf = next((f for t, f in reverse_index.get(case_dir.name, []) if t == token), "?")
                missing.append((case_dir.name, token, pf))
    return missing


def list_case_dirs_with_mapping(case_names: list[str] | None = None) -> list[Path]:
    """有 mapping.json 的 case (完整 coverage 报告)."""
    if case_names:
        return [CASES / c for c in case_names]
    return sorted(p for p in CASES.iterdir() if p.is_dir() and (p / "mapping.json").exists())


def list_case_dirs_with_readme(case_names: list[str] | None = None) -> list[Path]:
    """有 README.md 的 case (reverse-link 检查)."""
    if case_names:
        return [CASES / c for c in case_names]
    return sorted(p for p in CASES.iterdir() if p.is_dir() and (p / "README.md").exists())


def collect_candidate_contributions(case_dirs: list[Path]) -> list[dict]:
    """汇总所有 case 的 🆕/⚠️ system 作为候选贡献.

    Returns: [{"case": str, "system": str, "mark": str, "detail": str}, ...]
    """
    fw_index = load_framework_index()
    ref_only = is_optional_reference_only()
    candidates = []
    for case_dir in case_dirs:
        systems = extract_case_systems(case_dir)
        for sys in systems:
            mark, detail = classify_system(sys["name"], sys["framework_schemas"], fw_index, ref_only)
            if mark in ("🆕", "⚠️"):
                candidates.append({
                    "case": case_dir.name,
                    "system": sys["name"],
                    "mark": mark,
                    "detail": detail,
                    "source": sys["source"],
                })
    return candidates


def generate_candidate_index_md(case_dirs: list[Path]) -> str:
    """生成 docs/case-candidates.md 候选贡献索引."""
    candidates = collect_candidate_contributions(case_dirs)

    # 命名候选 (O14 等) — 跨所有 case
    all_readme_cases = list_case_dirs_with_readme()
    named: list[dict] = []
    for case_dir in all_readme_cases:
        decisions = load_candidate_decisions(case_dir)
        for item in extract_named_candidates(case_dir):
            oid = item["id"]
            dec = decisions.get(oid, {})
            named.append({
                "case": case_dir.name,
                "id": oid,
                "label": item.get("label", oid),
                "source": item.get("source", "?"),
                "decision": item.get("decision") or dec.get("decision"),
                "reason": item.get("reason") or dec.get("reason"),
            })

    lines = [
        "# Case → Framework 候选贡献索引",
        "",
        "> 由 `scripts/case-to-framework-coverage.py` 自动生成。",
        "> 每次跑脚本都会刷新本文件。",
        f"> 累计 {len(candidates)} 个自动检测候选 + {len(named)} 个命名候选。",
        "",
    ]

    if named:
        lines.extend([
            "## 命名候选 (Named Candidates — 需阶段 4 决策)",
            "",
            "case README 或 `derived/candidates.md` 中显式提出的 O14+ / Pattern 候选。",
            "",
            "| Case | ID | 描述 | 决策 | 理由 |",
            "|------|-----|------|------|------|",
        ])
        for n in named:
            decision = n.get("decision") or "⏳ 待评估"
            reason = (n.get("reason") or "—")[:80]
            label = str(n.get("label", n["id"]))[:50]
            lines.append(
                f"| [{n['case']}](../cases/{n['case']}/README.md) | **{n['id']}** | {label} | {decision} | {reason} |"
            )
        lines.append("")

    lines.extend([
        "## 自动候选 (按 case 分组 — coverage 🆕/⚠️)",
        "",
    ])

    by_case: dict[str, list[dict]] = {}
    for c in candidates:
        by_case.setdefault(c["case"], []).append(c)

    for case_name in sorted(by_case):
        case_cands = by_case[case_name]
        lines.append(f"### [{case_name}](../cases/{case_name}/README.md) ({len(case_cands)} 候选)")
        lines.append("")
        for c in case_cands:
            lines.append(f"- {c['mark']} **{c['system']}** ({c['source']}) — {c['detail']}")
        lines.append("")

    lines.extend([
        "## 下一步",
        "",
        "1. 对每个候选 system 跑 [case-to-framework-contribute.md § 阶段 4 决策矩阵](case-to-framework-contribute.md#6-阶段-4-决策矩阵)",
        "2. 决策为'沉淀'的 → 进入 [阶段 5 执行](case-to-framework-contribute.md#7-阶段-5-执行沉淀)",
        "3. 决策为'不沉淀'的 → 在 case README 的 system 段加 `framework_evidence: intentionally-not-contributed` 标注",
        "",
        "## 触发评估的阈值",
        "",
        "| 指标 | 阈值 | 含义 |",
        "|------|------|------|",
        "| 同一 system 出现在 ≥ 2 个 case | 必评估 | 强通用信号 |",
        "| 同一 system 出现在 ≥ 3 个 case | 必沉淀 | 重复损失 > 沉淀成本 |",
        "| 单一 case 独有 system | 可选 | 需要 `framework_evidence` 标注 |",
        "",
    ])

    return "\n".join(lines)


def generate_report(case_dir: Path, fw_index: dict[str, set[str]]) -> str:
    """生成单个 case 的覆盖度报告."""
    systems = extract_case_systems(case_dir)
    ref_only = is_optional_reference_only()
    reverse_link = check_pattern_reverse_link(case_dir)

    schema_usage: dict[str, int] = {}
    classified = []
    for sys in systems:
        mark, detail = classify_system(sys["name"], sys["framework_schemas"], fw_index, ref_only)
        for s in sys["framework_schemas"]:
            s_norm = s.replace(".schema.json", "").strip()
            s_base = s_norm.split("/")[-1] if "/" in s_norm else s_norm
            schema_usage[s_base] = schema_usage.get(s_base, 0) + 1
        classified.append((sys, mark, detail))

    lossy = [s for s, c in schema_usage.items() if c >= 3]

    lines = [
        f"# {case_dir.name} · framework 覆盖度报告",
        "",
        f"> 由 `scripts/case-to-framework-coverage.py` 自动生成.",
        f"> 4 类标记: ✅ 已覆盖 / 🆕 未覆盖 (新) / ⚠️ 部分覆盖 / ❌ 不适用 (case 独有)",
        f"> 共 {len(systems)} 个 system.",
        "",
        "| Case System | Framework 覆盖 | 备注 |",
        "|------------|--------------|------|",
    ]

    counts = {"✅": 0, "🆕": 0, "⚠️": 0, "❌": 0}
    for sys, mark, detail in classified:
        counts[mark] += 1
        lines.append(f"| {sys['name']} | {mark} | {detail} |")

    lines.extend([
        "",
        "## 统计",
        "",
        f"- ✅ 已覆盖: **{counts['✅']}**",
        f"- 🆕 未覆盖 (新): **{counts['🆕']}**",
        f"- ⚠️ 部分覆盖: **{counts['⚠️']}**",
        f"- ❌ 不适用: **{counts['❌']}**",
        "",
    ])

    if lossy:
        lines.extend([
            "## ⚠️ 框架映射过载提示 (Lossy Mapping)",
            "",
            "以下 framework 概念被 ≥ 3 个不同 case system 复用 — 暗示该概念太宽, 需新 pattern:",
            "",
        ])
        for s in lossy:
            lines.append(f"- `{s}` 被 {schema_usage[s]} 个 case system 复用")
        lines.append("")

    if reverse_link["claimed"] or reverse_link["missing"]:
        lines.extend([
            "## 🔗 Pattern Reverse-Link 完整性 (P2 检查)",
            "",
            "每个 pattern 文档在 header 标注的『来源 case』应在 case README 中被反向引用。",
            "正向声明 (pattern → case) 和反向引用 (case → pattern) 都齐全才算闭环。",
            "",
        ])
        if reverse_link["claimed"]:
            lines.extend([
                f"**本 case 贡献的 Pattern** ({len(reverse_link['claimed'])} 个):",
                "",
            ])
            for pname, status in reverse_link["claimed"]:
                mark = "✅" if status == "ok" else "❌"
                lines.append(f"- {mark} `{pname}` — {('已在 case README 中引用' if status == 'ok' else 'MISSING: case README 未引用此 pattern')}")
            lines.append("")
        if reverse_link["missing"]:
            lines.extend([
                f"**反向引用但未在 pattern header 声明** ({len(reverse_link['missing'])} 个, 通常 OK — case 引用多个 pattern):",
                "",
            ])
            for pname in reverse_link["missing"]:
                lines.append(f"- ℹ️ `{pname}`")
            lines.append("")

    if counts["🆕"] > 0 or counts["⚠️"] > 0:
        lines.extend([
            "## 🆕 候选贡献 (Candidate for Contribution)",
            "",
            "以下 case system 未被 framework schema 充分覆盖, 是沉淀新 pattern/optional 的候选:",
            "",
        ])
        for sys, mark, detail in classified:
            if mark in ("🆕", "⚠️"):
                lines.append(f"- {mark} **{sys['name']}** ({sys['source']}) — {detail}")
        lines.append("")
        lines.append("→ 触发 [case-to-framework-contribute.md § 阶段 3 候选贡献清单](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的评估")
        lines.append("")

    lines.extend([
        "## 进入 [case-to-framework-contribute.md § 阶段 3](../../../docs/case-to-framework-contribute.md#5-阶段-3-候选贡献清单) 的条件",
        "",
        f"- 🆕 数: **{counts['🆕']}**" + (" (≥ 1: 必进入)" if counts["🆕"] >= 1 else " (< 1: 可跳过)"),
        f"- ⚠️ 数: **{counts['⚠️']}**" + (" (≥ 2: 必进入)" if counts["⚠️"] >= 2 else " (< 2: 可跳过)"),
        f"- 🔗 Reverse-link 缺失: **{sum(1 for _, s in reverse_link['claimed'] if s != 'ok')}**" + (" (≥ 1: 修复后再合并)" if sum(1 for _, s in reverse_link["claimed"] if s != "ok") >= 1 else ""),
        "",
    ])

    return "\n".join(lines)


def process_case(case_dir: Path, fw_index: dict[str, set[str]], check: bool = False) -> bool:
    """处理单个 case. Returns True if pass (or not in --check mode)."""
    out_path = case_dir / "derived" / "coverage-report.md"
    report = generate_report(case_dir, fw_index)

    if check and out_path.exists():
        existing = out_path.read_text(encoding="utf-8")
        if existing.strip() == report.strip():
            print(f"  [OK]   {case_dir.name}")
            return True
        else:
            print(f"  [FAIL] {case_dir.name} (报告漂移, 请先跑不带 --check 更新)")
            return False

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(report, encoding="utf-8")
    sys_total = sum(1 for line in report.splitlines() if line.startswith("| ") and "Case System" not in line and "---" not in line)
    print(f"  [gen]  {case_dir.name} -> derived/coverage-report.md ({sys_total} systems)")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="case framework 覆盖度报告")
    parser.add_argument("cases", nargs="*", help="case 名 (留空 = 全部)")
    parser.add_argument("--check", action="store_true", help="CI 模式: 报告与上次一致 + reverse-link 完整才退出 0")
    args = parser.parse_args()

    fw_index = load_framework_index()
    case_dirs = list_case_dirs_with_mapping(args.cases or None)

    if not case_dirs and not args.cases:
        print("[warn] 未找到任何含 mapping.json 的 case 目录", file=sys.stderr)

    print(f"=== Case → Framework 覆盖度报告 ===\n")
    print(f"Framework 索引: {len(fw_index['pattern'])} pattern, {len(fw_index['optional'])} optional, {len(fw_index['schema'])} schema\n")

    all_pass = True
    for case_dir in case_dirs:
        if not case_dir.is_dir():
            print(f"  [warn] 无此 case 目录: {case_dir.name}")
            all_pass = False
            continue
        if not process_case(case_dir, fw_index, args.check):
            all_pass = False

    # Reverse-link 审计 (所有含 README 的 case, 含 upload-labs / kittens-game)
    rl_missing = audit_reverse_links_all_cases()
    readme_cases = list_case_dirs_with_readme(args.cases or None)
    claimed_total = sum(len(build_pattern_reverse_index().get(c.name, [])) for c in readme_cases)

    print(f"\n=== Pattern Reverse-Link 审计 ({claimed_total} 个正向声明) ===\n")
    if rl_missing:
        for case_name, token, pf in rl_missing:
            print(f"  [FAIL] {case_name}: pattern-{token} ({pf}) — case README 未反向引用")
        if args.check:
            all_pass = False
    else:
        print("  [OK]   所有 pattern 来源 case 均在 README 中被反向引用")

    if not args.check and case_dirs:
        candidate_md = generate_candidate_index_md(case_dirs)
        candidate_path = DOCS / "case-candidates.md"
        candidate_path.write_text(candidate_md, encoding="utf-8")
        candidates = collect_candidate_contributions(case_dirs)
        named_count = sum(len(extract_named_candidates(c)) for c in list_case_dirs_with_readme())
        print(f"\n  [gen]  docs/case-candidates.md ({len(candidates)} auto + {named_count} named)")

    print()
    if args.check:
        if all_pass:
            print("CI 模式: 覆盖度报告一致 + reverse-link 完整")
            return 0
        print("CI 模式: 覆盖度漂移或 reverse-link 缺失")
        return 1
    if case_dirs:
        print("完成 (报告已写入 cases/<case>/derived/coverage-report.md + docs/case-candidates.md)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
