#!/usr/bin/env python3
"""verify-case-metadata.py — 案例 metadata.json ↔ README.md 头部元信息同步校验。

校验 cases/<case>/metadata.json 与 cases/<case>/README.md 头部区域一致：
- A. 字段对齐：title / engine / data_source 字符串须在 README 头部出现
- B. 引用闭环：metadata._source 须在 README 中出现
- C. 规模双向一致：metadata 顶层 int 字段（>1）须在 README 头部出现相同数字

README 头部 = 文件开头至首个 ## 一级标题（不含）或前 120 行（取较短者）。
跳过围栏代码块内的内容（与 check-md-links 一致）。

用法：
    python scripts/verify-case-metadata.py
    python scripts/verify-case-metadata.py --first-run   # 只 warn，退出码 0

退出码：0 = 通过；1 = 有违反（--first-run 时违反也只 warn）。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
CASES = ROOT / "cases"

FENCE_RE = re.compile(r"^\s*```")
H1_RE = re.compile(r"^#\s+[^#]")

STRING_KEYS = ("title", "engine", "data_source")
INT_KEYS_MIN = 2  # 只校验 >= 2 的 int，避免 steam_app_id=0 等边缘值
INT_EXCLUDE = frozenset({"install_size_mb", "steam_app_id"})


def strip_fences(text: str) -> str:
    """去掉围栏代码块内容，保留其余文本。"""
    out: list[str] = []
    in_fence = False
    for line in text.splitlines():
        if FENCE_RE.match(line):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def readme_header(readme_path: Path) -> str:
    text = readme_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    end = min(120, len(lines))
    for i, line in enumerate(lines):
        if i > 0 and H1_RE.match(line) and line.startswith("## "):
            end = i
            break
    header = "\n".join(lines[:end])
    return strip_fences(header)


def substring_ok(needle: str, haystack: str, min_len: int = 12) -> bool:
    if not needle or not isinstance(needle, str):
        return True
    if needle in haystack:
        return True
    if len(needle) >= min_len:
        return needle[: min(len(needle), 40)] in haystack
    return False


def string_in_text(val: str, text: str) -> bool:
    if substring_ok(val, text):
        return True
    tokens = re.findall(r"[\w.+/-]+", val)
    sig = [t for t in tokens if len(t) >= 4]
    if not sig:
        return False
    matches = sum(1 for t in sig if t in text)
    return matches >= min(2, len(sig))


def check_one(case_dir: Path) -> list[str]:
    problems: list[str] = []
    meta_path = case_dir / "metadata.json"
    readme_path = case_dir / "README.md"
    if not meta_path.exists():
        return [f"{case_dir.name}: 缺少 metadata.json"]
    if not readme_path.exists():
        return [f"{case_dir.name}: 缺少 README.md"]

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    header = readme_header(readme_path)
    full_readme = strip_fences(readme_path.read_text(encoding="utf-8"))
    rel = f"cases/{case_dir.name}"

    for key in STRING_KEYS:
        val = meta.get(key)
        if val is None or not isinstance(val, str):
            continue
        target = header if key != "data_source" else full_readme
        if not string_in_text(val, target):
            problems.append(f"{rel}: metadata.{key!r} 未在 README {'头部' if key != 'data_source' else '全文'}出现")

    src = meta.get("_source")
    if isinstance(src, str) and src:
        if not string_in_text(src, full_readme):
            problems.append(f"{rel}: metadata._source 未在 README 中出现")

    for key, val in meta.items():
        if key.startswith("_"):
            continue
        if key in INT_EXCLUDE:
            continue
        if isinstance(val, int) and val >= INT_KEYS_MIN:
            if str(val) not in header:
                problems.append(
                    f"{rel}: metadata.{key}={val} 未在 README 头部元信息表中找到相同数字"
                )

    return problems


def main() -> int:
    parser = argparse.ArgumentParser(description="校验 case metadata ↔ README 同步")
    parser.add_argument(
        "--first-run",
        action="store_true",
        help="只输出 warning，退出码恒为 0（首跑摸底用）",
    )
    args = parser.parse_args()

    case_dirs = sorted(p for p in CASES.iterdir() if p.is_dir() and (p / "metadata.json").exists())
    all_problems: list[str] = []

    print("=== 案例 metadata ↔ README 同步校验 ===\n")
    for case_dir in case_dirs:
        probs = check_one(case_dir)
        if probs:
            all_problems.extend(probs)
            tag = "[warn]" if args.first_run else "[FAIL]"
            print(f"{tag} {case_dir.name}")
            for p in probs:
                print(f"       - {p}")
        else:
            print(f"[OK]   {case_dir.name}")

    print()
    if all_problems:
        if args.first_run:
            print(f"首跑模式：发现 {len(all_problems)} 处不同步（未阻塞，请修复后去掉 --first-run）")
            return 0
        print(f"校验失败：{len(all_problems)} 处违反。请同步 metadata.json 与 README.md 头部。")
        return 1
    print("校验通过：所有 case metadata 与 README 头部一致。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
