#!/usr/bin/env python3
"""case-to-framework.py — 用 mapping.json 把 case data 转成"框架视图"。

读 cases/<case>/mapping.json，按 field_map 把游戏原生字段重命名为
framework schema 字段，包到 wrapper_key 下，写到
cases/<case>/derived/framework-view/<data_file>。

这是**最佳努力**工具：逆向得到的 case data 往往缺少 framework 必填字段
（见 mapping 的 missing_in_native），生成的视图会带 `_incomplete` 标注列出
缺口，供人工补全后再用 validate-schemas.py 校验。

用法：
    python scripts/case-to-framework.py            # 处理全部 case
    python scripts/case-to-framework.py shelldiver # 只处理某个 case
    python scripts/case-to-framework.py --report   # 额外写 derived/missing-fields.md

退出码：0（生成成功，缺字段只警告，不算失败）。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
CASES = ROOT / "cases"


def load(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def get_path(obj, dotted: str):
    """按 'a.b.c' 取嵌套值；支持 '*' 通配合并所有子项的同名子集合。"""
    cur = obj
    for part in dotted.split("."):
        if part == "*":
            merged = []
            if isinstance(cur, dict):
                for v in cur.values():
                    if isinstance(v, list):
                        merged.extend(v)
                    elif isinstance(v, dict):
                        merged.append(v)
            cur = merged
            continue
        if isinstance(cur, list):
            out = []
            for item in cur:
                if isinstance(item, dict) and part in item:
                    val = item[part]
                    out.extend(val if isinstance(val, list) else [val])
            cur = out
        elif isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
        if cur is None:
            return None
    return cur


def apply_field_map(entity: dict, field_map: dict) -> dict:
    """简单键重命名；复杂表达式（含 [ . 等）原样保留 native 键并加注。"""
    out = {}
    for native_key, fw_key in field_map.items():
        if any(c in native_key for c in "[]. ") or any(c in fw_key for c in "[]. "):
            continue  # 复杂映射，交给人工
        if native_key in entity:
            out[fw_key] = entity[native_key]
    for k, v in entity.items():
        if k not in out:
            out.setdefault(k, v)
    return out


def process_case(case_dir: Path, report_entries: list[dict] | None = None) -> None:
    mapping_file = case_dir / "mapping.json"
    if not mapping_file.exists():
        print(f"  [skip] {case_dir.name}（无 mapping.json）")
        return
    mapping = load(mapping_file)
    out_dir = case_dir / "derived" / "framework-view"
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n=== {case_dir.name} ===")

    for m in mapping.get("mappings", []):
        data_file = m.get("data_file")
        src = case_dir / data_file
        if not src.exists():
            print(f"  [warn] {data_file} 不存在，跳过")
            continue
        if "schema" not in str(m.get("framework_schema", "")):
            print(f"  [skip] {data_file}（无对应 framework schema）")
            continue
        data = load(src)
        collections = m.get("native_collections", [])
        wrapper_key = m.get("wrapper_key", "items")
        field_map = m.get("field_map", {})
        missing = m.get("missing_in_native", {})

        entities = []
        for coll in collections:
            got = get_path(data, coll)
            if isinstance(got, list):
                entities.extend(e for e in got if isinstance(e, dict))
            elif isinstance(got, dict):
                entities.append(got)

        view_entities = [apply_field_map(e, field_map) for e in entities]
        incomplete = list(missing.keys())
        view = {
            "_generated_by": "scripts/case-to-framework.py",
            "_from": f"cases/{case_dir.name}/{data_file}",
            "_framework_schema": m.get("framework_schema"),
            "_incomplete": incomplete,
            wrapper_key: view_entities,
        }
        out_path = out_dir / data_file
        out_path.write_text(json.dumps(view, ensure_ascii=False, indent=2), encoding="utf-8")
        miss = f"（缺 {len(incomplete)} 必填字段需补全）" if incomplete else ""
        print(f"  [gen]  {data_file} -> derived/framework-view/{data_file}：{len(view_entities)} 实体{miss}")

        if report_entries is not None and incomplete:
            report_entries.append(
                {
                    "case": case_dir.name,
                    "data_file": data_file,
                    "framework_schema": m.get("framework_schema"),
                    "missing_fields": incomplete,
                    "missing_notes": missing,
                }
            )


def write_report(case_dir: Path, entries: list[dict]) -> None:
    case_entries = [e for e in entries if e["case"] == case_dir.name]
    if not case_entries:
        return
    lines = [
        f"# {case_dir.name} — framework 视图缺口报告",
        "",
        "> 由 `scripts/case-to-framework.py --report` 自动生成。",
        "> 带 `_incomplete` 的字段需人工补全后再跑 `validate-schemas.py`。",
        "",
    ]
    for e in case_entries:
        lines.append(f"## {e['data_file']}")
        lines.append("")
        lines.append(f"- **Schema**: `{e['framework_schema']}`")
        lines.append(f"- **缺字段数**: {len(e['missing_fields'])}")
        lines.append("")
        lines.append("| 字段 | 说明 |")
        lines.append("|------|------|")
        notes = e.get("missing_notes") or {}
        for field in e["missing_fields"]:
            note = notes.get(field, "—")
            lines.append(f"| `{field}` | {note} |")
        lines.append("")
    out = case_dir / "derived" / "missing-fields.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"  [report] -> derived/missing-fields.md（{len(case_entries)} 个 data_file 有缺口）")


def main() -> int:
    parser = argparse.ArgumentParser(description="case data → framework-view")
    parser.add_argument("cases", nargs="*", help="case 名（留空 = 全部有 mapping 的 case）")
    parser.add_argument(
        "--report",
        action="store_true",
        help="写缺口报告到 cases/<case>/derived/missing-fields.md",
    )
    args = parser.parse_args()

    if args.cases:
        case_dirs = [CASES / t for t in args.cases]
    else:
        case_dirs = sorted(p for p in CASES.iterdir() if p.is_dir() and (p / "mapping.json").exists())

    report_entries: list[dict] | None = [] if args.report else None

    for case_dir in case_dirs:
        if not case_dir.is_dir():
            print(f"  [warn] 无此 case 目录: {case_dir.name}")
            continue
        process_case(case_dir, report_entries)
        if args.report and report_entries is not None:
            write_report(case_dir, report_entries)

    print("\n完成（最佳努力生成；带 _incomplete 的视图需人工补全后再校验）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
