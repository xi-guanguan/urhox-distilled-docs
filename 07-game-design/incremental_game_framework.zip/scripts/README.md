# scripts · 一致性校验工具

保证框架文档 / Schema / 案例数据三者一致的自动化脚本。CI（[.github/workflows/ci.yml](../.github/workflows/ci.yml)）会跑全部 ✅ 门禁。

## 依赖

```bash
pip install -r scripts/requirements.txt   # 仅需 jsonschema
```

## 脚本一览

| 脚本 | 作用 | CI 门禁 |
|------|------|---------|
| [`validate-schemas.py`](validate-schemas.py) | 校验 schema 自身合法、`examples/configs/*.json` 通过对应 schema、`mapping.json` 结构合法、case data 顶层 dict 且无 `$schema`、每个 case 的 `metadata.json` 含 `_source` | ✅ |
| [`verify-changelog.py`](verify-changelog.py) | 把 CHANGELOG 的"同步声明"编码为不变量，防止"声明已改但文件没改"的伪同步回归 | ✅ |
| [`check-md-links.py`](check-md-links.py) | 扫描所有 `.md` 的内部相对链接，标记断链与对已删除文档的引用（跳过围栏代码块里的占位符） | ✅ |
| [`verify-case-metadata.py`](verify-case-metadata.py) | 校验 `cases/<case>/metadata.json` 与 case `README.md` 头部元信息同步 | ✅ |
| [`build-schema-index.py`](build-schema-index.py) | 维护 `schemas/README.md` 的 AUTO-GENERATED 索引段（`--check` 用于 CI） | ✅ |
| [`case-to-framework-coverage.py`](case-to-framework-coverage.py) | 覆盖度报告 (`derived/coverage-report.md`) + **Pattern reverse-link 审计** + 全库候选索引 (`docs/case-candidates.md`)；`--check` 时报告漂移或 reverse-link 缺失均失败 | ✅ |
| [`check-changelog-size.py`](check-changelog-size.py) | CHANGELOG 行数守门（soft 600 / hard 900）；超 hard 时 `--check` 失败，提示见 `CHANGELOG/archive/README.md` | ✅ |
| [`case-to-framework.py`](case-to-framework.py) | 用 `cases/<case>/mapping.json` 把游戏原生 case data 转成"框架视图"（`derived/framework-view/`），`--report` 写缺口报告 | ⛔（最佳努力工具，非门禁） |
| [`install-pre-commit.ps1`](install-pre-commit.ps1) / [`install-pre-commit.sh`](install-pre-commit.sh) | 安装 git pre-commit hook，提交前跑 `run-all-checks.ps1` | — |
| [`run-all-checks.ps1`](run-all-checks.ps1) | 本地一键跑全部门禁脚本 | — |

## 本地一键校验

```powershell
pwsh scripts/run-all-checks.ps1
```

或逐个：

```bash
python scripts/validate-schemas.py
python scripts/verify-changelog.py
python scripts/check-md-links.py
```

退出码 0 = 通过；非 0 = 有问题（终端会列出具体文件与原因）。

## 本地 pre-commit 集成

提交前自动跑与 CI 相同的门禁（见上方脚本一览中 ✅ 项）：

```powershell
# Windows
powershell -ExecutionPolicy Bypass -File scripts/install-pre-commit.ps1

# Unix / macOS / Git Bash
bash scripts/install-pre-commit.sh
```

安装后每次 `git commit` 会调用 [run-all-checks.ps1](run-all-checks.ps1)。跳过：`git commit --no-verify`。

卸载：删除 `.git/hooks/pre-commit`。

## Case → Framework 贡献工作流

跑完一个 case 后, 用 [`case-to-framework-coverage.py`](case-to-framework-coverage.py) 生成 framework 覆盖度报告, 决定是否反向沉淀到 framework (新 pattern / optional / schema / 反模式). 完整流程见 [`../docs/case-to-framework-contribute.md`](../docs/case-to-framework-contribute.md).

```bash
# 1. 生成 / 更新 case 覆盖度报告
python scripts/case-to-framework-coverage.py <case_name>

# 2. 读 cases/<case>/derived/coverage-report.md
#    - 🆕 数 ≥ 1 或 ⚠️ 数 ≥ 2: 必进入候选评估
#    - "框架映射过载" 段: 提示某些 framework 概念被过宽复用, 需新 pattern

# 3. (按 docs/case-to-framework-contribute.md) 写 candidates.md + 沉淀

# 4. CI 模式校验报告未漂移
python scripts/case-to-framework-coverage.py --check
```
