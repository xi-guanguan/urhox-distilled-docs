#!/usr/bin/env python3
"""check-changelog-size.py — CHANGELOG 体积守门 (P3).

根 CHANGELOG.md 超过 SOFT_LIMIT 行时打印警告; 超过 HARD_LIMIT 时退出 1 (CI 失败).

用法:
    python scripts/check-changelog-size.py          # 仅报告
    python scripts/check-changelog-size.py --check  # CI 模式 (超 HARD_LIMIT 失败)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent
CHANGELOG = ROOT / "CHANGELOG.md"
ARCHIVE_README = ROOT / "CHANGELOG" / "archive" / "README.md"

SOFT_LIMIT = 600
HARD_LIMIT = 900


def main() -> int:
    parser = argparse.ArgumentParser(description="CHANGELOG 行数守门")
    parser.add_argument("--check", action="store_true", help="超 HARD_LIMIT 时退出 1")
    args = parser.parse_args()

    if not CHANGELOG.exists():
        print("[FAIL] CHANGELOG.md 不存在")
        return 1

    lines = CHANGELOG.read_text(encoding="utf-8").count("\n") + 1
    print(f"CHANGELOG.md: {lines} 行 (soft={SOFT_LIMIT}, hard={HARD_LIMIT})")

    if lines >= HARD_LIMIT:
        print(f"[FAIL] 超过硬上限 {HARD_LIMIT} 行 — 请按 CHANGELOG/archive/README.md 归档")
        return 1 if args.check else 0

    if lines >= SOFT_LIMIT:
        print(f"[WARN] 超过软上限 {SOFT_LIMIT} 行 — 建议准备归档 (见 CHANGELOG/archive/README.md)")
        if ARCHIVE_README.exists():
            print(f"       策略: {ARCHIVE_README.relative_to(ROOT)}")
        return 0

    print("[OK]   CHANGELOG 体积健康")
    return 0


if __name__ == "__main__":
    sys.exit(main())
