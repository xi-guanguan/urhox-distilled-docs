# Install this repo as a local Cursor plugin (works on Windows without GitHub).
# Usage: pwsh scripts/install-cursor-plugin.ps1
#
# Prefer Customize → Add plugin → From folder (more reliable than junction).

$ErrorActionPreference = "Stop"

$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$LocalPlugins = Join-Path $env:USERPROFILE ".cursor\plugins\local"
$PluginName = "incremental-game-framework"
$Dest = Join-Path $LocalPlugins $PluginName
$PluginManifest = Join-Path $Dest ".cursor-plugin\plugin.json"
$MarketplaceManifest = Join-Path $Dest ".cursor-plugin\marketplace.json"

New-Item -ItemType Directory -Force -Path $LocalPlugins | Out-Null

if (Test-Path $Dest) {
    $item = Get-Item $Dest -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
        Remove-Item $Dest -Force
    } else {
        Write-Error "Already exists and is not a junction: $Dest`nRemove it manually and re-run."
    }
}

# Junction: Cursor may reject if target is outside plugins/local — use From folder if this fails.
cmd /c mklink /J "$Dest" "$RepoRoot" | Out-Null

if (-not (Test-Path $PluginManifest)) {
    Write-Error "Install failed: plugin.json not found at $PluginManifest"
}
if (-not (Test-Path $MarketplaceManifest)) {
    Write-Error "Install failed: marketplace.json not found at $MarketplaceManifest"
}

Write-Host "OK: Cursor local plugin installed"
Write-Host "  Source: $RepoRoot"
Write-Host "  Target: $Dest"
Write-Host "  Plugin: $PluginManifest"
Write-Host "  Marketplace: $MarketplaceManifest"
Write-Host ""
Write-Host "Next: Developer: Reload Window"
Write-Host "If skills appear under User instead of plugin group, use Customize -> From folder instead."
