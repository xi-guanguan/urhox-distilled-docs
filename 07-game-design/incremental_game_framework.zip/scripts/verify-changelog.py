#!/usr/bin/env python3
"""verify-changelog.py — CHANGELOG 闭环校验。

CHANGELOG.md 的"framework 文档同步清理"会声明"某文件来源已改为通用 / 删除某案例引用"。
历史上出现过"声明已改但文件没改"的伪同步（见审查报告 F-5）。

本脚本把这些声明编码为可执行不变量（invariant），每次跑校验它们是否仍成立，
防止回归。新增同步声明时，在 SYNC_INVARIANTS 里加一条。

退出码：0 = 全部成立；1 = 有违反。
"""
from __future__ import annotations
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent

# 每条：文件 / 描述 / must_contain（应包含的字样）/ must_not_contain（不应包含的字样）
# 对应 CHANGELOG.md "framework 文档同步清理" 的声明。
SYNC_INVARIANTS = [
    {
        "file": "patterns/pattern-e-status-stack.md",
        "desc": "Pattern E 来源应为'通用规律'，来源行不以 Tower Wizard 为唯一出处",
        "line_prefix_check": {
            # 来源行（以 '> **来源**' 开头）必须包含'通用'，且不得包含 'Tower Wizard'
            "prefix": "> **来源**",
            "must_contain": ["通用"],
            "must_not_contain": ["Tower Wizard"],
        },
    },
    {
        "file": "examples/configs/example-status-effect.json",
        "desc": "example-status-effect.json _source 应改为'理论沉淀'，全文不得残留 'Tower Wizard'",
        "must_contain": ["理论沉淀"],
        "must_not_contain": ["Tower Wizard"],
    },
    {
        "file": "examples/configs/example-multi-region.json",
        "desc": "example-multi-region.json _source 应改为'理论沉淀'，全文不得残留 'Tower Wizard'",
        "must_contain": ["理论沉淀"],
        "must_not_contain": ["Tower Wizard"],
    },
]


def check_one(inv: dict) -> list[str]:
    problems: list[str] = []
    path = ROOT / inv["file"]
    if not path.exists():
        return [f"文件不存在: {inv['file']}"]
    text = path.read_text(encoding="utf-8")

    for token in inv.get("must_contain", []):
        if token not in text:
            problems.append(f"缺少应有字样 {token!r}")
    for token in inv.get("must_not_contain", []):
        if token in text:
            problems.append(f"残留不应有字样 {token!r}")

    lpc = inv.get("line_prefix_check")
    if lpc:
        lines = [ln for ln in text.splitlines() if ln.strip().startswith(lpc["prefix"])]
        if not lines:
            problems.append(f"找不到以 {lpc['prefix']!r} 开头的行")
        else:
            line = lines[0]
            for token in lpc.get("must_contain", []):
                if token not in line:
                    problems.append(f"来源行缺少 {token!r}: {line.strip()}")
            for token in lpc.get("must_not_contain", []):
                if token in line:
                    problems.append(f"来源行残留 {token!r}: {line.strip()}")
    return problems


def main() -> int:
    total_problems = 0
    print("=== CHANGELOG 同步不变量校验 ===\n")
    for inv in SYNC_INVARIANTS:
        problems = check_one(inv)
        if problems:
            total_problems += len(problems)
            print(f"[FAIL] {inv['file']}")
            print(f"       {inv['desc']}")
            for p in problems:
                print(f"       - {p}")
        else:
            print(f"[OK]   {inv['file']}")
    print()
    if total_problems:
        print(f"校验失败：{total_problems} 处违反。请同步文件或更新 CHANGELOG 声明。")
        return 1
    print("校验通过：所有 CHANGELOG 同步声明均已落实。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
