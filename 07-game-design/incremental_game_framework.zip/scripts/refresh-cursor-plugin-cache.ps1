# Clear stale Cursor plugin cache and re-pin to current repo HEAD.
# Usage: pwsh scripts/refresh-cursor-plugin-cache.ps1

$ErrorActionPreference = "Stop"

$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Head = (git -C $RepoRoot rev-parse --short HEAD)

Write-Host "Repo: $RepoRoot"
Write-Host "HEAD: $Head"
Write-Host ""

$paths = @(
    Join-Path $env:USERPROFILE ".cursor\plugins\cache\incremental-game-framework"
    Join-Path $env:USERPROFILE ".cursor\plugins\marketplaces\_\d_\projects"
    Join-Path $env:USERPROFILE ".cursor\plugins\local\incremental-game-framework"
)

foreach ($p in $paths) {
    if (Test-Path $p) {
        Remove-Item -Recurse -Force $p
        Write-Host "Removed: $p"
    } else {
        Write-Host "Skip (missing): $p"
    }
}

Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Cursor -> Customize -> remove incremental-game-framework plugin (if listed)"
Write-Host "  2. Developer: Reload Window"
Write-Host "  3. Customize -> Add plugin -> From folder -> $RepoRoot"
Write-Host "  4. Reload again"
Write-Host ""
Write-Host "Expected after refresh:"
Write-Host "  - Skills: Incremental Game Framework group with 12 skills"
Write-Host "  - Subagents: 0 from this plugin (Superpowers-style)"
Write-Host "  - plugin.json must NOT contain agents (current HEAD $Head)"
