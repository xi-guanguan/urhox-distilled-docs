#!/usr/bin/env python3
"""check-md-links.py — Markdown 内部链接校验。

扫描所有 .md 的相对链接（[text](path)），校验目标文件存在。
- 跳过围栏代码块（``` ... ```）中的内容（那里常是模板占位符）
- 跳过 http(s) / mailto / 纯锚点（#xxx）链接
- 链接里的 #anchor 后缀会被剥离再检查文件是否存在
- 特别标记对已删除文档（如 core/01-game-loop.md）的引用

退出码：0 = 无断链；1 = 有断链。
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except Exception:
    pass

ROOT = Path(__file__).resolve().parent.parent

LINK_RE = re.compile(r"\[([^\]]*)\]\(([^)]+)\)")
FENCE_RE = re.compile(r"^\s*```")

# 已知已删除/不存在文档：引用即报错
FORBIDDEN_TARGETS = ["core/01-game-loop.md"]

problems: list[str] = []
n_links = 0


def iter_links(text: str):
    """产出 (line_no, link_target)，跳过围栏代码块。"""
    in_fence = False
    for i, line in enumerate(text.splitlines(), 1):
        if FENCE_RE.match(line):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        for m in LINK_RE.finditer(line):
            yield i, m.group(2).strip()


def main() -> int:
    global n_links
    md_files = sorted(ROOT.rglob("*.md"))
    md_files = [p for p in md_files if ".git" not in p.parts and "node_modules" not in p.parts]

    # 匹配 ## [vx.y.z] 或 ## [Unreleased] 这种"版本段"标题
    VERSION_HEADER_RE = re.compile(r"^##\s+\[[^\]]+\]")

    for md in md_files:
        rel = md.relative_to(ROOT)
        text = md.read_text(encoding="utf-8")
        is_changelog = rel.name == "CHANGELOG.md" or (
            len(rel.parts) >= 2 and rel.parts[0] == "CHANGELOG"
        )
        # CHANGELOG（含 archive/）是时间倒序历史档案，历史段里被重构过的旧路径
        # 引用不应该被 link checker 当作断链（改了会污染历史真实性）。
        # 约定：CHANGELOG 树内所有断链一律降级为 info（不计入 problems）。
        version_sections_seen = 0

        in_fence = False
        for line_no, line in enumerate(text.splitlines(), 1):
            if FENCE_RE.match(line):
                in_fence = not in_fence
                continue
            if in_fence:
                continue
            if is_changelog and VERSION_HEADER_RE.match(line):
                version_sections_seen += 1
                continue
            in_current_section = (version_sections_seen <= 1)
            for m in LINK_RE.finditer(line):
                target = m.group(2).strip()
                if target.startswith(("http://", "https://", "mailto:", "#")):
                    continue
                if "<" in target or ">" in target:
                    continue
                n_links += 1
                path_part = target.split("#", 1)[0]
                if not path_part:
                    continue
                for forbidden in FORBIDDEN_TARGETS:
                    if path_part.endswith(forbidden) and in_current_section:
                        problems.append(f"{rel}:{line_no} 引用已删除文档: {target}")
                resolved = (md.parent / path_part).resolve()
                if not resolved.exists():
                    if is_changelog:
                        print(f"  [info] {rel}:{line_no} CHANGELOG 历史/被重构路径（保留，不计入）: {target}")
                    else:
                        problems.append(f"{rel}:{line_no} 断链: {target}")

    print(f"扫描 {len(md_files)} 个 .md，检查 {n_links} 条内部链接\n")
    if problems:
        print(f"发现 {len(problems)} 处断链 / 失效引用：")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("所有内部链接有效")
    return 0


if __name__ == "__main__":
    sys.exit(main())
