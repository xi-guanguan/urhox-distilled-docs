<#
.SYNOPSIS
    Install a git pre-commit hook that runs framework consistency checks.
.DESCRIPTION
    Writes .git/hooks/pre-commit to invoke scripts/run-all-checks.ps1 before each commit.
    Run from repo root or any subdirectory.
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File scripts/install-pre-commit.ps1
#>

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$hooksDir = Join-Path $repoRoot ".git" "hooks"
$hookPath = Join-Path $hooksDir "pre-commit"

if (-not (Test-Path (Join-Path $repoRoot ".git"))) {
    Write-Error "Not a git repository: $repoRoot"
    exit 1
}

if (-not (Test-Path $hooksDir)) {
    New-Item -ItemType Directory -Path $hooksDir -Force | Out-Null
}

$hookContent = @'
#!/bin/sh
# incremental_game_framework pre-commit — run consistency checks before commit.
# Installed by scripts/install-pre-commit.ps1 or scripts/install-pre-commit.sh

REPO_ROOT="$(git rev-parse --show-toplevel)"
cd "$REPO_ROOT" || exit 1

if command -v pwsh >/dev/null 2>&1; then
    pwsh -NoProfile -ExecutionPolicy Bypass -File "$REPO_ROOT/scripts/run-all-checks.ps1"
elif command -v powershell >/dev/null 2>&1; then
    powershell -NoProfile -ExecutionPolicy Bypass -File "$REPO_ROOT/scripts/run-all-checks.ps1"
else
    echo "pre-commit: need pwsh or powershell to run scripts/run-all-checks.ps1" >&2
    exit 1
fi

if [ $? -ne 0 ]; then
    echo "pre-commit: consistency checks failed. Fix issues or skip with git commit --no-verify" >&2
    exit 1
fi
'@

Set-Content -Path $hookPath -Value $hookContent -Encoding utf8NoBOM -NoNewline
Add-Content -Path $hookPath -Value "`n" -NoNewline

Write-Host "Installed pre-commit hook: $hookPath" -ForegroundColor Green
Write-Host "Each commit will run scripts/run-all-checks.ps1 (use --no-verify to skip)."
